const PresaGeneration = () => {
  return <div>Presentation Generation Page</div>;
};

export default PresaGeneration;

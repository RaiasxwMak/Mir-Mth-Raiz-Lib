import { createBrowserRouter } from "react-router-dom";
import HomePage from "@/pages/HomePage";
import PresaGeneration from "@/pages/PresaGeneration";

const router = createBrowserRouter([
  {
    path: "/",
    element: <HomePage />,
  },
  {
    path: "/presageneration",
    element: <PresaGeneration />,
  },
]);

export { router };

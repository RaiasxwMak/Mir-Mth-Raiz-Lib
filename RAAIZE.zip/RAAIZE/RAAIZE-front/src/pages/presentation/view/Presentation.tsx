import { FC } from 'react';
import { PresentationStudio } from '@src/widgets/presentationStudio';

export const Presentation: FC = () => {
  return <PresentationStudio />;
};

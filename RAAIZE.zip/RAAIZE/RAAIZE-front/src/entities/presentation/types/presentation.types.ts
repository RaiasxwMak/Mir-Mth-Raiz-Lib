export interface SlideElement {
  id: string;
  type: 'text' | 'image' | 'video' | 'chart' | 'list';
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  style: {
    fontSize?: number;
    fontFamily?: string;
    color?: string;
    backgroundColor?: string;
    border?: string;
    borderRadius?: number;
    padding?: number;
    textAlign?: 'left' | 'center' | 'right';
    fontWeight?:
      | 'normal'
      | 'bold'
      | '100'
      | '200'
      | '300'
      | '400'
      | '500'
      | '600'
      | '700'
      | '800'
      | '900';
    fontStyle?: 'normal' | 'italic' | 'oblique';
    textDecoration?: string;
  };
  content: {
    text?: string;
    imageUrl?: string;
    videoUrl?: string;
    listItems?: string[];
    chartData?: Record<string, unknown>;
  };
}

export interface Slide {
  id: string;
  title: string;
  elements: SlideElement[];
  backgroundStyle: {
    color?: string;
    gradient?: string;
    imageUrl?: string;
    opacity?: number;
  };
  transition: 'fade' | 'slide' | 'zoom' | 'none';
  notes?: string;
}

export interface PresentationTheme {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  fonts: {
    heading: string;
    body: string;
  };
  styles: {
    slideBackground: string;
    titleStyle: React.CSSProperties;
    textStyle: React.CSSProperties;
  };
}

export interface Presentation {
  id: string;
  title: string;
  description?: string;
  author?: string;
  createdAt: Date;
  updatedAt: Date;
  slides: Slide[];
  theme: PresentationTheme;
  settings: {
    aspectRatio: '16:9' | '4:3' | '1:1';
    autoAdvance: boolean;
    autoAdvanceDelay?: number;
    showSlideNumbers: boolean;
    showNotes: boolean;
  };
}

export interface PresentationTemplate {
  id: string;
  name: string;
  description: string;
  category: 'business' | 'education' | 'creative' | 'minimal' | 'modern';
  thumbnail: string;
  slides: Omit<Slide, 'id'>[];
  theme: PresentationTheme;
}

export interface AIGenerationRequest {
  topic: string;
  slideCount?: number;
  style?: 'professional' | 'creative' | 'minimal' | 'academic';
  includeImages?: boolean;
  language?: string;
}

export interface AIGenerationResponse {
  slides: {
    title: string;
    content: string[];
    imagePrompt?: string;
    notes?: string;
  }[];
  theme: Partial<PresentationTheme>;
}

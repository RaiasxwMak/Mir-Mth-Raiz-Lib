import { useMutation } from '@tanstack/react-query';
import { AIService } from './aiService';
import {
  AIGenerationRequest,
  Presentation,
  Slide,
  SlideElement,
} from '../types';
import { usePresentationStore } from '../model';

const generateId = () =>
  `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

const defaultTheme = {
  id: 'default',
  name: 'Default',
  colors: {
    primary: '#4F46E5',
    secondary: '#7C3AED',
    accent: '#F59E0B',
    background: '#FFFFFF',
    text: '#1F2937',
  },
  fonts: {
    heading: 'Inter, sans-serif',
    body: 'Inter, sans-serif',
  },
  styles: {
    slideBackground: '#FFFFFF',
    titleStyle: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: '#1F2937',
      marginBottom: '1rem',
    } as const,
    textStyle: {
      fontSize: '1rem',
      lineHeight: '1.6',
      color: '#4B5563',
    } as const,
  },
};

export const useAIGeneration = () => {
  const { setLoading, setError } = usePresentationStore();

  const generatePresentationMutation = useMutation({
    mutationFn: async (request: AIGenerationRequest) => {
      setLoading(true);
      setError(null);

      try {
        const aiResponse = await AIService.generatePresentationStructure(
          request,
        );

        // Конвертируем AI ответ в нашу структуру слайдов
        const slides: Slide[] = aiResponse.slides.map((aiSlide) => {
          const elements: SlideElement[] = [];

          // Добавляем заголовок
          elements.push({
            id: generateId(),
            type: 'text',
            position: { x: 50, y: 50, width: 700, height: 80 },
            style: {
              fontSize: 36,
              fontWeight: 'bold',
              color: aiResponse.theme?.colors?.text || '#1F2937',
              textAlign: 'center',
            },
            content: { text: aiSlide.title },
          });

          // Добавляем контент как список или текст
          if (aiSlide.content.length > 0) {
            const isListFormat = aiSlide.content.length > 1;

            if (isListFormat) {
              elements.push({
                id: generateId(),
                type: 'list',
                position: { x: 100, y: 150, width: 600, height: 300 },
                style: {
                  fontSize: 18,
                  color: aiResponse.theme?.colors?.text || '#4B5563',
                  textAlign: 'left',
                },
                content: { listItems: aiSlide.content },
              });
            } else {
              elements.push({
                id: generateId(),
                type: 'text',
                position: { x: 100, y: 150, width: 600, height: 200 },
                style: {
                  fontSize: 18,
                  color: aiResponse.theme?.colors?.text || '#4B5563',
                  textAlign: 'left',
                },
                content: { text: aiSlide.content[0] },
              });
            }
          }

          // Добавляем заметки, если есть
          if (aiSlide.notes) {
            // Заметки можно добавить как скрытый элемент или в специальное поле
          }

          return {
            id: generateId(),
            title: aiSlide.title,
            elements,
            backgroundStyle: {
              color: aiResponse.theme?.colors?.background || '#FFFFFF',
            },
            transition: 'fade' as const,
            notes: aiSlide.notes,
          };
        });

        // Создаем новую презентацию
        const newPresentation: Presentation = {
          id: generateId(),
          title: request.topic,
          description: `Презентация создана с помощью AI на тему: ${request.topic}`,
          author: 'AI Генератор',
          createdAt: new Date(),
          updatedAt: new Date(),
          slides,
          theme: aiResponse.theme?.colors
            ? {
                ...defaultTheme,
                id: generateId(),
                name: aiResponse.theme.name || 'AI Generated',
                colors: {
                  ...defaultTheme.colors,
                  ...aiResponse.theme.colors,
                },
              }
            : defaultTheme,
          settings: {
            aspectRatio: '16:9',
            autoAdvance: false,
            showSlideNumbers: true,
            showNotes: Boolean(aiResponse.slides.some((s) => s.notes)),
          },
        };

        return newPresentation;
      } catch (error) {
        const errorMessage =
          error instanceof Error
            ? error.message
            : 'Неизвестная ошибка при генерации презентации';
        setError(errorMessage);
        throw error;
      } finally {
        setLoading(false);
      }
    },
    onSuccess: (newPresentation) => {
      // Обновляем store с новой презентацией
      usePresentationStore.getState().loadPresentation(newPresentation);

      // Добавляем в список презентаций
      usePresentationStore.setState((state) => ({
        presentations: [...state.presentations, newPresentation],
        currentSlideIndex: 0,
        isEditing: true,
      }));
    },
    onError: (error) => {
      console.error('Ошибка генерации презентации:', error);
    },
  });

  const generateSlideContentMutation = useMutation({
    mutationFn: async ({
      topic,
      slideTitle,
    }: {
      topic: string;
      slideTitle: string;
    }) => {
      return await AIService.generateSlideContent(topic, slideTitle);
    },
  });

  const improveContentMutation = useMutation({
    mutationFn: async ({
      content,
      improvements,
    }: {
      content: string;
      improvements: string;
    }) => {
      return await AIService.improveSlideContent(content, improvements);
    },
  });

  const generateImagePromptMutation = useMutation({
    mutationFn: async ({
      title,
      content,
    }: {
      title: string;
      content: string[];
    }) => {
      return await AIService.generateImagePrompt(title, content);
    },
  });

  return {
    // Мутации
    generatePresentation: generatePresentationMutation.mutateAsync,
    generateSlideContent: generateSlideContentMutation.mutateAsync,
    improveContent: improveContentMutation.mutateAsync,
    generateImagePrompt: generateImagePromptMutation.mutateAsync,

    // Состояния загрузки
    isGeneratingPresentation: generatePresentationMutation.isPending,
    isGeneratingContent: generateSlideContentMutation.isPending,
    isImprovingContent: improveContentMutation.isPending,
    isGeneratingImagePrompt: generateImagePromptMutation.isPending,

    // Ошибки
    generationError: generatePresentationMutation.error,
    contentError: generateSlideContentMutation.error,
    improvementError: improveContentMutation.error,
    imagePromptError: generateImagePromptMutation.error,
  };
};

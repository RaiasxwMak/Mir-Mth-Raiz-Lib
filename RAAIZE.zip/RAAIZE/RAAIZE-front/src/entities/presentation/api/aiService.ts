import axios from 'axios';
import { AIGenerationRequest, AIGenerationResponse } from '../types';

const OPENROUTER_API_KEY =
  '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';
const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1/chat/completions';

interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OpenAIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export class AIService {
  private static async makeOpenAIRequest(
    messages: OpenAIMessage[],
  ): Promise<string> {
    try {
      const response = await axios.post<OpenAIResponse>(
        OPENROUTER_BASE_URL,
        {
          model: 'openai/gpt-4o-mini',
          messages,
          temperature: 0.7,
          max_tokens: 4000,
        },
        {
          headers: {
            Authorization: `Bearer ${OPENROUTER_API_KEY}`,
            'Content-Type': 'application/json',
          },
        },
      );

      return response.data.choices[0]?.message?.content || '';
    } catch (error) {
      console.error('Ошибка запроса к OpenAI:', error);
      throw new Error('Не удалось сгенерировать контент с помощью AI');
    }
  }

  static async generatePresentationStructure(
    request: AIGenerationRequest,
  ): Promise<AIGenerationResponse> {
    const systemPrompt = `Ты профессиональный помощник для создания презентаций. Твоя задача - создать структуру презентации на основе заданной темы.

Требования к ответу:
1. Верни ТОЛЬКО валидный JSON без дополнительного текста
2. Создай ${request.slideCount || 5} слайдов
3. Стиль презентации: ${request.style || 'professional'}
4. Язык: ${request.language || 'русский'}

Формат JSON ответа:
{
  "slides": [
    {
      "title": "Заголовок слайда",
      "content": ["Пункт 1", "Пункт 2", "Пункт 3"],
      "imagePrompt": "Описание для поиска изображения (если нужно)",
      "notes": "Заметки спикера (необязательно)"
    }
  ],
  "theme": {
    "name": "Название темы",
    "colors": {
      "primary": "#hex",
      "secondary": "#hex", 
      "accent": "#hex",
      "background": "#hex",
      "text": "#hex"
    }
  }
}

Создай качественную презентацию с логичной структурой: введение, основное содержание, заключение.`;

    const userPrompt = `Создай презентацию на тему: "${request.topic}"

Дополнительные требования:
- Количество слайдов: ${request.slideCount || 5}
- Стиль: ${request.style || 'professional'}
- ${
      request.includeImages
        ? 'Включи предложения для изображений'
        : 'Без изображений'
    }
- Язык: ${request.language || 'русский'}

Создай интересную и информативную презентацию с четкой структурой.`;

    const messages: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ];

    const response = await this.makeOpenAIRequest(messages);

    try {
      // Пытаемся извлечь JSON из ответа
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('JSON не найден в ответе');
      }

      const parsedResponse = JSON.parse(jsonMatch[0]) as AIGenerationResponse;

      // Валидация структуры ответа
      if (!parsedResponse.slides || !Array.isArray(parsedResponse.slides)) {
        throw new Error('Неверная структура ответа: отсутствуют слайды');
      }

      return parsedResponse;
    } catch (error) {
      console.error('Ошибка парсинга ответа AI:', error, response);

      // Возвращаем fallback структуру
      return this.createFallbackPresentation(request);
    }
  }

  static async generateSlideContent(
    topic: string,
    slideTitle: string,
  ): Promise<string[]> {
    const systemPrompt = `Ты помощник для создания контента слайдов презентации. 
Создай 3-5 ключевых пунктов для слайда с заданным заголовком.
Отвечай только списком пунктов, каждый с новой строки, начиная с "- ".`;

    const userPrompt = `Тема презентации: "${topic}"
Заголовок слайда: "${slideTitle}"

Создай содержательные пункты для этого слайда.`;

    const messages: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ];

    const response = await this.makeOpenAIRequest(messages);

    // Парсим ответ в массив строк
    return response
      .split('\n')
      .filter((line) => line.trim().startsWith('-'))
      .map((line) => line.trim().substring(1).trim())
      .filter((line) => line.length > 0);
  }

  static async improveSlideContent(
    currentContent: string,
    improvements: string,
  ): Promise<string> {
    const systemPrompt = `Ты редактор презентаций. Улучши предоставленный контент слайда согласно пожеланиям пользователя.
Верни только улучшенный текст без дополнительных комментариев.`;

    const userPrompt = `Текущий контент: "${currentContent}"
Пожелания по улучшению: "${improvements}"

Улучши контент согласно пожеланиям.`;

    const messages: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ];

    return await this.makeOpenAIRequest(messages);
  }

  static async generateImagePrompt(
    slideTitle: string,
    slideContent: string[],
  ): Promise<string> {
    const systemPrompt = `Создай описание для поиска подходящего изображения для слайда презентации.
Описание должно быть на английском языке, кратким и точным.
Отвечай только описанием изображения без дополнительного текста.`;

    const userPrompt = `Заголовок слайда: "${slideTitle}"
Содержание: ${slideContent.join(', ')}

Создай описание для поиска подходящего изображения.`;

    const messages: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ];

    return await this.makeOpenAIRequest(messages);
  }

  private static createFallbackPresentation(
    request: AIGenerationRequest,
  ): AIGenerationResponse {
    const slideCount = request.slideCount || 5;
    const slides = [];

    // Создаем базовую структуру слайдов
    slides.push({
      title: `Введение в ${request.topic}`,
      content: [
        'Добро пожаловать на презентацию',
        'Обзор ключевых тем',
        'Цели и задачи',
      ],
      imagePrompt: request.includeImages
        ? `introduction to ${request.topic}`
        : undefined,
    });

    for (let i = 2; i < slideCount; i++) {
      slides.push({
        title: `${request.topic} - Часть ${i - 1}`,
        content: [
          'Основная информация',
          'Ключевые моменты',
          'Детали и примеры',
        ],
      });
    }

    slides.push({
      title: 'Заключение',
      content: ['Резюме основных пунктов', 'Выводы', 'Вопросы и ответы'],
    });

    return {
      slides: slides.slice(0, slideCount),
      theme: {
        name: 'Professional',
        colors: {
          primary: '#4F46E5',
          secondary: '#7C3AED',
          accent: '#F59E0B',
          background: '#FFFFFF',
          text: '#1F2937',
        },
      },
    };
  }
}

import { create } from 'zustand';
import {
  Presentation,
  Slide,
  SlideElement,
  PresentationTheme,
  AIGenerationRequest,
} from '../types';

interface PresentationStore {
  // Основные данные
  currentPresentation: Presentation | null;
  presentations: Presentation[];
  currentSlideIndex: number;
  isLoading: boolean;
  error: string | null;

  // Режимы
  isEditing: boolean;
  selectedElementId: string | null;
  isGenerating: boolean;

  // Действия с презентацией
  createPresentation: (title: string, theme?: PresentationTheme) => void;
  loadPresentation: (presentation: Presentation) => void;
  savePresentation: () => void;
  deletePresentation: (id: string) => void;
  updatePresentationTitle: (title: string) => void;
  updatePresentationTheme: (theme: PresentationTheme) => void;

  // Действия со слайдами
  addSlide: (slide?: Partial<Slide>) => void;
  deleteSlide: (slideId: string) => void;
  duplicateSlide: (slideId: string) => void;
  moveSlide: (fromIndex: number, toIndex: number) => void;
  setCurrentSlide: (index: number) => void;
  updateSlide: (slideId: string, updates: Partial<Slide>) => void;

  // Действия с элементами слайдов
  addElement: (slideId: string, element: Omit<SlideElement, 'id'>) => void;
  updateElement: (
    slideId: string,
    elementId: string,
    updates: Partial<SlideElement>,
  ) => void;
  deleteElement: (slideId: string, elementId: string) => void;
  selectElement: (elementId: string | null) => void;

  // AI генерация
  generateFromPrompt: (request: AIGenerationRequest) => Promise<void>;

  // Утилиты
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setEditing: (editing: boolean) => void;
  clearAll: () => void;
}

const defaultTheme: PresentationTheme = {
  id: 'default',
  name: 'Default',
  colors: {
    primary: '#4F46E5',
    secondary: '#7C3AED',
    accent: '#F59E0B',
    background: '#FFFFFF',
    text: '#1F2937',
  },
  fonts: {
    heading: 'Inter, sans-serif',
    body: 'Inter, sans-serif',
  },
  styles: {
    slideBackground: '#FFFFFF',
    titleStyle: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: '#1F2937',
      marginBottom: '1rem',
    },
    textStyle: {
      fontSize: '1rem',
      lineHeight: '1.6',
      color: '#4B5563',
    },
  },
};

const generateId = () =>
  `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

const createEmptySlide = (): Slide => ({
  id: generateId(),
  title: 'Новый слайд',
  elements: [],
  backgroundStyle: {
    color: '#FFFFFF',
  },
  transition: 'fade',
});

export const usePresentationStore = create<PresentationStore>((set, get) => ({
  // Инициализация состояния
  currentPresentation: null,
  presentations: [],
  currentSlideIndex: 0,
  isLoading: false,
  error: null,
  isEditing: false,
  selectedElementId: null,
  isGenerating: false,

  // Действия с презентацией
  createPresentation: (title: string, theme = defaultTheme) => {
    const newPresentation: Presentation = {
      id: generateId(),
      title,
      author: 'Пользователь',
      createdAt: new Date(),
      updatedAt: new Date(),
      slides: [createEmptySlide()],
      theme,
      settings: {
        aspectRatio: '16:9',
        autoAdvance: false,
        showSlideNumbers: true,
        showNotes: false,
      },
    };

    set((state) => ({
      currentPresentation: newPresentation,
      presentations: [...state.presentations, newPresentation],
      currentSlideIndex: 0,
      isEditing: true,
    }));
  },

  loadPresentation: (presentation: Presentation) => {
    set({
      currentPresentation: presentation,
      currentSlideIndex: 0,
      isEditing: false,
      selectedElementId: null,
    });
  },

  savePresentation: () => {
    const { currentPresentation } = get();
    if (!currentPresentation) return;

    const updatedPresentation = {
      ...currentPresentation,
      updatedAt: new Date(),
    };

    set((state) => ({
      currentPresentation: updatedPresentation,
      presentations: state.presentations.map((p) =>
        p.id === updatedPresentation.id ? updatedPresentation : p,
      ),
    }));
  },

  deletePresentation: (id: string) => {
    set((state) => {
      const newPresentations = state.presentations.filter((p) => p.id !== id);
      const currentIsDeleted = state.currentPresentation?.id === id;

      return {
        presentations: newPresentations,
        currentPresentation: currentIsDeleted
          ? null
          : state.currentPresentation,
        currentSlideIndex: currentIsDeleted ? 0 : state.currentSlideIndex,
      };
    });
  },

  updatePresentationTitle: (title: string) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      return {
        currentPresentation: {
          ...state.currentPresentation,
          title,
          updatedAt: new Date(),
        },
      };
    });
  },

  updatePresentationTheme: (theme: PresentationTheme) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      return {
        currentPresentation: {
          ...state.currentPresentation,
          theme,
          updatedAt: new Date(),
        },
      };
    });
  },

  // Действия со слайдами
  addSlide: (slideData?: Partial<Slide>) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      const newSlide: Slide = {
        ...createEmptySlide(),
        ...slideData,
        id: generateId(),
      };

      const newSlides = [...state.currentPresentation.slides];
      newSlides.splice(state.currentSlideIndex + 1, 0, newSlide);

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: newSlides,
          updatedAt: new Date(),
        },
        currentSlideIndex: state.currentSlideIndex + 1,
      };
    });
  },

  deleteSlide: (slideId: string) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      const slideIndex = state.currentPresentation.slides.findIndex(
        (s) => s.id === slideId,
      );
      if (slideIndex === -1) return state;

      const newSlides = state.currentPresentation.slides.filter(
        (s) => s.id !== slideId,
      );
      if (newSlides.length === 0) {
        newSlides.push(createEmptySlide());
      }

      const newCurrentIndex = Math.min(
        state.currentSlideIndex,
        newSlides.length - 1,
      );

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: newSlides,
          updatedAt: new Date(),
        },
        currentSlideIndex: newCurrentIndex,
      };
    });
  },

  duplicateSlide: (slideId: string) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      const slideIndex = state.currentPresentation.slides.findIndex(
        (s) => s.id === slideId,
      );
      if (slideIndex === -1) return state;

      const originalSlide = state.currentPresentation.slides[slideIndex];
      const duplicatedSlide: Slide = {
        ...originalSlide,
        id: generateId(),
        title: `${originalSlide.title} (копия)`,
        elements: originalSlide.elements.map((el) => ({
          ...el,
          id: generateId(),
        })),
      };

      const newSlides = [...state.currentPresentation.slides];
      newSlides.splice(slideIndex + 1, 0, duplicatedSlide);

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: newSlides,
          updatedAt: new Date(),
        },
      };
    });
  },

  moveSlide: (fromIndex: number, toIndex: number) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      const newSlides = [...state.currentPresentation.slides];
      const [movedSlide] = newSlides.splice(fromIndex, 1);
      newSlides.splice(toIndex, 0, movedSlide);

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: newSlides,
          updatedAt: new Date(),
        },
        currentSlideIndex: toIndex,
      };
    });
  },

  setCurrentSlide: (index: number) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      const maxIndex = state.currentPresentation.slides.length - 1;
      const newIndex = Math.max(0, Math.min(index, maxIndex));

      return {
        currentSlideIndex: newIndex,
        selectedElementId: null,
      };
    });
  },

  updateSlide: (slideId: string, updates: Partial<Slide>) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: state.currentPresentation.slides.map((slide) =>
            slide.id === slideId ? { ...slide, ...updates } : slide,
          ),
          updatedAt: new Date(),
        },
      };
    });
  },

  // Действия с элементами слайдов
  addElement: (slideId: string, elementData: Omit<SlideElement, 'id'>) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      const newElement: SlideElement = {
        ...elementData,
        id: generateId(),
      };

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: state.currentPresentation.slides.map((slide) =>
            slide.id === slideId
              ? { ...slide, elements: [...slide.elements, newElement] }
              : slide,
          ),
          updatedAt: new Date(),
        },
      };
    });
  },

  updateElement: (
    slideId: string,
    elementId: string,
    updates: Partial<SlideElement>,
  ) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: state.currentPresentation.slides.map((slide) =>
            slide.id === slideId
              ? {
                  ...slide,
                  elements: slide.elements.map((element) =>
                    element.id === elementId
                      ? { ...element, ...updates }
                      : element,
                  ),
                }
              : slide,
          ),
          updatedAt: new Date(),
        },
      };
    });
  },

  deleteElement: (slideId: string, elementId: string) => {
    set((state) => {
      if (!state.currentPresentation) return state;

      return {
        currentPresentation: {
          ...state.currentPresentation,
          slides: state.currentPresentation.slides.map((slide) =>
            slide.id === slideId
              ? {
                  ...slide,
                  elements: slide.elements.filter(
                    (element) => element.id !== elementId,
                  ),
                }
              : slide,
          ),
          updatedAt: new Date(),
        },
        selectedElementId:
          state.selectedElementId === elementId
            ? null
            : state.selectedElementId,
      };
    });
  },

  selectElement: (elementId: string | null) => {
    set({ selectedElementId: elementId });
  },

  // AI генерация
  generateFromPrompt: async (request: AIGenerationRequest) => {
    set({ isGenerating: true, error: null });

    try {
      // Здесь будет логика генерации через AI API
      // Пока создаем заглушку
      const mockSlides: Slide[] = [
        {
          id: generateId(),
          title: `Введение в ${request.topic}`,
          elements: [
            {
              id: generateId(),
              type: 'text',
              position: { x: 50, y: 100, width: 600, height: 200 },
              style: { fontSize: 48, fontWeight: 'bold', textAlign: 'center' },
              content: { text: `Введение в ${request.topic}` },
            },
          ],
          backgroundStyle: { color: '#FFFFFF' },
          transition: 'fade',
        },
      ];

      const newPresentation: Presentation = {
        id: generateId(),
        title: request.topic,
        author: 'AI Генератор',
        createdAt: new Date(),
        updatedAt: new Date(),
        slides: mockSlides,
        theme: defaultTheme,
        settings: {
          aspectRatio: '16:9',
          autoAdvance: false,
          showSlideNumbers: true,
          showNotes: false,
        },
      };

      set((state) => ({
        currentPresentation: newPresentation,
        presentations: [...state.presentations, newPresentation],
        currentSlideIndex: 0,
        isGenerating: false,
        isEditing: true,
      }));
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : 'Ошибка генерации презентации',
        isGenerating: false,
      });
    }
  },

  // Утилиты
  setLoading: (loading: boolean) => set({ isLoading: loading }),
  setError: (error: string | null) => set({ error }),
  setEditing: (editing: boolean) => set({ isEditing: editing }),

  clearAll: () =>
    set({
      currentPresentation: null,
      presentations: [],
      currentSlideIndex: 0,
      isLoading: false,
      error: null,
      isEditing: false,
      selectedElementId: null,
      isGenerating: false,
    }),
}));

import { create } from "zustand";

interface ChatStore {
    messages: { id: number; text: string; sender: "user" | "bot" }[];
    addMessage: (message: { id: number; text: string; sender: "user" | "bot" }) => void;
    clearMessages: () => void;
}

export const useChatStore = create<ChatStore>((set) => ({
  messages: [],
  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),
  clearMessages: () => set({ messages: [] }),
}));
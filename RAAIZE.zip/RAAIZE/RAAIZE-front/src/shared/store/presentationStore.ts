import { create } from 'zustand';

interface PresentationState {
  isLoading: boolean;
  setIsLoading: (value: boolean) => void;

  html: string | null; 
  setHtml: (html: string) => void;

  currentSlideIndex: number;
  setCurrentSlideIndex: (index: number) => void;
}

export const usePresentationStore = create<PresentationState>((set) => ({
  isLoading: false,
  setIsLoading: (value) => set({ isLoading: value }),

  html: null,
  setHtml: (html) => set({ html }),

  currentSlideIndex: 0,
  setCurrentSlideIndex: (index) => set({ currentSlideIndex: index }),
}));

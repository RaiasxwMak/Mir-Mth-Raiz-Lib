import axios from 'axios';

// Unsplash API (бесплатный план с ограничениями)
const UNSPLASH_ACCESS_KEY = 'YOUR_UNSPLASH_ACCESS_KEY'; // Замените на реальный ключ
const UNSPLASH_BASE_URL = 'https://api.unsplash.com';

// Альтернативно, можно использовать Pixabay API (бесплатный)
const PIXABAY_API_KEY = 'YOUR_PIXABAY_API_KEY'; // Замените на реальный ключ
const PIXABAY_BASE_URL = 'https://pixabay.com/api/';

export interface ImageSearchResult {
  id: string;
  url: string;
  thumbnailUrl: string;
  description: string;
  author: string;
  width: number;
  height: number;
}

export class ImageService {
  // Поиск изображений через Unsplash
  static async searchUnsplashImages(
    query: string,
    count: number = 12,
  ): Promise<ImageSearchResult[]> {
    try {
      if (
        !UNSPLASH_ACCESS_KEY ||
        UNSPLASH_ACCESS_KEY === 'YOUR_UNSPLASH_ACCESS_KEY'
      ) {
        // Если ключ не настроен, возвращаем mock данные
        return this.getMockImages(query, count);
      }

      const response = await axios.get(`${UNSPLASH_BASE_URL}/search/photos`, {
        params: {
          query,
          per_page: count,
          orientation: 'landscape',
        },
        headers: {
          Authorization: `Client-ID ${UNSPLASH_ACCESS_KEY}`,
        },
      });

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return response.data.results.map(
        (photo: any): ImageSearchResult => ({
          id: String(photo.id || 'unknown'),
          url: photo.urls?.regular || '',
          thumbnailUrl: photo.urls?.thumb || '',
          description:
            photo.alt_description ||
            photo.description ||
            `Image about ${query}`,
          author: photo.user?.name || 'Unknown',
          width: Number(photo.width || 800),
          height: Number(photo.height || 600),
        }),
      );
    } catch (error) {
      console.error('Error searching Unsplash images:', error);
      return this.getMockImages(query, count);
    }
  }

  // Поиск изображений через Pixabay
  static async searchPixabayImages(
    query: string,
    count: number = 12,
  ): Promise<ImageSearchResult[]> {
    try {
      if (!PIXABAY_API_KEY || PIXABAY_API_KEY === 'YOUR_PIXABAY_API_KEY') {
        return this.getMockImages(query, count);
      }

      const response = await axios.get(PIXABAY_BASE_URL, {
        params: {
          key: PIXABAY_API_KEY,
          q: query,
          image_type: 'photo',
          orientation: 'horizontal',
          category: 'all',
          min_width: 640,
          min_height: 480,
          per_page: count,
          safesearch: 'true',
        },
      });

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return response.data.hits.map(
        (photo: any): ImageSearchResult => ({
          id: photo.id.toString(),
          url: photo.webformatURL,
          thumbnailUrl: photo.previewURL,
          description: photo.tags.replace(/,/g, ', '),
          author: photo.user,
          width: photo.imageWidth,
          height: photo.imageHeight,
        }),
      );
    } catch (error) {
      console.error('Error searching Pixabay images:', error);
      return this.getMockImages(query, count);
    }
  }

  // Основной метод поиска изображений
  static async searchImages(
    query: string,
    count: number = 12,
  ): Promise<ImageSearchResult[]> {
    // Сначала пробуем Pixabay (проще в настройке), затем Unsplash
    try {
      return await this.searchPixabayImages(query, count);
    } catch (error) {
      console.warn('Pixabay search failed, trying Unsplash:', error);
      return await this.searchUnsplashImages(query, count);
    }
  }

  // Mock данные для демонстрации без API ключей
  private static getMockImages(
    query: string,
    count: number,
  ): ImageSearchResult[] {
    const mockImages: ImageSearchResult[] = [];

    for (let i = 0; i < count; i++) {
      const width = 800 + Math.floor(Math.random() * 400);
      const height = 600 + Math.floor(Math.random() * 300);

      mockImages.push({
        id: `mock-${i}`,
        url: `https://picsum.photos/${width}/${height}?random=${
          Date.now() + i
        }`,
        thumbnailUrl: `https://picsum.photos/300/200?random=${Date.now() + i}`,
        description: `${query} related image ${i + 1}`,
        author: 'Demo Author',
        width,
        height,
      });
    }

    return mockImages;
  }

  // Получить случайное изображение по теме
  static async getRandomImage(
    topic: string,
  ): Promise<ImageSearchResult | null> {
    try {
      const images = await this.searchImages(topic, 1);
      return images[0] || null;
    } catch (error) {
      console.error('Error getting random image:', error);
      return null;
    }
  }

  // Предложить изображения для слайда на основе контента
  static async suggestImagesForSlide(
    title: string,
    content: string[],
  ): Promise<ImageSearchResult[]> {
    // Создаем поисковой запрос из заголовка и контента
    const searchTerms = [title, ...content.slice(0, 2)].join(' ');

    // Очищаем запрос от лишних символов
    const cleanQuery = searchTerms.replace(/[^\w\s]/g, ' ').trim();

    return await this.searchImages(cleanQuery, 6);
  }

  // Категории изображений для разных типов презентаций
  static async getImagesByCategory(
    category: 'business' | 'technology' | 'education' | 'creative' | 'nature',
  ): Promise<ImageSearchResult[]> {
    const categoryQueries = {
      business: 'business meeting office professional',
      technology: 'technology computer innovation digital',
      education: 'education learning books study',
      creative: 'creative art design colorful',
      nature: 'nature landscape beautiful scenery',
    };

    return await this.searchImages(categoryQueries[category], 12);
  }
}

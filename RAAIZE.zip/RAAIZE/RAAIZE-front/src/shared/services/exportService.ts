import { Presentation, Slide } from '@src/entities/presentation';

// Для работы с PDF будем использовать jsPDF (добавить в package.json)
// Для работы с PPTX будем использовать библиотеки или генерировать HTML

export interface ExportOptions {
  format: 'pdf' | 'pptx' | 'html' | 'png';
  quality?: 'low' | 'medium' | 'high';
  includeNotes?: boolean;
  slideSize?: '16:9' | '4:3' | 'custom';
  customSize?: { width: number; height: number };
}

export class PresentationExportService {
  // Экспорт в HTML (для просмотра и печати)
  static async exportToHTML(
    presentation: Presentation,
    options: ExportOptions = { format: 'html' },
  ): Promise<string> {
    const { slides, theme } = presentation;

    const css = `
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
          font-family: ${theme.fonts.body}; 
          background: ${theme.colors.background};
          color: ${theme.colors.text};
        }
        .presentation { 
          max-width: 1200px; 
          margin: 0 auto; 
          padding: 20px; 
        }
        .slide { 
          background: white; 
          margin-bottom: 40px; 
          padding: 40px; 
          border-radius: 12px; 
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          position: relative;
          min-height: 600px;
        }
        .slide-number { 
          position: absolute; 
          top: 20px; 
          right: 20px; 
          font-size: 14px; 
          color: #666; 
        }
        .slide-title { 
          font-size: 2rem; 
          font-weight: bold; 
          margin-bottom: 30px; 
          color: ${theme.colors.primary};
        }
        .slide-element { 
          margin-bottom: 20px; 
        }
        .element-text { 
          line-height: 1.6; 
        }
        .element-list { 
          padding-left: 20px; 
        }
        .element-list li { 
          margin-bottom: 8px; 
        }
        .element-image { 
          max-width: 100%; 
          height: auto; 
          border-radius: 8px; 
          margin: 20px 0;
        }
        .notes { 
          background: #f8f9fa; 
          padding: 20px; 
          margin-top: 20px; 
          border-radius: 8px; 
          border-left: 4px solid ${theme.colors.accent};
        }
        .notes h4 { 
          margin-bottom: 10px; 
          color: ${theme.colors.primary};
        }
        @media print {
          .slide { 
            page-break-after: always; 
            margin-bottom: 0; 
            box-shadow: none;
          }
        }
      </style>
    `;

    const slidesHTML = slides
      .map((slide, index) =>
        this.generateSlideHTML(slide, index, options.includeNotes),
      )
      .join('');

    return `
      <!DOCTYPE html>
      <html lang="ru">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${presentation.title}</title>
        ${css}
      </head>
      <body>
        <div class="presentation">
          <header style="text-align: center; margin-bottom: 40px;">
            <h1>${presentation.title}</h1>
            ${
              presentation.description
                ? `<p style="font-size: 1.2rem; color: #666; margin-top: 10px;">${presentation.description}</p>`
                : ''
            }
            ${
              presentation.author
                ? `<p style="margin-top: 20px;">Автор: ${presentation.author}</p>`
                : ''
            }
          </header>
          ${slidesHTML}
        </div>
      </body>
      </html>
    `;
  }

  // Генерация HTML для отдельного слайда
  private static generateSlideHTML(
    slide: Slide,
    index: number,
    includeNotes?: boolean,
  ): string {
    const elementsHTML = slide.elements
      .map((element) => {
        switch (element.type) {
          case 'text':
            return `
            <div class="slide-element element-text" style="
              font-size: ${element.style.fontSize || 16}px;
              color: ${element.style.color || '#333'};
              text-align: ${element.style.textAlign || 'left'};
              font-weight: ${element.style.fontWeight || 'normal'};
            ">
              ${element.content.text || ''}
            </div>
          `;

          case 'list': {
            const listItems =
              element.content.listItems
                ?.map((item) => `<li>${item}</li>`)
                .join('') || '';
            return `
            <div class="slide-element">
              <ul class="element-list" style="
                font-size: ${element.style.fontSize || 16}px;
                color: ${element.style.color || '#333'};
              ">
                ${listItems}
              </ul>
            </div>
          `;
          }

          case 'image':
            return `
            <div class="slide-element">
              <img src="${
                element.content.imageUrl || ''
              }" alt="Slide image" class="element-image" />
            </div>
          `;

          default:
            return '';
        }
      })
      .join('');

    const notesHTML =
      includeNotes && slide.notes
        ? `
      <div class="notes">
        <h4>Заметки спикера:</h4>
        <p>${slide.notes}</p>
      </div>
    `
        : '';

    return `
      <div class="slide" style="background-color: ${
        slide.backgroundStyle.color || 'white'
      };">
        <div class="slide-number">${index + 1}</div>
        <h2 class="slide-title">${slide.title}</h2>
        ${elementsHTML}
        ${notesHTML}
      </div>
    `;
  }

  // Экспорт в PDF (требует jsPDF)
  static async exportToPDF(
    presentation: Presentation,
    options: ExportOptions = { format: 'pdf' },
  ): Promise<Blob> {
    // Для демонстрации создаем простой PDF через HTML
    const htmlContent = await this.exportToHTML(presentation, options);

    // В реальном проекте здесь должна быть интеграция с jsPDF или puppeteer
    // Пока что возвращаем HTML как blob для демонстрации
    return new Blob([htmlContent], { type: 'application/pdf' });
  }

  // Экспорт отдельных слайдов как изображения
  static async exportSlideAsImage(
    slide: Slide,
    format: 'png' | 'jpg' = 'png',
  ): Promise<Blob> {
    // Создаем canvas для рендеринга слайда
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      throw new Error('Canvas context not available');
    }

    // Устанавливаем размеры (можно сделать настраиваемыми)
    canvas.width = 1920;
    canvas.height = 1080;

    // Заливаем фон
    ctx.fillStyle = slide.backgroundStyle.color || '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Рендерим элементы слайда
    for (const element of slide.elements) {
      await this.renderElementOnCanvas(
        ctx,
        element,
        canvas.width,
        canvas.height,
      );
    }

    // Конвертируем в blob
    return new Promise((resolve) => {
      canvas.toBlob(
        (blob) => {
          resolve(blob || new Blob());
        },
        `image/${format}`,
        0.9,
      );
    });
  }

  // Рендеринг элемента на canvas
  private static async renderElementOnCanvas(
    ctx: CanvasRenderingContext2D,
    element: Record<string, any>,
    canvasWidth: number,
    canvasHeight: number,
  ): Promise<void> {
    const x = (element.position.x / 800) * canvasWidth; // Нормализуем координаты
    const y = (element.position.y / 600) * canvasHeight;

    switch (element.type) {
      case 'text':
        ctx.font = `${element.style.fontSize || 16}px ${
          element.style.fontFamily || 'Arial'
        }`;
        ctx.fillStyle = element.style.color || '#000000';
        ctx.textAlign = element.style.textAlign || 'left';
        ctx.fillText(element.content.text || '', x, y);
        break;

      case 'list':
        if (element.content.listItems) {
          ctx.font = `${element.style.fontSize || 16}px ${
            element.style.fontFamily || 'Arial'
          }`;
          ctx.fillStyle = element.style.color || '#000000';

          element.content.listItems.forEach((item: string, index: number) => {
            const itemY = y + index * (element.style.fontSize || 16) * 1.5;
            ctx.fillText(`• ${item}`, x, itemY);
          });
        }
        break;

      case 'image':
        if (element.content.imageUrl) {
          const img = new Image();
          img.crossOrigin = 'anonymous';

          return new Promise((resolve) => {
            img.onload = () => {
              ctx.drawImage(
                img,
                x,
                y,
                element.position.width,
                element.position.height,
              );
              resolve();
            };
            img.onerror = () => resolve(); // Продолжаем даже если изображение не загрузилось
            img.src = element.content.imageUrl;
          });
        }
        break;
    }
  }

  // Скачивание файла
  static downloadFile(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // Основной метод экспорта
  static async exportPresentation(
    presentation: Presentation,
    options: ExportOptions,
  ): Promise<void> {
    const timestamp = new Date().toISOString().slice(0, 10);
    const baseFilename = `${presentation.title.replace(
      /[^a-zA-Z0-9]/g,
      '_',
    )}_${timestamp}`;

    try {
      switch (options.format) {
        case 'html': {
          const htmlContent = await this.exportToHTML(presentation, options);
          const htmlBlob = new Blob([htmlContent], { type: 'text/html' });
          this.downloadFile(htmlBlob, `${baseFilename}.html`);
          break;
        }

        case 'pdf': {
          const pdfBlob = await this.exportToPDF(presentation, options);
          this.downloadFile(pdfBlob, `${baseFilename}.pdf`);
          break;
        }

        case 'png':
          // Экспортируем все слайды как отдельные изображения
          for (let i = 0; i < presentation.slides.length; i++) {
            const slide = presentation.slides[i];
            const imageBlob = await this.exportSlideAsImage(slide, 'png');
            this.downloadFile(imageBlob, `${baseFilename}_slide_${i + 1}.png`);
          }
          break;

        case 'pptx': {
          // Здесь должна быть интеграция с библиотекой для создания PPTX
          // Пока что экспортируем как HTML
          const pptxContent = await this.exportToHTML(presentation, options);
          const pptxBlob = new Blob([pptxContent], { type: 'text/html' });
          this.downloadFile(pptxBlob, `${baseFilename}.html`);
          break;
        }
      }
    } catch (error) {
      console.error('Export error:', error);
      throw new Error(`Ошибка экспорта в формат ${options.format}: ${error}`);
    }
  }
}

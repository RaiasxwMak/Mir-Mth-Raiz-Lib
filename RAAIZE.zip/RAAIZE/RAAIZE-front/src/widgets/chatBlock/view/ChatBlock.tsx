import { FC, useState } from 'react';
import { InputAI } from '@src/shared/ui';
import classNames from 'classnames';
import styles from './ChatBlock.module.scss';
import { Trash2, Wand2, Settings } from 'lucide-react';
import { useChatStore } from '@src/entities/chatBlock/model/useChatStore';
import {
  useAIGeneration,
  AIGenerationRequest,
} from '@src/entities/presentation';

export const ChatBlock: FC = () => {
  const [inputValue, setInputValue] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [settings, setSettings] = useState<Partial<AIGenerationRequest>>({
    slideCount: 5,
    style: 'professional',
    includeImages: true,
    language: 'русский',
  });

  const { messages, addMessage, clearMessages } = useChatStore();
  const { generatePresentation, isGeneratingPresentation } = useAIGeneration();

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    addMessage({ id: Date.now(), text: inputValue, sender: 'user' });

    try {
      const request: AIGenerationRequest = {
        topic: inputValue,
        ...settings,
      };

      await generatePresentation(request);

      addMessage({
        id: Date.now(),
        text: `Презентация на тему "${inputValue}" создана успешно!`,
        sender: 'bot',
      });
    } catch (error) {
      console.error('Ошибка генерации презентации:', error);
      addMessage({
        id: Date.now(),
        text: 'Извините, произошла ошибка при создании презентации. Попробуйте еще раз.',
        sender: 'bot',
      });
    }

    setInputValue('');
  };

  return (
    <div className={styles.chatWrapper}>
      <div className={styles.chatHeader}>
        <h3>AI Генератор Презентаций</h3>
        <div className={styles.headerActions}>
          <button
            className={styles.settingsButton}
            onClick={() => setShowAdvanced(!showAdvanced)}
            title="Настройки генерации"
          >
            <Settings size={16} />
          </button>
          <button
            className={styles.btnTrash}
            onClick={clearMessages}
            title="Очистить чат"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {showAdvanced && (
        <div className={styles.settingsPanel}>
          <div className={styles.settingGroup}>
            <label>Количество слайдов:</label>
            <select
              value={settings.slideCount || 5}
              onChange={(e) =>
                setSettings((prev) => ({
                  ...prev,
                  slideCount: parseInt(e.target.value),
                }))
              }
            >
              <option value={3}>3</option>
              <option value={5}>5</option>
              <option value={8}>8</option>
              <option value={12}>12</option>
            </select>
          </div>

          <div className={styles.settingGroup}>
            <label>Стиль:</label>
            <select
              value={settings.style || 'professional'}
              onChange={(e) =>
                setSettings((prev) => ({
                  ...prev,
                  style: e.target.value as
                    | 'professional'
                    | 'creative'
                    | 'minimal'
                    | 'academic',
                }))
              }
            >
              <option value="professional">Профессиональный</option>
              <option value="creative">Творческий</option>
              <option value="minimal">Минималистичный</option>
              <option value="academic">Академический</option>
            </select>
          </div>

          <div className={styles.settingGroup}>
            <label>
              <input
                type="checkbox"
                checked={settings.includeImages || false}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    includeImages: e.target.checked,
                  }))
                }
              />
              Включить изображения
            </label>
          </div>
        </div>
      )}

      <div className={styles.messagesContainer}>
        {messages.length === 0 && (
          <div className={styles.welcomeMessage}>
            <Wand2 size={32} className={styles.welcomeIcon} />
            <h4>Создайте презентацию с помощью AI</h4>
            <p>
              Опишите тему вашей презентации, и я создам для вас
              профессиональные слайды
            </p>
            <div className={styles.examples}>
              <strong>Примеры:</strong>
              <ul>
                <li>&quot;Искусственный интеллект в медицине&quot;</li>
                <li>&quot;Стратегия цифрового маркетинга&quot;</li>
                <li>&quot;Основы машинного обучения&quot;</li>
              </ul>
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div
            key={i}
            className={classNames(
              msg.sender === 'user' ? styles.userMessage : styles.aiMessage,
              styles.message,
            )}
          >
            <p className={styles.role}>{msg.sender === 'user' ? 'Вы' : 'AI'}</p>
            <div
              className={classNames(
                msg.sender === 'user' ? styles.msgUser : styles.msgAi,
              )}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {isGeneratingPresentation && (
          <div className={styles.loadingMessage}>
            <div className={styles.loadingIcon}>⏳</div>
            <p>Генерирую презентацию...</p>
          </div>
        )}
      </div>

      <div className={styles.inputContainer}>
        <InputAI
          fullWidth
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onSubmit={handleSend}
        />
      </div>
    </div>
  );
};

import { FC, useCallback } from 'react';
import { usePresentationStore, SlideElement } from '@src/entities/presentation';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Trash2,
  Palette,
  Type,
  Move,
  RotateCcw,
} from 'lucide-react';
import classNames from 'classnames';
import styles from './ElementPropertiesPanel.module.scss';

interface ElementPropertiesPanelProps {
  className?: string;
}

export const ElementPropertiesPanel: FC<ElementPropertiesPanelProps> = ({
  className,
}) => {
  const {
    currentPresentation,
    currentSlideIndex,
    selectedElementId,
    updateElement,
    deleteElement,
    selectElement,
  } = usePresentationStore();

  const currentSlide = currentPresentation?.slides[currentSlideIndex];
  const selectedElement = selectedElementId
    ? currentSlide?.elements.find((el) => el.id === selectedElementId)
    : null;

  const handleStyleUpdate = useCallback(
    (updates: Partial<SlideElement['style']>) => {
      if (!currentSlide || !selectedElementId) return;

      updateElement(currentSlide.id, selectedElementId, {
        style: { ...selectedElement?.style, ...updates },
      });
    },
    [currentSlide, selectedElementId, selectedElement, updateElement],
  );

  const handlePositionUpdate = useCallback(
    (updates: Partial<SlideElement['position']>) => {
      if (!currentSlide || !selectedElementId) return;

      if (selectedElement?.position) {
        updateElement(currentSlide.id, selectedElementId, {
          position: { ...selectedElement.position, ...updates },
        });
      }
    },
    [currentSlide, selectedElementId, selectedElement, updateElement],
  );

  const handleContentUpdate = useCallback(
    (updates: Partial<SlideElement['content']>) => {
      if (!currentSlide || !selectedElementId) return;

      updateElement(currentSlide.id, selectedElementId, {
        content: { ...selectedElement?.content, ...updates },
      });
    },
    [currentSlide, selectedElementId, selectedElement, updateElement],
  );

  const handleDelete = useCallback(() => {
    if (!currentSlide || !selectedElementId) return;

    deleteElement(currentSlide.id, selectedElementId);
    selectElement(null);
  }, [currentSlide, selectedElementId, deleteElement, selectElement]);

  const handleDuplicate = useCallback(() => {
    if (!currentSlide || !selectedElement) return;

    // Создаем копию элемента со смещением
    const duplicatedElement: Omit<SlideElement, 'id'> = {
      ...selectedElement,
      position: {
        ...selectedElement.position,
        x: selectedElement.position.x + 20,
        y: selectedElement.position.y + 20,
      },
    };

    // Добавляем через store
    usePresentationStore
      .getState()
      .addElement(currentSlide.id, duplicatedElement);
  }, [currentSlide, selectedElement]);

  const fontFamilies = [
    'Inter, sans-serif',
    'Arial, sans-serif',
    'Helvetica, sans-serif',
    'Verdana, sans-serif',
    'Roboto, sans-serif',
    'Open Sans, sans-serif',
    'Lato, sans-serif',
    'Montserrat, sans-serif',
    'Poppins, sans-serif',
    'Georgia, serif',
    'Times New Roman, serif',
    'Playfair Display, serif',
    'Merriweather, serif',
    'Courier New, monospace',
    'Monaco, monospace',
    'Source Code Pro, monospace',
  ];

  if (!selectedElement) {
    return (
      <div className={classNames(styles.panel, styles.empty, className)}>
        <div className={styles.emptyState}>
          <Type size={32} className={styles.emptyIcon} />
          <h4>Элемент не выбран</h4>
          <p>Выберите элемент на слайде для редактирования его свойств</p>
        </div>
      </div>
    );
  }

  return (
    <div className={classNames(styles.panel, className)}>
      <div className={styles.header}>
        <h3>Свойства элемента</h3>
        <div className={styles.headerActions}>
          <button
            className={styles.actionButton}
            onClick={handleDuplicate}
            title="Дублировать элемент"
          >
            <RotateCcw size={16} />
          </button>
          <button
            className={classNames(styles.actionButton, styles.deleteButton)}
            onClick={handleDelete}
            title="Удалить элемент"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className={styles.content}>
        {/* Позиция и размер */}
        <div className={styles.section}>
          <h4>
            <Move size={16} />
            Позиция и размер
          </h4>
          <div className={styles.positionGrid}>
            <div className={styles.inputGroup}>
              <label>X:</label>
              <input
                type="number"
                value={Math.round(selectedElement.position.x)}
                onChange={(e) =>
                  handlePositionUpdate({ x: Number(e.target.value) })
                }
                className={styles.numberInput}
              />
            </div>
            <div className={styles.inputGroup}>
              <label>Y:</label>
              <input
                type="number"
                value={Math.round(selectedElement.position.y)}
                onChange={(e) =>
                  handlePositionUpdate({ y: Number(e.target.value) })
                }
                className={styles.numberInput}
              />
            </div>
            <div className={styles.inputGroup}>
              <label>Ширина:</label>
              <input
                type="number"
                value={Math.round(selectedElement.position.width)}
                onChange={(e) =>
                  handlePositionUpdate({ width: Number(e.target.value) })
                }
                className={styles.numberInput}
              />
            </div>
            <div className={styles.inputGroup}>
              <label>Высота:</label>
              <input
                type="number"
                value={Math.round(selectedElement.position.height)}
                onChange={(e) =>
                  handlePositionUpdate({ height: Number(e.target.value) })
                }
                className={styles.numberInput}
              />
            </div>
          </div>
        </div>

        {/* Стили текста (только для текстовых элементов) */}
        {(selectedElement.type === 'text' ||
          selectedElement.type === 'list') && (
          <>
            <div className={styles.section}>
              <h4>
                <Type size={16} />
                Шрифт
              </h4>

              <div className={styles.fontControls}>
                <div className={styles.inputGroup}>
                  <label>Размер:</label>
                  <div className={styles.sizeControls}>
                    <div className={styles.sizeInputGroup}>
                      <button
                        className={styles.sizeStepper}
                        onClick={() =>
                          handleStyleUpdate({
                            fontSize: Math.max(
                              8,
                              (selectedElement.style.fontSize || 16) - 2,
                            ),
                          })
                        }
                        disabled={(selectedElement.style.fontSize || 16) <= 8}
                      >
                        −
                      </button>
                      <input
                        type="number"
                        min="8"
                        max="128"
                        value={selectedElement.style.fontSize || 16}
                        onChange={(e) =>
                          handleStyleUpdate({
                            fontSize: Number(e.target.value),
                          })
                        }
                        className={styles.numberInput}
                      />
                      <button
                        className={styles.sizeStepper}
                        onClick={() =>
                          handleStyleUpdate({
                            fontSize: Math.min(
                              128,
                              (selectedElement.style.fontSize || 16) + 2,
                            ),
                          })
                        }
                        disabled={(selectedElement.style.fontSize || 16) >= 128}
                      >
                        +
                      </button>
                    </div>
                    <div className={styles.quickSizes}>
                      {[10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 64].map(
                        (size) => (
                          <button
                            key={size}
                            className={classNames(styles.quickSizeButton, {
                              [styles.active]:
                                selectedElement.style.fontSize === size,
                            })}
                            onClick={() =>
                              handleStyleUpdate({ fontSize: size })
                            }
                          >
                            {size}
                          </button>
                        ),
                      )}
                    </div>
                  </div>
                </div>

                <div className={styles.inputGroup}>
                  <label>Семейство:</label>
                  <select
                    value={
                      selectedElement.style.fontFamily || 'Inter, sans-serif'
                    }
                    onChange={(e) =>
                      handleStyleUpdate({ fontFamily: e.target.value })
                    }
                    className={styles.select}
                  >
                    {fontFamilies.map((font) => (
                      <option key={font} value={font}>
                        {font.split(',')[0]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className={styles.fontStyleControls}>
                <button
                  className={classNames(styles.styleButton, {
                    [styles.active]:
                      selectedElement.style.fontWeight === 'bold' ||
                      selectedElement.style.fontWeight === '700',
                  })}
                  onClick={() =>
                    handleStyleUpdate({
                      fontWeight:
                        selectedElement.style.fontWeight === 'bold'
                          ? 'normal'
                          : 'bold',
                    })
                  }
                  title="Жирный"
                >
                  <Bold size={16} />
                </button>

                <button
                  className={classNames(styles.styleButton, {
                    [styles.active]:
                      selectedElement.style.fontStyle === 'italic',
                  })}
                  onClick={() =>
                    handleStyleUpdate({
                      fontStyle:
                        selectedElement.style.fontStyle === 'italic'
                          ? 'normal'
                          : 'italic',
                    })
                  }
                  title="Курсив"
                >
                  <Italic size={16} />
                </button>

                <button
                  className={classNames(styles.styleButton, {
                    [styles.active]:
                      selectedElement.style.textDecoration?.includes(
                        'underline',
                      ),
                  })}
                  onClick={() => {
                    const currentDecoration =
                      selectedElement.style.textDecoration || '';
                    const hasUnderline =
                      currentDecoration.includes('underline');
                    let newDecoration = currentDecoration
                      .replace('underline', '')
                      .trim();

                    if (!hasUnderline) {
                      newDecoration = newDecoration
                        ? `${newDecoration} underline`
                        : 'underline';
                    }

                    handleStyleUpdate({
                      textDecoration: newDecoration || 'none',
                    });
                  }}
                  title="Подчеркивание"
                >
                  <Underline size={16} />
                </button>

                <button
                  className={classNames(styles.styleButton, {
                    [styles.active]:
                      selectedElement.style.textDecoration?.includes(
                        'line-through',
                      ),
                  })}
                  onClick={() => {
                    const currentDecoration =
                      selectedElement.style.textDecoration || '';
                    const hasStrikethrough =
                      currentDecoration.includes('line-through');
                    let newDecoration = currentDecoration
                      .replace('line-through', '')
                      .trim();

                    if (!hasStrikethrough) {
                      newDecoration = newDecoration
                        ? `${newDecoration} line-through`
                        : 'line-through';
                    }

                    handleStyleUpdate({
                      textDecoration: newDecoration || 'none',
                    });
                  }}
                  title="Зачеркивание"
                >
                  <Strikethrough size={16} />
                </button>
              </div>
            </div>

            <div className={styles.section}>
              <h4>
                <Palette size={16} />
                Цвет и выравнивание
              </h4>

              <div className={styles.colorControl}>
                <label>Цвет текста:</label>
                <div className={styles.colorSection}>
                  <div className={styles.colorPresets}>
                    {[
                      '#000000',
                      '#FFFFFF',
                      '#FF0000',
                      '#00FF00',
                      '#0000FF',
                      '#FFFF00',
                      '#FF00FF',
                      '#00FFFF',
                      '#FFA500',
                      '#800080',
                      '#FFC0CB',
                      '#A52A2A',
                      '#808080',
                      '#FF69B4',
                      '#20B2AA',
                      '#DDA0DD',
                      '#98FB98',
                      '#F0E68C',
                      '#FF6347',
                      '#4169E1',
                    ].map((color) => (
                      <button
                        key={color}
                        className={classNames(styles.colorPreset, {
                          [styles.active]:
                            selectedElement.style.color === color,
                        })}
                        style={{ backgroundColor: color }}
                        onClick={() => handleStyleUpdate({ color })}
                        title={color}
                      />
                    ))}
                  </div>
                  <div className={styles.colorPickerWrapper}>
                    <input
                      type="color"
                      value={selectedElement.style.color || '#000000'}
                      onChange={(e) =>
                        handleStyleUpdate({ color: e.target.value })
                      }
                      className={styles.colorPicker}
                    />
                    <span className={styles.colorValue}>
                      {selectedElement.style.color || '#000000'}
                    </span>
                  </div>
                </div>
              </div>

              <div className={styles.alignmentControls}>
                <label>Выравнивание:</label>
                <div className={styles.alignmentButtons}>
                  <button
                    className={classNames(styles.styleButton, {
                      [styles.active]:
                        selectedElement.style.textAlign === 'left',
                    })}
                    onClick={() => handleStyleUpdate({ textAlign: 'left' })}
                    title="По левому краю"
                  >
                    <AlignLeft size={16} />
                  </button>
                  <button
                    className={classNames(styles.styleButton, {
                      [styles.active]:
                        selectedElement.style.textAlign === 'center',
                    })}
                    onClick={() => handleStyleUpdate({ textAlign: 'center' })}
                    title="По центру"
                  >
                    <AlignCenter size={16} />
                  </button>
                  <button
                    className={classNames(styles.styleButton, {
                      [styles.active]:
                        selectedElement.style.textAlign === 'right',
                    })}
                    onClick={() => handleStyleUpdate({ textAlign: 'right' })}
                    title="По правому краю"
                  >
                    <AlignRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Содержимое */}
        <div className={styles.section}>
          <h4>Содержимое</h4>

          {selectedElement.type === 'text' && (
            <div className={styles.inputGroup}>
              <label>Текст:</label>
              <textarea
                value={selectedElement.content.text || ''}
                onChange={(e) => handleContentUpdate({ text: e.target.value })}
                className={styles.textarea}
                rows={3}
                placeholder="Введите текст..."
              />
            </div>
          )}

          {selectedElement.type === 'list' && (
            <div className={styles.inputGroup}>
              <label>Пункты списка (по одному на строку):</label>
              <textarea
                value={selectedElement.content.listItems?.join('\n') || ''}
                onChange={(e) =>
                  handleContentUpdate({
                    listItems: e.target.value
                      .split('\n')
                      .filter((item) => item.trim()),
                  })
                }
                className={styles.textarea}
                rows={5}
                placeholder="Пункт 1&#10;Пункт 2&#10;Пункт 3"
              />
            </div>
          )}

          {selectedElement.type === 'image' && (
            <div className={styles.inputGroup}>
              <label>URL изображения:</label>
              <input
                type="url"
                value={selectedElement.content.imageUrl || ''}
                onChange={(e) =>
                  handleContentUpdate({ imageUrl: e.target.value })
                }
                className={styles.input}
                placeholder="https://example.com/image.jpg"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

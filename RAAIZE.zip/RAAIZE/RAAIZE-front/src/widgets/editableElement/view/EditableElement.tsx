import { FC, useCallback, useState } from 'react';
import { Rnd } from 'react-rnd';
import { usePresentationStore, SlideElement } from '@src/entities/presentation';
import { Trash2, Copy, MoreVertical } from 'lucide-react';
import classNames from 'classnames';
import styles from './EditableElement.module.scss';

interface EditableElementProps {
  element: SlideElement;
  slideId: string;
  isSelected: boolean;
  onSelect: () => void;
  scale?: number;
}

export const EditableElement: FC<EditableElementProps> = ({
  element,
  slideId,
  isSelected,
  onSelect,
  scale = 1,
}) => {
  const { updateElement, deleteElement, selectElement } =
    usePresentationStore();
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [contextMenuPos, setContextMenuPos] = useState({ x: 0, y: 0 });

  const handleDragStop = useCallback(
    (_e: unknown, data: { x: number; y: number }) => {
      updateElement(slideId, element.id, {
        position: {
          ...element.position,
          x: data.x / scale,
          y: data.y / scale,
        },
      });
    },
    [slideId, element.id, element.position, updateElement, scale],
  );

  const handleResizeStop = useCallback(
    (
      _e: unknown,
      _direction: unknown,
      ref: { style: { width: string; height: string } },
      _delta: unknown,
      position: { x: number; y: number },
    ) => {
      updateElement(slideId, element.id, {
        position: {
          x: position.x / scale,
          y: position.y / scale,
          width: parseInt(ref.style.width) / scale,
          height: parseInt(ref.style.height) / scale,
        },
      });
    },
    [slideId, element.id, updateElement, scale],
  );

  const handleContentChange = useCallback(
    (newContent: string) => {
      if (element.type === 'text') {
        updateElement(slideId, element.id, {
          content: { ...element.content, text: newContent },
        });
      }
    },
    [slideId, element.id, element.content, element.type, updateElement],
  );

  const handleListItemsChange = useCallback(
    (newItems: string[]) => {
      if (element.type === 'list') {
        updateElement(slideId, element.id, {
          content: { ...element.content, listItems: newItems },
        });
      }
    },
    [slideId, element.id, element.content, element.type, updateElement],
  );

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenuPos({ x: e.clientX, y: e.clientY });
    setShowContextMenu(true);
  }, []);

  const handleDuplicate = useCallback(() => {
    const duplicatedElement: Omit<SlideElement, 'id'> = {
      ...element,
      position: {
        ...element.position,
        x: element.position.x + 20,
        y: element.position.y + 20,
      },
    };

    usePresentationStore.getState().addElement(slideId, duplicatedElement);
    setShowContextMenu(false);
  }, [element, slideId]);

  const handleDelete = useCallback(() => {
    deleteElement(slideId, element.id);
    selectElement(null);
    setShowContextMenu(false);
  }, [slideId, element.id, deleteElement, selectElement]);

  const renderContent = () => {
    const baseStyle = {
      fontSize: (element.style.fontSize || 16) * scale,
      color: element.style.color || '#000000',
      textAlign: element.style.textAlign || 'left',
      fontWeight: element.style.fontWeight || 'normal',
      fontStyle: element.style.fontStyle || 'normal',
      fontFamily: element.style.fontFamily || 'Inter, sans-serif',
      lineHeight: 1.4,
    } as React.CSSProperties;

    switch (element.type) {
      case 'text':
        return (
          <textarea
            value={element.content.text || ''}
            onChange={(e) => handleContentChange(e.target.value)}
            className={styles.textInput}
            style={baseStyle}
            placeholder="Введите текст..."
          />
        );

      case 'list':
        return (
          <div className={styles.listEditor} style={baseStyle}>
            {element.content.listItems?.map((item, index) => (
              <div key={index} className={styles.listItem}>
                <span className={styles.bullet}>•</span>
                <input
                  type="text"
                  value={item}
                  onChange={(e) => {
                    const newItems = [...(element.content.listItems || [])];
                    newItems[index] = e.target.value;
                    handleListItemsChange(newItems);
                  }}
                  className={styles.listItemInput}
                  style={baseStyle}
                />
                <button
                  className={styles.removeItem}
                  onClick={() => {
                    const newItems =
                      element.content.listItems?.filter(
                        (_, i) => i !== index,
                      ) || [];
                    handleListItemsChange(newItems);
                  }}
                >
                  ×
                </button>
              </div>
            )) || []}
            <button
              className={styles.addItem}
              onClick={() => {
                const newItems = [
                  ...(element.content.listItems || []),
                  'Новый пункт',
                ];
                handleListItemsChange(newItems);
              }}
            >
              + Добавить пункт
            </button>
          </div>
        );

      case 'image':
        return (
          <img
            src={element.content.imageUrl || ''}
            alt="Slide content"
            className={styles.image}
            draggable={false}
          />
        );

      default:
        return <div>Неизвестный тип элемента</div>;
    }
  };

  return (
    <>
      <Rnd
        size={{
          width: element.position.width * scale,
          height: element.position.height * scale,
        }}
        position={{
          x: element.position.x * scale,
          y: element.position.y * scale,
        }}
        onDragStop={handleDragStop}
        onResizeStop={handleResizeStop}
        className={classNames(styles.element, {
          [styles.selected]: isSelected,
        })}
        bounds="parent"
        enableResizing={{
          top: isSelected,
          right: isSelected,
          bottom: isSelected,
          left: isSelected,
          topRight: isSelected,
          bottomRight: isSelected,
          bottomLeft: isSelected,
          topLeft: isSelected,
        }}
        disableDragging={!isSelected}
        resizeHandleStyles={{
          topRight: { cursor: 'ne-resize' },
          bottomRight: { cursor: 'se-resize' },
          bottomLeft: { cursor: 'sw-resize' },
          topLeft: { cursor: 'nw-resize' },
          top: { cursor: 'n-resize' },
          right: { cursor: 'e-resize' },
          bottom: { cursor: 's-resize' },
          left: { cursor: 'w-resize' },
        }}
        resizeHandleClasses={{
          topRight: styles.resizeHandle,
          bottomRight: styles.resizeHandle,
          bottomLeft: styles.resizeHandle,
          topLeft: styles.resizeHandle,
          top: styles.resizeHandle,
          right: styles.resizeHandle,
          bottom: styles.resizeHandle,
          left: styles.resizeHandle,
        }}
        onClick={onSelect}
        onContextMenu={handleContextMenu}
      >
        <div className={styles.elementContent}>{renderContent()}</div>

        {isSelected && (
          <div className={styles.toolbar}>
            <button
              className={styles.toolbarButton}
              onClick={handleDuplicate}
              title="Дублировать"
            >
              <Copy size={12} />
            </button>
            <button
              className={styles.toolbarButton}
              onClick={() => setShowContextMenu(!showContextMenu)}
              title="Меню"
            >
              <MoreVertical size={12} />
            </button>
            <button
              className={classNames(styles.toolbarButton, styles.deleteButton)}
              onClick={handleDelete}
              title="Удалить"
            >
              <Trash2 size={12} />
            </button>
          </div>
        )}
      </Rnd>

      {/* Контекстное меню */}
      {showContextMenu && (
        <>
          <div
            className={styles.contextMenuOverlay}
            onClick={() => setShowContextMenu(false)}
          />
          <div
            className={styles.contextMenu}
            style={{
              left: contextMenuPos.x,
              top: contextMenuPos.y,
            }}
          >
            <button onClick={handleDuplicate}>
              <Copy size={14} />
              Дублировать
            </button>
            <button onClick={handleDelete} className={styles.dangerItem}>
              <Trash2 size={14} />
              Удалить
            </button>
          </div>
        </>
      )}
    </>
  );
};

export type Slide = {
  id: number;
  html: string;
  css?: string;
};

export type PresentationContent = {
  slides: Slide[];
};

export type CreatePresentationDto = {
  title: string;
  content: PresentationContent;
  board_id: number;
};

export type Presentation = {
  id: number;
  title: string;
  user_id: number;
  content: PresentationContent;
  board_id: number;
  created_at: string;
  updated_at: string;
};
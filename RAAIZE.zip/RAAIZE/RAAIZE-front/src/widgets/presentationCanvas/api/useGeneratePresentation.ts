import { useMutation } from '@tanstack/react-query';
import { $mainApi } from '@src/shared/lib/requester/requester';
import { toast } from 'react-toastify';
import { usePresentationStore } from '@src/entities/presentation';

export interface EnhancedGenerateDto {
  topic: string;
  slides_count?: number;
  audience?: string;
  style?: string;
  language?: string;
  include_images?: boolean;
  image_style?: string;
  auto_enhance?: boolean;
}

export const useGeneratePresentation = () => {
  const { loadPresentation, setLoading } = usePresentationStore();

  return useMutation({
    mutationFn: async (dto: EnhancedGenerateDto) => {
      setLoading(true);
      const res = await $mainApi.post('/enhanced/generate', dto);
      return res.data;
    },
    onSuccess: (data) => {
      toast.success('Презентация успешно сгенерирована');
      loadPresentation({
        id: Date.now().toString(),
        title: data.title,
        author: 'AI Генератор',
        createdAt: new Date(),
        updatedAt: new Date(),
        slides: data.slides.map(
          (s: {
            title: string;
            content?: string;
            image?: { url: string; alt?: string };
          }) => ({
            id: crypto.randomUUID(),
            title: s.title,
            elements: [],
            backgroundStyle: { color: '#FFFFFF' },
            transition: 'fade' as const,
          }),
        ),
        theme: {
          id: 'default',
          name: 'Default',
          colors: {
            primary: '#4F46E5',
            secondary: '#7C3AED',
            accent: '#F59E0B',
            background: '#FFFFFF',
            text: '#1F2937',
          },
          fonts: {
            heading: 'Inter, sans-serif',
            body: 'Inter, sans-serif',
          },
          styles: {
            slideBackground: '#FFFFFF',
            titleStyle: {},
            textStyle: {},
          },
        },
        settings: {
          aspectRatio: '16:9' as const,
          autoAdvance: false,
          showSlideNumbers: true,
          showNotes: false,
        },
      });
    },
    onError: (err: Error & { response?: { data?: { message?: string } } }) => {
      toast.error(
        err?.response?.data?.message || 'Ошибка при генерации презентации',
      );
    },
    onSettled: () => setLoading(false),
  });
};

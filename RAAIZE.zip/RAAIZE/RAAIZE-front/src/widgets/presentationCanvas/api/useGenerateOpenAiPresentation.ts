import { useMutation } from '@tanstack/react-query';
import axios from 'axios';

export const useGenerateOpenAiPresentation = () => {
  return useMutation({
    mutationKey: ['generateOpenAiPresentation'],
    mutationFn: async (prompt) => {
      const { data } = await axios.post(
        'https://openrouter.ai/api/v1/chat/completions',
        {
          model: 'openai/gpt-4o-mini',
          messages: [
            {
              role: 'system',
              content:  `Ты помощник для генерации презентаций. 
                  Создай готовую HTML-презентацию слайдов (div.container > div.slide), 
                  с базовыми стилями, шрифтами и анимацией появления элементов.
                  Не используй внешние библиотеки, весь CSS должен быть встроенный.`

            },
            { role: 'user', content: prompt },
          ],
        },
        {
          headers: {
            Authorization:
              'Bearer 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',
            'Content-Type': 'application/json',
          },
        },
      );
      return data;
    },
  });
};

import { FC, useEffect, useRef, useState } from 'react';
import { usePresentationStore } from '@src/shared/store/presentationStore';
import styles from './PresentationCanvas.module.scss';

export const PresentationCanvas: FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const shadowRoot = useRef<ShadowRoot | null>(null);

  const { html, isLoading } = usePresentationStore();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState<HTMLElement[]>([]);

  useEffect(() => {
    if (containerRef.current && !shadowRoot.current) {
      shadowRoot.current = containerRef.current.attachShadow({ mode: 'open' });
    }
  }, []);

  useEffect(() => {
    const root = shadowRoot.current;
    if (!root) return;

    root.innerHTML = ''; 

    if (!html) {
      root.innerHTML = '<p style="padding:20px;color:#888">Нет презентации</p>';
      return;
    }

    const wrapper = document.createElement('div');
    wrapper.innerHTML = html;

    const slideElements = Array.from(wrapper.querySelectorAll('.slide')) as HTMLElement[];

    slideElements.forEach((slide, i) => {
      slide.style.opacity = i === 0 ? '1' : '0';
      slide.style.transition = 'opacity 0.5s ease';
      slide.style.position = 'absolute';
      slide.style.top = '0';
      slide.style.left = '0';
      slide.style.width = '100%';
      slide.style.height = '100%';
    });

    setSlides(slideElements);

    root.appendChild(wrapper);
  }, [html]);
  const showSlide = (index: number) => {
    if (!slides.length) return;
    slides[currentSlide].style.opacity = '0';
    const newIndex = (index + slides.length) % slides.length;
    slides[newIndex].style.opacity = '1';
    setCurrentSlide(newIndex);
  };

  const nextSlide = () => showSlide(currentSlide + 1);
  const prevSlide = () => showSlide(currentSlide - 1);

  return (
    <div
      className={styles.canvasWrapper}
      ref={containerRef}
      style={{ position: 'relative', width: '100%', height: '100%' }}
    >
      {!isLoading && slides.length > 0 && (
        <div
          style={{
            position: 'absolute',
            bottom: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            display: 'flex',
            gap: '10px',
            zIndex: 10,
          }}
        >
          <button onClick={prevSlide} style={buttonStyle}>
            Назад
          </button>
          <button onClick={nextSlide} style={buttonStyle}>
            Вперед
          </button>
        </div>
      )}

      {isLoading && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'rgba(255,255,255,0.7)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 20,
          }}
        >
          <div style={{ fontSize: 22, color: '#4F46E5', fontWeight: 600 }}>
            ⏳ Генерируется презентация...
          </div>
        </div>
      )}
    </div>
  );
};

const buttonStyle: React.CSSProperties = {
  padding: '8px 12px',
  borderRadius: '6px',
  backgroundColor: '#4F46E5',
  color: '#fff',
  border: 'none',
  cursor: 'pointer',
};

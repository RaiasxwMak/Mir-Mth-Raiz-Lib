import { FC, useCallback, useRef, useEffect, useState } from 'react';
import { usePresentationStore, SlideElement } from '@src/entities/presentation';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Palette,
  Type,
  Plus,
  Minus,
  ChevronDown,
} from 'lucide-react';
import classNames from 'classnames';
import styles from './TextToolbar.module.scss';

interface TextToolbarProps {
  element: SlideElement;
  elementPosition: DOMRect;
}

export const TextToolbar: FC<TextToolbarProps> = ({
  element,
  elementPosition,
}) => {
  const [showFontDropdown, setShowFontDropdown] = useState(false);
  const [showColorPalette, setShowColorPalette] = useState(false);
  const toolbarRef = useRef<HTMLDivElement>(null);

  const { updateElement, currentPresentation, currentSlideIndex } =
    usePresentationStore();

  const currentSlide = currentPresentation?.slides[currentSlideIndex];

  const handleStyleUpdate = useCallback(
    (updates: Partial<SlideElement['style']>) => {
      if (!currentSlide) return;

      updateElement(currentSlide.id, element.id, {
        style: { ...element.style, ...updates },
      });
    },
    [currentSlide, element, updateElement],
  );

  const fontFamilies = [
    'Arial, sans-serif',
    'Helvetica, sans-serif',
    'Times New Roman, serif',
    'Georgia, serif',
    'Courier New, monospace',
    'Verdana, sans-serif',
    'Trebuchet MS, sans-serif',
    'Roboto, sans-serif',
    'Open Sans, sans-serif',
    'Montserrat, sans-serif',
    'Lato, sans-serif',
    'Playfair Display, serif',
    'Source Sans Pro, sans-serif',
    'Oswald, sans-serif',
    'Raleway, sans-serif',
    'PT Sans, sans-serif',
  ];

  const colorPresets = [
    '#000000',
    '#FFFFFF',
    '#FF0000',
    '#00FF00',
    '#0000FF',
    '#FFFF00',
    '#FF00FF',
    '#00FFFF',
    '#FFA500',
    '#800080',
    '#FFC0CB',
    '#A52A2A',
    '#808080',
    '#FF69B4',
    '#20B2AA',
    '#DDA0DD',
    '#98FB98',
    '#F0E68C',
    '#FF6347',
    '#4169E1',
  ];

  const handleFontSizeChange = (delta: number) => {
    const currentSize = element.style.fontSize || 16;
    const newSize = Math.max(8, Math.min(200, currentSize + delta));
    handleStyleUpdate({ fontSize: newSize });
  };

  const handleToggleStyle = (
    styleType: 'bold' | 'italic' | 'underline' | 'strikethrough',
  ) => {
    switch (styleType) {
      case 'bold':
        handleStyleUpdate({
          fontWeight: element.style.fontWeight === 'bold' ? 'normal' : 'bold',
        });
        break;
      case 'italic':
        handleStyleUpdate({
          fontStyle: element.style.fontStyle === 'italic' ? 'normal' : 'italic',
        });
        break;
      case 'underline': {
        const currentDecoration = element.style.textDecoration || '';
        const hasUnderline = currentDecoration.includes('underline');
        let newDecoration = currentDecoration.replace('underline', '').trim();
        if (!hasUnderline) {
          newDecoration = newDecoration
            ? `${newDecoration} underline`
            : 'underline';
        }
        handleStyleUpdate({ textDecoration: newDecoration || 'none' });
        break;
      }
      case 'strikethrough': {
        const currentDecorationS = element.style.textDecoration || '';
        const hasStrikethrough = currentDecorationS.includes('line-through');
        let newDecorationS = currentDecorationS
          .replace('line-through', '')
          .trim();
        if (!hasStrikethrough) {
          newDecorationS = newDecorationS
            ? `${newDecorationS} line-through`
            : 'line-through';
        }
        handleStyleUpdate({ textDecoration: newDecorationS || 'none' });
        break;
      }
    }
  };

  // Закрытие dropdown при клике вне
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        toolbarRef.current &&
        !toolbarRef.current.contains(event.target as Node)
      ) {
        setShowFontDropdown(false);
        setShowColorPalette(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Позиционирование панели
  const toolbarStyle = {
    position: 'absolute' as const,
    top: elementPosition.top - 60,
    left: elementPosition.left + elementPosition.width / 2,
    transform: 'translateX(-50%)',
    zIndex: 1000,
  };

  return (
    <div ref={toolbarRef} className={styles.toolbar} style={toolbarStyle}>
      {/* Шрифт */}
      <div className={styles.fontSection}>
        <div className={styles.dropdown}>
          <button
            className={styles.dropdownButton}
            onClick={() => setShowFontDropdown(!showFontDropdown)}
          >
            <Type size={16} />
            <ChevronDown size={14} />
          </button>
          {showFontDropdown && (
            <div className={styles.dropdownMenu}>
              {fontFamilies.map((font) => (
                <button
                  key={font}
                  className={classNames(styles.dropdownItem, {
                    [styles.active]: element.style.fontFamily === font,
                  })}
                  style={{ fontFamily: font }}
                  onClick={() => {
                    handleStyleUpdate({ fontFamily: font });
                    setShowFontDropdown(false);
                  }}
                >
                  {font.split(',')[0]}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Размер шрифта */}
      <div className={styles.sizeSection}>
        <button
          className={styles.sizeButton}
          onClick={() => handleFontSizeChange(-1)}
        >
          <Minus size={12} />
        </button>
        <span className={styles.sizeDisplay}>
          {element.style.fontSize || 16}
        </span>
        <button
          className={styles.sizeButton}
          onClick={() => handleFontSizeChange(1)}
        >
          <Plus size={12} />
        </button>
      </div>

      {/* Быстрые размеры */}
      <div className={styles.quickSizes}>
        {[12, 16, 20, 24, 32].map((size) => (
          <button
            key={size}
            className={classNames(styles.quickSizeButton, {
              [styles.active]: element.style.fontSize === size,
            })}
            onClick={() => handleStyleUpdate({ fontSize: size })}
          >
            {size}
          </button>
        ))}
      </div>

      <div className={styles.divider} />

      {/* Стили */}
      <div className={styles.styleSection}>
        <button
          className={classNames(styles.styleButton, {
            [styles.active]: element.style.fontWeight === 'bold',
          })}
          onClick={() => handleToggleStyle('bold')}
          title="Жирный"
        >
          <Bold size={16} />
        </button>

        <button
          className={classNames(styles.styleButton, {
            [styles.active]: element.style.fontStyle === 'italic',
          })}
          onClick={() => handleToggleStyle('italic')}
          title="Курсив"
        >
          <Italic size={16} />
        </button>

        <button
          className={classNames(styles.styleButton, {
            [styles.active]:
              element.style.textDecoration?.includes('underline'),
          })}
          onClick={() => handleToggleStyle('underline')}
          title="Подчеркивание"
        >
          <Underline size={16} />
        </button>

        <button
          className={classNames(styles.styleButton, {
            [styles.active]:
              element.style.textDecoration?.includes('line-through'),
          })}
          onClick={() => handleToggleStyle('strikethrough')}
          title="Зачеркивание"
        >
          <Strikethrough size={16} />
        </button>
      </div>

      <div className={styles.divider} />

      {/* Цвет */}
      <div className={styles.colorSection}>
        <div className={styles.dropdown}>
          <button
            className={styles.colorButton}
            onClick={() => setShowColorPalette(!showColorPalette)}
            style={{
              borderBottom: `3px solid ${element.style.color || '#000000'}`,
            }}
          >
            <Palette size={16} />
          </button>
          {showColorPalette && (
            <div className={styles.colorPalette}>
              <div className={styles.colorGrid}>
                {colorPresets.map((color) => (
                  <button
                    key={color}
                    className={classNames(styles.colorPreset, {
                      [styles.active]: element.style.color === color,
                    })}
                    style={{ backgroundColor: color }}
                    onClick={() => {
                      handleStyleUpdate({ color });
                      setShowColorPalette(false);
                    }}
                    title={color}
                  />
                ))}
              </div>
              <input
                type="color"
                value={element.style.color || '#000000'}
                onChange={(e) => handleStyleUpdate({ color: e.target.value })}
                className={styles.colorPicker}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export { SlideEditor } from './view/SlideEditor';

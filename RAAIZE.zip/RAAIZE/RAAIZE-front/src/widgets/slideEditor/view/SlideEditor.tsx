import { FC, useState, useRef, useCallback, useEffect } from 'react';
import { usePresentationStore, SlideElement } from '@src/entities/presentation';
import { Type, Image, List, Save, Download } from 'lucide-react';
import { ImagePicker } from '@src/features/imagePicker';
import { ExportModal } from '@src/features/exportModal';
import { TextToolbar } from '@src/widgets/textToolbar';
import classNames from 'classnames';
import styles from './SlideEditor.module.scss';

interface SlideEditorProps {
  className?: string;
}

export const SlideEditor: FC<SlideEditorProps> = ({ className }) => {
  const {
    currentPresentation,
    currentSlideIndex,
    selectedElementId,
    addElement,
    updateElement,
    deleteElement,
    selectElement,
    updateSlide,
    savePresentation,
  } = usePresentationStore();

  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [dragStartPos, setDragStartPos] = useState({ x: 0, y: 0 });
  const [resizeStartPos, setResizeStartPos] = useState({
    x: 0,
    y: 0,
    width: 0,
    height: 0,
  });
  const [resizeHandle, setResizeHandle] = useState<string>('');
  const [showImagePicker, setShowImagePicker] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showTextToolbar, setShowTextToolbar] = useState(false);
  const [textToolbarPosition, setTextToolbarPosition] =
    useState<DOMRect | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  const currentSlide = currentPresentation?.slides[currentSlideIndex];

  const handleAddTextElement = useCallback(() => {
    if (!currentSlide) return;

    const newElement: Omit<SlideElement, 'id'> = {
      type: 'text',
      position: { x: 100, y: 100, width: 300, height: 50 },
      style: {
        fontSize: 18,
        color: '#1e293b',
        textAlign: 'left',
      },
      content: { text: 'Новый текст' },
    };

    addElement(currentSlide.id, newElement);
  }, [currentSlide, addElement]);

  const handleAddListElement = useCallback(() => {
    if (!currentSlide) return;

    const newElement: Omit<SlideElement, 'id'> = {
      type: 'list',
      position: { x: 100, y: 100, width: 400, height: 150 },
      style: {
        fontSize: 16,
        color: '#1e293b',
        textAlign: 'left',
      },
      content: {
        listItems: ['Пункт 1', 'Пункт 2', 'Пункт 3'],
      },
    };

    addElement(currentSlide.id, newElement);
  }, [currentSlide, addElement]);

  const handleAddImageElement = useCallback(() => {
    setShowImagePicker(true);
  }, []);

  const handleImageSelect = useCallback(
    (imageUrl: string) => {
      if (!currentSlide) return;

      const newElement: Omit<SlideElement, 'id'> = {
        type: 'image',
        position: { x: 100, y: 100, width: 300, height: 200 },
        style: {},
        content: {
          imageUrl,
        },
      };

      addElement(currentSlide.id, newElement);
    },
    [currentSlide, addElement],
  );

  const handleElementMouseDown = useCallback(
    (element: SlideElement, event: React.MouseEvent) => {
      event.preventDefault();
      event.stopPropagation();

      if (!canvasRef.current) return;

      const rect = canvasRef.current.getBoundingClientRect();
      selectElement(element.id);
      setIsDragging(true);
      setDragStartPos({
        x: event.clientX - rect.left - element.position.x,
        y: event.clientY - rect.top - element.position.y,
      });

      // Показываем текстовую панель для текстовых элементов
      if (element.type === 'text') {
        const elementRect = new DOMRect(
          rect.left + element.position.x,
          rect.top + element.position.y,
          element.position.width,
          element.position.height,
        );
        setTextToolbarPosition(elementRect);
        setShowTextToolbar(true);
      } else {
        setShowTextToolbar(false);
      }
    },
    [selectElement],
  );

  const handleMouseMove = useCallback(
    (event: React.MouseEvent) => {
      if (!canvasRef.current || !selectedElementId || !currentSlide) return;

      const rect = canvasRef.current.getBoundingClientRect();
      const element = currentSlide.elements.find(
        (el) => el.id === selectedElementId,
      );
      if (!element) return;

      if (isDragging) {
        const newX = event.clientX - rect.left - dragStartPos.x;
        const newY = event.clientY - rect.top - dragStartPos.y;

        const finalX = Math.max(
          0,
          Math.min(newX, rect.width - element.position.width),
        );
        const finalY = Math.max(
          0,
          Math.min(newY, rect.height - element.position.height),
        );

        updateElement(currentSlide.id, selectedElementId, {
          position: {
            ...element.position,
            x: finalX,
            y: finalY,
          },
        });

        // Обновляем позицию панели инструментов для текстовых элементов
        if (element.type === 'text' && showTextToolbar) {
          const elementRect = new DOMRect(
            rect.left + finalX,
            rect.top + finalY,
            element.position.width,
            element.position.height,
          );
          setTextToolbarPosition(elementRect);
        }
      } else if (isResizing) {
        const currentX = event.clientX - rect.left;
        const currentY = event.clientY - rect.top;
        const deltaX = currentX - resizeStartPos.x;
        const deltaY = currentY - resizeStartPos.y;

        let newWidth = resizeStartPos.width;
        let newHeight = resizeStartPos.height;
        let newX = element.position.x;
        let newY = element.position.y;

        switch (resizeHandle) {
          case 'se': // Юго-восток
            newWidth = Math.max(50, resizeStartPos.width + deltaX);
            newHeight = Math.max(30, resizeStartPos.height + deltaY);
            break;
          case 'sw': // Юго-запад
            newWidth = Math.max(50, resizeStartPos.width - deltaX);
            newHeight = Math.max(30, resizeStartPos.height + deltaY);
            newX = element.position.x + (resizeStartPos.width - newWidth);
            break;
          case 'ne': // Северо-восток
            newWidth = Math.max(50, resizeStartPos.width + deltaX);
            newHeight = Math.max(30, resizeStartPos.height - deltaY);
            newY = element.position.y + (resizeStartPos.height - newHeight);
            break;
          case 'nw': // Северо-запад
            newWidth = Math.max(50, resizeStartPos.width - deltaX);
            newHeight = Math.max(30, resizeStartPos.height - deltaY);
            newX = element.position.x + (resizeStartPos.width - newWidth);
            newY = element.position.y + (resizeStartPos.height - newHeight);
            break;
          case 'e': // Восток
            newWidth = Math.max(50, resizeStartPos.width + deltaX);
            break;
          case 'w': // Запад
            newWidth = Math.max(50, resizeStartPos.width - deltaX);
            newX = element.position.x + (resizeStartPos.width - newWidth);
            break;
          case 's': // Юг
            newHeight = Math.max(30, resizeStartPos.height + deltaY);
            break;
          case 'n': // Север
            newHeight = Math.max(30, resizeStartPos.height - deltaY);
            newY = element.position.y + (resizeStartPos.height - newHeight);
            break;
        }

        // Соблюдаем пропорции при зажатом Shift
        if (event.shiftKey && ['se', 'sw', 'ne', 'nw'].includes(resizeHandle)) {
          const aspectRatio = resizeStartPos.width / resizeStartPos.height;
          if (Math.abs(deltaX) > Math.abs(deltaY)) {
            newHeight = newWidth / aspectRatio;
          } else {
            newWidth = newHeight * aspectRatio;
          }

          // Корректируем позицию для точек с изменением X или Y
          if (resizeHandle.includes('w')) {
            newX = element.position.x + (resizeStartPos.width - newWidth);
          }
          if (resizeHandle.includes('n')) {
            newY = element.position.y + (resizeStartPos.height - newHeight);
          }
        }

        updateElement(currentSlide.id, selectedElementId, {
          position: {
            x: Math.max(0, Math.min(newX, rect.width - newWidth)),
            y: Math.max(0, Math.min(newY, rect.height - newHeight)),
            width: Math.min(newWidth, rect.width - newX),
            height: Math.min(newHeight, rect.height - newY),
          },
        });
      }
    },
    [
      isDragging,
      isResizing,
      selectedElementId,
      currentSlide,
      dragStartPos,
      resizeStartPos,
      resizeHandle,
      updateElement,
      showTextToolbar,
    ],
  );

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsResizing(false);
    setResizeHandle('');
  }, []);

  const handleResizeStart = useCallback(
    (element: SlideElement, handle: string, event: React.MouseEvent) => {
      event.preventDefault();
      event.stopPropagation();

      if (!canvasRef.current) return;

      const rect = canvasRef.current.getBoundingClientRect();
      setIsResizing(true);
      setResizeHandle(handle);
      setResizeStartPos({
        x: event.clientX - rect.left,
        y: event.clientY - rect.top,
        width: element.position.width,
        height: element.position.height,
      });
    },
    [],
  );

  const handleCanvasClick = useCallback(
    (event: React.MouseEvent) => {
      if (event.target === event.currentTarget) {
        selectElement(null);
        setShowTextToolbar(false);
      }
    },
    [selectElement],
  );

  const handleElementContentChange = useCallback(
    (elementId: string, newContent: string) => {
      if (!currentSlide) return;

      const element = currentSlide.elements.find((el) => el.id === elementId);
      if (!element) return;

      if (element.type === 'text') {
        updateElement(currentSlide.id, elementId, {
          content: { ...element.content, text: newContent },
        });
      }
    },
    [currentSlide, updateElement],
  );

  const handleElementDoubleClick = useCallback(
    (elementId: string, event: React.MouseEvent) => {
      event.preventDefault();
      event.stopPropagation();

      const element = currentSlide?.elements.find((el) => el.id === elementId);
      if (element && (element.type === 'text' || element.type === 'list')) {
        setIsEditing(elementId);
      }
    },
    [currentSlide],
  );

  const handleEditingBlur = useCallback(() => {
    setIsEditing(null);
  }, []);

  const handleEditingKeyDown = useCallback((event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      setIsEditing(null);
    }
    if (event.key === 'Escape') {
      setIsEditing(null);
    }
  }, []);

  // Обработчик клавиатуры для навигации элементов
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!selectedElementId || !currentSlide || isEditing) return;

      const element = currentSlide.elements.find(
        (el) => el.id === selectedElementId,
      );
      if (!element) return;

      const step = event.shiftKey ? 10 : 1;
      const newPosition = { ...element.position };

      switch (event.key) {
        case 'ArrowLeft':
          event.preventDefault();
          newPosition.x = Math.max(0, element.position.x - step);
          break;
        case 'ArrowRight':
          event.preventDefault();
          newPosition.x = Math.min(
            (canvasRef.current?.clientWidth || 800) - element.position.width,
            element.position.x + step,
          );
          break;
        case 'ArrowUp':
          event.preventDefault();
          newPosition.y = Math.max(0, element.position.y - step);
          break;
        case 'ArrowDown':
          event.preventDefault();
          newPosition.y = Math.min(
            (canvasRef.current?.clientHeight || 600) - element.position.height,
            element.position.y + step,
          );
          break;
        case 'Delete':
        case 'Backspace': {
          event.preventDefault();
          deleteElement(currentSlide.id, selectedElementId);
          selectElement(null);
          return;
        }
        default:
          return;
      }

      if (
        newPosition.x !== element.position.x ||
        newPosition.y !== element.position.y
      ) {
        updateElement(currentSlide.id, selectedElementId, {
          position: newPosition,
        });
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [
    selectedElementId,
    currentSlide,
    isEditing,
    updateElement,
    selectElement,
    deleteElement,
  ]);

  const handleSlideBackgroundChange = useCallback(
    (color: string) => {
      if (!currentSlide) return;

      updateSlide(currentSlide.id, {
        backgroundStyle: { ...currentSlide.backgroundStyle, color },
      });
    },
    [currentSlide, updateSlide],
  );

  const handleSave = useCallback(() => {
    savePresentation();
  }, [savePresentation]);

  if (!currentPresentation || !currentSlide) {
    return (
      <div className={classNames(styles.slideEditor, className)}>
        <div className={styles.emptyState}>
          <p>Выберите или создайте презентацию для редактирования</p>
        </div>
      </div>
    );
  }

  return (
    <div className={classNames(styles.slideEditor, className)}>
      {/* Панель инструментов */}
      <div className={styles.toolbar}>
        <div className={styles.toolGroup}>
          <button
            className={styles.toolButton}
            onClick={handleAddTextElement}
            title="Добавить текст"
          >
            <Type size={18} />
            <span>Текст</span>
          </button>

          <button
            className={styles.toolButton}
            onClick={handleAddListElement}
            title="Добавить список"
          >
            <List size={18} />
            <span>Список</span>
          </button>

          <button
            className={styles.toolButton}
            onClick={handleAddImageElement}
            title="Добавить изображение"
          >
            <Image size={18} />
            <span>Изображение</span>
          </button>
        </div>

        <div className={styles.toolGroup}>
          <div className={styles.backgroundPicker}>
            <label>Фон:</label>
            <input
              type="color"
              value={currentSlide.backgroundStyle.color || '#ffffff'}
              onChange={(e) => handleSlideBackgroundChange(e.target.value)}
              className={styles.colorInput}
            />
          </div>
        </div>

        <div className={styles.toolGroup}>
          <button
            className={classNames(styles.toolButton, styles.saveButton)}
            onClick={handleSave}
            title="Сохранить"
          >
            <Save size={18} />
            <span>Сохранить</span>
          </button>

          <button
            className={styles.toolButton}
            onClick={() => setShowExportModal(true)}
            title="Экспорт презентации"
          >
            <Download size={18} />
            <span>Экспорт</span>
          </button>
        </div>
      </div>

      {/* Канвас для редактирования */}
      <div className={styles.canvasContainer}>
        <div className={styles.slideTitle}>
          <input
            type="text"
            value={currentSlide.title}
            onChange={(e) =>
              updateSlide(currentSlide.id, { title: e.target.value })
            }
            className={styles.titleInput}
            placeholder="Заголовок слайда"
          />
        </div>

        <div
          ref={canvasRef}
          className={styles.canvas}
          style={{
            backgroundColor: currentSlide.backgroundStyle.color || '#ffffff',
          }}
          onClick={handleCanvasClick}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {currentSlide.elements.map((element) => (
            <div
              key={element.id}
              className={classNames(styles.element, {
                [styles.selected]: element.id === selectedElementId,
                [styles.dragging]:
                  isDragging && element.id === selectedElementId,
                [styles.resizing]:
                  isResizing && element.id === selectedElementId,
              })}
              style={{
                left: element.position.x,
                top: element.position.y,
                width: element.position.width,
                height: element.position.height,
                fontSize: element.style.fontSize,
                fontFamily: element.style.fontFamily,
                color: element.style.color,
                textAlign: element.style.textAlign,
                fontWeight: element.style.fontWeight,
                fontStyle: element.style.fontStyle,
                textDecoration: element.style.textDecoration,
              }}
              onMouseDown={(e) => handleElementMouseDown(element, e)}
              onDoubleClick={(e) => handleElementDoubleClick(element.id, e)}
            >
              {element.type === 'text' && (
                <>
                  {isEditing === element.id ? (
                    <textarea
                      value={element.content.text || ''}
                      onChange={(e) =>
                        handleElementContentChange(element.id, e.target.value)
                      }
                      onBlur={handleEditingBlur}
                      onKeyDown={handleEditingKeyDown}
                      className={classNames(styles.textInput, styles.editing)}
                      style={{
                        fontSize: element.style.fontSize,
                        fontFamily: element.style.fontFamily,
                        color: element.style.color,
                        textAlign: element.style.textAlign,
                        fontWeight: element.style.fontWeight,
                        fontStyle: element.style.fontStyle,
                        textDecoration: element.style.textDecoration,
                      }}
                      autoFocus
                    />
                  ) : (
                    <div
                      className={styles.textDisplay}
                      style={{
                        fontSize: element.style.fontSize,
                        fontFamily: element.style.fontFamily,
                        color: element.style.color,
                        textAlign: element.style.textAlign,
                        fontWeight: element.style.fontWeight,
                        fontStyle: element.style.fontStyle,
                        textDecoration: element.style.textDecoration,
                      }}
                    >
                      {element.content.text || 'Пустой текст'}
                    </div>
                  )}
                </>
              )}

              {element.type === 'list' && (
                <div className={styles.listElement}>
                  {element.content.listItems?.map((item, index) => (
                    <div key={index} className={styles.listItem}>
                      • {item}
                    </div>
                  ))}
                </div>
              )}

              {element.type === 'image' && (
                <img
                  src={element.content.imageUrl || ''}
                  alt="Slide content"
                  className={styles.imageElement}
                />
              )}

              {element.id === selectedElementId && !isEditing && (
                <div className={styles.selectionBorder}>
                  {/* Угловые ресайзеры */}
                  <div
                    className={`${styles.resizeHandle} ${styles.nw}`}
                    onMouseDown={(e) => handleResizeStart(element, 'nw', e)}
                  />
                  <div
                    className={`${styles.resizeHandle} ${styles.ne}`}
                    onMouseDown={(e) => handleResizeStart(element, 'ne', e)}
                  />
                  <div
                    className={`${styles.resizeHandle} ${styles.sw}`}
                    onMouseDown={(e) => handleResizeStart(element, 'sw', e)}
                  />
                  <div
                    className={`${styles.resizeHandle} ${styles.se}`}
                    onMouseDown={(e) => handleResizeStart(element, 'se', e)}
                  />

                  {/* Боковые ресайзеры */}
                  <div
                    className={`${styles.resizeHandle} ${styles.n}`}
                    onMouseDown={(e) => handleResizeStart(element, 'n', e)}
                  />
                  <div
                    className={`${styles.resizeHandle} ${styles.s}`}
                    onMouseDown={(e) => handleResizeStart(element, 's', e)}
                  />
                  <div
                    className={`${styles.resizeHandle} ${styles.w}`}
                    onMouseDown={(e) => handleResizeStart(element, 'w', e)}
                  />
                  <div
                    className={`${styles.resizeHandle} ${styles.e}`}
                    onMouseDown={(e) => handleResizeStart(element, 'e', e)}
                  />
                </div>
              )}
            </div>
          ))}

          {currentSlide.elements.length === 0 && (
            <div className={styles.emptyCanvas}>
              <p>Нажмите на кнопки выше, чтобы добавить элементы на слайд</p>
            </div>
          )}
        </div>
      </div>

      {/* Панель свойств выбранного элемента */}
      {selectedElementId && (
        <div className={styles.propertiesPanel}>
          <h4>Свойства элемента</h4>
          {/* Здесь будут элементы управления свойствами */}
        </div>
      )}

      {/* Модальное окно выбора изображений */}
      <ImagePicker
        isOpen={showImagePicker}
        onClose={() => setShowImagePicker(false)}
        onSelectImage={handleImageSelect}
        initialQuery={currentSlide?.title || ''}
      />

      {/* Модальное окно экспорта */}
      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
      />

      {/* Плавающая панель инструментов для текста */}
      {showTextToolbar &&
        selectedElementId &&
        textToolbarPosition &&
        (() => {
          const selectedElement = currentSlide?.elements.find(
            (el) => el.id === selectedElementId,
          );
          return selectedElement && selectedElement.type === 'text' ? (
            <TextToolbar
              element={selectedElement}
              elementPosition={textToolbarPosition}
            />
          ) : null;
        })()}
    </div>
  );
};

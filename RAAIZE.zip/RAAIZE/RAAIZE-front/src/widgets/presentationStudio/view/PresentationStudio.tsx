import { FC } from 'react';
import { SlidesList } from '@src/widgets/slidesList';
import { SlideEditor } from '@src/widgets/slideEditor';
import { ChatBlock } from '@src/widgets/chatBlock/view/ChatBlock';
import { usePresentationStore } from '@src/entities/presentation';
import classNames from 'classnames';
import styles from './PresentationStudio.module.scss';

interface PresentationStudioProps {
  className?: string;
}

export const PresentationStudio: FC<PresentationStudioProps> = ({
  className,
}) => {
  const { currentPresentation } = usePresentationStore();

  return (
    <div className={classNames(styles.studio, className)}>
      {/* Левая панель: Список слайдов */}
      <div className={styles.leftPanel}>
        <SlidesList />
      </div>

      {/* Центральная область: Редактор слайдов */}
      <div className={styles.centerPanel}>
        {currentPresentation ? (
          <SlideEditor />
        ) : (
          <div className={styles.welcomeScreen}>
            <div className={styles.welcomeContent}>
              <h2>Добро пожаловать в AI Презентации!</h2>
              <p>
                Создавайте профессиональные презентации с помощью искусственного
                интеллекта
              </p>
              <div className={styles.features}>
                <div className={styles.feature}>
                  <div className={styles.featureIcon}>🤖</div>
                  <h3>AI Генерация</h3>
                  <p>Просто опишите тему, и мы создадим полную презентацию</p>
                </div>
                <div className={styles.feature}>
                  <div className={styles.featureIcon}>✏️</div>
                  <h3>Легкое редактирование</h3>
                  <p>
                    Перетаскивайте элементы, редактируйте тексты, меняйте стили
                  </p>
                </div>
                <div className={styles.feature}>
                  <div className={styles.featureIcon}>📤</div>
                  <h3>Экспорт в любом формате</h3>
                  <p>Сохраняйте в PDF, PPTX или просто презентуйте онлайн</p>
                </div>
              </div>
              <div className={styles.getStarted}>
                <p>
                  <strong>Начните прямо сейчас:</strong> опишите тему вашей
                  презентации в чате справа →
                </p>
                <button
                  className={styles.createTestButton}
                  onClick={() => {
                    const { createPresentation } =
                      usePresentationStore.getState();
                    createPresentation('Тестовая презентация');
                  }}
                >
                  Создать тестовую презентацию
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Правая панель: Чат с AI */}
      <div className={styles.rightPanel}>
        <ChatBlock />
      </div>
    </div>
  );
};

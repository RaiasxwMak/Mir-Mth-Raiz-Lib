import { FC } from 'react';
import { usePresentationStore } from '@src/entities/presentation';
import { Plus, Copy, Trash2, GripVertical } from 'lucide-react';
import classNames from 'classnames';
import styles from './SlidesList.module.scss';

interface SlidesListProps {
  className?: string;
}

export const SlidesList: FC<SlidesListProps> = ({ className }) => {
  const {
    currentPresentation,
    currentSlideIndex,
    setCurrentSlide,
    addSlide,
    deleteSlide,
    duplicateSlide,
  } = usePresentationStore();

  if (!currentPresentation) {
    return (
      <div className={classNames(styles.slidesList, className)}>
        <div className={styles.emptyState}>
          <p>Нет активной презентации</p>
        </div>
      </div>
    );
  }

  const handleAddSlide = () => {
    addSlide();
  };

  const handleDeleteSlide = (slideId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    if (currentPresentation.slides.length > 1) {
      deleteSlide(slideId);
    }
  };

  const handleDuplicateSlide = (slideId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    duplicateSlide(slideId);
  };

  return (
    <div className={classNames(styles.slidesList, className)}>
      <div className={styles.header}>
        <h3 className={styles.title}>Слайды</h3>
        <button
          className={styles.addButton}
          onClick={handleAddSlide}
          title="Добавить слайд"
        >
          <Plus size={16} />
        </button>
      </div>

      <div className={styles.slidesContainer}>
        {currentPresentation.slides.map((slide, index) => (
          <div
            key={slide.id}
            className={classNames(styles.slideItem, {
              [styles.active]: index === currentSlideIndex,
            })}
            onClick={() => setCurrentSlide(index)}
          >
            <div className={styles.slideNumber}>{index + 1}</div>

            <div className={styles.slidePreview}>
              <div className={styles.slideTitle}>
                {slide.title || `Слайд ${index + 1}`}
              </div>
              <div className={styles.slideContent}>
                {slide.elements.length > 0 ? (
                  <div className={styles.elementsPreview}>
                    {slide.elements.slice(0, 3).map((element) => (
                      <div
                        key={element.id}
                        className={styles.elementPreview}
                        style={{ fontSize: '8px' }}
                      >
                        {element.type === 'text' && element.content.text && (
                          <span>
                            {element.content.text.substring(0, 30)}...
                          </span>
                        )}
                        {element.type === 'list' &&
                          element.content.listItems && (
                            <span>
                              • {element.content.listItems[0]?.substring(0, 20)}
                              ...
                            </span>
                          )}
                        {element.type === 'image' && (
                          <span>🖼️ Изображение</span>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className={styles.emptySlide}>Пустой слайд</div>
                )}
              </div>
            </div>

            <div className={styles.slideActions}>
              <button
                className={styles.actionButton}
                onClick={(e) => handleDuplicateSlide(slide.id, e)}
                title="Дублировать слайд"
              >
                <Copy size={12} />
              </button>

              {currentPresentation.slides.length > 1 && (
                <button
                  className={classNames(
                    styles.actionButton,
                    styles.deleteButton,
                  )}
                  onClick={(e) => handleDeleteSlide(slide.id, e)}
                  title="Удалить слайд"
                >
                  <Trash2 size={12} />
                </button>
              )}

              <button
                className={classNames(styles.actionButton, styles.dragHandle)}
                title="Перетащить"
              >
                <GripVertical size={12} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

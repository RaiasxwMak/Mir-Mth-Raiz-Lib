export { SlidesList } from './view/SlidesList';

import { FC, useState } from 'react';
import { usePresentationStore } from '@src/entities/presentation';
import {
  PresentationExportService,
  ExportOptions,
} from '@src/shared/services/exportService';
import { Download, FileText, Image, File, X } from 'lucide-react';
import classNames from 'classnames';
import styles from './ExportModal.module.scss';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const { currentPresentation } = usePresentationStore();
  const [selectedFormat, setSelectedFormat] = useState<
    'html' | 'pdf' | 'png' | 'pptx'
  >('html');
  const [options, setOptions] = useState<Partial<ExportOptions>>({
    quality: 'high',
    includeNotes: false,
    slideSize: '16:9',
  });
  const [isExporting, setIsExporting] = useState(false);

  const exportFormats = [
    {
      id: 'html' as const,
      name: 'HTML',
      description: 'Веб-страница для просмотра и печати',
      icon: FileText,
      color: '#e16426',
    },
    {
      id: 'pdf' as const,
      name: 'PDF',
      description: 'Документ PDF (экспериментально)',
      icon: File,
      color: '#dc2626',
    },
    {
      id: 'png' as const,
      name: 'PNG',
      description: 'Изображения слайдов',
      icon: Image,
      color: '#059669',
    },
    {
      id: 'pptx' as const,
      name: 'PowerPoint',
      description: 'Файл презентации (как HTML)',
      icon: File,
      color: '#d97706',
    },
  ];

  const handleExport = async () => {
    if (!currentPresentation) return;

    setIsExporting(true);
    try {
      const exportOptions: ExportOptions = {
        format: selectedFormat,
        ...options,
      };

      await PresentationExportService.exportPresentation(
        currentPresentation,
        exportOptions,
      );
      onClose();
    } catch (error) {
      console.error('Export failed:', error);
      alert(
        'Ошибка экспорта: ' +
          (error instanceof Error ? error.message : 'Неизвестная ошибка'),
      );
    } finally {
      setIsExporting(false);
    }
  };

  if (!isOpen || !currentPresentation) return null;

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div className={styles.header}>
          <h2>Экспорт презентации</h2>
          <button className={styles.closeButton} onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <div className={styles.content}>
          <div className={styles.presentationInfo}>
            <h3>{currentPresentation.title}</h3>
            <p>{currentPresentation.slides.length} слайдов</p>
          </div>

          <div className={styles.section}>
            <h4>Выберите формат экспорта:</h4>
            <div className={styles.formatGrid}>
              {exportFormats.map((format) => {
                const Icon = format.icon;
                return (
                  <button
                    key={format.id}
                    className={classNames(styles.formatCard, {
                      [styles.selected]: selectedFormat === format.id,
                    })}
                    onClick={() => setSelectedFormat(format.id)}
                  >
                    <div
                      className={styles.formatIcon}
                      style={{ color: format.color }}
                    >
                      <Icon size={32} />
                    </div>
                    <div className={styles.formatInfo}>
                      <h5>{format.name}</h5>
                      <p>{format.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className={styles.section}>
            <h4>Настройки экспорта:</h4>
            <div className={styles.optionsGrid}>
              <div className={styles.option}>
                <label>
                  <input
                    type="checkbox"
                    checked={options.includeNotes || false}
                    onChange={(e) =>
                      setOptions((prev) => ({
                        ...prev,
                        includeNotes: e.target.checked,
                      }))
                    }
                  />
                  Включить заметки спикера
                </label>
              </div>

              <div className={styles.option}>
                <label htmlFor="quality">Качество:</label>
                <select
                  id="quality"
                  value={options.quality || 'high'}
                  onChange={(e) =>
                    setOptions((prev) => ({
                      ...prev,
                      quality: e.target.value as 'low' | 'medium' | 'high',
                    }))
                  }
                >
                  <option value="low">Низкое</option>
                  <option value="medium">Среднее</option>
                  <option value="high">Высокое</option>
                </select>
              </div>

              <div className={styles.option}>
                <label htmlFor="slideSize">Формат слайдов:</label>
                <select
                  id="slideSize"
                  value={options.slideSize || '16:9'}
                  onChange={(e) =>
                    setOptions((prev) => ({
                      ...prev,
                      slideSize: e.target.value as '16:9' | '4:3',
                    }))
                  }
                >
                  <option value="16:9">16:9 (широкоэкранный)</option>
                  <option value="4:3">4:3 (стандартный)</option>
                </select>
              </div>
            </div>
          </div>

          {selectedFormat === 'png' && (
            <div className={styles.notice}>
              <p>
                <strong>Примечание:</strong> При экспорте в PNG каждый слайд
                будет сохранен как отдельное изображение.
              </p>
            </div>
          )}

          {(selectedFormat === 'pdf' || selectedFormat === 'pptx') && (
            <div className={styles.notice}>
              <p>
                <strong>Примечание:</strong> Экспорт в{' '}
                {selectedFormat.toUpperCase()} находится в разработке. Пока что
                файл будет сохранен как HTML.
              </p>
            </div>
          )}
        </div>

        <div className={styles.footer}>
          <button
            className={styles.cancelButton}
            onClick={onClose}
            disabled={isExporting}
          >
            Отмена
          </button>
          <button
            className={styles.exportButton}
            onClick={handleExport}
            disabled={isExporting}
          >
            {isExporting ? (
              <>
                <div className={styles.spinner}>⏳</div>
                Экспортируется...
              </>
            ) : (
              <>
                <Download size={20} />
                Экспортировать
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

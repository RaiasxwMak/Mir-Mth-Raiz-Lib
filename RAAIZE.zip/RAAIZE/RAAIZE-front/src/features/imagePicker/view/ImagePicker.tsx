import { FC, useState, useEffect } from 'react';
import {
  ImageService,
  ImageSearchResult,
} from '@src/shared/services/imageService';
import { Search, X, Download } from 'lucide-react';
import classNames from 'classnames';
import styles from './ImagePicker.module.scss';

interface ImagePickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectImage: (imageUrl: string) => void;
  initialQuery?: string;
}

export const ImagePicker: FC<ImagePickerProps> = ({
  isOpen,
  onClose,
  onSelectImage,
  initialQuery = '',
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [images, setImages] = useState<ImageSearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  const categories = [
    { id: 'business', label: 'Бизнес', query: 'business meeting office' },
    {
      id: 'technology',
      label: 'Технологии',
      query: 'technology computer innovation',
    },
    {
      id: 'education',
      label: 'Образование',
      query: 'education learning books',
    },
    { id: 'creative', label: 'Творчество', query: 'creative art design' },
    { id: 'nature', label: 'Природа', query: 'nature landscape scenery' },
  ];

  const searchImages = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    try {
      const results = await ImageService.searchImages(searchQuery, 24);
      setImages(results);
    } catch (error) {
      console.error('Error searching images:', error);
      setImages([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = () => {
    searchImages(query);
  };

  const handleCategorySelect = (category: (typeof categories)[0]) => {
    setSelectedCategory(category.id);
    setQuery(category.query);
    searchImages(category.query);
  };

  const handleImageSelect = (image: ImageSearchResult) => {
    onSelectImage(image.url);
    onClose();
  };

  useEffect(() => {
    if (isOpen && initialQuery) {
      setQuery(initialQuery);
      searchImages(initialQuery);
    }
  }, [isOpen, initialQuery]);

  if (!isOpen) return null;

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div className={styles.header}>
          <h2>Выбрать изображение</h2>
          <button className={styles.closeButton} onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <div className={styles.searchSection}>
          <div className={styles.searchBox}>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Поиск изображений..."
              className={styles.searchInput}
            />
            <button
              onClick={handleSearch}
              className={styles.searchButton}
              disabled={isLoading}
            >
              <Search size={20} />
            </button>
          </div>

          <div className={styles.categories}>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => handleCategorySelect(category)}
                className={classNames(styles.categoryButton, {
                  [styles.active]: selectedCategory === category.id,
                })}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        <div className={styles.content}>
          {isLoading && (
            <div className={styles.loading}>
              <div className={styles.spinner}>⏳</div>
              <p>Поиск изображений...</p>
            </div>
          )}

          {!isLoading && images.length === 0 && query && (
            <div className={styles.noResults}>
              <p>Изображения не найдены</p>
              <p>Попробуйте изменить поисковый запрос</p>
            </div>
          )}

          {!isLoading && images.length === 0 && !query && (
            <div className={styles.initialState}>
              <Download size={48} className={styles.initialIcon} />
              <h3>Найдите идеальное изображение</h3>
              <p>Введите ключевые слова в поиск или выберите категорию</p>
            </div>
          )}

          {images.length > 0 && (
            <div className={styles.imageGrid}>
              {images.map((image) => (
                <div
                  key={image.id}
                  className={styles.imageCard}
                  onClick={() => handleImageSelect(image)}
                >
                  <img
                    src={image.thumbnailUrl}
                    alt={image.description}
                    className={styles.image}
                    loading="lazy"
                  />
                  <div className={styles.imageOverlay}>
                    <div className={styles.imageInfo}>
                      <p className={styles.imageDescription}>
                        {image.description}
                      </p>
                      <p className={styles.imageAuthor}>by {image.author}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

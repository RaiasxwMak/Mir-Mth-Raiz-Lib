import { FC } from 'react';
import { CustomButton, Typography } from '@src/shared/ui';
import styles from './LessonForm.module.scss';
import { LessonProps } from '../types/types';

export const LessonForm: FC<LessonProps> = ({
  title,
  description,
  videoUrl,
  materials,
}) => {
  return (
    <div className={styles.lesson}>
      <div className="btn">
        <Typography variant="h3">{title}</Typography>
        <CustomButton>Submit</CustomButton>
      </div>
      <Typography variant="bodyText">{description}</Typography>
      <iframe src={videoUrl}></iframe>
      <Typography variant="bodyText">{materials}</Typography>
      
    </div>
  );
};

import { Container, LessonForm } from '@src/shared/ui';
import { useLessonQuery } from '@src/widgets/lessonStudent/api/lessonQuery';
import { FC } from 'react';

export const Lesson: FC = () => {
  const { data } = useLessonQuery();
  return (
    <Container>
      <LessonForm
        title={data?.title }
        description={data?.description}
        videoUrl={data?.videoUrl}
        materials={data?.materials}
      />
    </Container>
  );
};

import { useFetchTeacherEdit } from 'entities/InfoTeacher/model/useFetchInfoTeacher';
import { useCreateAvatar } from 'features/CreateAvatarInfo/model/CreateAvatarInfo';
import { FC } from 'react';
import { useParams } from 'react-router-dom';
import CreateAvatar from 'shared/ui/CreateAvatar/CreateAvatar';

interface IPropsEdit {
  photo: string | null;
}

const InfoEditAva: FC<IPropsEdit> = ({ photo }) => {
  const {  image, setImage } = useCreateAvatar();
  const { user_id = '' } = useParams();
  const { mutateAsync } = useFetchTeacherEdit(user_id);

  const handleAsyncChange = async (param:File) => {
    return mutateAsync({ photo: param })
  };

  return (
    <CreateAvatar 
      asCb={handleAsyncChange}
      image={image} 
      setImage={setImage} 
      src={photo} 
      avatarSize={140}/>
  )
}

export default InfoEditAva;

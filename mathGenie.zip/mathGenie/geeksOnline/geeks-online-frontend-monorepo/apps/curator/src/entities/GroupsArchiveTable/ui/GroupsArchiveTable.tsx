import cls from "./GroupsArchiveTable.module.scss";
import TableList from "shared/ui/TableList/TableList";
import CustomPagination, {
  usePageChange,
} from "shared/ui/CustomPagination/CustomPagination";
import { Loader, Typography } from "shared/ui";
import { getMonthNumber } from "shared/lib/helpers/helpers";
import { useEffect } from "react";
import useFilterMemoryNavigate from "shared/lib/useFilterMemoryNavigate/useFilterMemoryNavigate";
import { useFetchArchiveGroups } from "../model/useFetchArchiveGroups";
import { EmptyState } from "@geeks-online/uikit";

export const GroupsArchiveTable = () => {
  const { data, isLoading } = useFetchArchiveGroups();
  const { resetPage } = usePageChange();
  const navigateWithMemory = useFilterMemoryNavigate();

  const headList = ["№", "Направление", "Группа", "Месяц", "Урок"];

  useEffect(() => {
    return () => resetPage();
  }, []);

  const handleNavigate = (url: string) => navigateWithMemory(url);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={cls.groups}>
        <TableList headList={headList}>
          {data?.results?.map((group, index) => (
            <li
              className={cls.group}
              onClick={() =>
                handleNavigate(
                  `/curator/groups/${group.id}/?month_id=${group.month_id}`
                )
              }
              key={group.id}
            >
              <Typography variant="Text2">{index + 1}</Typography>
              <Typography variant="Text2">
                {group?.course?.title || "-"}
              </Typography>
              <Typography variant="Text2">{group?.title || "-"}</Typography>
              <Typography variant="Text2">
                {getMonthNumber(`${group?.course?.months ?? "-"}`)}
              </Typography>
              <Typography variant="Text2">
                {getMonthNumber(group?.lesson ?? "-")}
              </Typography>
            </li>
          ))}
        </TableList>
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

import cls from "./ProfileInfo.module.scss";
import {
  useFetchProfile,
  useFetchProfileEdit,
} from "entities/ProfileInfo/model/useFetchProfile";
import { FC } from "react";
import EditProfileAva from "./EditProfileAva/EditProfileAva";
import { Loader } from "shared/ui";
import { AsyncInput } from "@geeks-online/uikit";

const ProfileInfo: FC = () => {
  const { data, isLoading } = useFetchProfile();
  const { mutateAsync } = useFetchProfileEdit();

  const editInputs = [
    {
      label: "ФИО",
      star: "*",
      value: data?.user.full_name ?? "",
      name: "full_name",
      disabled: true,
    },
    {
      label: "Телеграм",
      star: "*",
      value: data?.user.telegram ?? "",
      name: "telegram",
      disabled: data?.user.is_supreme ? true : false,
    },
    {
      label: "Номер телефона",
      star: "*",
      value: data?.user.phone ?? "",
      name: "phone",
      mask: "+***************************************",
      disabled: data?.user.is_supreme ? true : false,
    },
  ];

  const emailError = { 400: "Неверный формат" };

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  if (isLoading) return <Loader />;
  return (
    <div className={cls.profile}>
      <EditProfileAva photo={data?.user?.photo} />
      <div className={cls.row}>
        {editInputs.map((item, index) => (
          <div key={index}>
            <label htmlFor={item.name}>
              <p>
                {item.label} <span>{item.star}</span>
              </p>
              <AsyncInput
                mask={item?.mask}
                className={cls.input}
                key={item.value}
                disabled={item.disabled}
                value={item.value}
                customError={emailError}
                asyncCallBack={(val) => handleChangeAsync(val, item.name)}
                id={item.name}
                name={item.name}
              />
            </label>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProfileInfo;

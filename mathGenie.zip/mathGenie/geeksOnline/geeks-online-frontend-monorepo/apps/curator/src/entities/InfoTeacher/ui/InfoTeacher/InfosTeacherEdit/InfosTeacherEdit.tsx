import cls from "./InfosTeacherEdit.module.scss";
import { FC } from "react";
import { useParams } from "react-router-dom";
import {
  useFetchInfoTeacher,
  useFetchTeacherEdit,
} from "entities/InfoTeacher/model/useFetchInfoTeacher";
import InfoEditAva from "../../InfoEditAva/InfoEditAva";
import { Loader } from "shared/ui";
import ChangePassword from "features/ChangePassword/ui/ChangePassword";
import ArchiveTeacherButton from "features/ArchiveTeacher/ui/ArchiveTeacherButton/ArchiveTeacherButton";
import ArchiveTeacherRecovery from "features/ArchiveTeacher/ui/ArchiveTeacherRecovery/ArchiveTeacherRecovery";
import { AsyncInput } from "@geeks-online/uikit";

const InfosTeacherEdit: FC = () => {
  const { user_id = "" } = useParams();
  const { data, isLoading } = useFetchInfoTeacher(user_id);
  const { mutateAsync } = useFetchTeacherEdit(user_id);

  const editInputs = [
    {
      label: "ФИО",
      star: "*",
      value: data?.full_name ?? "",
      name: "full_name",
    },
    {
      label: "Логин",
      star: "*",
      value: data?.username ?? "",
      name: "username",
    },
    {
      label: "Телеграм",
      star: "*",
      value: data?.telegram ?? "",
      name: "telegram",
    },
    {
      label: "Номер телефона",
      star: "*",
      value: data?.phone ?? "",
      name: "phone",
      mask: "+***************************************",
    },
    { label: "Почта", value: data?.email ?? "", name: "email" },
  ];

  const emailError = { 400: "Неверный формат" };

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  if (isLoading) return <Loader />;
  return (
    <>
      <InfoEditAva photo={data?.photo ?? ""} />
      <div className={cls.row}>
        {editInputs.map((item, index) => (
          <div key={index}>
            <label htmlFor={item.name}>
              <p>
                {item.label} <span>{item.star}</span>
              </p>
              <AsyncInput
                mask={item?.mask}
                className={cls.input}
                key={item.value}
                value={item.value}
                customError={emailError}
                asyncCallBack={(val) => handleChangeAsync(val, item.name)}
                id={item.name}
                name={item.name}
              />
            </label>
          </div>
        ))}
      </div>
      <ChangePassword />
      {data?.is_deleted ? <ArchiveTeacherRecovery /> : <ArchiveTeacherButton />}
    </>
  );
};

export default InfosTeacherEdit;

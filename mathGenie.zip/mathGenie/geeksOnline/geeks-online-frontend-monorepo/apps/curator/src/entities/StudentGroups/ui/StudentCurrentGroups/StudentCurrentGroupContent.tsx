import { FC, useCallback, useEffect } from "react";
import cls from "./StudentCurrentGroups.module.scss";
import { IStudentModule } from "entities/StudentGroups/type/StudentMonthsSchema";
import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import { Input, Typography } from "shared/ui";
import StudentStatusesModule from "../StudentStatusesModule/StudentStatusesModule";
import { useParams } from "react-router-dom";
import { AsyncInput, IOption, UIFlexRow } from "@geeks-online/uikit";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import { PaymentWaysType } from "shared/lib/enums";
import { PaymentWaySelect } from "features/PaymentWaySelect";
import { changeStatus } from "entities/StudentStatus/model/StudentStatusChangeFetchRequest";
import { useQueryClient } from "@tanstack/react-query";
import { queryKeyFetchStudentMonthsGroups } from "entities/StudentGroups/model/useFetchStudentMonthsGroups";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import PrevAmounts from "features/PrevAmounts/ui/PrevAmounts";
import { validateAmountInput } from "shared/lib/helpers/helpers";

interface IStudentCurrentGroupContent {
  data: IStudentModule;
  isSupremeMentor?: boolean;
}

const gapBetweenInput = 4;

const StudentCurrentGroupContent: FC<IStudentCurrentGroupContent> = ({
  data,
  isSupremeMentor,
}) => {
  const { id } = useParams();
  const { paymentWayData, setPaymentWay } = useCreateInfos();
  const queryClient = useQueryClient();
  const openErrorAlert = useOpenErrorAlert();

  useEffect(() => {
    if (data?.payment_type) {
      setPaymentWay("way", {
        label: data.payment_type,
        value: data.payment_type as PaymentWaysType,
      });
    }
  }, [data?.payment_type, setPaymentWay]);
  const infoStudentCureentMonth = {
    leftInfos: [
      {
        label: "Направление",
        value: data?.course ?? "",
        disabled: true,
      },
      {
        label: "Группа",
        value: data?.group ?? "",
        disabled: true,
      },
      {
        label: "Месяц",
        value: data?.month ?? "",
        disabled: true,
      },
    ],
    rightInfos: [
      {
        label: "Стоимость курса",
        value: String(data?.amount) ?? "",
        disabled: data?.payment_type === "Ежемесячная оплата",
      },
      ...(data?.payment_type === "Ежемесячная оплата"
        ? [
            {
              label: "Депозит",
              value: String(data?.deposit) ?? "",
              disabled: false,
            },
          ]
        : []),
      {
        label: "Скидка",
        value: String(data?.discount) ?? "",
        disabled: data?.payment_type === "Полная оплата",
      },
      {
        label: "Переплата",
        value: String(data?.overpayment) ?? "",
        disabled: true,
      },
      {
        label: "Долг",
        value: String(data?.debt) ?? "",
        disabled: true,
      },
      {
        label: "Сумма к оплате",
        value: String(data?.for_payment) ?? "",
        disabled: true,
      },
      {
        label: "Остаток",
        value: String(data?.remains) ?? "",
        disabled: true,
      },
    ],
  };

  const handleWayChange = useCallback(
    async (value: IOption | null) => {
      const paymentTypeValue = value?.label?.toString() ?? "";
      await changeStatus({
        student_id: id,
        module_id: data.module_id,
        param: {
          payment_type: paymentTypeValue,
        },
      });

      setPaymentWay("way", value as IOption<PaymentWaysType>);
      queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups]);
    },
    [id, data.module_id, setPaymentWay, queryClient]
  );

  const handleInputChange = async (
    type: "amount" | "deposit" | "discount",
    value: string
  ) => {
    if (!validateAmountInput(value, openErrorAlert, "Неверный формат")) {
      return Promise.reject();
    }
    await changeStatus({
      student_id: id,
      module_id: data.module_id,
      param: {
        [type]: +value,
      },
    });
    queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups]);
  };

  return (
    <div className={cls.renderContent}>
      <UIFlexColumn gap={50} className={cls.wrapper}>
        <UIFlexColumn gap={30}>
          <UIFlexRow gap={100}>
            <UIFlexColumn style={{ width: "400px" }} gap={8}>
              {infoStudentCureentMonth.leftInfos.map((item, index) => (
                <UIFlexColumn gap={gapBetweenInput} key={index}>
                  <Typography variant="Text2_bold">{item.label}</Typography>
                  <Input
                    fullWidth
                    disabled={item.disabled}
                    value={item.value}
                  />
                </UIFlexColumn>
              ))}
              <StudentStatusesModule
                data={data}
                id={id}
                isSupremeMentor={isSupremeMentor}
              />
            </UIFlexColumn>
            <UIFlexColumn style={{ width: "400px" }} gap={8}>
              {!isSupremeMentor && (
                <>
                  <PaymentWaySelect
                    width="100%"
                    isLabel
                    isNotStar={true}
                    fullWidth
                    value={paymentWayData.way}
                    onChange={handleWayChange}
                    sumValue={
                      typeof paymentWayData.sum === "number"
                        ? String(paymentWayData.sum)
                        : ""
                    }
                    onSumChange={() => {}}
                    isShowSumField={false}
                  />
                  {infoStudentCureentMonth.rightInfos.map((item, index) => {
                    const isEditable = [
                      "Скидка",
                      "Депозит",
                      "Стоимость курса",
                    ].includes(item.label);
                    const fieldMap: Record<
                      string,
                      "amount" | "deposit" | "discount"
                    > = {
                      ["Скидка"]: "discount",
                      ["Депозит"]: "deposit",
                      ["Стоимость курса"]: "amount",
                    };
                    return (
                      <UIFlexColumn
                        key={index}
                        gap={4}
                        className={cls.dontFullWidth}
                      >
                        <Typography variant="Text2_bold">
                          {item.label}
                        </Typography>
                        {isEditable ? (
                          <AsyncInput
                            value={String(data?.[fieldMap[item.label]]) || ""}
                            placeholder={item.label}
                            asyncCallBack={(value) =>
                              handleInputChange(fieldMap[item.label], value)
                            }
                            fullWidth
                            disabled={item.disabled}
                          />
                        ) : (
                          <Input
                            value={item.value}
                            disabled={item.disabled}
                            fullWidth
                            className={cls.lightInput}
                          />
                        )}
                      </UIFlexColumn>
                    );
                  })}
                  <PrevAmounts
                    data={data.payments || []}
                    titleLabel={"Оплаченная сумма"}
                    prevValue={Number(data.paid_amount) ?? Number("0.00")}
                    width="400px"
                  />
                </>
              )}
            </UIFlexColumn>
          </UIFlexRow>
        </UIFlexColumn>
      </UIFlexColumn>
    </div>
  );
};

export default StudentCurrentGroupContent;

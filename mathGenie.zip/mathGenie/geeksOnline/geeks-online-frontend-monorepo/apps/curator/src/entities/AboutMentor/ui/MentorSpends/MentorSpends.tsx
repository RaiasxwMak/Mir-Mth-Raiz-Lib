import {
  Button,
  CustomSelect,
  Input,
  IOption,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIModal,
} from "@geeks-online/uikit";
import { useGetMentorBalance } from "entities/AboutMentor/model/useMentorBalance";
import {
  SpendMethods,
  useMentorSpendGroups,
  useSpendCoins,
} from "entities/AboutMentor/model/useSpendCoins";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { handleChangeForNumber } from "shared/lib/helpers/helpers";
import { Textarea } from "shared/ui/Textarea/Textarea";
import cls from "./MentorSpends.module.scss";

const cancallationOption = [
  { label: "За учебу", value: "За учебу" },
  { label: "Списать", value: "Списать" },
];

const MentorSpends = ({
  method,
  isSupremeMentor,
}: {
  method: SpendMethods;
  isSupremeMentor?: boolean;
}) => {
  const { data } = useGetMentorBalance();

  const { mutateAsync, isLoading } = useSpendCoins();

  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [comment, setComment] = useState("");
  const [groupsSelect, setGroupsSelect] = useState<IOption | null>(null);
  const [cancellationValue, setCancellationValue] = useState<IOption | null>(
    null
  );

  const { data: groupsData } = useMentorSpendGroups(
    method === "cancellation" && open
  );

  const [param, _] = useSearchParams();
  const mentor_id = param.get("mentor_id");

  const onClose = () => {
    setOpen(false);
    setAmount("");
    setComment("");
    setGroupsSelect(null);
    setCancellationValue(null);
  };

  const mentorGroupsOptions = useMemo(() => {
    return (
      groupsData?.map((group) => ({
        label: group.title,
        value: group.id,
      })) ?? []
    );
  }, [groupsData]);

  const handleSpend = async () => {
    if (cancellationValue?.value === "За учебу") {
      await mutateAsync({
        method: "tuition_fee",
        body: {
          mentor_id: mentor_id!,
          group_id: String(groupsSelect?.value),
          amount: +amount,
        },
      });
      onClose();
      return;
    }
    await mutateAsync({
      method,
      body: {
        mentor_id: mentor_id!,
        comment,
        amount: +amount,
      },
    });
    onClose();
  };

  const spendTitle: Record<string, string> = {
    replenishment_mentor_supreme: "Начислить 20%",
    replenishment: "Пополнить",
    cancellation: "Списать",
  };

  const spendBtns: Record<string, ReactNode> = {
    replenishment_mentor_supreme: (
      <div className={cls.balances}>
        <div className={cls.balance}>
          <Typography variant="Text1">
            {" "}
            {`Баланс : ${data?.total ?? 0} GeekCoin`}{" "}
          </Typography>
        </div>
        {!!data?.accumulated_amount &&
          !isSupremeMentor &&
          data.subtractive_percentage && (
            <div
              className={cls.balance}
              style={{ cursor: "pointer" }}
              onClick={() => setOpen(true)}
            >
              <Typography variant="Text1">
                {" "}
                {`${data?.subtractive_percentage}%: ${data.accumulated_amount} GeekCoin`}
              </Typography>
            </div>
          )}
      </div>
    ),
    replenishment: (
      <Button
        width={180}
        theme={ThemeButton.outline}
        onClick={() => setOpen(true)}
      >
        {"Пополнить"}
      </Button>
    ),
    cancellation: (
      <Button
        width={180}
        theme={ThemeButton.outline}
        onClick={() => setOpen(true)}
      >
        {"Списать"}
      </Button>
    ),
  };

  useEffect(() => {
    if (method === "cancellation") {
      setCancellationValue(cancallationOption[0]);
    }
    if (method === "replenishment_mentor_supreme") {
      setAmount(
        data?.accumulated_amount ? String(data?.accumulated_amount) : ""
      );
    }
  }, [open, method]);

  const btnDisable = useMemo(() => {
    if (method === "cancellation") {
      if (cancellationValue?.value === "За учебу") {
        return !groupsSelect?.value || !amount;
      }
      if (cancellationValue?.value === "Списать") {
        return !amount || !comment;
      }
    }
    if (method === "replenishment" || method === "replenishment_mentor_supreme")
      return !amount || !comment;
    return false;
  }, [method, cancellationValue, groupsSelect, amount, comment]);

  return (
    <>
      {spendBtns[method]}
      <UIModal
        open={open}
        onCancel={onClose}
        onOk={handleSpend}
        title={spendTitle[method]}
        okTitle={
          method === "replenishment_mentor_supreme" ? "Начислить" : "Сохранить"
        }
        cancelTitle="Отмена"
        isLoading={isLoading}
        okBtnDisable={btnDisable}
      >
        <UIFlexColumn gap={8}>
          {method === "cancellation" && (
            <>
              <CustomSelect
                isArrow
                width="100%"
                value={cancellationValue}
                onChange={(param) => {
                  setCancellationValue(param);
                  setAmount("");
                }}
                options={cancallationOption}
              />
              {cancellationValue?.value === "За учебу" && (
                <UIFlexColumn gap={4}>
                  <Typography variant="Text1">
                    Группа <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <CustomSelect
                    isArrow
                    width="100%"
                    placeholder={
                      !mentorGroupsOptions.length
                        ? "Нет активных групп"
                        : "Выбрать группу"
                    }
                    value={groupsSelect}
                    onChange={setGroupsSelect}
                    options={mentorGroupsOptions}
                    disabled={!mentorGroupsOptions.length}
                  />
                </UIFlexColumn>
              )}
            </>
          )}
          <UIFlexColumn gap={4}>
            <Typography variant="Text1">
              {"Сумма"} <span style={{ color: "red" }}>*</span>
            </Typography>
            <Input
              fullWidth
              value={amount}
              onChange={(e) => handleChangeForNumber(e, setAmount)}
              maxLength={10}
            />
          </UIFlexColumn>
          {cancellationValue?.value !== "За учебу" && (
            <UIFlexColumn gap={4}>
              <Typography variant="Text1">
                {"Комментарий"} <span style={{ color: "red" }}>*</span>
              </Typography>
              <Textarea
                value={comment}
                height="96px"
                notShow
                placeholder="Написать комментарий"
                onChange={(e) => setComment(e.target.value)}
                maxLength={100}
              />
            </UIFlexColumn>
          )}
        </UIFlexColumn>
      </UIModal>
    </>
  );
};

export default MentorSpends;

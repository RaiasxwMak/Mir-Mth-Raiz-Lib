import { FC } from 'react';
import InfosTeacherEdit from './InfosTeacherEdit/InfosTeacherEdit';

const InfoTeacher: FC = () => {
  return (
    <div>
      <InfosTeacherEdit />
    </div>
  );
};

export default InfoTeacher;

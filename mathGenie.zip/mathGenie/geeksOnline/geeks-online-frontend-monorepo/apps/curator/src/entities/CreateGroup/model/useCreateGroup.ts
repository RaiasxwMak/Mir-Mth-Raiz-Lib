import { IOption } from 'shared/ui/Select/Select';
import { create } from 'zustand';

export type ErrorType = 'course' | 'group-name' | 'users';
export interface UseCreateGroup {
  errors: ErrorType[];
  directionValue: IOption | null;
  setDirectionValue: (value: IOption) => void;
  setErrors: (errors: ErrorType[]) => void;
}

export const useCreateGroup = create<UseCreateGroup>((set) => ({
  errors: [],
  directionValue: null,
  setDirectionValue(value) {
    set({ directionValue: value });
  },
  setErrors(err) {
    set({ errors: err });
    setTimeout(() => {
      set({ errors: [] });
    }, 3000);
  },
}));

import { useMutation } from '@tanstack/react-query';
import { useOpenAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { isAxiosError } from 'axios';
import { useCreateInfos } from 'features/CreateInfos/model/CreateInfos';
import { useNavigate } from 'react-router-dom';
import { requester } from 'shared/configs/axios/axiosConfig';

const ENDPOINTS: Record<string, string> = {
  CREATE: '/api/v1/curator/students/create/',
};

export const useCreateStudentRequest = () => {
  const navigate = useNavigate();
  const successAlert = useOpenAlert();
  const { setErrorInputs } = useCreateInfos();
  const createStudent = useMutation(async (data: FormData) => {
    try {
      const res = await requester.post(ENDPOINTS.CREATE, data);
      if (res.status >= 200) {
        successAlert('Сохранено');
        setTimeout(() => navigate(-1), 500);
      }
      return res;
    } catch (e) {
      if (!isAxiosError(e)) return;
      if (e.response?.data.status === 'already_exist') {
        setErrorInputs('login', true);
        return;
      }
    }
  });
  return createStudent;
};

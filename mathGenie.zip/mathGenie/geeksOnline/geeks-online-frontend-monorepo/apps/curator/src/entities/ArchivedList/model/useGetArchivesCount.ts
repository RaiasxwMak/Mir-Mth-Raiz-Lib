import { useQuery } from '@tanstack/react-query';
import { requester } from 'shared/configs/axios/axiosConfig';

const ENDPOINTS: Record<string, string> = {
  ARCHIVES_COUNT: '/api/v1/curator/archive/counts/',
};

interface IArchives {
  title: string;
  count: number;
}

const queryKeyArchives = 'archivesCount';

export const useGetArchivesCount = () => {
  return useQuery<IArchives[]>([queryKeyArchives], async () => {
    const { data } = await requester.get(ENDPOINTS.ARCHIVES_COUNT);
    return data;
  });
};

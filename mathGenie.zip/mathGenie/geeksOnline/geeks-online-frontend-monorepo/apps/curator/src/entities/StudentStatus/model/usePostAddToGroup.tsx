import { useMutation } from "@tanstack/react-query";
import { studentStatusChangePost } from "./StudentStatusChangeFetchRequest";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";

export const usePostAddToGroup = () => {
  const alertSuccess = useOpenAlert();
  return useMutation(studentStatusChangePost, {
    onSuccess() {
      alertSuccess("Ученик добавлен в группу");
    },
  });
};

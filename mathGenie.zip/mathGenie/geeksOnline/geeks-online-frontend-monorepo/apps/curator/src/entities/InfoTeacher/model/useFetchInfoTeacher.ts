import { useMutation, useQuery } from '@tanstack/react-query';
import { requester } from 'shared/configs/axios/axiosConfig';
import { IInfoTeacher } from '../type/InfoTeacherType';

const ENDPOINTS = {
  TEACHER: (user_id: string) => `/api/v1/curator/teacher/${user_id}/`,
};

export const queryKeyTeacher = 'infoTeacher';

interface ITeacherEdit {
  photo?: string | File;
  full_name?: string;
  email?: string;
  phone?: string;
  telegram?: string;
  username?: string;
}

export const useFetchInfoTeacher = (user_id: string) => {
  return useQuery<IInfoTeacher>([queryKeyTeacher], async () => {
    const { data } = await requester.get(ENDPOINTS.TEACHER(user_id));
    return data;
  });
};

export const useFetchTeacherEdit = (user_id: string) => {
  const teacherEdit = useMutation(async (param: ITeacherEdit) => {
    const formdata = new FormData();
    Object.entries(param).forEach((item) => {
      if (item[0] === 'phone' && item[1].length < 3) {
        throw { response: { status: 400 } };
      }
      formdata.append(item[0], item[1]);
    });
    const response = await requester.patch(
      ENDPOINTS.TEACHER(user_id),
      formdata
    );
    return response.data;
  });

  return teacherEdit;
};

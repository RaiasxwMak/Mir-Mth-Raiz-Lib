import cls from "./GroupInfoDataTable.module.scss";
import GroupInfoTable from "features/GroupInfoTable/ui/GroupInfoTable/GroupInfoTable";

const GroupInfoDataTable = ({
  isSupremeMentor = false,
}: {
  isSupremeMentor?: boolean;
}) => {
  return (
    <div className={cls.tables}>
      <GroupInfoTable isSupremeMentor={isSupremeMentor} />
    </div>
  );
};

export default GroupInfoDataTable;

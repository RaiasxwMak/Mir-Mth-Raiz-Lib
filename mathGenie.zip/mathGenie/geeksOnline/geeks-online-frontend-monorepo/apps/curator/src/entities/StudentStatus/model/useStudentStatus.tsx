import { useMutation, useQueryClient } from '@tanstack/react-query';
import { changeStatus } from './StudentStatusChangeFetchRequest';
import { useOpenAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { queryKeyFetchStudentMonthsGroups } from 'entities/StudentGroups/model/useFetchStudentMonthsGroups';

const useStudentStatus = () => {
  const openSuccess = useOpenAlert();

  const queryClient = useQueryClient();

  return useMutation(changeStatus, {
    onSuccess: () => {
      openSuccess('Данные успешно сохранены');
      queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups]);
    },
  });
};

export default useStudentStatus;

import { formatDateMonth, maskInputDate } from 'shared/lib/helpers/helpers';
import { Button, Input, Loader, Typography } from 'shared/ui';
import { ThemeButton } from 'shared/ui/Button/Button';
import { Textarea } from 'shared/ui/Textarea/Textarea';
import { UIFlexBetween, UIFlexColumn } from 'shared/ui/UIFlex/UIFlex';
import { FC, useEffect } from 'react';
import { useRejectForm } from 'entities/StudentStatus/model/useRejectForm';
import useStudentStatus from 'entities/StudentStatus/model/useStudentStatus';
import { useOpenErrorAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { failDate, failEmpty } from 'shared/lib/consts/consts';

interface IStudentRejectForm {
  onClose: () => void;
  student_id: string;
  module_id: string;
  afterRequest?: () => void;
}

const StudentRejectForm: FC<IStudentRejectForm> = ({
  onClose,
  student_id,
  module_id,
  afterRequest,
}) => {
  const { rejectReason, startRejectReason, setRejectForm, resetRejectForm } =
    useRejectForm();

  const { mutateAsync, isLoading } = useStudentStatus();
  const openError = useOpenErrorAlert();

  const handleClickRequest = async () => {
    try {
      if (rejectReason.trim() && startRejectReason.trim()) {
        if (!formatDateMonth(startRejectReason)) return openError(failDate);
        await mutateAsync({
          param: {
            module_status: 'Отказ',
            reject_reason: rejectReason,
            reject_date: formatDateMonth(startRejectReason),
          },
          student_id,
          module_id,
        });
        if (afterRequest) afterRequest();
        onClose();
      } else openError(failEmpty);
    } catch (e) {
      throw e;
    }
  };

  useEffect(() => {
    return () => resetRejectForm();
  }, []);

  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={8}>
        <UIFlexColumn gap={4}>
          <label htmlFor='rejectReason'>
            <Typography variant='Text2'>Причина</Typography>
          </label>
          <Textarea
            id='rejectReason'
            notShow
            value={rejectReason}
            onChange={(e) => setRejectForm({ rejectReason: e.target.value })}
            placeholder={'Введите причину ...'}
            height='60px'
          />
        </UIFlexColumn>
        <UIFlexColumn gap={4}>
          <label htmlFor='startC'>
            <Typography variant='Text2'>Начало отказа</Typography>
          </label>
          <Input
            placeholder='12.12.2023'
            mask={maskInputDate}
            value={startRejectReason}
            onChange={(e) =>
              setRejectForm({ startRejectReason: e.target.value })
            }
            fullWidth
            id='startC'
          />
        </UIFlexColumn>
      </UIFlexColumn>
      <UIFlexBetween>
        <Button width={210} theme={ThemeButton.not_bordered} onClick={onClose}>
          Отмена
        </Button>
        <Button
          width={210}
          onClick={handleClickRequest}
          theme={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        >
          {isLoading ? <Loader small /> : 'Сохранить'}
        </Button>
      </UIFlexBetween>
    </UIFlexColumn>
  );
};

export default StudentRejectForm;

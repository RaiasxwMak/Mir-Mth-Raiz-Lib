export interface IModules {
  id: string;
  title: string;
  number: number;
}

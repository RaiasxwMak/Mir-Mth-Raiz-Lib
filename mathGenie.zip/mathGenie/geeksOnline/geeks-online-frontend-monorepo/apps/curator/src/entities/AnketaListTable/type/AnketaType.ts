export interface IAnketaList {
  count: number;
  next: string | null;
  previous: string | null;
  results: IAnketa[];
}

export interface IAnketa {
  id: string;
  full_name: string;
  course: string;
  created_at: string;
  activated: boolean;
}

import { useQueryClient, useMutation } from "@tanstack/react-query";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useLessonSelect } from "features/LessonSelect/model/useLessonSelect";
import { requester } from "shared/configs/axios/axiosConfig";
import { useTimeRange } from "shared/ui/TimeRangeSelect/model/useTimeRange";
import { UseQueryReservationKey } from "widgets/CalendarForOneDay/model/calendarForOneDayRequests";
import { IMeeting } from "../ui/MeetingMode/MeetingMode";
import { isAxiosError } from "axios";
import { Dispatch, SetStateAction } from "react";
import { useLessonTypeSelect } from "features/LessonTypeSelect/model/useLessonTypeSelect";
import { useLessonDescription } from "features/LessonDescription/model/useLessonDescription";

interface CreateReservationData {
  classroom: number | string;
  floor: number | null;
  start_time: string;
  end_time: string;
  lesson: string | null;
  meeting: null | {
    title: string;
    description: string;
  };
  lesson_type?: string;
  id?: string;
  lesson_desc?: string | null;
  day?: string;
}

interface IMutateParam {
  isLesson: boolean;
  meeting: IMeeting | null;
}

export const useMutationCreateReservation = (
  floor: number | string | undefined,
  classroom: number | string,
  date: string,
  id?: string,
  setOpen?: Dispatch<SetStateAction<boolean>>
) => {
  const errorAlert = useOpenErrorAlert();
  const client = useQueryClient();
  const lessonSelect = useLessonSelect((state) => state.lessonSelect);
  const timeRangeSelect = useTimeRange((state) => state.timeRangeSelect);
  const lessonDescription = useLessonDescription(
    (state) => state.lessonDescription
  );
  const lessonTypeSelect = useLessonTypeSelect(
    (state) => state.lessonTypeSelect
  );
  const openError = useOpenErrorAlert();
  const openSuccess = useOpenAlert();
  return useMutation({
    mutationFn: async ({ isLesson, meeting }: IMutateParam) => {
      if (!timeRangeSelect?.start?.value)
        return openError("Выберите время начало урока");
      if (!timeRangeSelect?.end?.value)
        return openError("Выберите время конца урока");
      if (!lessonSelect?.value && isLesson) return openError("Выберите урок");
      if (!isLesson && !meeting?.title) return openError("Введите заголовок");
      if (timeRangeSelect.start.value === timeRangeSelect.end.value)
        return openError("Время начала не может быть равен временю конца");
      if (floor === "other" && !lessonTypeSelect?.value)
        return openError("Выберите тип урока");
      if (lessonTypeSelect?.value === "Другое") {
        if (
          floor === "other" &&
          (!lessonDescription || lessonDescription?.length < 5)
        )
          return openError("Введите не менее 5 символов (цифры, буквы)");
      }

      const isLessonDesc =
        lessonTypeSelect?.value === "Оффлайн" ||
        lessonTypeSelect?.value === "Онлайн";

      const data: CreateReservationData = {
        day: date,
        start_time: timeRangeSelect.start.value.toString(),
        end_time: timeRangeSelect.end.value.toString(),
        lesson:
          lessonSelect?.value && isLesson
            ? lessonSelect.value.toString()
            : null,
        meeting: !isLesson ? meeting : null,
        floor: Number(floor),
        classroom,
        lesson_type: lessonTypeSelect?.value.toString(),
        id,
        lesson_desc: !isLessonDesc ? lessonDescription : null,
      };

      try {
        if (id) await fetchMutateReservation(data);
        else await fetchCreateReservation(data);
        if (id) openSuccess("Бронирование обновлено");
        else openSuccess("Бронирование создано");
        setOpen && setOpen(false);
        client.invalidateQueries([UseQueryReservationKey]);
        return true;
      } catch (error) {
        if (!isAxiosError(error)) return errorAlert(`Что-то пошло не так :(`);
        if (error?.response?.data?.non_field_errors?.[0])
          errorAlert(error?.response?.data?.non_field_errors[0]);
        else if (error?.response?.data?.lesson?.[0])
          errorAlert(error?.response?.data?.lesson?.[0]);
        console.log("Error");
        return false;
      }
    },
  });
};

export const fetchCreateReservation = async (data: CreateReservationData) => {
  return await requester.post(
    "/api/v1/curator/schedule/reservations/create/",
    data
  );
};

export const fetchMutateReservation = async (data: CreateReservationData) => {
  return await requester.patch(
    `/api/v1/curator/schedule/reservations/${data.id}/`,
    data
  );
};

import { Loader, Stats, Typography } from "shared/ui";
import useFetchStats from "../model/useFetchStats";
import cls from "./StatisticGroups.module.scss";
import { memo } from "react";
import { EmptyState } from "@geeks-online/uikit";

const blueColor = "#F89418";
const orangeColor = "#6298E7";
const standupColor = "#FFE743";
const statsNumberList = [0, 20, 40, 60, 80, 100];

const StatisticGroups = memo(() => {
  const { data, isLoading } = useFetchStats();

  const monthStats = [
    {
      height: data?.month?.grades ?? 0,
      color: orangeColor,
    },
    {
      height: data?.month?.attandance ?? 0,
      color: blueColor,
    },
    {
      height: data?.month?.standup ?? 0,
      color: standupColor,
    },
  ];
  const totalStats = [
    {
      height: data?.global.grades ?? 0,
      color: orangeColor,
    },
    {
      height: data?.global.attandance ?? 0,
      color: blueColor,
    },
    {
      height: data?.global.standup ?? 0,
      color: standupColor,
    },
  ];

  if (isLoading) return <Loader height="500px" />;
  if (
    !data?.global.attandance &&
    !data?.global.grades &&
    !data?.global.standup &&
    !data?.month.attandance &&
    !data?.month.grades &&
    !data?.month.standup
  )
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={cls.stats_wrapper}>
        <div className={cls.stat_block}>
          <div className={cls.head_title}>
            <Typography variant="Text2">За месяц</Typography>
          </div>
          <div className={cls.charts}>
            <Stats
              statsCharts={monthStats}
              height={420}
              statsList={statsNumberList}
            />
          </div>
        </div>
        <div className={cls.stat_block}>
          <div className={cls.head_title}>
            <Typography variant="Text2">Общая</Typography>
          </div>
          <div className={cls.charts}>
            <Stats
              statsCharts={totalStats}
              height={420}
              statsList={statsNumberList}
            />
          </div>
        </div>
      </div>
      <div className={cls.stats_info}>
        <div className={cls.stats_color_mean}>
          <div className={cls.stats_bg} style={{ background: orangeColor }} />
          <Typography variant="Text2">Успеваемость</Typography>
        </div>
        <div className={cls.stats_color_mean}>
          <div className={cls.stats_bg} style={{ background: blueColor }} />
          <Typography variant="Text2">Посещаемость</Typography>
        </div>
        <div className={cls.stats_color_mean}>
          <div className={cls.stats_bg} style={{ background: standupColor }} />
          <Typography variant="Text2">StandUp</Typography>
        </div>
      </div>
    </div>
  );
});

export default StatisticGroups;

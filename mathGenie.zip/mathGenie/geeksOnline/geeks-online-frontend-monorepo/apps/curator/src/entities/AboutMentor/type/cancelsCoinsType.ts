export interface ICancelsCoins {
  by_student: {
    count: number;
    link: string;
    text: string;
  };
  by_mentor: {
    count: number;
    link: string;
    text: string;
  };
}

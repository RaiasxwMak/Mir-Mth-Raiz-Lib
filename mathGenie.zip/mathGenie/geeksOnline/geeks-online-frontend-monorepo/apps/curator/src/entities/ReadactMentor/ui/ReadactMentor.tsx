import { UIFlexColumn, UIFlexRow } from "shared/ui/UIFlex/UIFlex";
import { useFetchMentor } from "../model/useFetchMentor";
import { Loader, SwitchCustom, Typography } from "shared/ui";
import { useMentorEdit } from "features/MentorInfoEdit/model/MentorInfoEdit";
import { useState, useEffect } from "react";
import RedactCourseMentor from "./RedactCourseMentor";
import { AsyncInput } from "@geeks-online/uikit";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";

const ReadactMentor = ({
  isSupremeMentor = false,
}: {
  isSupremeMentor?: boolean;
}) => {
  const { data, isLoading } = useFetchMentor();
  const { mutateAsync } = useMentorEdit();
  const { courseValueSelect } = useCoursesSelect();
  const [isSupreme, setIsSupreme] = useState(Boolean(data?.is_supreme));
  const [isTechMentor, setIsTechMentor] = useState(
    Boolean(data?.is_techmentor)
  );

  const handleChangeAsync = async (val: unknown, name: string) => {
    return await mutateAsync({ [name]: val });
  };

  const handleSwitchChange = async (
    fieldName: string,
    currentValue: boolean,
    setState: (value: boolean) => void
  ) => {
    try {
      await mutateAsync({
        [fieldName]: !currentValue,
        ...(fieldName === "is_supreme" && {
          course_id: String(courseValueSelect?.value),
        }),
      });
      setState(!currentValue);
    } catch (error) {
      console.error(`Ошибка при обновлении поля ${fieldName}:`, error);
    }
  };

  useEffect(() => {
    setIsSupreme(Boolean(data?.is_supreme));
    setIsTechMentor(Boolean(data?.is_techmentor));
  }, [data?.is_supreme, data?.is_techmentor]);

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={4} style={{ width: "400px" }}>
        <Typography variant="Text2_bold">
          ФИО студента <span style={{ color: "red" }}>*</span>
        </Typography>
        <AsyncInput
          fullWidth
          disabled
          value={data?.full_name ?? ""}
          asyncCallBack={(val) => handleChangeAsync(val, "full_name")}
        />
      </UIFlexColumn>
      <RedactCourseMentor data={data!} />
      {!isSupremeMentor && (
        <UIFlexRow gap={7}>
          <SwitchCustom
            switched={isSupreme}
            setSwitch={() =>
              handleSwitchChange("is_supreme", isSupreme, setIsSupreme)
            }
          />
          <Typography variant="Text2_bold">Старший ментор</Typography>
        </UIFlexRow>
      )}

      {!isSupremeMentor && (
        <UIFlexRow gap={7}>
          <SwitchCustom
            switched={isTechMentor}
            setSwitch={() =>
              handleSwitchChange("is_techmentor", isTechMentor, setIsTechMentor)
            }
          />
          <Typography variant="Text2_bold">Технический ментор</Typography>
        </UIFlexRow>
      )}
    </UIFlexColumn>
  );
};

export default ReadactMentor;

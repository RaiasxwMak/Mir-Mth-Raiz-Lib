import CreateAvatar from "shared/ui/CreateAvatar/CreateAvatar";
import { useFetchStudent } from "../model/requestsRedactStudent";
import cls from "./RedactStudent.module.scss";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { Loader, Typography } from "shared/ui";
import { useStudentEdit } from "features/StudentInfoEdt/model/StudentInfoEdit";
import ChangePassword from "features/ChangePassword/ui/ChangePassword";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import { useEffect } from "react";
import { AsyncInput } from "@geeks-online/uikit";
import { useFetchProfile } from "entities/ProfileInfo/model/useFetchProfile";
import dayjs from "dayjs";
import { formatMonth } from "shared/lib/consts/consts";

const RedactStudent = () => {
  const { data: profile } = useFetchProfile();
  const isSupremeMentor = profile?.user.is_supreme;
  const { data, isLoading } = useFetchStudent();
  const { image, setImage } = useCreateAvatar();
  const { mutateAsync } = useStudentEdit();
  const { clearAllInputs } = useCreateInfos();

  const form = [
    {
      label: "ФИО",
      star: "*",
      value: data?.full_name ?? "",
      name: "full_name",
    },
    data?.requisite
      ? {
          label: "Лицевой счет",
          value: data.requisite,
          name: "requisite",
          disabled: true,
        }
      : null,
    {
      label: "Номер телефона",
      star: "*",
      value: data?.phone ?? "",
      name: "phone",
      mask: "+***************************************",
    },
    {
      label: "Телеграм",
      value: data?.telegram ?? "",
      name: "telegram",
    },
    {
      label: "Дата Рождения",
      value: data?.birth_date ?? "",
      name: "birth_date",
      disabled: true,
    },
    {
      label: "Логин",
      star: "*",
      value: data?.login ?? "",
      name: "username",
    },
    {
      label: "Дата создания",
      value: data?.created_at
        ? dayjs(data?.created_at).format(formatMonth)
        : "",
      name: "created_at",
      disabled: true,
    },
  ];

  const handleChangeAsync = async (val: unknown, name: string) => {
    return await mutateAsync({ [name]: val });
  };

  useEffect(() => {
    return () => {
      clearAllInputs();
    };
  }, []);

  if (isLoading) return <Loader />;

  return (
    <div className={cls.form}>
      <CreateAvatar
        image={image}
        setImage={setImage}
        avatarSize={140}
        asCb={(img) => handleChangeAsync(img, "photo")}
        src={data?.photo ?? ""}
      />
      <div className={cls.form_inputs}>
        {form.map((item) => (
          <label className={cls.label} key={item?.name}>
            <Typography variant="Text2">
              {item?.label} {item?.star && <span>{item?.star}</span>}
            </Typography>
            <AsyncInput
              key={item?.value}
              mask={item?.mask}
              asyncCallBack={(val) => handleChangeAsync(val, item?.name!)}
              value={item?.value ?? ""}
              name={item?.name}
              disabled={item?.disabled || isSupremeMentor}
              isNotRequired={item?.name === "telegram"}
            />
          </label>
        ))}
      </div>
      {!isSupremeMentor && (
        <>
          <ChangePassword />
        </>
      )}
    </div>
  );
};

export default RedactStudent;

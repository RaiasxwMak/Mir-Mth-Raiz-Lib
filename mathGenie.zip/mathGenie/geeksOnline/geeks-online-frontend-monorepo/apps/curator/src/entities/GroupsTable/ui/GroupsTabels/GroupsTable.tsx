import CustomPagination, {
  usePageChange,
} from "shared/ui/CustomPagination/CustomPagination";
import { useFetchGroups } from "entities/GroupsTable/model/groupsTableRequest";
import { Loader } from "shared/ui";
import { ReactComponent as ChatSvg } from "shared/assets/icon/chatIcon.svg";
import { getMonthNumber } from "shared/lib/helpers/helpers";
import { useEffect, useMemo } from "react";
import useFilterMemoryNavigate from "shared/lib/useFilterMemoryNavigate/useFilterMemoryNavigate";
import { EmptyState, rowClass, TableAccordionList } from "@geeks-online/uikit";
import { Root2 } from "entities/GroupsTable/type/GroupsTableType";
import { ingnoreAny } from "shared/global/types";
import { ColumnsType } from "antd/es/table";

export const GroupsTable = () => {
  const { resetPage } = usePageChange();
  const { data, isLoading } = useFetchGroups();
  const navigateWithMemory = useFilterMemoryNavigate();

  const columns: ColumnsType<Root2> = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Направление",
      dataIndex: "course_title",
      width: "20%",
      render: (text: string, record: Root2) => {
        return (
          <span
            className={"link"}
            onClick={() =>
              navigateWithMemory(
                `/curator/groups/${record.id}/?month_id=${record.month_id}`
              )
            }
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Группа",
      dataIndex: "title",
      width: "20%",
    },
    {
      title: "Месяц",
      dataIndex: "month_number",
      align: "center",
    },
    {
      title: "Урок",
      dataIndex: "lesson",
      align: "center",
    },
    {
      title: "Кол-во студентов ",
      dataIndex: "students_amount",
      align: "center",
    },
    {
      title: " ",
      dataIndex: "chat",
      render: (_: ingnoreAny, record: Root2) => (
        <ChatSvg
          cursor={"pointer"}
          onClick={() =>
            navigateWithMemory(
              `/curator/groups/${record.id}/?month_id=${record.month_id}&tab=chat`
            )
          }
        />
      ),
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
        course_title: elm.course.title,
        month_number: getMonthNumber(elm.month) ?? "-",
        lesson: getMonthNumber(elm.lesson) ?? "-",
      };
    });
  }, [data]);

  useEffect(() => {
    return () => resetPage();
  }, []);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={"tableWidth"}>
        <TableAccordionList columns={columns} dataSource={dataSource} />
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

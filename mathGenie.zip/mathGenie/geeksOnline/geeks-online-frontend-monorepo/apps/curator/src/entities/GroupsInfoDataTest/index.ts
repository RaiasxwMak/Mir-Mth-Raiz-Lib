export { default as GroupInfoDataTest } from './ui/GroupsInfoDataTest'

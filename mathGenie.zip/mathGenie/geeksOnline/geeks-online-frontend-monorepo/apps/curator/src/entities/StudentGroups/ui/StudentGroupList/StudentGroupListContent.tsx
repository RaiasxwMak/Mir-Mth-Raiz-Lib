import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import cls from "./StudentGroups.module.scss";
import { IStudentModule } from "entities/StudentGroups/type/StudentMonthsSchema";
import { FC, useCallback } from "react";
import { Input, Typography } from "shared/ui";
import PauseStatusDescription from "features/studentStatus/ui/StudentStatusSelect/PauseStatusDescription";
import RejectStatusDescription from "features/studentStatus/ui/StudentStatusSelect/RejectStatusDescription";
import { useParams } from "react-router-dom";
import PrevAmounts from "features/PrevAmounts/ui/PrevAmounts";
import { useQueryClient } from "@tanstack/react-query";
import { queryKeyFetchStudentMonthsGroups } from "entities/StudentGroups/model/useFetchStudentMonthsGroups";
import { AsyncInput, IOption, UIFlexRow } from "@geeks-online/uikit";
import { changeStatus } from "entities/StudentStatus/model/StudentStatusChangeFetchRequest";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import { PaymentWaysType } from "shared/lib/enums";
import { PaymentWaySelect } from "features/PaymentWaySelect";
import PaymentSelectAsync from "features/PaymentSelect/ui/PaymentSelectAsync";
import StudentCurrentGroupContent from "../StudentCurrentGroups/StudentCurrentGroupContent";
import { validateAmountInput } from "shared/lib/helpers/helpers";
import RepeatSelectAsync from "features/RepeatSelect/ui/RepeatSelectAsync";

interface IStudentStatusesModule {
  data: IStudentModule;
  isSupremeMentor?: boolean;
}

const gapBetweenInput = 4;

const StudentGroupListContent: FC<IStudentStatusesModule> = ({
  data,
  isSupremeMentor,
}) => {
  const queryClient = useQueryClient();
  const openErrorAlert = useOpenErrorAlert();

  const { id } = useParams();
  const { paymentWayData } = useCreateInfos();
  const infoStudentCureentMonth = {
    rightInfos: [
      {
        label: "Стоимость курса",
        value: String(data?.amount) ?? "",
        disabled: data?.payment_type === "Ежемесячная оплата",
      },
      ...(data?.payment_type === "Ежемесячная оплата"
        ? [
            {
              label: "Депозит",
              value: String(data?.deposit) ?? "",
              disabled: false,
            },
          ]
        : []),
      {
        label: "Скидка",
        value: String(data?.discount) ?? "",
        disabled: data?.payment_type === "Полная оплата",
      },
      {
        label: "Переплата",
        value: String(data?.overpayment) ?? "",
        disabled: true,
      },
      {
        label: "Долг",
        value: String(data?.debt) ?? "",
        disabled: true,
      },
      {
        label: "Сумма к оплате",
        value: String(data?.for_payment) ?? "",
        disabled: true,
      },
      {
        label: "Остаток",
        value: String(data?.remains) ?? "",
        disabled: true,
      },
    ],
  };

  const PaidMonthsConst = {
    true: "Оплаченный",
    false: "Неоплаченный",
  };

  const isPayedValue = PaidMonthsConst[`${data.is_payed}`];
  const moduleStatus = data.module_status ?? null;

  const handleInputChange = async (
    type: "amount" | "deposit" | "discount",
    value: string
  ) => {
    if (!validateAmountInput(value, openErrorAlert, "Неверный формат")) {
      return Promise.reject();
    }
    await changeStatus({
      student_id: id,
      module_id: data.module_id,
      param: {
        [type]: +value,
      },
    });
    queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups]);
  };

  const handleWayChange = useCallback(
    async (value: IOption | null) => {
      const paymentTypeValue = value?.label?.toString() ?? "";
      await changeStatus({
        student_id: id,
        module_id: data.module_id,
        param: {
          payment_type: paymentTypeValue,
        },
      });
      queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups]);
    },
    [id, data.module_id, queryClient]
  );

  const convertDateFormat = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, "0");
    const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Months are 0-based in JavaScript
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  if (moduleStatus === "Активный")
    return (
      <div className={cls.renderContent}>
        <StudentCurrentGroupContent
          data={data}
          isSupremeMentor={isSupremeMentor}
        />
      </div>
    );

  return (
    <div className={cls.renderContent}>
      <UIFlexColumn gap={50} className={cls.wrapper}>
        <UIFlexColumn gap={30}>
          <UIFlexRow gap={100}>
            <UIFlexColumn gap={8} style={{ width: 400 }}>
              <UIFlexColumn gap={gapBetweenInput}>
                <Typography variant="Text2_bold">Статус</Typography>
                <Input
                  fullWidth
                  placeholder={"Статус"}
                  value={data?.dynamic_module_status ?? ""}
                  disabled
                />
                {data?.ignore_date && (
                  <>
                    <Typography variant="Text2_bold">Дата</Typography>
                    <Input
                      fullWidth
                      placeholder={"Статус"}
                      value={convertDateFormat(data?.ignore_date) ?? ""}
                      disabled
                    />
                  </>
                )}
                {moduleStatus === "Пауза" && (
                  <PauseStatusDescription
                    student_id={String(id)}
                    module_id={data?.module_id ?? ""}
                    pause_start_date={data?.pause_start_date}
                    pause_end_date={data?.pause_end_date}
                    pause_reason={data?.pause_reason ?? ""}
                    moduleStatus={moduleStatus}
                    isSupremeMentor={isSupremeMentor}
                    disabled
                  />
                )}
                {moduleStatus === "Отказ" && (
                  <RejectStatusDescription
                    student_id={""}
                    module_id={data?.module_id ?? ""}
                    reject_date={data?.reject_date}
                    reject_reason={data?.reject_reason}
                    disabled
                  />
                )}
              </UIFlexColumn>
              <UIFlexColumn gap={gapBetweenInput}>
                <Typography variant="Text2_bold">Статус повтора</Typography>
                <RepeatSelectAsync
                  onSuccess={() =>
                    queryClient.invalidateQueries([
                      queryKeyFetchStudentMonthsGroups,
                    ])
                  }
                  repeat_status={data.dynamic_repeat_status}
                  module_id={data.module_id}
                  disable={isSupremeMentor}
                  id={id ?? ""}
                />
              </UIFlexColumn>
              {isSupremeMentor ? (
                <UIFlexColumn gap={gapBetweenInput}>
                  <Typography variant="Text2_bold">Статус оплаты</Typography>
                  <Input
                    fullWidth
                    placeholder={"Статус оплаты"}
                    value={isPayedValue}
                    disabled
                  />
                </UIFlexColumn>
              ) : (
                <UIFlexColumn gap={gapBetweenInput}>
                  <Typography variant="Text2_bold">
                    {"Статус оплаты"}
                  </Typography>
                  <PaymentSelectAsync
                    status={data.is_payed}
                    student_id={id ?? ""}
                    module_id={data.module_id}
                    disable={isSupremeMentor}
                    onSuccess={() =>
                      queryClient.invalidateQueries([
                        queryKeyFetchStudentMonthsGroups,
                      ])
                    }
                  />
                </UIFlexColumn>
              )}
            </UIFlexColumn>
            <UIFlexColumn gap={8} style={{ width: 400 }}>
              {!isSupremeMentor && (
                <>
                  <PaymentWaySelect
                    width="100%"
                    isLabel
                    isNotStar={true}
                    fullWidth
                    value={{
                      label: data.payment_type,
                      value: data.payment_type as PaymentWaysType,
                    }}
                    onChange={handleWayChange}
                    sumValue={
                      typeof paymentWayData.sum === "number"
                        ? String(paymentWayData.sum)
                        : ""
                    }
                    onSumChange={() => {}}
                    isShowSumField={false}
                  />
                  {infoStudentCureentMonth.rightInfos.map((item, index) => {
                    const isEditable = [
                      "Скидка",
                      "Депозит",
                      "Стоимость курса",
                    ].includes(item.label);
                    const fieldMap: Record<
                      string,
                      "amount" | "deposit" | "discount"
                    > = {
                      ["Скидка"]: "discount",
                      ["Депозит"]: "deposit",
                      ["Стоимость курса"]: "amount",
                    };
                    return (
                      <UIFlexColumn
                        key={index}
                        gap={4}
                        className={cls.dontFullWidth}
                      >
                        <Typography variant="Text2_bold">
                          {item.label}
                        </Typography>
                        {isEditable ? (
                          <AsyncInput
                            value={String(data?.[fieldMap[item.label]]) || ""}
                            placeholder={item.label}
                            asyncCallBack={(value) =>
                              handleInputChange(fieldMap[item.label], value)
                            }
                            fullWidth
                            disabled={item.disabled}
                          />
                        ) : (
                          <Input
                            value={item.value}
                            disabled={item.disabled}
                            fullWidth
                            className={cls.lightInput}
                          />
                        )}
                      </UIFlexColumn>
                    );
                  })}
                  <PrevAmounts
                    data={data.payments || []}
                    titleLabel={"Оплаченная сумма"}
                    prevValue={Number(data.paid_amount) ?? Number("0.00")}
                    width="400px"
                  />
                </>
              )}
            </UIFlexColumn>
          </UIFlexRow>
        </UIFlexColumn>
      </UIFlexColumn>
    </div>
  );
};

export default StudentGroupListContent;

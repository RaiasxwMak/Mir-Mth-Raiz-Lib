import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { useMemo } from "react";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import { useAnketaListQuery } from "../model/useAnketaListQuery";
import useFilterMemoryNavigate from "shared/lib/useFilterMemoryNavigate/useFilterMemoryNavigate";
import { IAnketa } from "../type/AnketaType";

const AnketaListTable = () => {
  const { data, isLoading } = useAnketaListQuery();
  const navigateWithMemory = useFilterMemoryNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
      width: "312px",
      render: (text: string, record: IAnketa) => {
        return (
          <span
            className={"link"}
            onClick={() => navigateWithMemory(`/curator/anketa/${record.id}/`)}
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Лиц. счет",
      dataIndex: "requisite",
    },
    {
      title: "Направление",
      dataIndex: "course",
    },
    {
      title: "Дата заполнения формы",
      dataIndex: "date",
    },
    {
      title: "",
      dataIndex: "activated",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        course: elm?.course || "-",
        date: elm?.created_at.split("-").reverse().join(".") || "-",
        key: index + 1,
        index: index + 1,
        activated: elm.activated ? "Активированный" : "",
        className: even ? rowClass : "",
        expand: false,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={"tableWidth"}>
        <TableAccordionList columns={columns} dataSource={dataSource} />
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default AnketaListTable;

import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import PaymentSelect from "features/PaymentSelect/ui/PaymentSelect";
import RepeatSelect from "features/RepeatSelect/ui/RepeatSelect";
import StatusSelects from "features/StatusSelects/StatusSelects";
import { Button, Loader, Typography } from "shared/ui";
import { UIFlexBetween, UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import { FC, useCallback, useEffect } from "react";
import { ThemeButton } from "shared/ui/Button/Button";
import cls from "./StudentForm.module.scss";
import MonthsSelects from "features/MonthsSelects/ui/MonthsSelects";
import SearchGroupDropDown from "features/SearchGroupDropDown/ui/SearchGroupDropDown";
import { useMonthsSelect } from "features/MonthsSelects/model/useMonthsSelects";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useGroupsDropDown } from "features/SearchGroupDropDown/model/useGroupsDropDown";
import { IStudentModule } from "entities/StudentGroups/type/StudentMonthsSchema";
import { PaymentWaySelect } from "features/PaymentWaySelect";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import { IOption } from "shared/ui/Select/Select";
import { PaymentWaysType } from "shared/lib/enums";

const gapBetween = 4;

interface IStudentForm {
  disabled?: boolean;
  onCancel: () => void;
  onOk: () => void;
  isLoading?: boolean;
  formData?: {};
  data?: IStudentModule;
  isAddNewCourse?: boolean;
}

const StudentStatusForm: FC<IStudentForm> = ({
  disabled,
  onCancel,
  onOk,
  isLoading = false,
  isAddNewCourse = false,
}) => {
  const { clearGroupsSelect } = useGroupsDropDown();
  const { monthSelect } = useMonthsSelect();
  const { courseValueSelect } = useCoursesSelect();
  const { paymentWayData, setPaymentWay, clearAllInputs, errorInputs } =
    useCreateInfos();

  const handleWayChange = useCallback((value: IOption | null) => {
    setPaymentWay("way", value as IOption<PaymentWaysType>);
  }, []);

  const handleSumChange = useCallback((value: string) => {
    setPaymentWay("sum", Number(value));
  }, []);

  useEffect(() => {
    clearAllInputs();
  }, []);
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={10}>
        <UIFlexColumn gap={gapBetween}>
          <Typography variant="Text2">Направление</Typography>
          <CourseSelect
            afterChange={clearGroupsSelect}
            width="100%"
            disabled={disabled}
          />
        </UIFlexColumn>
        <UIFlexColumn gap={gapBetween}>
          <Typography variant="Text2">Месяц</Typography>
          <MonthsSelects
            placeholder={"Выберите месяц"}
            afterChange={clearGroupsSelect}
            width="100%"
          />
        </UIFlexColumn>
        <UIFlexColumn gap={gapBetween}>
          <Typography variant="Text2">Группа</Typography>
          <SearchGroupDropDown
            course_id={courseValueSelect?.value.toString() ?? ""}
            month_number={monthSelect?.value?.toString() ?? ""}
            className={cls.select_group}
          />
        </UIFlexColumn>
        <UIFlexColumn gap={gapBetween}>
          <Typography variant="Text2">Статус</Typography>
          <StatusSelects width="100%" isArchive disabled />
        </UIFlexColumn>
        <UIFlexColumn gap={gapBetween}>
          <Typography variant="Text2">Статус повтора</Typography>
          <RepeatSelect width="100%" />
        </UIFlexColumn>
        <UIFlexColumn gap={gapBetween}>
          <Typography variant="Text2">Статус оплаты</Typography>
          <PaymentSelect width="100%" isStudent />
        </UIFlexColumn>
        {isAddNewCourse && (
          <UIFlexColumn gap={gapBetween}>
            <Typography variant="Text2_bold">{"Тип оплаты"}</Typography>
            <PaymentWaySelect
              width="100%"
              fullWidth
              placeholder={"Тип оплаты"}
              value={paymentWayData.way}
              onChange={handleWayChange}
              sumValue={
                typeof paymentWayData.sum === "number"
                  ? String(paymentWayData.sum)
                  : ""
              }
              onSumChange={handleSumChange}
              errorSum={errorInputs["sum"]}
              isNotStar
            />
          </UIFlexColumn>
        )}
      </UIFlexColumn>
      <UIFlexBetween>
        <Button width={195} theme={ThemeButton.not_bordered} onClick={onCancel}>
          Отмена
        </Button>
        <Button
          width={195}
          theme={isLoading ? ThemeButton.disabled : ThemeButton.outline}
          onClick={onOk}
        >
          {isLoading ? <Loader small /> : "Добавить"}
        </Button>
      </UIFlexBetween>
    </UIFlexColumn>
  );
};

export default StudentStatusForm;

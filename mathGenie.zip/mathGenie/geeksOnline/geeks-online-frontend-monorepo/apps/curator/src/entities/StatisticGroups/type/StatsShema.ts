export interface IStats {
  month: {
    attandance: number;
    grades: number;
    standup: number;
  };
  global: {
    attandance: number;
    grades: number;
    standup: number;
  };
}

import { Button } from "shared/ui";
import { ThemeButton } from "shared/ui/Button/Button";
import { UIModal } from "shared/ui/UIModal/UIModal";
import { useState } from "react";
import StudentStatusForm from "../StudentForm/StudentForm";
import { usePostAddToGroup } from "entities/StudentStatus/model/usePostAddToGroup";
import useStudentForm from "entities/StudentStatus/model/useStudentForm";
import { useEffect } from "react";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import { IStudentCourse } from "entities/StudentGroups/type/StudentMonthsSchema";
import { usePaymentSelect } from "features/PaymentSelect/model/usePaymentSelect";

interface IStudentAddToGroup {
  student_id: string;
  data: IStudentCourse | null;
}

const StudentAddToGroup = ({ student_id, data }: IStudentAddToGroup) => {
  const [open, setOpen] = useState(false);

  const { mutateAsync, isLoading } = usePostAddToGroup();
  const { form, setForm, resetForm } = useStudentForm();

  const { paymentSelect } = usePaymentSelect();

  const { paymentWayData, clearAllInputs } = useCreateInfos();

  const lastModule = data?.student_modules[data?.student_modules.length - 1];
  const lastModuleData = lastModule?.[lastModule?.length - 1];

  const handleCancel = () => setOpen(false);

  const handleSubmitAddToGroup = async () => {
    try {
      await mutateAsync({
        group_id: form.group_id,
        student_id,
        param: {
          previous:
            lastModuleData?.module_status !== "Выпускник"
              ? lastModuleData?.id
              : undefined,
          module_status: form.module_status,
          month: form.month,
          repeat_status: form.repeat_status,
          payment_type: String(paymentWayData.way?.label),
          amount: paymentWayData.sum,
          is_payed: paymentSelect?.value ?? "",
        },
      });
      handleCancel();
    } catch (e) {
      throw e;
    }
  };

  useEffect(() => {
    setForm({
      statusSelectData: { value: "Активный", label: "Активный" },
    });
  }, [open]);

  useEffect(() => {
    return () => {
      resetForm();
      clearAllInputs();
    };
  }, []);

  return (
    <>
      <Button
        width={331}
        onClick={() => setOpen(true)}
        theme={ThemeButton.contained}
      >
        Добавить в другое направление
      </Button>
      <UIModal
        modalWidth="450px"
        title={"Добавить в группу"}
        confirm
        open={open}
        onCancel={handleCancel}
      >
        <StudentStatusForm
          isLoading={isLoading}
          onOk={handleSubmitAddToGroup}
          onCancel={handleCancel}
          data={lastModuleData}
          isAddNewCourse
        />
      </UIModal>
    </>
  );
};

export default StudentAddToGroup;

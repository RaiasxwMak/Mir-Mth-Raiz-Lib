import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { requester } from 'shared/configs/axios/axiosConfig';
import { IMentorDetail } from '../type/IMentorDetailType';

const ENDPOINTS = {
  MENTOR: (student_id: string) => `/api/v1/mentor/${student_id}/`,
};

export const queryKeyDetailMentor = 'detailMentor';

const fetchMentor = async (id: string) => {
  const { data } = await requester.get(ENDPOINTS.MENTOR(id));
  return data;
};

export const useFetchMentor = () => {
  const { student_id } = useParams();
  return useQuery<IMentorDetail>(
    [queryKeyDetailMentor, student_id],
    async () => {
      if (!student_id) return;
      return await fetchMentor(student_id);
    }
  );
};

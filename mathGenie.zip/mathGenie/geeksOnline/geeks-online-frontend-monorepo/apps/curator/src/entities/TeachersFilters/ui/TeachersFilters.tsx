import CourseSelect from 'features/CourseSelect/ui/CourseSelect';
import cls from './TeachersFilters.module.scss';
import SearchGroupsSelect from 'features/SearchGroupsSelect/ui/SearchGroupsSelect/SearchGroupsSelect';
import SelectStatusMonth from 'features/SelectStatusMonth/ui/SelectStatusMonth';
import { useSearchGroupsSelect } from 'features/SearchGroupsSelect/model/useSearchGroupsSelect';

const TeachersFilters = ({ isArchive }: { isArchive?: boolean }) => {
  const { clearSelect } = useSearchGroupsSelect();
  return (
    <div className={cls.selects}>
      <CourseSelect afterChange={clearSelect} />
      {!isArchive && <SearchGroupsSelect className={[cls.searchGroup]} />}
      {!isArchive && <SelectStatusMonth />}
    </div>
  );
};

export default TeachersFilters;

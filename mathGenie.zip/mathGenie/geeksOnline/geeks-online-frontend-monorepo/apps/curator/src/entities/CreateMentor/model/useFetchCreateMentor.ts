import { useMutation } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useNavigate } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS = {
  CREATE_MENTOR: "/api/v1/mentor/",
};

interface ICreateMentor {
  student_id: string;
  course_id: string;
  is_supreme?: boolean;
  is_techmentor?: boolean;
  months: number[];
}

const createMentor = async (param: ICreateMentor) => {
  const response = await requester.post(ENDPOINTS.CREATE_MENTOR, param);
  return response;
};

export const useFetchCreateMentor = () => {
  const navigate = useNavigate();

  const openSuccess = useOpenAlert();

  return useMutation(createMentor, {
    onSuccess: () => {
      openSuccess("Данные успешно сохранены");
      setTimeout(() => navigate(-1), 500);
    },
  });
};

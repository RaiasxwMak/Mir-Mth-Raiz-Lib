export { default as GroupInfoData} from './ui/GroupInfoData'

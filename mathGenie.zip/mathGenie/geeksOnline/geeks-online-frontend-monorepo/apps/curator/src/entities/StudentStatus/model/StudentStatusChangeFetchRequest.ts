import { requester } from 'shared/configs/axios/axiosConfig';
import { IParamStudent } from '../type/StudentStatusSchema';

const ENDPOINTS = {
  STUDENT_GROUP: (group_id: string, student_id: string) =>
    `/api/v1/curator/group/${group_id}/student/${student_id}/`,
  STUDENT_MONTH: (student_id: string, module_id: string) =>
    `/api/v1/curator/students/${module_id}/month/${student_id}/`,
};

export const studentStatusChangePost = async ({
  param,
  student_id,
  group_id,
}: IParamStudent) => {
  if (!student_id) return;
  const response = await requester.post(
    ENDPOINTS.STUDENT_GROUP(group_id ?? '', student_id),
    param
  );
  return response;
};

export const changeStatus = async ({
  param,
  student_id,
  module_id,
}: IParamStudent) => {
  if (!student_id) return;
  const response = await requester.patch(
    ENDPOINTS.STUDENT_MONTH(module_id ?? '', student_id),
    param
  );
  return response;
};

export const deleteStudent = async ({
  student_id,
  group_id,
  module_id,
}: Partial<IParamStudent>) => {
  const response = await requester.delete(
    ENDPOINTS.STUDENT_GROUP(group_id ?? '', student_id ?? ''),
    {
      params: {
        students_module_id: module_id,
      },
    }
  );
  return response;
};

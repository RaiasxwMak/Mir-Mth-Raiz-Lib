import { useQuery } from '@tanstack/react-query';
import { useCoursesSelect } from 'features/CourseSelect/model/useCourseSelect';
import { requester } from 'shared/configs/axios/axiosConfig';
import { usePageChange } from 'shared/ui/CustomPagination/CustomPagination';
import { useEffect } from 'react';
import { useSearchInfo } from 'features/SearchInfo/model/useSearchInfo';
import { IRes } from 'entities/GroupsTable/type/GroupsTableType';

const ENDPOINTS: Record<string, string> = {
  GROUPS_ARCHIVE: 'api/v1/curator/group/archive/',
};

const queryKeyArchiveGroups = 'ArchivegroupsList';

export const useFetchArchiveGroups = () => {
  const { search } = useSearchInfo((state) => state);
  const { courseValueSelect } = useCoursesSelect((state) => state);
  const { page, resetPage } = usePageChange();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [courseValueSelect?.value, search]);

  const limit = 12;
  const offset = (page - 1) * limit;

  return useQuery<IRes>(
    [queryKeyArchiveGroups, page, search, courseValueSelect?.value],
    async () => {
      const { data } = await requester.get(ENDPOINTS.GROUPS_ARCHIVE, {
        params: {
          limit,
          offset,
          course_id:
            courseValueSelect?.value === '0' ? '' : courseValueSelect?.value,
          search,
        },
      });
      return data;
    }
  );
};

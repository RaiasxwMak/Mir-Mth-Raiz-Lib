import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";
import { mentorBalanceKey } from "./useMentorBalance";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { IMentorSpendGroups } from "../type/mentorBalanceTypes";
import { useSearchParams } from "react-router-dom";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export type SpendMethods =
  | "replenishment_mentor_supreme"
  | "tuition_fee"
  | "cancellation"
  | "replenishment";

interface SpendCoinsParams {
  method: SpendMethods;
  body: {
    mentor_id?: string;
    comment?: string;
    amount?: number;
    group_id?: string;
  };
}

export const useSpendCoins = () => {
  const queryClient = useQueryClient();
  const openAlert = useOpenAlert();
  const { resetPage } = usePageChange();

  return useMutation({
    mutationFn: async (param: SpendCoinsParams) => {
      const res = await requester.post(
        `/api/v1/curator/students/mentor/balance/?method=${param.method}`,
        param.body
      );

      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [mentorBalanceKey] });
      openAlert("Сохранено");
      resetPage();
    },
  });
};

export const useMentorSpendGroups = (enabled: boolean) => {
  const [param, _] = useSearchParams();
  const mentorId = param.get("mentor_id");

  return useQuery<IMentorSpendGroups[]>({
    queryFn: async () => {
      if (!mentorId) return;
      const res = await requester.get(
        `/api/v1/curator/students/mentor/${mentorId}/group/`
      );
      return res.data.results;
    },
    queryKey: ["mentorGroups", mentorId],
    enabled,
  });
};

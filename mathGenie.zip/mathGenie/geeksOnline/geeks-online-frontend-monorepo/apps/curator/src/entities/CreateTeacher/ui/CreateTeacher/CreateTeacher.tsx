import { useCreateAvatar } from 'features/CreateAvatarInfo/model/CreateAvatarInfo';
import CreateInfosTeacher from 'features/CreateInfosTeacher/ui/CreateInfosTeacher/CreateInfosTeacher';
import { FC } from 'react';
import CreateAvatar from 'shared/ui/CreateAvatar/CreateAvatar';
import CreateTeacherButton from '../CreateTeacherButton/CreateTeacherButton';
import { UIFlexColumn } from 'shared/ui/UIFlex/UIFlex';

const CreateTeacher: FC = () => {
  const { image, setImage } = useCreateAvatar();
  return (
    <UIFlexColumn style={{ width: 400 }} gap={40}>
      <CreateAvatar image={image} setImage={setImage} avatarSize={140} />
      <CreateInfosTeacher />
      <CreateTeacherButton />
    </UIFlexColumn>
  );
};

export default CreateTeacher;


export interface IInfoTeacher {
    id: string;
    username: string;
    full_name: string;
    photo: null | string;
    telegram: string;
    email: string;
    phone: string;
    is_active:boolean;
    is_deleted: boolean;
    is_staff: boolean;
    is_teacher:boolean;
    is_student: boolean;
    is_curator: boolean;
    role: string;
}

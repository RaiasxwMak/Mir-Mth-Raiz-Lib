import { CustomCheckbox, Typography } from "shared/ui";
import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import { useEffect, useState } from "react";
import { useMentorEdit } from "features/MentorInfoEdit/model/MentorInfoEdit";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { IMentorDetail } from "../type/IMentorDetailType";
import { iMonthsMs } from "entities/CreateMentor/ui/MentorCourse/MentorCourse";
import { CheckboxChangeEvent } from "antd/es/checkbox";
import { useMentorsSelect } from "features/MentorsList/model/useMentorsSelect";
import { CustomSelect, IOption } from "@geeks-online/uikit";

interface CourseData {
  course_id: string;
  course_title: string;
  course_months: number;
  months: number[];
}

const RedactCourseMentor = ({ data }: { data: IMentorDetail }) => {
  const { mutateAsync } = useMentorEdit();
  const { courseChangeSelect } = useCoursesSelect();
  const { mentorsonChange } = useMentorsSelect();

  const [selectedCourseIndex, setSelectedCourseIndex] = useState<number>(0);
  const [monthsHelp, setMonthsHelp] = useState<number[]>([]);
  const [monthsMentors, setMonthsMentors] = useState<iMonthsMs[]>([]);
  const [previousMonthsHelpLength, setPreviousMonthsHelpLength] =
    useState<number>(0);

  const currentCourse: CourseData | undefined =
    data?.courses?.[selectedCourseIndex];

  const courseOptions: IOption[] =
    data?.courses?.map((course, index) => ({
      value: index,
      label: course.course_title,
    })) || [];

  const selectedCourseOption: IOption | null =
    courseOptions[selectedCourseIndex] || null;

  const onChangeCourse = (option: IOption) => {
    setSelectedCourseIndex(Number(option.value));
  };

  const handleChangeAsync = async (
    course: unknown,
    nameCourse: string,
    months: unknown,
    monthsName: string,
    prevLength: unknown,
    prevLengthName: string
  ) => {
    try {
      await mutateAsync({
        [nameCourse]: course,
        [monthsName]: months,
        [prevLengthName]: prevLength,
      });
    } catch {
      setMonthsHelp(currentCourse?.months || []);
    }
  };
  useEffect(() => {
    if (currentCourse) {
      setMonthsHelp(currentCourse.months || []);
      setPreviousMonthsHelpLength(currentCourse.months?.length || 0);

      courseChangeSelect({
        label: currentCourse.course_title,
        value: currentCourse.course_id,
        title: currentCourse.course_months,
      });
    }
  }, [selectedCourseIndex, data, currentCourse]);

  useEffect(() => {
    const selectsList = [];
    if (!currentCourse?.course_months) {
      setMonthsMentors([]);
      return;
    }
    for (let i = 1; i <= currentCourse.course_months; i++) {
      selectsList.push({
        value: i,
        label: `${i} месяц`,
        title: monthsHelp?.includes(i),
      });
    }
    setMonthsMentors(selectsList);
  }, [currentCourse?.course_months, monthsHelp]);

  const onChangeMonths = (e: CheckboxChangeEvent) => {
    const checkedValue = e.target.value;
    const newMonths = monthsHelp.includes(checkedValue)
      ? monthsHelp.filter((value) => value !== checkedValue)
      : [...monthsHelp, checkedValue];

    setPreviousMonthsHelpLength((prevLength) => {
      const updatedLength =
        prevLength === newMonths.length ? prevLength : newMonths.length;
      return updatedLength;
    });

    setMonthsHelp(newMonths);

    handleChangeAsync(
      currentCourse?.course_id,
      "course_id",
      newMonths,
      "months",
      previousMonthsHelpLength,
      "prevLength"
    );
  };

  useEffect(() => {
    if (data?.student_id && data?.full_name) {
      mentorsonChange(data.student_id, {
        label: data.full_name,
        value: data.student_id,
      });
    }
  }, [data]);

  if (!data?.courses || data.courses.length === 0) {
    return (
      <UIFlexColumn gap={4}>
        <Typography variant="Text2_bold">Направления не найдены</Typography>
      </UIFlexColumn>
    );
  }

  return (
    <>
      <UIFlexColumn gap={4}>
        <Typography variant="Text2_bold">
          Направление <span style={{ color: "red" }}>*</span>
        </Typography>
        {data.courses.length > 0 && (
          <CustomSelect
            options={courseOptions}
            value={selectedCourseOption}
            onChange={onChangeCourse}
            width="400px"
            placeholder="Выберите курс"
            isArrow={data.courses.length > 1}
            disabled={data.courses.length <= 1}
          />
        )}
      </UIFlexColumn>
      {currentCourse &&
        monthsMentors?.map((item, key) => (
          <CustomCheckbox
            value={item.value}
            label={item.label}
            checked={item.title}
            onChange={onChangeMonths}
            key={key}
          />
        ))}
    </>
  );
};

export default RedactCourseMentor;

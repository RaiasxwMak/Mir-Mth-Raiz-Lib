import { Input, Loader, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { Avatar } from "antd";
import { IProfileStident } from "../model/useFetchProfileStudent";

const CashierProfileStudent = ({
  data,
  isLoading,
}: {
  data: IProfileStident | undefined;
  isLoading: boolean;
}) => {
  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={20} mt={50} style={{ maxWidth: 500, width: "100%" }}>
      <Avatar src={data?.photo} size={140}>
        {data?.full_name.charAt(0).toUpperCase()}
      </Avatar>
      <UIFlexColumn gap={30}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text2_bold">ФИО</Typography>
          <Input
            value={data?.full_name ?? ""}
            fullWidth
            disabled
            className="inputBlock"
          />
        </UIFlexColumn>
        <UIFlexColumn gap={4}>
          <Typography variant="Text2_bold">Номер телефона</Typography>
          <Input
            value={data?.phone ?? ""}
            fullWidth
            disabled
            className="inputBlock"
          />
        </UIFlexColumn>
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default CashierProfileStudent;

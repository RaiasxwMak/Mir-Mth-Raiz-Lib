import { studentStatusType } from "shared/lib/consts/consts";

export interface IParamStudent {
  student_id?: string;
  module_id?: string;
  group_id?: string;
  students_module_id?: string;
  param: {
    module_status?: studentStatusType | string;
    reject_description?: string;
    pause_start_date?: string;
    pause_end_date?: string;
    pause_reason?: string;
    reject_reason?: string;
    reject_date?: string;
    month?: number | string;
    repeat_status?: string;
    is_payed?: string | number;
    previous?: string;
    discount?: number | null;
    amount?: number | null;
    ignore_date?: string;
    debt?: string;
    overpayment?: string;
    payment_type?: string;
    deposit?: number | null;
  };
}

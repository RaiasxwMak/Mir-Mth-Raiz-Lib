import { useQuery } from '@tanstack/react-query';
import { useGroupInfoSelect } from 'entities/GroupInfoSelect/model/useGroupInfoSelect';
import { useParams } from 'react-router-dom';
import { requester } from 'shared/configs/axios/axiosConfig';
import { IStats } from '../type/StatsShema';

const ENDPOINTS = {
  STATS: (group_id: string, month_id: string) =>
    `/api/v1/curator/stats/${group_id}/${month_id}/`,
};

export const queryKeyStats = 'stats';

const useFetchStats = () => {
  const { group_id } = useParams();
  const { valueSelect } = useGroupInfoSelect();
  return useQuery<IStats>([queryKeyStats, group_id, valueSelect], async () => {
    if (!group_id) return;
    const { data } = await requester.get(
      ENDPOINTS.STATS(group_id, valueSelect?.value?.toString() ?? '')
    );
    return data;
  });
};

export default useFetchStats;

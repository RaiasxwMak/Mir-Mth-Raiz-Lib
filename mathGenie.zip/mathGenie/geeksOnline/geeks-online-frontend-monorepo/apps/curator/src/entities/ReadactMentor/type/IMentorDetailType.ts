export interface IMentorDetail {
  id: string;
  student_id: string;
  full_name: string;
  requisite: string;
  balance: string;
  is_supreme: boolean;
  is_techmentor: boolean;
  is_available: boolean;
  rating: boolean;
  courses: ICources[];
}

export interface ICources {
  course_id: string;
  course_title: string;
  course_months: number;
  months: number[];
}

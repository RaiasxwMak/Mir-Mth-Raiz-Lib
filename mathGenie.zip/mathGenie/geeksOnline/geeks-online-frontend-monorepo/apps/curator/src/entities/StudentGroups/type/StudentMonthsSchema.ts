import { repeatStatus, studentStatusType } from "shared/lib/consts/consts";

export type IStudentMonthGroups = IStudentCourse[];

export interface IStudentCourse {
  course: string;
  student_modules: Array<IStudentModule[]>;
}

export type IStudentMonthCurrentCourse = IStudentCurrentCourse[];

export interface IStudentCurrentCourse {
  course: string;
  student_modules: IStudentModule[];
}

export interface IMarkPayemt {
  students_module_id: string;
  paid_amount: number;
  payment_method: string;
  comment: string;
  payment_date?: string;
  bank_method?: string;
}

export interface IStudentModule {
  id: string;
  course: string;
  group: string;
  month: string;
  group_id: string;
  module_id: string;
  module_status?: studentStatusType | null;
  repeat_status: null | repeatStatus;
  dynamic_module_status: string;
  dynamic_repeat_status: string;
  pause_start_date?: string;
  pause_end_date?: string;
  pause_reason?: string;
  is_payed: boolean;
  reject_reason?: string;
  reject_date?: string;
  amount?: number;
  discount?: number;
  deposit?: number;
  ignore_date?: string;
  debt: string;
  for_payment: string;
  last_payment_comment: string;
  next_module_debt: string;
  next_module_has_debt: boolean;
  overpayment: string;
  paid_amount: string;
  payment_type: string;
  payments: IMarkPayemt[];
  remains: string;
}

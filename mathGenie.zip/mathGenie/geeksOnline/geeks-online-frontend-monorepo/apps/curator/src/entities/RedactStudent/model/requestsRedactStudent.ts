import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { requester } from 'shared/configs/axios/axiosConfig';
import { IStudentDetail } from '../type/RedactStudentSchema';

const ENDPOINTS = {
  STUDENT: (id: string) => `/api/v1/curator/students/list/${id}/`,
};

export const queryKeyDetailStudent = 'detailStudent';

const fetchStudent = async (id: string) => {
  const { data } = await requester.get(ENDPOINTS.STUDENT(id));
  return data;
};

export const useFetchStudent = () => {
  const { id } = useParams();
  return useQuery<IStudentDetail>([queryKeyDetailStudent], async () => {
    if (!id) return;
    return await fetchStudent(id);
  });
};

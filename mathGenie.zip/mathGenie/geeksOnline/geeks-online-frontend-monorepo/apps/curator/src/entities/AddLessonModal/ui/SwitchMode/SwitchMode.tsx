import { Dispatch, SetStateAction } from "react";
import cls from "./SwitchMode.module.scss";
import { Typography } from "shared/ui";

interface SwitchModeProps {
  setMode: Dispatch<SetStateAction<boolean>>;
  mode: boolean;
}

export const SwitchMode = ({ setMode, mode }: SwitchModeProps) => {
  return (
    <div className={cls.switcher}>
      <div
        onClick={() => setMode(true)}
        style={{
          background: !mode ? "transparent" : "rgba(34, 36, 41, 1)",
        }}
      >
        <Typography variant="Title2">{"Доп.урок"}</Typography>
      </div>
      <div
        onClick={() => setMode(false)}
        style={{
          background: mode ? "transparent" : "rgba(34, 36, 41, 1)",
        }}
      >
        <Typography variant="Title2">Собрание</Typography>
      </div>
    </div>
  );
};

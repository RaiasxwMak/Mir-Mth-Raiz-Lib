import { formatDateMonth, maskInputDate } from 'shared/lib/helpers/helpers';
import { Button, Input, Loader, Typography } from 'shared/ui';
import { ThemeButton } from 'shared/ui/Button/Button';
import { UIFlexBetween, UIFlexColumn } from 'shared/ui/UIFlex/UIFlex';
import { FC, useState } from 'react';
import useStudentStatus from 'entities/StudentStatus/model/useStudentStatus';
import { useOpenErrorAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { failDate, failEmpty } from 'shared/lib/consts/consts';

interface IStudentRejectForm {
  onClose: () => void;
  student_id: string;
  module_id: string;
  afterRequest?: () => void;
}

const StudentIgnoreForm: FC<IStudentRejectForm> = ({
  onClose,
  student_id,
  module_id,
  afterRequest,
}) => {
  const { mutateAsync, isLoading } = useStudentStatus();
  const openError = useOpenErrorAlert();

  const [ignoreReason, setIgnoreReason] = useState('');

  const handleClickRequest = async () => {
    try {
      if (ignoreReason.trim()) {
        if (!formatDateMonth(ignoreReason)) return openError(failDate);
        await mutateAsync({
          param: {
            module_status: 'Игнор',
            ignore_date: formatDateMonth(ignoreReason),
          },
          student_id,
          module_id,
        });
        if (afterRequest) afterRequest();
        onClose();
      } else openError(failEmpty);
    } catch (e) {
      throw e;
    }
  };

  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={8}>
        <UIFlexColumn gap={4}>
          <label htmlFor='startC'>
            <Typography variant='Text2'>Начало игнора</Typography>
          </label>
          <Input
            placeholder='12.12.2023'
            mask={maskInputDate}
            value={ignoreReason}
            onChange={(e) => setIgnoreReason(e.target.value)}
            fullWidth
            id='startC'
          />
        </UIFlexColumn>
      </UIFlexColumn>
      <UIFlexBetween>
        <Button width={210} theme={ThemeButton.not_bordered} onClick={onClose}>
          Отмена
        </Button>
        <Button
          width={210}
          onClick={handleClickRequest}
          theme={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        >
          {isLoading ? <Loader small /> : 'Сохранить'}
        </Button>
      </UIFlexBetween>
    </UIFlexColumn>
  );
};

export default StudentIgnoreForm;

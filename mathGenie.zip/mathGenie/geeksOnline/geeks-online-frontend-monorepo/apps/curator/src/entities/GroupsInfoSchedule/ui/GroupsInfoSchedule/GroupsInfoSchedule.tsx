import {
  Button,
  Input,
  Loader,
  ThemeButton,
  Typography,
} from "@geeks-online/uikit";
import { ChangeEvent, FC, useEffect, useMemo, useState } from "react";
import { CustomCheckbox, TimeRangeSelect } from "shared/ui";
import { CheckboxChangeEvent } from "antd/es/checkbox";
import { CALENDAR_HOURS } from "shared/lib/consts/consts";
import { useTimeRange } from "shared/ui/TimeRangeSelect/model/useTimeRange";
import { useFloorsAndRoomsSelect } from "features/FloorsAndRoomsSelect/model/useFloorsAndRooms";
import {
  IParamAutoReservation,
  useAutoReservation,
  useGetAutoReserve,
} from "entities/GroupsInfoSchedule/model/useAutoReservation";
import {
  formatDateMonth,
  getFormatDateMonth,
} from "shared/lib/helpers/helpers";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import FloorsAndRoomsSelect from "features/FloorsAndRoomsSelect/ui/FloorsAndRoomsSelect";
import dayjs from "dayjs";
import cls from "./GroupsInfoSchedule.module.scss";

const weekdays = [
  { id: 1, label: "Пн" },
  { id: 2, label: "Вт" },
  { id: 3, label: "Ср" },
  { id: 4, label: "Чт" },
  { id: 5, label: "Пт" },
  { id: 6, label: "Сб" },
  { id: 7, label: "Вс" },
];

interface IInfoSchedule {
  lesson_per_week: number;
  online: boolean;
}

const GroupsInfoSchedule: FC<IInfoSchedule> = ({ lesson_per_week, online }) => {
  const errorAlert = useOpenErrorAlert();
  const { data, isLoading: loding } = useGetAutoReserve();
  const [dates, setDates] = useState({ start_date: "", end_date: "" });
  const [weekIds, setWeekIds] = useState<number[]>([]);
  const { timeRangeSelect, changeSelectTimerange, resetSelect } =
    useTimeRange();
  const { floorsSelect, changeFloors, roomsSelect, changeRooms, resetSelects } =
    useFloorsAndRoomsSelect();

  const [isChanging, setIsChanging] = useState(false);

  const { mutateAsync, isLoading } = useAutoReservation(data?.id);

  const hourOptions = useMemo(() => {
    return CALENDAR_HOURS.map((hour) => ({
      label: hour,
      value: hour,
    }));
  }, []);

  const handleIsChange = () => setIsChanging(true);

  const handleDateChange = (e: ChangeEvent<HTMLInputElement>, name: string) => {
    setDates((prev) => ({ ...prev, [name]: e.target.value }));
    handleIsChange();
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;
    if (!value.trim()) return;

    const isValidDate = dayjs(value, "DD.MM.YYYY", true).isValid();
    if (!isValidDate) {
      errorAlert("Неверная дата");
      setDates((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const checkboxChange = (e: CheckboxChangeEvent) => {
    const checkedValue = e.target.value;
    setWeekIds((prev) => {
      const existingIndex = prev.findIndex((item) => item === checkedValue);
      if (existingIndex !== -1) {
        handleIsChange();
        return prev.filter((_, index) => index !== existingIndex);
      } else {
        if (prev.length < lesson_per_week) {
          handleIsChange();
          return [...prev, checkedValue];
        }
        return prev;
      }
    });
  };

  const handleAutoReserve = async () => {
    const data: IParamAutoReservation = {
      weekdays: weekIds,
      start_date: formatDateMonth(dates.start_date),
      end_date: formatDateMonth(dates.end_date),
      start_time: String(timeRangeSelect?.start?.value),
      end_time: String(timeRangeSelect?.end?.value),
    };
    if (!online) {
      data.classroom = Number(roomsSelect?.value);
      data.floor = Number(floorsSelect?.value);
    }
    await mutateAsync(data);
    setIsChanging(false);
  };

  const areFieldsValid =
    dates.start_date &&
    weekIds.length > 0 &&
    timeRangeSelect?.start?.value &&
    timeRangeSelect?.end?.value &&
    (online ||
      (typeof floorsSelect?.value === "number" &&
        typeof roomsSelect?.value === "number"));

  const btnDisabled = data?.id
    ? !isChanging || !areFieldsValid
    : !areFieldsValid;

  useEffect(() => {
    setDates({
      start_date: getFormatDateMonth(data?.start_date) ?? "",
      end_date: getFormatDateMonth(data?.end_date) ?? "",
    });
    setWeekIds(data?.weekdays ?? []);

    if (data?.start_time && data?.end_time) {
      changeSelectTimerange({
        start: {
          value: data?.start_time,
          label: data?.start_time,
        },
        end: {
          value: data?.end_time,
          label: data?.end_time,
        },
      });
    } else {
      changeSelectTimerange({
        start: undefined,
        end: undefined,
      });
    }

    if (!online) {
      changeFloors({
        label: data?.floor ?? "",
        value: data?.floor ?? "",
      });
      changeRooms({
        label: data?.classroom ?? "",
        value: data?.classroom ?? "",
      });
    }
  }, [data, online]);

  useEffect(() => {
    return () => {
      resetSelect();
      resetSelects();
    };
  }, []);
  if (loding) return <Loader />;
  return (
    <div className={cls.wrap}>
      <div className={cls.schedule}>
        <div className={cls.dates}>
          <div className={cls.date}>
            <Typography variant="Text2_bold" className={cls.text}>
              Дата старта
            </Typography>
            <Input
              name="start_date"
              value={dates.start_date}
              onChange={(e) => handleDateChange(e, "start_date")}
              onBlur={handleBlur}
              mask="99.99.9999"
              placeholder="чч.мм.гггг"
              fullWidth
            />
          </div>
          <div className={cls.date}>
            <Typography variant="Text2_bold" className={cls.text}>
              Дата финиша
            </Typography>
            <Input
              name="end_date"
              value={dates.end_date}
              onChange={(e) => handleDateChange(e, "end_date")}
              onBlur={handleBlur}
              mask="99.99.9999"
              placeholder="чч.мм.гггг"
              fullWidth
            />
          </div>
        </div>
        <div className={cls.weeks}>
          <Typography variant="Text2_bold">Добавить расписание</Typography>
          <div className={cls.weekdays}>
            {weekdays.map((day) => (
              <CustomCheckbox
                key={day.id}
                onChange={checkboxChange}
                checked={weekIds.some((item) => item === day.id)}
                value={day.id}
                label={day.label}
              />
            ))}
          </div>
        </div>
        <div className={cls.hours}>
          <TimeRangeSelect
            width="100px"
            height="40px"
            startOptions={hourOptions}
            endOptions={hourOptions}
            placeholder="чч:мм"
            isChanging={handleIsChange}
          />
        </div>
        {!online && (
          <div className={cls.floors}>
            <Typography variant="Text2_bold">
              Добавить этаж и аудиторию
            </Typography>
            <FloorsAndRoomsSelect isChanging={handleIsChange} />
          </div>
        )}
      </div>
      <Button
        isLoading={isLoading}
        theme={btnDisabled ? ThemeButton.disabled : ThemeButton.contained}
        onClick={handleAutoReserve}
      >
        Сохранить
      </Button>
    </div>
  );
};

export default GroupsInfoSchedule;

import { create } from 'zustand';

interface form {
  rejectReason: string;
  startRejectReason: string;
}
interface IuseRejectForm extends form {
  setRejectForm: (param: Partial<form> ) => void;
  resetRejectForm: () => void;
}

export const useRejectForm = create<IuseRejectForm>((set) => ({
  rejectReason: '',
  startRejectReason: '',
  setRejectForm: (param: { rejectReason?: string; startRejectReason?: string }) => {
    set(prev=> ({...prev, ...param}))
  },
  resetRejectForm: () => {
    set({rejectReason: '', startRejectReason: ''})
  }
}));

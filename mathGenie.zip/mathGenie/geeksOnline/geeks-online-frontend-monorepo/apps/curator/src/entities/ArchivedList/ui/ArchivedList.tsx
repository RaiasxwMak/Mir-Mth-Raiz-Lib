import { Loader, Typography } from 'shared/ui';
import cls from './ArchivedList.module.scss';
import { FC } from 'react';
import { useGetArchivesCount } from '../model/useGetArchivesCount';
import { useNavigate } from 'react-router-dom';

const navigateList = ['students', 'teachers', 'groups'];

const ArchivedList: FC = () => {
  const { data, isLoading } = useGetArchivesCount();
  const navigate = useNavigate();

  const archiveArr = ['Название архива', 'Количество'];

  if (isLoading) return <Loader height='600px' />;
  return (
    <div className={cls.archived}>
      <div className={cls.archive}>
        <ul className={cls.headlist}>
          {archiveArr.map((item, index) => (
            <li key={index}>
              <Typography variant='Text2'>{item}</Typography>
            </li>
          ))}
        </ul>
        <ul className={cls.archivesList}>
          {data?.map((elm, key) => (
            <li key={key} onClick={() => navigate(navigateList[key])}>
              <Typography variant='Text2'>{elm.title}</Typography>
              <Typography variant='Text2'>{elm.count}</Typography>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ArchivedList;

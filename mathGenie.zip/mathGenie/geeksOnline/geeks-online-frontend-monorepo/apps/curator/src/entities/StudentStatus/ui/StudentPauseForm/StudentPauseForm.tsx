import { useState, FC, useEffect } from "react";
import { formatDateMonth, maskInputDate } from "shared/lib/helpers/helpers";
import { Button, Input, Loader, Typography } from "shared/ui";
import { ThemeButton } from "shared/ui/Button/Button";
import { Textarea } from "shared/ui/Textarea/Textarea";
import { UIFlexBetween, UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import useStudentStatus from "entities/StudentStatus/model/useStudentStatus";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { failDate, failEmpty } from "shared/lib/consts/consts";
import { dateDiff } from "shared/lib/helpers/dateDiff";
import { usePauseForm } from "entities/StudentStatus/model/usePauseForm";

interface IStudentPauseForm {
  student_id: string;
  module_id: string;
  onClose: () => void;
  afterRequest?: () => void;
}

const StudentPauseForm: FC<IStudentPauseForm> = ({
  student_id,
  module_id,
  onClose,
  afterRequest,
}) => {
  const openError = useOpenErrorAlert();

  const { mutateAsync, isLoading } = useStudentStatus();
  const { cause, startCause, endCause, resetPauseForm, setPauseForm } =
    usePauseForm();

  const [errorDate, setErrorDate] = useState(false);

  const handleClickRequest = async () => {
    const diff = dateDiff(startCause, endCause);

    if (diff >= 0) {
      openError(failDate);
      setErrorDate(true);
      const timeoutId = setTimeout(() => {
        setErrorDate(false);
        clearTimeout(timeoutId);
      }, 2000);
      return;
    }

    try {
      if (cause.trim() && startCause.trim() && endCause.trim()) {
        if (!formatDateMonth(startCause) || !formatDateMonth(endCause))
          return openError(failDate);
        await mutateAsync({
          param: {
            module_status: "Пауза",
            pause_start_date: formatDateMonth(startCause),
            pause_end_date: formatDateMonth(endCause),
            pause_reason: cause,
          },
          student_id,
          module_id,
        });
        if (!isLoading) onClose();
        if (afterRequest) afterRequest();
      } else openError(failEmpty);
    } catch {}
  };

  useEffect(() => {
    return () => resetPauseForm();
  }, []);

  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={8}>
        <label>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2">Причина</Typography>
            <Textarea
              notShow
              value={cause}
              onChange={(e) => setPauseForm({ cause: e.target.value })}
              placeholder={"Введите причину ..."}
              height="60px"
            />
          </UIFlexColumn>
        </label>
        <label>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2">Начало паузы</Typography>
            <Input
              placeholder="12.12.2023"
              mask={maskInputDate}
              value={startCause}
              error={errorDate}
              onChange={(e) => setPauseForm({ startCause: e.target.value })}
              fullWidth
            />
          </UIFlexColumn>
        </label>
        <label>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2">Конец паузы</Typography>
            <Input
              placeholder="12.12.2023"
              mask={maskInputDate}
              value={endCause}
              error={errorDate}
              onChange={(e) => setPauseForm({ endCause: e.target.value })}
              fullWidth
            />
          </UIFlexColumn>
        </label>
      </UIFlexColumn>
      <UIFlexBetween>
        <Button width={210} theme={ThemeButton.not_bordered} onClick={onClose}>
          Отмена
        </Button>
        <Button
          width={210}
          onClick={handleClickRequest}
          theme={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        >
          {isLoading ? <Loader small /> : "Сохранить"}
        </Button>
      </UIFlexBetween>
    </UIFlexColumn>
  );
};

export default StudentPauseForm;

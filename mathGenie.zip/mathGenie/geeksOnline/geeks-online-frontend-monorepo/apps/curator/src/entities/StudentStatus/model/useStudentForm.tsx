import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { usePaymentSelect } from "features/PaymentSelect/model/usePaymentSelect";
import { useStatusSelects } from "features/StatusSelects/model/useStatusSelects";
import { useRepeatSelect } from "features/RepeatSelect/model/useRepeatSelect";
import { IOption } from "shared/ui/Select/Select";
import { useMonthsSelect } from "features/MonthsSelects/model/useMonthsSelects";
import { useGroupsDropDown } from "features/SearchGroupDropDown/model/useGroupsDropDown";
import { useCallback } from "react";

interface IsetForm {
  courseValueData?: IOption;
  groupSelectData?: { value: string; option?: any };
  statusSelectData?: IOption;
  paymentSelectData?: IOption;
  repeatSelectData?: IOption;
  monthSelectData?: IOption;
}

interface IuseStudentFormResp {
  form: {
    course: string;
    repeat_status?: string | undefined;
    group_id: string;
    module_status?: string;
    is_payed?: string;
    month?: string;
  };
  setForm: (param: IsetForm) => void;
  resetForm: () => void;
}

const useStudentForm = (): IuseStudentFormResp => {
  const { courseValueSelect, courseChangeSelect, courseResetSelect } =
    useCoursesSelect();
  const { monthSelect, changeSelectMonth, resetSelect } = useMonthsSelect();
  const { groupsDropDownSelect, onChangeGroupsDropDown, clearGroupsSelect } =
    useGroupsDropDown();
  const { statusSelect, onChangeStatusSelects, onClearStatusSelects } =
    useStatusSelects();
  const { repeatSelect, onChangeRepeatSelect, onClearRepeatSelect } =
    useRepeatSelect();
  const { paymentSelect, onClearPaymentSelect, onChangePaymentSelect } =
    usePaymentSelect();

  const setForm = ({
    courseValueData,
    groupSelectData,
    statusSelectData,
    paymentSelectData,
    repeatSelectData,
    monthSelectData,
  }: IsetForm) => {
    if (courseValueData) courseChangeSelect(courseValueData);
    if (groupSelectData)
      onChangeGroupsDropDown(groupSelectData.value, groupSelectData.option);
    if (statusSelectData) onChangeStatusSelects(statusSelectData);
    if (paymentSelectData) onChangePaymentSelect(paymentSelectData);
    if (repeatSelectData) onChangeRepeatSelect(repeatSelectData);
    if (monthSelectData) changeSelectMonth(monthSelectData);
  };

  const resetForm = useCallback(() => {
    courseResetSelect();
    resetSelect();
    clearGroupsSelect();
    onClearStatusSelects();
    onClearRepeatSelect();
    onClearPaymentSelect();
  }, []);

  return {
    form: {
      course: courseValueSelect?.value?.toString() ?? "",
      month: monthSelect?.value?.toString(),
      group_id: groupsDropDownSelect?.value,
      module_status: statusSelect?.value?.toString(),
      is_payed: paymentSelect?.value.toString(),
      repeat_status: repeatSelect?.value?.toString(),
    },
    setForm,
    resetForm,
  };
};

export default useStudentForm;

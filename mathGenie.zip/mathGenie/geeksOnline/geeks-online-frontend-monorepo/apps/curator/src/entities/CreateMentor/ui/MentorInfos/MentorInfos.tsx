import MentorsList from 'features/MentorsList/ui/MentorsList';
import { FC } from 'react';
import { Typography } from 'shared/ui';
import { UIFlexColumn } from 'shared/ui/UIFlex/UIFlex';
import MentorCourse from '../MentorCourse/MentorCourse';

const MentorInfos: FC = () => {
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={4}>
        <Typography variant='Text2_bold'>
          ФИО студента <span style={{ color: 'red' }}>*</span>
        </Typography>
        <MentorsList />
      </UIFlexColumn>
      <MentorCourse />
    </UIFlexColumn>
  );
};

export default MentorInfos;

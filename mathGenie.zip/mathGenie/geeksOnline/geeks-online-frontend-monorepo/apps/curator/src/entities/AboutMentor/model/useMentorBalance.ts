import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { IMentorBalance } from "../type/mentorBalanceTypes";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export const mentorBalanceKey = "mentorBalanceKey";

export const useGetMentorBalance = () => {
  const { page } = usePageChange();
  const [param, _] = useSearchParams();
  const mentorId = param.get("mentor_id");

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    offset,
    limit,
  };

  return useQuery<IMentorBalance>({
    queryFn: async () => {
      if (!mentorId) return;
      const res = await requester.get(
        `/api/v1/curator/students/mentor/${mentorId}/balance/history/`,
        { params }
      );
      return res.data;
    },
    queryKey: [mentorBalanceKey, mentorId, page],
  });
};

import { GroupsTable } from "./ui/GroupsTabels/GroupsTable";
import { GroupsSelects } from "./ui/GroupsSelects/GroupsSelects";

export { GroupsTable, GroupsSelects };

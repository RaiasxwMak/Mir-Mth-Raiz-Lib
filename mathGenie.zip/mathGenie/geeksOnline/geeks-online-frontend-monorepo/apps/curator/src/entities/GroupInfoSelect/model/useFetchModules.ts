import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { IModules } from "../type/GroupInfoSelect";

const ENDPOINTS = {
  month: (group_id: string) => `/api/v1/curator/group/${group_id}/modules/`,
};

export const queryKeyModules = "modulesInfo";

const useFetchModules = (groupId?: string, isSchedule?: boolean) => {
  const { group_id, month_id } = useParams();
  const GROUP_ID = groupId ?? group_id;
  return useQuery<IModules[]>(
    [queryKeyModules, GROUP_ID, month_id],
    async () => {
      if (!GROUP_ID) return;
      const { data } = await requester.get(ENDPOINTS.month(GROUP_ID ?? ""), {
        params: isSchedule ? { is_shedule: 1 } : {},
      });
      return data;
    }
  );
};

export default useFetchModules;

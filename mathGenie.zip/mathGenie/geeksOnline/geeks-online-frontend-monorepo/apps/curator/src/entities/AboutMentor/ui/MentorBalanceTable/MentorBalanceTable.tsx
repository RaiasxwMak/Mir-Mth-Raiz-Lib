import { EmptyState, Input, Loader, TableAccordion } from "@geeks-online/uikit";
import { useGetMentorBalance } from "entities/AboutMentor/model/useMentorBalance";
import cls from "./MentorBalance.module.scss";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import { useMemo } from "react";
import dayjs from "dayjs";
import MentorSpends from "../MentorSpends/MentorSpends";

const MentorBalanceTable = () => {
  const { data, isLoading } = useGetMentorBalance();

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Пополнение":
        return "#00A210";
      case "Списывание":
        return "#DA2222";
      default:
        return "inherit";
    }
  };

  const formatAmount = (amount: string, status: string) => {
    switch (status) {
      case "Пополнение":
        return `+${amount}`;
      case "Списывание":
        return `-${amount}`;
      default:
        return amount;
    }
  };

  const shouldShowAccordion = (note: string) => {
    const normalizedNote = note.toLowerCase();
    return normalizedNote === "менторство" || normalizedNote === "за учебу";
  };

  const columns = [
    { title: "№", dataIndex: "key" },
    { title: "Дата", dataIndex: "created_at" },
    { title: "ФИО", dataIndex: "full_name" },
    { title: "Тип", dataIndex: "status", width: "20%" },
    { title: "Примечание", dataIndex: "note" },
    { title: "Сумма", dataIndex: "amount" },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((module, index) => ({
      ...module,
      key: index + 1,
      created_at: dayjs(module.created_at).format("DD.MM.YYYY"),
      status: (
        <div
          className={cls.table_cell}
          style={{ color: getStatusColor(module.status) }}
        >
          {module.status}
        </div>
      ),
      amount: (
        <div className={cls.table_cell}>
          {formatAmount(module.amount, module.status)}
        </div>
      ),
      description: (
        <div className={cls.accordion}>
          <div className={cls.infos}>
            <div className={cls.accordionCell}>
              <div className={cls.accordionTitle}>Направление</div>
              <Input
                fullWidth
                placeholder={"Направление"}
                value={module.course ?? ""}
                disabled
              />
            </div>
            <div className={cls.accordionCell}>
              <div className={cls.accordionTitle}>Группа</div>
              <Input
                fullWidth
                placeholder={"Группа"}
                value={module.group ?? ""}
                disabled
              />
            </div>
            <div className={cls.accordionCell}>
              <div className={cls.accordionTitle}>Месяц</div>
              <Input
                fullWidth
                placeholder={"Месяц"}
                value={String(module.month_number) ?? ""}
                disabled
              />
            </div>
            {module.lesson_number && (
              <div className={cls.accordionCell}>
                <div className={cls.accordionTitle}>Номер урока</div>
                <Input
                  fullWidth
                  placeholder="Номер урока"
                  value={module.lesson_number ?? ""}
                  disabled
                />
              </div>
            )}
          </div>
        </div>
      ),
      expand: shouldShowAccordion(module.note),
    }));
  }, [data]);

  if (isLoading) return <Loader />;

  if (!data?.results.length)
    return (
      <div>
        <div className="tableWidth">
          <EmptyState text={"Здесь пока ничего нет"} />
        </div>
        <div className={cls.cashOuts}>
          <MentorSpends method="replenishment" />
          <MentorSpends method="cancellation" />
        </div>
      </div>
    );
  return (
    <div>
      <div className="tableWidth">
        <TableAccordion
          columns={columns}
          showHeader={true}
          className={cls.table}
          accordion={true}
          dataSource={dataSource}
          rowExpandedColor="rgba(198, 198, 198, 0.12)"
        />
      </div>
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
      <div className={cls.cashOuts}>
        <MentorSpends method="replenishment" />
        <MentorSpends method="cancellation" />
      </div>
    </div>
  );
};

export default MentorBalanceTable;

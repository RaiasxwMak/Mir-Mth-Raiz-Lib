import { INote } from "entities/CashierStudentsList/type/StudentSchema";
import { studentStatusType, teacherStatusType } from "shared/lib/consts/consts";

export interface IGroupInfoData {
  id: string;
  title: string;
  number: number;
  teacher: null | ITeacher;
  students: [] | IStudent[];
  status: null | teacherStatusType | string;
  dynamic_status: string;
  start_date: null | string;
  end_date: null | string;
  next_month_id: null | string;
  is_month_result_sent: boolean;
  lesson_per_week: number;
  online: boolean;
  groups: {
    id: string;
    title: string;
    course: {
      id: string;
      title: string;
    };
    is_graduated: boolean;
  };
}

export interface ITeacher {
  id: string;
  user?: {
    id: string;
    full_name: string;
    photo: string;
  };
}

export interface IStudent {
  student: {
    id: string;
    user: {
      id: string;
      full_name: string;
      photo: string;
    };
  };
  id: string;
  module_status: studentStatusType;
  repeat_status: string;
  dynamic_module_status: string;
  dynamic_repeat_status: string;
  is_graduated: boolean;
  paid: boolean;
  paid_amount: number;
  remains: number;
  debt: string;
  archive_debt: string;
  debt_paid: boolean;
  amount: number | null;
  discount: number | null;
  for_payment: number | null;
  comment: string;
  note: INote | null;
  is_welcome_letter: boolean;
}

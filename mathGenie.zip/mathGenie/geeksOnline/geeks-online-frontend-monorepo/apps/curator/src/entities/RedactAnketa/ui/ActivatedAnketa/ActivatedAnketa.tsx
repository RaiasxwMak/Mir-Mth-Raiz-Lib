import {
  Button,
  Input,
  IOption,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIFlexRow,
  UIModal,
} from "@geeks-online/uikit";
import { Tooltip } from "antd";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useAnketaForm } from "entities/RedactAnketa/model/anketaForm";
import {
  useActivateAnketa,
  useFetchAnketaStudent,
} from "entities/RedactAnketa/model/useFetchAnketaStudent";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import CreateGroupStudent from "features/CreateStudentInfo/ui/CreateGroupStudent/CreateGroupStudent";
import { PaymentWaySelect } from "features/PaymentWaySelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { useCallback, useEffect, useState } from "react";
import { ReactComponent as Contract } from "shared/assets/icon/contractAnketa.svg";
import { ReactComponent as DisableContract } from "shared/assets/icon/contractAnketaDisable.svg";
import { PaymentWaysType } from "shared/lib/enums";
import { useFetchGenerateCredentials } from "features/GenerateCredentials/model/useFetchGenerateCredentials";

interface InputField {
  username: string;
  password: string;
  confirm_password: string;
  discount: string;
  deposit: string;
}

const ActivatedAnketa = () => {
  const { mutateAsync, isLoading: activatedLoading } = useActivateAnketa();
  const { data, isLoading } = useFetchAnketaStudent();
  const { data: credentialsData } = useFetchGenerateCredentials(
    data?.full_name || ""
  );
  const { clearSelect, groupsSelect } = useSearchGroupsSelect();
  const {
    errorInputs,
    clearAllInputs,
    paymentWayData,
    setPaymentWay,
    setErrorInputs,
  } = useCreateInfos();

  const { courseValueSelect, courseResetSelect } = useCoursesSelect();

  const { isChange } = useAnketaForm();

  const openError = useOpenErrorAlert();

  const [inputs, setInputs] = useState<InputField>({
    username: "",
    password: "",
    confirm_password: "",
    discount: "0",
    deposit: "0",
  });
  useEffect(() => {
    if (credentialsData) {
      setInputs((prev) => ({
        ...prev,
        username: credentialsData.username || "",
        password: credentialsData.password || "",
        confirm_password: credentialsData.password || "",
      }));
    }
  }, [credentialsData]);

  const [open, setOpen] = useState(false);

  const onClose = () => setOpen(false);

  const studentInfo = [
    {
      name: "username",
      label: "Логин",
      star: "*",
      type: "text",
      placeholder: "Логин",
    },
    {
      name: "password",
      label: "Пароль",
      star: "*",
      type: "text",
      placeholder: "Пароль",
      helper: "Введите не менее 5 символов (цифры, буквы)",
    },
    {
      name: "confirm_password",
      label: "Подтверждение пароля",
      star: "*",
      type: "text",
      placeholder: "Подтверждение пароля",
    },
  ];

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;
    if (name === "deposit" || name === "discount") {
      const numericValue = value.replace(/\D/g, "");
      setInputs((prev) => ({
        ...prev,
        [name]: numericValue === "" ? "0" : numericValue,
      }));
    } else {
      setInputs((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleWayChange = useCallback((value: IOption | null) => {
    setPaymentWay("way", value as IOption<PaymentWaysType>);
  }, []);

  const handleSumChange = useCallback((value: string) => {
    setPaymentWay("sum", Number(value));
  }, []);

  const handleActivate = async () => {
    try {
      if (
        !inputs.username ||
        !inputs.password ||
        !inputs.confirm_password ||
        !paymentWayData.way?.label ||
        !groupsSelect.value ||
        !courseValueSelect?.value
      )
        return openError("Заполните все обязательные поля");

      if (
        paymentWayData.way?.label !== "Ежемесячная оплата" &&
        typeof paymentWayData.sum !== "number"
      ) {
        setErrorInputs("sum", true);
        return openError("Заполните все обязательные поля");
      }

      if (inputs.confirm_password !== inputs.password)
        return openError("Пароли не совпадают");

      if (inputs.password.length < 5 && inputs.confirm_password.length < 5)
        return openError("Пароль должен содержать не менее 5 символов");

      const isNotAmount = paymentWayData.way.value === "monthly";
      await mutateAsync({
        ...inputs,
        deposit: inputs.deposit || "0",
        discount: inputs.discount || "0",
        group_id: groupsSelect.value || null,
        payment_type: String(paymentWayData.way?.label),
        amount: isNotAmount ? "0" : String(paymentWayData.sum || 0),
      });
      onClose();
    } catch {}
  };

  useEffect(() => {
    return () => {
      clearAllInputs();
      clearSelect();
      courseResetSelect();
    };
  }, []);
  return (
    <UIFlexRow gap={20}>
      {!data?.activated && (
        <Button
          style={{ height: 50 }}
          isLoading={isLoading}
          theme={ThemeButton.contained}
          onClick={() => setOpen(true)}
        >
          Активировать
        </Button>
      )}
      <UIModal
        title="Активировать студента"
        open={open}
        onCancel={onClose}
        onCancelRequest={onClose}
        onOkRequest={handleActivate}
        cancelTitle="Закрыть"
        okTitle="Создать"
        isLoading={activatedLoading}
      >
        <UIFlexColumn gap={20} mt={20} mb={40}>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2_bold">
              Направление <span style={{ color: "red" }}>*</span>
            </Typography>
            <CourseSelect width="100%" />
          </UIFlexColumn>
          <CreateGroupStudent
            star
            isStudent
            fullWidth
            course_id={String(courseValueSelect?.value)}
          />
          <PaymentWaySelect
            width="100%"
            isLabel
            isNotStar={false}
            fullWidth
            isFullWrap
            value={paymentWayData.way}
            onChange={handleWayChange}
            sumValue={
              typeof paymentWayData.sum === "number"
                ? String(paymentWayData.sum)
                : ""
            }
            onSumChange={handleSumChange}
            errorSum={errorInputs["sum"]}
          />
          {paymentWayData.way?.label === "Ежемесячная оплата" && (
            <UIFlexColumn gap={4}>
              <Typography variant="Text2_bold">
                Депозит <span style={{ color: "red" }}>*</span>
              </Typography>
              <Input
                value={inputs.deposit}
                name="deposit"
                mask={"99999999999"}
                onChange={inputsChange}
                fullWidth
                placeholder={"Депозит"}
              />
            </UIFlexColumn>
          )}
          <UIFlexColumn gap={4}>
            <Typography variant="Text2_bold">Скидка</Typography>
            <Input
              value={inputs.discount}
              name="discount"
              mask={"99999999999"}
              onChange={inputsChange}
              fullWidth
              placeholder={"Скидка"}
            />
          </UIFlexColumn>
          {studentInfo.map((item, key) => (
            <UIFlexColumn gap={4} key={key}>
              <Typography variant="Text2_bold">
                {item.label} <span style={{ color: "red" }}>{item.star}</span>
              </Typography>
              <Input
                value={inputs[item.name as keyof InputField]}
                type={item.type}
                name={item.name}
                onChange={inputsChange}
                id={item.name}
                helperText={item?.helper}
                placeholder={item.placeholder}
                fullWidth
              />
            </UIFlexColumn>
          ))}
        </UIFlexColumn>
      </UIModal>
      {data?.contract && (
        <>
          {!isChange ? (
            <Tooltip title="Сформировать договор" placement="top">
              <div style={{ cursor: "pointer" }}>
                <a href={data.contract}>
                  <Contract />
                </a>
              </div>
            </Tooltip>
          ) : (
            <div style={{ cursor: "not-allowed" }}>
              <DisableContract />
            </div>
          )}
        </>
      )}
    </UIFlexRow>
  );
};

export default ActivatedAnketa;

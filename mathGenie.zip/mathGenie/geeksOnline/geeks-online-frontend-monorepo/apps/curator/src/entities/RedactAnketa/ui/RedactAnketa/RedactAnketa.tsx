import {
  Button,
  Input,
  Loader,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { useAnketaForm } from "entities/RedactAnketa/model/anketaForm";
import {
  useFetchAnketaStudent,
  useStudentAnketaEdit,
} from "entities/RedactAnketa/model/useFetchAnketaStudent";
import { useEffect, useMemo } from "react";
import RedactAnketaSelects from "../RedactAnketaSelects/RedactAnketaSelects";
import RedactAnketaParent from "../RedactAnketaParent/RedactAnketaParent";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import dayjs from "dayjs";
import { cyrillicRegex, emailRegex } from "shared/lib/helpers/helpers";

const RedactAnketa = () => {
  const { form, setForm, isChange, setIsChange, clearAllForm } =
    useAnketaForm();
  const { data, isLoading } = useFetchAnketaStudent();
  const { mutateAsync, isLoading: load } = useStudentAnketaEdit();
  const errorAlert = useOpenErrorAlert();

  const forms = useMemo(() => {
    if (data?.from_bitrix) {
      return [
        {
          name: "full_name",
          label: "Фамилия Имя",
          star: "*",
          type: "text",
          placeholder: "",
          value: form?.full_name,
        },
        {
          name: "requisite",
          label: "Лиц. счет",
          type: "text",
          placeholder: "",
          value: form?.requisite,
          disabled: true,
        },
        {
          name: "bitrix_course",
          label: "Направление",
          type: "text",
          placeholder: "",
          value: form?.bitrix_course,
          disabled: true,
        },
        {
          name: "phone",
          label: "Номер телефона студента",
          star: "*",
          type: "text",
          placeholder: "+ 996",
          mask: "+996 999 99 99 99",
          value: form?.phone,
        },
        {
          name: "telegram",
          label: "Никнейм в телеграме студента",
          type: "text",
          placeholder: "@",
          value: form?.telegram,
        },
      ];
    }
    return [
      {
        name: "full_name",
        label: "Фамилия Имя",
        star: "*",
        type: "text",
        placeholder: "",
        value: form?.full_name,
      },
      {
        name: "patronymic",
        label: "Отчество",
        type: "text",
        placeholder: "",
        value: form?.patronymic,
      },
      {
        name: "birth_date",
        label: "Дата рождения",
        star: "*",
        type: "text",
        placeholder: "ДД.ММ.ГГГГ",
        mask: "99.99.9999",
        value: form?.birth_date,
      },
      ...(!data?.is_parent
        ? [
            {
              name: "an_id",
              label: "Серия и номер паспорта",
              star: "*",
              type: "text",
              placeholder: "AN/ID",
              value: form?.an_id,
            },
            {
              name: "inn",
              label: "ИНН",
              star: "*",
              type: "text",
              placeholder: "",
              mask: "99999999999999999999",
              value: form?.inn,
            },
            {
              name: "mkk",
              label: "Орган выдачи",
              type: "text",
              star: "*",
              placeholder: "MKK",
              value: form?.mkk,
            },
            {
              name: "issue_date",
              label: "Дата выдачи",
              star: "*",
              type: "text",
              placeholder: "ДД.ММ.ГГГГ",
              mask: "99.99.9999",
              value: form?.issue_date,
            },
          ]
        : []),
      {
        name: "adress",
        label: "Адрес студента по факту проживания",
        star: "*",
        type: "text",
        placeholder: "",
        value: form?.adress,
      },
      {
        name: "phone",
        label: "Номер телефона студента",
        star: "*",
        type: "text",
        placeholder: "+ 996",
        mask: "+996 999 99 99 99",
        value: form?.phone,
      },
      {
        name: "additional_phone",
        label: "Номер телефона (WhatsApp)",
        type: "text",
        star: "*",
        placeholder: "+",
        mask: "+999999999999999",
        value: form?.additional_phone,
      },
      {
        name: "telegram",
        label: "Никнейм в телеграме студента",
        type: "text",
        placeholder: "@",
        value: form?.telegram,
      },
      {
        name: "email",
        label: "Email студента",
        star: "*",
        type: "text",
        placeholder: "",
        value: form?.email,
      },
    ];
  }, [form]);

  const handleChangeForm = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setIsChange(true);
  };

  const styleForPassport = (src: string) => {
    return {
      width: 320,
      height: 180,
      backgroundImage: `url(${src})`,
      backgroundSize: "cover",
    };
  };

  const handleChangeAsync = async () => {
    if (data?.from_bitrix) {
      if (!form.full_name || !form.phone)
        return errorAlert("Заполните все обязательные поля");
    }
    if (!data?.is_parent && !data?.from_bitrix) {
      if (
        !form.full_name ||
        !form.birth_date ||
        !form.adress ||
        !form.phone ||
        !form.additional_phone ||
        !form.course_id ||
        !form.an_id ||
        !form.inn ||
        !form.mkk ||
        !form.issue_date
      )
        return errorAlert("Заполните все обязательные поля");
    }
    if (data?.is_parent) {
      if (
        !form.full_name ||
        !form.birth_date ||
        !form.adress ||
        !form.phone ||
        !form.additional_phone ||
        !form.course_id ||
        !form.an_id ||
        !form.inn ||
        !form.mkk ||
        !form.issue_date ||
        !form.parent_adress ||
        !form.parent_birth_date ||
        !form.parent_phone ||
        !form.parent_first_name ||
        !form.parent_last_name
      )
        return errorAlert("Заполните все обязательные поля");
    }
    if (form) {
      const updates = Object.entries(form).reduce<Record<string, string>>(
        (acc, [key, value]) => {
          if (
            key === "birth_date" ||
            key === "issue_date" ||
            key === "parent_birth_date"
          ) {
            acc[key] = value?.split(".").reverse().join("-");
          } else {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
      const keysToRemove = [
        "back_passport",
        "front_passport",
        "contract",
        "course",
        "from_bitrix",
        "requisite",
        "bitrix_course",
      ];
      keysToRemove.forEach((key) => {
        delete updates[key];
      });

      await mutateAsync(updates);
      setIsChange(false);
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;

    if (!value.trim()) return;

    if (name === "birth_date" || name === "issue_date") {
      const isValidDate = dayjs(value, "DD.MM.YYYY", true).isValid();
      if (!isValidDate) {
        errorAlert("Неверная дата");
        setForm((prev) => ({ ...prev, [name]: "" }));
      }
    }

    if (name === "email") {
      const isValidEmail = emailRegex.test(value);
      if (!isValidEmail) {
        errorAlert("Неверный формат email");
        setForm((prev) => ({ ...prev, [name]: "" }));
      }
    }

    if (name === "full_name" || name === "patronymic") {
      const isValidName = cyrillicRegex.test(value);
      if (!isValidName) {
        errorAlert("Поле должно содержать только кириллицу");
        setForm((prev) => ({ ...prev, [name]: "" }));
      }
    }
  };

  useEffect(() => {
    if (data) {
      Object.entries(data).forEach((item) => {
        if (
          item[0] === "id" ||
          item[0] === "activated" ||
          item[0] === "is_parent" ||
          item[0] === "course" ||
          item[0] === "from_bitrix"
        )
          return;
        if (
          item[0] === "birth_date" ||
          item[0] === "issue_date" ||
          item[0] === "parent_birth_date"
        ) {
          setForm((prev) => ({
            ...prev,
            [item[0]]: item[1]?.split("-").reverse().join("."),
          }));
        } else {
          setForm((prev) => ({ ...prev, [item[0]]: item[1] ?? "" }));
        }
      });
    }
  }, [data]);

  useEffect(() => {
    return () => {
      clearAllForm();
    };
  }, []);

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={40}>
      <UIFlexRow mt={20} gap={120}>
        <UIFlexColumn gap={40} width={400}>
          {data?.is_parent && <Typography variant="Title1">Студент</Typography>}
          {forms.map((item, key) => (
            <UIFlexColumn gap={4} key={key}>
              <Typography variant="Text1">
                {item.label}{" "}
                {item.star && <span style={{ color: "red" }}>{item.star}</span>}
              </Typography>
              <Input
                mask={item.mask}
                value={item.value ?? ""}
                type={item.type}
                name={item.name}
                onChange={handleChangeForm}
                placeholder={item.placeholder}
                onBlur={handleBlur}
                disabled={item.disabled}
                fullWidth
              />
            </UIFlexColumn>
          ))}
          {!data?.from_bitrix && (
            <RedactAnketaSelects handleChangeForm={handleChangeForm} />
          )}
          <Button
            isLoading={load}
            width={"100%"}
            theme={isChange ? ThemeButton.contained : ThemeButton.disabled}
            onClick={handleChangeAsync}
          >
            Сохранить
          </Button>
        </UIFlexColumn>
        {!data?.from_bitrix && (
          <UIFlexColumn mt={!data?.is_parent ? 22 : 0} gap={40}>
            {data?.is_parent && <RedactAnketaParent />}
            <UIFlexColumn gap={20}>
              <div style={styleForPassport(String(data?.front_passport))}></div>
              <div style={styleForPassport(String(data?.back_passport))}></div>
            </UIFlexColumn>
          </UIFlexColumn>
        )}
      </UIFlexRow>
    </UIFlexColumn>
  );
};

export default RedactAnketa;

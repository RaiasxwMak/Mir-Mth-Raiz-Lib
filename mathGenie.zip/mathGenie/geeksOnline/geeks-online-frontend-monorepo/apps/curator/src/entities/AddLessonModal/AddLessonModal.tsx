import { Dispatch, SetStateAction, useState, useEffect, useMemo } from "react";
import { UIModal } from "shared/ui/UIModal/UIModal";
import { LessonMode } from "./ui/LessonMode/LessonMode";
import { IMeeting, MeetingMode } from "./ui/MeetingMode/MeetingMode";
import { useMutationCreateReservation } from "./model/addLessonRequests";
import { ISelectedData } from "pages/ScheduleOneDay/ScheduleOneDay";
import { useTimeRange } from "shared/ui/TimeRangeSelect/model/useTimeRange";
import { Loader, TimeRangeSelect, Typography } from "shared/ui";
import { SwitchMode } from "./ui/SwitchMode/SwitchMode";
import { useDeleteLesson, useGetLesson } from "./model/getLessonRequest";
import { useLessonDescription } from "features/LessonDescription/model/useLessonDescription";
import { useLessonTypeSelect } from "features/LessonTypeSelect/model/useLessonTypeSelect";
import { CALENDAR_HOURS } from "shared/lib/consts/consts";
import { LessonTypeSelect } from "features/LessonTypeSelect/LessonTypeSelect";
import { Textarea } from "shared/ui/Textarea/Textarea";
import { useFloorsAndRoomsSelect } from "features/FloorsAndRoomsSelect/model/useFloorsAndRooms";
import { Input } from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import FloorsAndRoomsSelect from "features/FloorsAndRoomsSelect/ui/FloorsAndRoomsSelect";
import dayjs from "dayjs";
import cls from "./AddLessonModal.module.scss";

interface AddLessonModalProps {
  open: boolean;
  selectedDate: ISelectedData;
  setOpen: Dispatch<SetStateAction<boolean>>;
  lessonType?: string;
}

export const AddLessonModal = ({
  open,
  setOpen,
  selectedDate,
  lessonType,
}: AddLessonModalProps) => {
  const {
    floor,
    classroom,
    date,
    title,
    description,
    start_time,
    end_time,
    time,
    finish_time,
    id,
    lesson,
  } = selectedDate;

  const errorAlert = useOpenErrorAlert();

  const { changeSelectTimerange } = useTimeRange();
  const { lessonDescription, resetDescription, changeSelectLessonDescription } =
    useLessonDescription();
  const { lessonTypeSelect, resetSelect, changeSelectLessonType } =
    useLessonTypeSelect();
  const { changeFloors, floorsSelect, changeRooms, roomsSelect } =
    useFloorsAndRoomsSelect();
  const { data, isLoading } = useGetLesson(lesson);

  const [dateLesson, setDateLesson] = useState("");
  const [mode, setMode] = useState(true);
  const [meeting, setMeeting] = useState<IMeeting | null>(null);

  const isPatch = id !== undefined;
  const isRedactLesson = mode && lesson;

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const { value } = e.target;
    if (!value.trim()) return;

    const isValidDate = dayjs(value, "DD.MM.YYYY", true).isValid();
    if (!isValidDate) {
      errorAlert("Неверная дата");
      setDateLesson("");
    }
  };

  const { mutate, isLoading: isAddLessonLoading } = isRedactLesson
    ? useMutationCreateReservation(
        floorsSelect?.value,
        roomsSelect?.value!,
        dateLesson.split(".").reverse().join("-"),
        id,
        setOpen
      )
    : useMutationCreateReservation(floor, classroom!, date, id, setOpen);

  const isLesson = mode === true;
  const isDopLesson = selectedDate.title === "Доп. Урок" || !isLesson;

  const hourOptions = useMemo(() => {
    return CALENDAR_HOURS.map((hour) => ({
      label: hour,
      value: hour,
    }));
  }, []);

  const lessonDelete = useDeleteLesson(selectedDate.id ?? "");

  const handleDeleteLesson = async () => {
    await lessonDelete.mutateAsync();
    setOpen(false);
  };

  const onOk = () => {
    mutate({ isLesson, meeting });
  };

  useEffect(() => {
    if (isPatch) {
      if (description !== null) setMode(false);
      else setMode(true);
    }

    const startDate = start_time ?? time;
    const finishDate = end_time ?? finish_time;
    changeSelectTimerange({
      start: { value: startDate, label: startDate },
      end: { value: finishDate, label: finishDate },
    });
  }, [selectedDate]);

  useEffect(() => {
    if (isRedactLesson && floor && typeof classroom === "number") {
      changeSelectLessonType({ label: "Оффлайн", value: "Оффлайн" });
      changeFloors({ label: floor, value: floor });
      changeRooms({ label: classroom, value: classroom });
    }
    if (isRedactLesson && date) {
      setDateLesson(date?.split("-").reverse().join("."));
    }
  }, [isRedactLesson, floor, classroom, date]);

  useEffect(() => {
    if (!isPatch) {
      resetDescription();
      resetSelect();
    }
  }, []);

  return (
    <UIModal
      open={open}
      onCancel={() => setOpen(false)}
      onCancelRequest={isDopLesson ? handleDeleteLesson : undefined}
      onOk={onOk}
      className={cls.modal}
      okTitle={"Сохранить"}
      cancelTitle={isDopLesson ? "Удалить" : "Отмена"}
      modalWidth="400px"
      isLoading={isAddLessonLoading}
    >
      <div className={cls.addWrapper}>
        {lessonType !== "other" ? (
          !isPatch ? (
            <SwitchMode setMode={setMode} mode={mode} />
          ) : (
            <></>
          )
        ) : !isPatch ? (
          <div style={{ padding: "0 25px" }}>
            <Typography variant="HeadlineH2">Урок</Typography>
          </div>
        ) : (
          <></>
        )}
        <div className={cls.flexColumn} style={{ padding: "0 25px" }}>
          {isPatch && isLesson && (
            <Typography variant="HeadlineH2">Урок</Typography>
          )}
          {isPatch && !isLesson && (
            <Typography variant="HeadlineH2">Собрание</Typography>
          )}
          {isLoading && <Loader height="300px" />}
          {mode && !isLoading && (
            <LessonMode
              lesson={data}
              id={lesson}
              isLoading={isLoading}
              lessonType={lessonType}
            />
          )}
          {isRedactLesson && (
            <div>
              <label className={cls.label}>
                {"Дата урока"}
                <Input
                  value={dateLesson}
                  onChange={(e) => setDateLesson(e.target.value)}
                  onBlur={handleBlur}
                  fullWidth
                  mask="99.99.9999"
                />
              </label>
            </div>
          )}
          {!mode && !isLoading && (
            <MeetingMode
              meeting={{
                title: isPatch ? title || "" : "",
                description: isPatch ? description || "" : "",
              }}
              onChange={(param) => setMeeting(param)}
            />
          )}
          <div>
            <TimeRangeSelect
              startOptions={hourOptions}
              endOptions={hourOptions}
              height="40px"
            />
          </div>
          {mode && (floor === "other" || lesson) && (
            <div className={cls.selectsWrap}>
              <label>
                {"Формат урока"}
                <LessonTypeSelect
                  addOffline={floor === "other" ? false : true}
                />
              </label>
              {lessonTypeSelect?.value === "Другое" ? (
                <Textarea
                  value={lessonDescription?.toString()}
                  onChange={(ev) =>
                    changeSelectLessonDescription(ev.target.value)
                  }
                  label={"Локация"}
                  maxLength={40}
                  height="60px"
                />
              ) : (
                <></>
              )}
              {lessonTypeSelect?.value === "Оффлайн" ? (
                <FloorsAndRoomsSelect />
              ) : (
                <></>
              )}
            </div>
          )}
        </div>
      </div>
    </UIModal>
  );
};

import { Textarea } from 'shared/ui/Textarea/Textarea';
import { useState, useEffect } from 'react';
import { UIFlexColumn } from 'shared/ui/UIFlex/UIFlex';

export interface IMeeting {
  title: string;
  description: string;
}

export interface MeetingModeProps {
  onChange?: (obj: IMeeting) => void;
  meeting: IMeeting;
}

export const MeetingMode = ({ onChange, meeting }: MeetingModeProps) => {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');

  useEffect(() => {
    onChange && onChange({ title, description: desc });
  }, [title, desc]);

  useEffect(() => {
    setTitle(meeting.title || '');
    setDesc(meeting.description || '');

    return () => {
      setTitle('');
      setDesc('');
    };
  }, []);

  return (
    <UIFlexColumn gap={20}>
      <Textarea
        value={title}
        onChange={(ev) => setTitle(ev.target.value)}
        label={"Заголовок"}
        placeholder={"Заголовок"}
        maxLength={50}
        height='60px'
      />
      <Textarea
        value={desc}
        onChange={(ev) => setDesc(ev.target.value)}
        label={"Описание"}
        placeholder={"Описание"}
        maxLength={200}
        height='60px'
      />
    </UIFlexColumn>
  );
};

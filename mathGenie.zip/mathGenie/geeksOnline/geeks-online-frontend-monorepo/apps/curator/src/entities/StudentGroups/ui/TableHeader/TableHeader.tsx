import { Typography } from 'shared/ui';
import cls from './TableHeader.module.scss';

const TableHeader = ({ title }: { title: string }) => {
  return (
    <div className={cls.header}>
      <Typography variant='Text2' className={cls.title}>
        {title}
      </Typography>
      <Typography variant='Text2'>Месяц</Typography>
    </div>
  );
};

export default TableHeader;

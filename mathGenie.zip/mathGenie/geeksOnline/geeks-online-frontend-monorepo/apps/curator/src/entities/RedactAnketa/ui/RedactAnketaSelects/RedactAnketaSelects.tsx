import {
  CustomSelect,
  Input,
  IOption,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useAnketaForm } from "entities/RedactAnketa/model/anketaForm";
import {
  educationStudentOption,
  infosourceOptions,
  laptopOptions,
} from "entities/RedactAnketa/model/anketaFormOptions";
import { useFetchAnketaStudent } from "entities/RedactAnketa/model/useFetchAnketaStudent";
import AnketaFilialsSelects from "features/AnketaFilialsSelects/ui/AnketaFilialsSelects";
import {
  ChangeEvent,
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useState,
} from "react";

const emptyOption = { value: "", label: "" };

interface IRedactAnketaSelectsType {
  handleChangeForm: (e: ChangeEvent<HTMLInputElement>) => void;
}

const RedactAnketaSelects: FC<IRedactAnketaSelectsType> = ({
  handleChangeForm,
}) => {
  const { data } = useFetchAnketaStudent();
  const { form, setForm, setIsChange } = useAnketaForm();

  const [educationSelect, setEducationSelect] = useState<IOption | null>(null);
  const [lapTopSelect, setLapTopSelect] = useState<IOption | null>(null);
  const [infoSourceSelect, setInfoSourceSelect] = useState<IOption | null>(
    null
  );

  const handleChangeEductionSelect = (
    param: IOption | null,
    setState: Dispatch<SetStateAction<IOption<string | number> | null>>,
    name: string
  ) => {
    if (param) {
      setState(param);
      setForm((prev) => ({ ...prev, [name]: String(param?.value) }));
      setIsChange(true);
    }
  };

  useEffect(() => {
    if (data?.education) {
      const el =
        educationStudentOption.find((item) => item.value === data.education) ??
        emptyOption;
      setEducationSelect(el);
    }
    if (data?.laptop_availabe) {
      const el =
        laptopOptions.find((item) => item.value === data.laptop_availabe) ??
        emptyOption;
      setLapTopSelect(el);
    }
    if (data?.info_source) {
      const el =
        infosourceOptions.find((item) => item.value === data.info_source) ??
        emptyOption;
      setInfoSourceSelect(el);
    }
  }, [data?.education, data?.laptop_availabe, data?.info_source]);
  return (
    <>
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">Образование студента</Typography>
        <CustomSelect
          isArrow
          onChange={(param) =>
            handleChangeEductionSelect(param, setEducationSelect, "education")
          }
          value={educationSelect}
          width={"100%"}
          height={"44px"}
          options={educationStudentOption}
        />
      </UIFlexColumn>
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">Наименование учебного заведения</Typography>
        <Input
          value={form?.educational_institution ?? ""}
          name={"educational_institution"}
          onChange={handleChangeForm}
          fullWidth
        />
      </UIFlexColumn>
      {data?.course_id && data?.course && data?.filial && (
        <AnketaFilialsSelects
          fililalId={data?.filial}
          course={data?.course}
          course_id={data?.course_id}
        />
      )}
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">Укажите наличие ноутбука</Typography>
        <CustomSelect
          isArrow
          onChange={(param) =>
            handleChangeEductionSelect(
              param,
              setLapTopSelect,
              "laptop_availabe"
            )
          }
          value={lapTopSelect}
          width={"100%"}
          height={"44px"}
          options={laptopOptions}
        />
      </UIFlexColumn>
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">Откуда вы о нас узнали?</Typography>
        <CustomSelect
          isArrow
          onChange={(param) =>
            handleChangeEductionSelect(
              param,
              setInfoSourceSelect,
              "info_source"
            )
          }
          value={infoSourceSelect}
          width={"100%"}
          height={"44px"}
          options={infosourceOptions}
        />
      </UIFlexColumn>
    </>
  );
};

export default RedactAnketaSelects;

import { requester } from "shared/configs/axios/axiosConfig";
import {
  IStudentList,
  PostNotesType,
  StudentGroup,
  StudentsListParamsType,
} from "../type/StudentSchema";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useEffect } from "react";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { usePaymentSelect } from "features/PaymentSelect/model/usePaymentSelect";
import { useMonthCashierSelect } from "features/MonthCashierSelect/model/useMonthCashierSelect";
import { useYearsSelect } from "features/YearsSelect/model/useYearsSelect";
import { usePaymentTypeSelect } from "features/PaymentTypeSelect/model/usePaymentTypeSelect";
import { useTableStore } from "./useTableStore";

export const cashierStudentsList = "cashierStudentsList";
export const cashierStudentsModules = "studentsModules";

export const useCashierStudentsQuery = () => {
  const { page, resetPage } = usePageChange();
  const { courseValueSelect } = useCoursesSelect();
  const { groupsSelect } = useSearchGroupsSelect();
  const { monthsSelect } = useMonthCashierSelect();
  const { yearsSelect } = useYearsSelect();
  const { paymentTypeSelect } = usePaymentTypeSelect();
  const { paymentSelect } = usePaymentSelect();
  const { search } = useSearchInfo();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [
    search,
    courseValueSelect?.value,
    groupsSelect.value,
    monthsSelect?.value,
    yearsSelect?.value,
    paymentTypeSelect?.value,
    paymentSelect?.value,
  ]);

  const limit = 12;
  const offset = (page - 1) * limit;
  const params: StudentsListParamsType = {
    offset,
    limit,
    q: search,
    course_id: courseValueSelect ? String(courseValueSelect?.value) : "",
    group_id: groupsSelect.value ?? "",
    month: monthsSelect ? String(monthsSelect?.value) : "",
    year: yearsSelect ? String(yearsSelect?.value) : "",
    payment_type: paymentTypeSelect ? String(paymentTypeSelect?.value) : "",
    payment_status: paymentSelect ? String(paymentSelect?.value) : "",
  };
  return useQuery<IStudentList>({
    queryFn: async () => await fetchCashierStudentsList(params),
    queryKey: [
      cashierStudentsList,
      page,
      search,
      courseValueSelect?.value,
      groupsSelect.value,
      monthsSelect?.value,
      yearsSelect?.value,
      paymentTypeSelect?.value,
      paymentSelect?.value,
    ],
  });
};

export const fetchCashierStudentsList = async (
  params: StudentsListParamsType
) => {
  const res = await requester.get("/api/v1/cashier/students/", { params });
  return res.data;
};

export const useStudentsModules = () => {
  const { module_id } = useTableStore();

  const { monthsSelect } = useMonthCashierSelect();
  const { yearsSelect } = useYearsSelect();
  const { paymentTypeSelect } = usePaymentTypeSelect();
  const { paymentSelect } = usePaymentSelect();
  const { search } = useSearchInfo();

  const params: StudentsListParamsType = {
    q: search,
    month: monthsSelect ? String(monthsSelect?.value) : "",
    year: yearsSelect ? String(yearsSelect?.value) : "",
    payment_type: paymentTypeSelect ? String(paymentTypeSelect?.value) : "",
    payment_status: paymentSelect ? String(paymentSelect?.value) : "",
  };

  return useQuery<StudentGroup[]>({
    queryFn: async () => {
      if (!module_id) return;
      const res = await requester.get(`/api/v1/cashier/month/${module_id}/`, {
        params,
      });
      return res.data;
    },
    queryKey: [
      cashierStudentsModules,
      module_id,
      search,
      monthsSelect?.value,
      yearsSelect?.value,
      paymentTypeSelect?.value,
      paymentSelect?.value,
    ],
  });
};

///
export const useFetchPostNotes = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: postNotesFetch,
    onSuccess: () => {
      queryClient.invalidateQueries([cashierStudentsList]);
    },
  });
};

export const postNotesFetch = async (body: PostNotesType) => {
  const res = await requester.post("/api/v1/cashier/students/", body);
  return res;
};

import { useMutation } from "@tanstack/react-query";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCourseDirections } from "features/CourseDirections/model/useCourseDirections";
import { useGroupSelect } from "features/GroupSelector/model/useGroupSelect";
import { useUsersSelect } from "features/UsersSelect/model/useUsersSelect";
import { useNavigate } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { ErrorType, useCreateGroup } from "./useCreateGroup";
import { isAxiosError } from "axios";
import { useEffect } from "react";

export interface CreateGroupDate {
  course: string;
  title: string;
  students: string[];
}

export const useCreateGroupMutation = () => {
  const navigate = useNavigate();
  const { setErrors } = useCreateGroup();
  const directionValue = useCourseDirections((state) => state.directionValue);
  const groupValue = useGroupSelect((state) => state.groupValue);
  const users = useUsersSelect((state) => state.usersSelect);
  const onClearUsers = useUsersSelect((state) => state.onClear);
  const onClearDirectionValue = useCourseDirections((state) => state.onClear);
  const onClearGroupValue = useGroupSelect((state) => state.onClear);

  const successAlert = useOpenAlert();
  const openError = useOpenErrorAlert();

  const onClearAll = () => {
    onClearUsers();
    onClearDirectionValue();
    onClearGroupValue();
  };

  useEffect(() => {
    return () => {
      onClearAll();
    };
  }, []);

  const isStudents = users[0]?.selectedOption?.value ? true : false;

  return useMutation({
    mutationFn: async () => {
      const dataAtr: CreateGroupDate = {
        title: groupValue,
        course: directionValue?.value.toString() || "",
        students: isStudents
          ? users
              ?.map((option) => option?.selectedOption?.value)
              .filter(Boolean)
          : [],
      };

      const createErrors: ErrorType[] = [];

      if (!dataAtr.title) {
        openError("Введите название группы");
        createErrors.push("group-name");
      }

      if (!dataAtr.course) {
        openError("Выберите направление");
        createErrors.push("course");
      }

      const nullUser = users.filter(
        (elm) => !elm?.selectedOption?.value && elm.value
      );

      if (nullUser.length > 0) {
        openError("Выберите пользователя");
        createErrors.push("users");
      }

      if (createErrors.length > 0) {
        setErrors(createErrors);
        return;
      }

      try {
        await fetchCreateGroup(dataAtr);
        onClearAll();
        navigate(-1);
        successAlert(`Группа ${dataAtr.title} создана`);
      } catch (error) {
        if (isAxiosError(error) && error.response?.status === 409) {
          // openError('Группа с таким названием уже существует');
          setErrors(["group-name"]);
          return;
        }
      }
    },
  });
};

export const fetchCreateGroup = async (data: CreateGroupDate) => {
  const res = await requester.post("/api/v1/curator/group/create/", data);
  return res.data;
};

import cls from "./MentorHistoryHelp.module.scss";
import { useGetCoinDays } from "entities/AboutMentor/model/useGetCoinDays";
import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { getFormatDateMonth } from "shared/lib/helpers/helpers";
import { Loader } from "shared/ui";
import MentorCoins from "features/MentorCoins/ui/MentorCoins/MentorCoins";
import { EmptyState, TableAccordion } from "@geeks-online/uikit";

const MentorHistoryHelp = () => {
  const [param, _] = useSearchParams();
  const mentorId = param.get("mentor_id");
  const { data, isLoading } = useGetCoinDays(mentorId ?? "");

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Дата обналичивания",
      dataIndex: "date",
      width: "55%",
    },
    {
      title: "",
      dataIndex: "status",
      width: "180px",
    },
    {
      title: "GeekCoin",
      dataIndex: "geekcoin",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.items?.map((elm, index: number) => {
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        date: getFormatDateMonth(elm?.geekcoin_day.date),
        status: "",
        geekcoin: elm?.total,
        description: (
          <MentorCoins
            mentorId={mentorId ?? ""}
            date={elm?.geekcoin_day?.date}
          />
        ),
      };
    });
  }, [data, mentorId]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.items.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordion
        isLoading={isLoading}
        accordion
        rowExpandedColor="rgba(198, 198, 198, 0.12)"
        columns={columns}
        dataSource={dataSource}
        expanableClass={[cls.expanableClass]}
      />
    </div>
  );
};

export default MentorHistoryHelp;

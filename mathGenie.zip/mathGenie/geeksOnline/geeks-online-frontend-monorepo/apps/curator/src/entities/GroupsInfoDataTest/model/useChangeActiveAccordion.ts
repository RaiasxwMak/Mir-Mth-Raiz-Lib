import { create } from 'zustand';
export interface IuseChangeActiveAccordion {
  isExpanded: string | null;
  setExpanded: (param: string | null) => void;
}
export const useChangeActiveAccordion = create<IuseChangeActiveAccordion>(
  (set) => ({
    isExpanded: null,
    setExpanded: (param) => {
      set((state) => ({
        isExpanded: state.isExpanded !== param ? param : null,
      }));
    },
  })
);

import { Select } from "shared/ui";
import { IOption } from "shared/ui/Select/Select";
import { useGroupInfoSelect } from "../model/useGroupInfoSelect";
import cls from "./GroupInfoSelect.module.scss";
import useFetchModules from "../model/useFetchModules";
import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import classNames from "classnames";

const GroupInfoSelect = ({
  groupId,
  isArrow = true,
  width,
  bordered = false,
  height,
  disabled,
  afterChange,
  titleMonth,
  isSchedule,
}: {
  groupId?: string;
  isArrow?: boolean;
  width?: string;
  bordered?: boolean;
  height?: string;
  disabled?: boolean;
  month_id?: string;
  afterChange?: (param?: IOption) => void;
  titleMonth?: string;
  isSchedule?: boolean;
}) => {
  const { valueSelect, changeSelect } = useGroupInfoSelect();
  const { data, isError } = useFetchModules(groupId, isSchedule);
  const [searchParams, setSearchParams] = useSearchParams();

  const selectOptions: IOption[] = data
    ? data?.map((item) => ({
        value: item.id,
        label: item.title,
      }))
    : [];

  useEffect(() => {
    const monthValue = searchParams.get("month_id");
    if (!monthValue || isError) return changeSelect(null);
    changeSelect({
      value: monthValue,
      label: titleMonth ?? "-",
    });
  }, []);

  const handleOnChangeMonthDecorator = (param: IOption | null) => {
    changeSelect(param);
    setSearchParams(
      (prev) => ({
        ...prev,
        month_id: param?.value ?? "",
        tab: prev.get("tab"),
      }),
      {
        replace: true,
      }
    );
    if (afterChange) afterChange();
  };

  return (
    <div className={cls.main} style={{ width: width || "150px" }}>
      <Select
        isArrow={isArrow}
        placeholder={"Месяц"}
        rootClass={classNames({
          [cls.select]: !bordered,
        })}
        width={width || "150px"}
        onChange={handleOnChangeMonthDecorator}
        value={valueSelect}
        options={selectOptions}
        bordered={false}
        height={height}
        disabled={disabled}
      />
    </div>
  );
};

export default GroupInfoSelect;

export interface ICoinDays {
  items: ICoinsDays[];
  total: number;
  page: number;
  size: number;
  pages: number;
}

export interface ICoinsDays {
  id: string;
  status: string;
  geekcoin_day: {
    id: string;
    date: string;
    time: string;
  };
  total: number;
  created_at: string;
}

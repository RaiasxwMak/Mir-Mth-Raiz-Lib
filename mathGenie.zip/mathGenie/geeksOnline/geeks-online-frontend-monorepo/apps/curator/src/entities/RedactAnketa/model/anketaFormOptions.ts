export const educationStudentOption = [
  { label: "Без образования", value: "Без образования" },
  { label: "Незаконченное среднее", value: "Незаконченное среднее" },
  { label: "Среднее", value: "Среднее" },
  { label: "Среднее-специальное", value: "Среднее-специальное" },
  { label: "Незаконченное высшее", value: "Незаконченное высшее" },
  { label: "Высшее", value: "Высшее" },
];

export const laptopOptions = [
  { label: "Есть ноутбук", value: "Есть ноутбук" },
  {
    label: "Нет ноутбука, собираюсь приобрести",
    value: "Нет ноутбука, собираюсь приобрести",
  },
  {
    label: "Хочу купить ноутбук в Geeks",
    value: "Хочу купить ноутбук в Geeks",
  },
];

export const infosourceOptions = [
  { label: "Реклама", value: "Реклама" },
  {
    label: "Рекомендация",
    value: "Рекомендация",
  },
];

import { useQueryClient } from "@tanstack/react-query";
import { queryKeyFetchStudentMonthsGroups } from "entities/StudentGroups/model/useFetchStudentMonthsGroups";
import { IStudentModule } from "entities/StudentGroups/type/StudentMonthsSchema";
import PaymentSelectAsync from "features/PaymentSelect/ui/PaymentSelectAsync";
import RepeatSelectAsync from "features/RepeatSelect/ui/RepeatSelectAsync";
import StudentStatusSelectAsync from "features/studentStatus/ui/StudentStatusSelect/StudentStatusSelectAsync";
import { Typography } from "shared/ui";
import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";

interface IStudentStatusesModule {
  data: IStudentModule;
  isSupremeMentor?: boolean;
  id?: string;
}

const gapBetweenInput = 4;

const StudentStatusesModule = ({
  data,
  isSupremeMentor,
  id,
}: IStudentStatusesModule) => {
  const queryClient = useQueryClient();

  return (
    <UIFlexColumn gap={8} style={{ width: 400 }}>
      <UIFlexColumn gap={gapBetweenInput}>
        <Typography variant="Text2_bold">Статус</Typography>
        <StudentStatusSelectAsync
          module_id={data.module_id}
          student_id={id ?? ""}
          width="400px"
          data={data}
          disable={isSupremeMentor}
          onSuccess={() =>
            queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups])
          }
        />
      </UIFlexColumn>
      <UIFlexColumn gap={gapBetweenInput}>
        <Typography variant="Text2_bold">Статус повтора</Typography>
        <RepeatSelectAsync
          onSuccess={() =>
            queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups])
          }
          repeat_status={data.dynamic_repeat_status}
          module_id={data.module_id}
          disable={isSupremeMentor}
          id={id ?? ""}
        />
      </UIFlexColumn>
      <UIFlexColumn gap={gapBetweenInput}>
        <Typography variant="Text2_bold">Статус оплаты</Typography>
        <PaymentSelectAsync
          status={data.is_payed}
          student_id={id ?? ""}
          module_id={data.module_id}
          disable={isSupremeMentor}
          onSuccess={() =>
            queryClient.invalidateQueries([queryKeyFetchStudentMonthsGroups])
          }
        />
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default StudentStatusesModule;

import { create } from "zustand";
import { IAnketaStudent } from "../type/RedactAnketaType";

interface IuseCreateInfosStudent {
  isChange: boolean;
  setIsChange: (param: boolean) => void;

  form: IAnketaStudent;
  setForm: (
    param:
      | Partial<IAnketaStudent>
      | ((prev: IAnketaStudent) => Partial<IAnketaStudent>)
  ) => void;
  clearAllForm: () => void;
}

export const useAnketaForm = create<IuseCreateInfosStudent>((set) => ({
  isChange: false,
  setIsChange: (param: boolean) => set({ isChange: param }),
  form: {},
  setForm: (param) => {
    set(({ form }) => ({
      form: {
        ...form,
        ...(typeof param === "function" ? param(form) : param),
      },
    }));
  },
  clearAllForm: () => {
    set({ form: {}, isChange: false });
  },
}));

import cls from "./StudentCurrentGroups.module.scss";
import useFetchStudentMonthsGroups from "entities/StudentGroups/model/useFetchStudentMonthsGroups";
import { IStudentMonthCurrentCourse } from "entities/StudentGroups/type/StudentMonthsSchema";
import TableHeader from "../TableHeader/TableHeader";
import StudentCurrentGroupContent from "./StudentCurrentGroupContent";
import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import { Loader, Typography } from "shared/ui";
import { EmptyState, TableAccordion } from "@geeks-online/uikit";

const StudentCurrentGroups = ({
  isSupremeMentor,
}: {
  isSupremeMentor?: boolean;
}) => {
  const { data, isLoading } =
    useFetchStudentMonthsGroups<IStudentMonthCurrentCourse>(true);

  if (!data?.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  if (isLoading) return <Loader />;
  return (
    <div className={cls.wrapper}>
      <UIFlexColumn gap={40}>
        {data?.map((item) => (
          <div className={cls.table} key={item.course}>
            <TableHeader title={item.course} />
            <TableAccordion
              columns={[
                {
                  dataIndex: "group",
                  className: cls.table_title,
                },
                {
                  dataIndex: "month",
                  width: "100%",
                },
              ]}
              showHeader={false}
              accordion={true}
              dataSource={item.student_modules.map((module, index) => ({
                key: index,
                group: (
                  <Typography variant="Text2" className={cls.group}>
                    {module.group}
                  </Typography>
                ),
                month: module.month,
                description: (
                  <StudentCurrentGroupContent
                    data={module}
                    isSupremeMentor={isSupremeMentor}
                  />
                ),
                expand: true,
              }))}
              rowExpandedColor="rgba(198, 198, 198, 0.12)"
            />
          </div>
        ))}
      </UIFlexColumn>
    </div>
  );
};

export default StudentCurrentGroups;

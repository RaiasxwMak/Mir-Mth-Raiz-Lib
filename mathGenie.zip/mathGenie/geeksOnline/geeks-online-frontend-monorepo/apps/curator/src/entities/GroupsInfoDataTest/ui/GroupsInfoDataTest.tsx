import { Accordion, Loader, Typography } from "shared/ui";
import cls from "./GroupInfoDataTest.module.scss";
import classNames from "classnames";
import { useFetchTests } from "../model/useFetchTests";
import DetailTest from "features/DetailTest/ui/DetailTest";
import { useChangeActiveAccordion } from "../model/useChangeActiveAccordion";
import { ILinkInput } from "features/GroupInfoTestChange/ui/LinkInputTest";
import DateInputTest from "features/GroupInfoTestChange/ui/DateInputTest";
import dayjs from "dayjs";
import { formatMonthTime } from "shared/lib/consts/consts";
import { useEffect } from "react";
import { EmptyState } from "@geeks-online/uikit";

interface ILabel extends Omit<ILinkInput, "value"> {
  index: number;
  link: string;
  type: string;
  date: string;
  id: string;
}

const Label = ({ index, link, type, date, month_id, test_id, id }: ILabel) => {
  const { isExpanded, setExpanded } = useChangeActiveAccordion();
  const isRedact = isExpanded === id;
  const formatedDate = dayjs(date).format(formatMonthTime);
  useEffect(() => {
    return () => setExpanded(null);
  }, []);
  return (
    <div className={cls.grid}>
      <div>
        <Typography className={cls.grid_item} variant="Text2">
          {index + 1}
        </Typography>
      </div>
      <div className={classNames(cls.link, cls.grid_item)}>
        <a href={link} onClick={(e) => e.stopPropagation()} target="_blank">
          {link}
        </a>
      </div>
      <div>
        <Typography className={cls.grid_item} variant="Text2">
          {type}
        </Typography>
      </div>
      <div>
        {isRedact ? (
          <DateInputTest test_id={test_id} month_id={month_id} value={date} />
        ) : (
          <Typography className={cls.grid_item} variant="Text2">
            {formatedDate}
          </Typography>
        )}
      </div>
      <div></div>
    </div>
  );
};

const GroupInfoDataTest = ({
  isSupremeMentor = false,
}: {
  isSupremeMentor?: boolean;
}) => {
  const { data: tests, isLoading } = useFetchTests();
  const { setExpanded } = useChangeActiveAccordion();

  const handleChange = (key: string | string[]) => {
    setExpanded(key[0]);
  };

  const staticHead = ["№", "Ссылка на GoogleForm", "Статус", "Дедлайн"];

  if (isLoading) return <Loader height="500px" />;
  if (!tests?.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={classNames(cls.head, cls.grid)}>
        {staticHead.map((item) => (
          <div key={item} className={cls.head_item}>
            <Typography variant="Text2">{item}</Typography>
          </div>
        ))}
      </div>
      <Accordion
        isTable
        onChange={handleChange}
        items={
          tests?.map((item, i) => ({
            key: item.id,
            label: (
              <Label
                month_id={item.module.id}
                test_id={item.id}
                key={item.id}
                id={isSupremeMentor ? "null" : item.id}
                index={i}
                link={item.link}
                type={item.type}
                date={item.date}
              />
            ),
            children: (
              <DetailTest
                type={item.type}
                index={i}
                key={item.id}
                id={item.id}
                isSupremeMentor={isSupremeMentor}
              />
            ),
          })) ?? []
        }
      />
    </div>
  );
};

export default GroupInfoDataTest;

import { useQuery } from "@tanstack/react-query";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { IAnketaList } from "../type/AnketaType";
import { useYearsSelect } from "features/YearsSelect/model/useYearsSelect";
import { useMonthCashierSelect } from "features/MonthCashierSelect/model/useMonthCashierSelect";
import { useActivateSelect } from "features/ActivateSelect/model/useActivateSelect";

export interface AnketaListParamsType {
  q?: string;
  course_id?: string;
  limit?: number;
  offset?: number;
  year?: string;
  month?: string;
  activated?: number;
}

export const useAnketaListQuery = () => {
  const { courseValueSelect } = useCoursesSelect();
  const { monthsSelect } = useMonthCashierSelect();
  const { activateSelect } = useActivateSelect();
  const { page, resetPage } = usePageChange();
  const { search } = useSearchInfo((state) => state);
  const { yearsSelect } = useYearsSelect();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [
    courseValueSelect?.value,
    search,
    monthsSelect?.value,
    yearsSelect?.value,
    activateSelect?.value,
  ]);

  const limit = 12;
  const offset = (page - 1) * limit;

  return useQuery<IAnketaList>({
    queryFn: async () => {
      const dataArg: AnketaListParamsType = {
        course_id:
          courseValueSelect?.value === "0"
            ? undefined
            : courseValueSelect?.value.toString(),
        limit,
        offset,
        q: search || undefined,
      };
      if (monthsSelect?.value) {
        dataArg.month = String(monthsSelect?.value);
      }
      if (yearsSelect?.value) {
        dataArg.year = String(yearsSelect?.value);
      }
      if (activateSelect?.value) {
        dataArg.activated = Number(activateSelect?.value);
      }

      return await fetchAnketaList(dataArg);
    },
    queryKey: [
      "anketaList",
      page,
      courseValueSelect?.value,
      search,
      yearsSelect?.value,
      monthsSelect?.value,
      activateSelect?.value,
    ],
  });
};

export const fetchAnketaList = async (
  params?: AnketaListParamsType
): Promise<IAnketaList> => {
  const res = await requester.get("/api/v1/application/list/", {
    params,
  });
  return res.data;
};

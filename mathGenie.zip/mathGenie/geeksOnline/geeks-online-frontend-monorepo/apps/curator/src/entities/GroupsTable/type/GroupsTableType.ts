export interface Root2 {
  id: string;
  title: string;
  course: Course;
  month: string;
  is_graduated: boolean;
  month_id: string;
  lesson: string;
  students_amount: number;
}

export interface Course {
  id: string;
  title: string;
  months: number;
  date?: string;
}

export interface IRes {
  count: number;
  next: string | null;
  previous: string | null;
  results: Root2[] | [];
  total_students: number;
}

import cls from "./GroupsSelects.module.scss";
import { FC } from "react";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import MonthsSelects from "features/MonthsSelects/ui/MonthsSelects";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo/SearchInfo";
import { Typography, UIFlexBetween } from "@geeks-online/uikit";

interface IProps {
  archive?: boolean;
  total_students?: number;
  isLoading?: boolean;
}

export const GroupsSelects: FC<IProps> = ({
  archive,
  total_students,
  isLoading,
}) => {
  return (
    <>
      <UIFlexBetween>
        <SearchInfo />
        {!isLoading && (
          <Typography variant="Body1" style={{ color: "#afafaf" }}>
            Общее количество :{" "}
            <span style={{ paddingLeft: 32 }}>{total_students ?? 0}</span>
          </Typography>
        )}{" "}
      </UIFlexBetween>
      <div className={cls.selects}>
        <CourseSelect />
        {!archive && <MonthsSelects />}
      </div>
    </>
  );
};

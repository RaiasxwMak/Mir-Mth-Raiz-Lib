import { create } from 'zustand';

export interface form {
  cause: string;
  startCause: string;
  endCause: string;
}
interface IusePauseForm extends form {
  setPauseForm: (param: Partial<form>) => void;
  resetPauseForm: () => void;
}

export const usePauseForm = create<IusePauseForm>((set) => ({
  cause: '',
  startCause: '',
  endCause: '',
  setPauseForm: (param: Partial<form>) => {
    set((prev) => ({ ...prev, ...param }));
  },
  resetPauseForm: () => {
    set({ cause: '', startCause: '', endCause: '' });
  },
}));

export interface IAnketaStudent {
  activated?: boolean;
  full_name?: string;
  first_name?: string;
  last_name?: string;
  patronymic?: string;
  birth_date?: string;
  an_id?: string;
  inn?: string;
  mkk?: string;
  issue_date?: string;
  front_passport?: string | File;
  back_passport?: string | File;
  adress?: string;
  phone?: string;
  additional_phone?: string;
  telegram?: string;
  email?: string;
  education?: string;
  educational_institution?: string;
  filial?: string;
  course?: string;
  laptop_availabe?: string;
  info_source?: string;
  is_parent?: boolean;
  parent_last_name?: string;
  parent_first_name?: string;
  parent_patronymic?: string;
  parent_birth_date?: string;
  parent_adress?: string;
  parent_phone?: string;
  contract?: string;
  course_id?: string;
  from_bitrix?: boolean;
  requisite?: string;
  bitrix_course?: string;
}

export interface IActivateAnketa {
  username: string;
  password: string;
  confirm_password: string;
  group_id: string | null;
  payment_type: string;
  amount: string | null;
  discount: string;
  deposit: string;
}

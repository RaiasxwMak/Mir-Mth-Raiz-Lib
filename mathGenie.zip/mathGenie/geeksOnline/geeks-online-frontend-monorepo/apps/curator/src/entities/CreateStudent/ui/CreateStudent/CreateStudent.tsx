import cls from './CreateStudent.module.scss';
import { FC } from 'react';
import CreateAvaStudent from 'features/CreateStudentInfo/ui/CreateAvaStudent/CreateAvaStudent';
import CreateInfosStudent from 'features/CreateStudentInfo/ui/CreateInfosStudent/CreateInfosStudent';
import CreateStudentButton from '../CreateStudentButton/CreateStudentButton';

const CreateStudent: FC = () => {
  return (
    <div className={cls.createStudent}>
      <CreateAvaStudent />
      <CreateInfosStudent />
      <CreateStudentButton />
    </div>
  );
};

export default CreateStudent;

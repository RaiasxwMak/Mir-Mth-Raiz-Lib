import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useParams, useSearchParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";

export interface IParamAutoReservation {
  weekdays: number[];
  start_date?: string;
  end_date?: string;
  start_time: string;
  end_time: string;
  classroom?: number;
  floor?: number;
}

export interface IGetAutoReservation {
  weekdays: number[];
  start_date?: string;
  end_date?: string;
  start_time: string;
  end_time: string;
  classroom: number;
  floor: number;
  id: string;
}
const getReserveKey = "auto_reservation";

export const useGetAutoReserve = () => {
  const { group_id } = useParams();
  const [searchParam] = useSearchParams();
  const month_id = searchParam.get("month_id");
  return useQuery<IGetAutoReservation>({
    queryFn: async () => {
      const res = await requester.get(
        `/api/v1/curator/group/${group_id}/modules/${month_id}/auto_reservation/`
      );
      return res.data;
    },
    queryKey: [getReserveKey, month_id],
  });
};

export const useAutoReservation = (id?: string) => {
  const quryClient = useQueryClient();
  const successAlert = useOpenAlert();
  const { group_id } = useParams();
  const [searchParam] = useSearchParams();
  const month_id = searchParam.get("month_id");

  return useMutation({
    mutationFn: async (param: IParamAutoReservation) => {
      if (id) {
        const res = requester.patch(
          `/api/v1/curator/group/${group_id}/modules/${month_id}/auto_reservation/`,
          param
        );
        return res;
      }
      const res = requester.post(
        `/api/v1/curator/group/${group_id}/modules/${month_id}/auto_reservation/`,
        param
      );
      return res;
    },
    onSuccess: (res) => {
      if (res && res.status >= 200) {
        successAlert("Сохранено");
        quryClient.invalidateQueries([getReserveKey]);
      }
    },
  });
};

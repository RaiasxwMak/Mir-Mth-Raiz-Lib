import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { IActivateAnketa, IAnketaStudent } from "../type/RedactAnketaType";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";

const ENDPOINTS = {
  ANKETA: (id: string) => `/api/v1/application/${id}/`,
  ACTIVATE: (id: string) => `/api/v1/application/${id}/activate/`,
};

export const queryKeyAnketaDetailStudent = "detailAnketaStudent";

const fetchAnketaDetail = async (id: string) => {
  const { data } = await requester.get(ENDPOINTS.ANKETA(id));
  return data;
};

export const useFetchAnketaStudent = () => {
  const { id } = useParams();
  return useQuery<IAnketaStudent>(
    [queryKeyAnketaDetailStudent, id],
    async () => {
      if (!id) return;
      return await fetchAnketaDetail(id);
    }
  );
};

export const useStudentAnketaEdit = () => {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const successAlert = useOpenAlert();
  const errorAlert = useOpenErrorAlert();
  const studentAnketaEdit = useMutation(
    async (param: IAnketaStudent) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      if (!id) return;
      return requester.patch(ENDPOINTS.ANKETA(id), formdata);
    },
    {
      onSuccess() {
        successAlert("Сохранено");
        queryClient.invalidateQueries([queryKeyAnketaDetailStudent]);
      },
      onError() {
        errorAlert("Ошибка");
      },
    }
  );

  return studentAnketaEdit;
};

export const useActivateAnketa = () => {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const successAlert = useOpenAlert();
  const activate = useMutation(
    async (param: IActivateAnketa) => {
      if (!id) return;
      return requester.post(ENDPOINTS.ACTIVATE(id), param);
    },
    {
      onSuccess() {
        successAlert("Сохранено");
        queryClient.invalidateQueries([queryKeyAnketaDetailStudent]);
      },
    }
  );

  return activate;
};

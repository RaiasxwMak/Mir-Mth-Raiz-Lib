import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { requester } from 'shared/configs/axios/axiosConfig';
import { useGroupInfoSelect } from 'entities/GroupInfoSelect/model/useGroupInfoSelect';
import { ITests } from '../type/GroupInfoTestsSchema';

const ENDPOINTS = {
  TESTS: (group_id: string, module_id: string) =>
    `/api/v1/curator/group/${group_id}/modules/${module_id}/tests/`,
};

export const queryKeyTests = 'tests';

const fetchTests = async (group_id: string, module_id: string) => {
  const response = await requester.get(
    ENDPOINTS.TESTS(group_id ?? '', `${module_id}`)
  );
  return response.data;
};

export const useFetchTests = () => {
  const { group_id } = useParams();
  const { valueSelect } = useGroupInfoSelect();
  return useQuery<ITests[]>(
    [queryKeyTests, valueSelect?.value, group_id],
    async () => {
      if (group_id)
        return await fetchTests(group_id, valueSelect?.value?.toString() ?? '');
    }
  );
};

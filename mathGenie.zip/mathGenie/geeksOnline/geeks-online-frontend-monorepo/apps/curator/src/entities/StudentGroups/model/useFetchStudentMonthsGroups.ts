import { useQuery } from '@tanstack/react-query';
import { requester } from 'shared/configs/axios/axiosConfig';
import { useParams } from 'react-router-dom';

const ENDPOINTS = {
  GET_MONTHS_GROUP: (studentId: string) =>
    `/api/v1/curator/students/${studentId}/month/`,
};


export const fetchStudentMonthsGroups = async (
  studentId: string,
  active?: boolean,
  archive?: boolean
) => {
  const { data } = await requester.get(ENDPOINTS.GET_MONTHS_GROUP(studentId), {
    params: { only_active: active, archive },
  });
  return data;
};

export const queryKeyFetchStudentMonthsGroups = 'FetchStudentMonthsGroups';

const useFetchStudentMonthsGroups = <T>(
  active?: boolean,
  archive?: boolean
) => {
  const { id } = useParams();
  return useQuery<T>(
    [queryKeyFetchStudentMonthsGroups, active, archive],
    async () => {
      if (!id) return;
      return await fetchStudentMonthsGroups(id, active, archive);
    },
    {
      refetchOnWindowFocus: false,
    }
  );
};

export default useFetchStudentMonthsGroups;

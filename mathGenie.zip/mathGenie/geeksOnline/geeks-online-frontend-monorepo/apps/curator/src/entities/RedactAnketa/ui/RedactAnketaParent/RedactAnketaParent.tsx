import { Input, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import dayjs from "dayjs";
import { useAnketaForm } from "entities/RedactAnketa/model/anketaForm";
import { useMemo } from "react";
import { cyrillicRegex } from "shared/lib/helpers/helpers";

const RedactAnketaParent = () => {
  const { form, setForm, setIsChange } = useAnketaForm();
  const errorAlert = useOpenErrorAlert();

  const forms = useMemo(() => {
    return [
      {
        name: "parent_last_name",
        label: "Фамилия родителя",
        star: "*",
        type: "text",
        placeholder: "",
        value: form.parent_last_name,
      },
      {
        name: "parent_first_name",
        label: "Имя родителя",
        star: "*",
        type: "text",
        placeholder: "",
        value: form.parent_first_name,
      },
      {
        name: "parent_patronymic",
        label: "Отчество родителя",
        type: "text",
        placeholder: "",
        value: form.parent_patronymic,
      },
      {
        name: "parent_birth_date",
        label: "Дата рождения родителя",
        star: "*",
        type: "text",
        placeholder: "ДД.ММ.ГГГГ",
        mask: "99.99.9999",
        value: form.parent_birth_date,
      },
      {
        name: "parent_phone",
        label: "Номер телефона родителя",
        star: "*",
        type: "text",
        placeholder: "+ 996",
        mask: "+996 999 99 99 99",
        value: form.parent_phone,
      },
      {
        name: "an_id",
        label: "Серия и номер паспорта",
        star: "*",
        type: "text",
        placeholder: "AN/ID",
        value: form.an_id,
      },
      {
        name: "inn",
        label: "ИНН",
        star: "*",
        type: "text",
        placeholder: "",
        mask: "99999999999999999999",
        value: form.inn,
      },
      {
        name: "mkk",
        label: "Орган выдачи",
        type: "text",
        star: "*",
        placeholder: "MKK",
        value: form.mkk,
      },
      {
        name: "issue_date",
        label: "Дата выдачи",
        star: "*",
        type: "text",
        placeholder: "ДД.ММ.ГГГГ",
        mask: "99.99.9999",
        value: form.issue_date,
      },
      {
        name: "parent_adress",
        label: "Адрес родителя по факту проживания",
        star: "*",
        type: "text",
        placeholder: "",
        value: form.parent_adress,
      },
    ];
  }, [form]);

  const handleChangeForm = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setIsChange(true);
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;

    if (!value.trim()) return;

    if (name === "parent_birth_date" || name === "issue_date") {
      const isValidDate = dayjs(value, "DD.MM.YYYY", true).isValid();
      if (!isValidDate) {
        errorAlert("Неверная дата");
        setForm((prev) => ({ ...prev, [name]: "" }));
      }
    }

    if (
      name === "parent_last_name" ||
      name === "parent_first_name" ||
      name === "parent_patronymic"
    ) {
      const isValidName = cyrillicRegex.test(value);
      if (!isValidName) {
        errorAlert("Поле должно содержать только кириллицу");
        setForm((prev) => ({ ...prev, [name]: "" }));
      }
    }
  };

  return (
    <UIFlexColumn gap={40} width={400}>
      <Typography variant="Title1">Родитель</Typography>
      {forms.map((item, key) => (
        <UIFlexColumn gap={4} key={key}>
          <Typography variant="Text1">
            {item.label}{" "}
            {item.star && <span style={{ color: "red" }}>{item.star}</span>}
          </Typography>
          <Input
            mask={item.mask}
            value={item.value ?? ""}
            type={item.type}
            name={item.name}
            onChange={handleChangeForm}
            onBlur={handleBlur}
            placeholder={item.placeholder}
            fullWidth
          />
        </UIFlexColumn>
      ))}
    </UIFlexColumn>
  );
};

export default RedactAnketaParent;

import { UIFlexColumn } from 'shared/ui/UIFlex/UIFlex';
import cls from './CreateGroup.module.scss';
import { Button, Typography } from 'shared/ui';
import { UsersSelect } from 'features/UsersSelect/UsersSelect';
import { CourseDirections } from 'features/CourseDirections/CourseDirections';
import { GroupSelect } from 'features/GroupSelector/GroupSelect';
import { useCreateGroup } from '../model/useCreateGroup';
import { useCreateGroupMutation } from '../model/createGroupMutation';
import { ThemeButton } from 'shared/ui/Button/Button';

export const CreateGroup = () => {
  const errors = useCreateGroup((state) => state.errors);
  const { mutate } = useCreateGroupMutation();

  const isCourseError = errors.includes('course');
  const isGroupError = errors.includes('group-name');
  const isUsersError = errors.includes('users');

  return (
    <div className={cls.wrapper}>
      <Typography variant='Title1'>Группа</Typography>
      <CourseDirections error={isCourseError} />
      <GroupSelect error={isGroupError} />
      <UIFlexColumn style={{ alignItems: 'flex-start', gap: '10px' }}>
        <Typography variant='Text1'>Студент</Typography>
        <div style={{ width: '100%' }}>
          <UsersSelect error={isUsersError} />
        </div>
      </UIFlexColumn>
      <Button
        width='100%'
        className={cls.button}
        theme={ThemeButton.contained}
        onClick={() => mutate()}
      >
        Сохранить
      </Button>
    </div>
  );
};

import { useQuery } from '@tanstack/react-query';
import { requester } from 'shared/configs/axios/axiosConfig';
import { ICoinDays } from '../type/CoinDaysType';

export const queryKeyMentorCoinDays = 'mentorCoinDays';

export const useGetCoinDays = (mentorId: string) => {
  return useQuery<ICoinDays>([queryKeyMentorCoinDays, mentorId], async () => {
    const { data } = await requester.get(
      `api/geekcoin/v1/mentor/${mentorId}/withdrawals/days`
    );
    return data;
  });
};

import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateStudentRequest } from "entities/CreateStudent/model/CreateStudentRequest";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { useCreateInfos } from "features/CreateInfos/model/CreateInfos";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { FC } from "react";
import { Button, Loader } from "shared/ui";
import { ThemeButton } from "shared/ui/Button/Button";

const CreateStudentButton: FC = () => {
  const { mutateAsync, isLoading } = useCreateStudentRequest();

  const { image } = useCreateAvatar();
  const { inputs, setErrorInputs, paymentWayData } = useCreateInfos();
  const { groupsSelect } = useSearchGroupsSelect();
  const { courseValueSelect } = useCoursesSelect();
  const openError = useOpenErrorAlert();

  const handleClick = async (): Promise<void> => {
    const formData = new FormData();

    image && formData.append("photo", image);

    if (inputs.fio) {
      formData.append("full_name", inputs.fio);
    } else {
      setErrorInputs("fio", true);
      return openError("Заполните все обязательные поля");
    }

    if (inputs.login) {
      formData.append("username", inputs.login);
    } else {
      setErrorInputs("login", true);
      return openError("Заполните все обязательные поля");
    }

    if (inputs.password.length >= 5 || inputs.confirmPassword.length >= 5) {
      if (inputs.password && inputs.confirmPassword) {
        if (inputs.confirmPassword === inputs.password) {
          formData.append("confirm_password", inputs.confirmPassword);
          formData.append("password", inputs.password);
        } else {
          setErrorInputs("password", true);
          setErrorInputs("confirmPassword", true);
          return openError("Пароли не совпадают");
        }
      } else {
        setErrorInputs("password", true);
        setErrorInputs("confirmPassword", true);
        return openError("Заполните все обязательные поля");
      }
    } else {
      setErrorInputs("password", true);
      setErrorInputs("confirmPassword", true);
      return openError("Пароль должен содержать не менее 5 символов");
    }

    if (inputs.telegram) {
      formData.append("telegram", inputs.telegram);
    }

    if (!courseValueSelect) {
      return openError("Заполните все обязательные поля");
    }

    if (inputs.phone) {
      formData.append("phone", inputs.phone);
    } else {
      setErrorInputs("phone", true);
      return openError("Заполните все обязательные поля");
    }

    if (!paymentWayData.way) {
      return openError("Заполните все обязательные поля");
    }
    if (paymentWayData && paymentWayData.way) {
      formData.append("payment_type", paymentWayData.way.label as string);

      const requiredAmount =
        paymentWayData.way.value === "full" ||
        paymentWayData.way.value === "fixed";

      if (requiredAmount && paymentWayData.sum === null) {
        setErrorInputs("sum", true);
        return openError("Заполните все обязательные поля");
      }

      if (requiredAmount) {
        const amount =
          paymentWayData.sum != null ? String(paymentWayData.sum) : "0";
        formData.append("amount", amount);
      }
    }

    if (groupsSelect.value) {
      formData.append("group_id", groupsSelect.value);
    } else return openError("Заполните все обязательные поля");

    inputs.discount && formData.append("discount", inputs.discount);
    inputs.deposit && formData.append("deposit", inputs.deposit);

    mutateAsync(formData);
  };

  return (
    <Button width="100%" onClick={handleClick} theme={ThemeButton.contained}>
      {isLoading ? <Loader small /> : "Сохранить"}
    </Button>
  );
};

export default CreateStudentButton;

import { TestType } from 'shared/lib/consts/consts';

export interface ITests {
  id: string;
  link: string;
  module: IModule;
  type: TestType;
  date: string;
}

interface IModule {
  id: string;
  title: string;
}

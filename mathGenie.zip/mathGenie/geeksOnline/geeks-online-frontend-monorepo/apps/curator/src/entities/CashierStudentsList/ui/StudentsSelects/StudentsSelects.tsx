import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import PaymentSelect from "features/PaymentSelect/ui/PaymentSelect";
import cls from "./StudentsSelects.module.scss";
import SearchGroupsSelect from "features/SearchGroupsSelect/ui/SearchGroupsSelect/SearchGroupsSelect";
import MonthCashierSelect from "features/MonthCashierSelect/ui/MonthCashierSelect";
import YearsSelect from "features/YearsSelect/ui/YearsSelect";
import PaymentTypeSelect from "features/PaymentTypeSelect/ui/PaymentTypeSelect";

export const StudentsSelects = () => {
  const { courseValueSelect } = useCoursesSelect();
  const { clearSelect } = useSearchGroupsSelect();

  return (
    <div className={cls.selects}>
      <CourseSelect afterChange={clearSelect} />
      <div className={cls.wrapper}>
        <SearchGroupsSelect
          course_id={
            courseValueSelect?.value
              ? courseValueSelect?.value.toString()
              : undefined
          }
          className={[cls.autocomplete]}
        />
      </div>
      <PaymentSelect />
      <PaymentTypeSelect />
      <YearsSelect />
      <MonthCashierSelect />
    </div>
  );
};

import { IHistoryPayments } from "../model/useFetchPaymentHistory";
import { Input, Typography, UIFlexColumn } from "@geeks-online/uikit";
import PrevAmounts from "features/PrevAmounts/ui/PrevAmounts";
import cls from "./HistoryPaymentInfo.module.scss";

const HistoryPaymentInfo = ({ info }: { info: IHistoryPayments }) => {
  const historyPayments = [
    {
      label: "Статус оплаты",
      value: info?.is_payed ? "Оплаченный" : "Неоплаченный",
      disabled: true,
    },
    {
      label: "Тип оплаты",
      value: info?.payment_type ?? "",
      disabled: true,
    },
    {
      label: "Стоимость курса",
      value: info?.amount ?? "",
      disabled: true,
    },
    {
      label: "Скидка",
      value: info?.discount ?? "",
      disabled: true,
    },
    {
      label: "Переплата",
      value: info?.overpayment ?? "",
      disabled: true,
    },
    {
      label: "Долг",
      value: info?.debt ?? "",
      disabled: true,
    },
    {
      label: "Сумма к оплате",
      value: info?.for_payment ?? "",
      disabled: true,
    },
    {
      label: "Остаток",
      value: info?.remains ?? "",
      disabled: true,
    },
  ];

  return (
    <UIFlexColumn gap={8} className={cls.wrapInfos}>
      {historyPayments.map((elm, index) => (
        <UIFlexColumn key={index} gap={4} className={cls.dontFullWidth}>
          <Typography variant="Text2_bold">{elm.label}</Typography>
          <Input
            value={elm.value}
            disabled={elm.disabled}
            className={cls.lightInput}
            fullWidth
          />
        </UIFlexColumn>
      ))}
      <PrevAmounts
        titleLabel={"Оплаченная сумма"}
        data={info?.payments || []}
        width={"500px"}
        prevValue={info?.paid_amount ?? 0}
        className={cls.lightInput}
      />
    </UIFlexColumn>
  );
};

export default HistoryPaymentInfo;

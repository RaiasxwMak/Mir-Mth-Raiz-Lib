import { CheckboxChangeEvent } from "antd/es/checkbox";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useFetchCreateMentor } from "entities/CreateMentor/model/useFetchCreateMentor";
import { useFetchProfile } from "entities/ProfileInfo/model/useFetchProfile";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useMentorsSelect } from "features/MentorsList/model/useMentorsSelect";
import { FC, useEffect, useState } from "react";
import {
  Button,
  CustomCheckbox,
  Loader,
  SwitchCustom,
  Typography,
} from "shared/ui";
import { ThemeButton } from "shared/ui/Button/Button";
import { UIFlexColumn, UIFlexRow } from "shared/ui/UIFlex/UIFlex";

export interface iMonthsMs {
  value: number;
  label: string;
  title?: boolean;
  checked?: boolean;
}

const MentorCourse: FC = () => {
  const { data: profile } = useFetchProfile();
  const isSupremeMentor = profile?.user.is_supreme;

  const { mutateAsync, isLoading } = useFetchCreateMentor();

  const openError = useOpenErrorAlert();

  const { courseValueSelect } = useCoursesSelect();
  const { mentorsSelect } = useMentorsSelect();
  const [switched, setSwitched] = useState(false);
  const [istechmentor, setIsTechmentor] = useState(false);
  const [monthHelp, setMonthHelp] = useState<number[]>([]);

  const monthsMs: iMonthsMs[] = [{ value: 1, label: `1 месяц` }];
  const [monthsMentors, setMonthsMentors] = useState<iMonthsMs[]>(monthsMs);

  useEffect(() => {
    const selectsList = [];
    if (!courseValueSelect?.title) return setMonthsMentors(monthsMs);
    for (let i = 1; i <= Number(courseValueSelect.title); i++) {
      selectsList.push({
        value: i,
        label: `${i} месяц`,
      });
    }
    setMonthsMentors(selectsList);
  }, [courseValueSelect?.value]);

  const onChangeMonths = (e: CheckboxChangeEvent) => {
    const checkedValue = e.target.value;
    setMonthHelp((prev) => {
      if (prev.includes(checkedValue)) {
        return prev.filter((value) => value !== checkedValue);
      } else {
        return [...prev, checkedValue];
      }
    });
  };

  const changeSwitch = () => setSwitched((prev) => !prev);
  const changeSwitchTechmentor = () => setIsTechmentor((prev) => !prev);

  const createMentor = () => {
    if (mentorsSelect.value && courseValueSelect?.value && monthHelp.length) {
      return mutateAsync({
        student_id: mentorsSelect.value,
        course_id: courseValueSelect?.value.toString() ?? "",
        months: monthHelp,
        is_supreme: switched,
        is_techmentor: istechmentor,
      });
    } else openError("Заполните все обязательные поля");
  };

  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={4}>
        <Typography variant="Text2_bold">
          Направление <span style={{ color: "red" }}>*</span>
        </Typography>
        <CourseSelect width="400px" />
      </UIFlexColumn>
      <UIFlexColumn gap={20}>
        {monthsMentors?.map((item, key) => (
          <CustomCheckbox
            value={item.value}
            label={item.label}
            checked={monthHelp.includes(item.value)}
            onChange={onChangeMonths}
            key={key}
          />
        ))}
      </UIFlexColumn>
      {!isSupremeMentor && (
        <UIFlexRow gap={6}>
          <SwitchCustom switched={switched} setSwitch={changeSwitch} />
          <Typography variant="Text2_bold">Старший ментор</Typography>
        </UIFlexRow>
      )}
      {!isSupremeMentor && (
        <UIFlexRow gap={6}>
          <SwitchCustom
            switched={istechmentor}
            setSwitch={changeSwitchTechmentor}
          />
          <Typography variant="Text2_bold">Технический ментор</Typography>
        </UIFlexRow>
      )}
      <Button onClick={createMentor} width={400} theme={ThemeButton.contained}>
        {isLoading ? <Loader small /> : "Сохранить"}
      </Button>
    </UIFlexColumn>
  );
};

export default MentorCourse;

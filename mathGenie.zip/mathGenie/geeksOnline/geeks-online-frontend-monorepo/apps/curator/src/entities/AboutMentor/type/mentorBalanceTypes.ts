export interface IMentorBalance {
  count: number;
  next: string;
  previous: string;
  total: number;
  accumulated_amount: number;
  subtractive_percentage: number;
  results: {
    id: string;
    amount: string;
    status: string;
    note: string;
    full_name: string;
    group: string;
    course: string;
    month_number: number;
    created_at: string;
    lesson_number: string;
  }[];
}

export interface IMentorSpendGroups {
  id: string;
  title: string;
}

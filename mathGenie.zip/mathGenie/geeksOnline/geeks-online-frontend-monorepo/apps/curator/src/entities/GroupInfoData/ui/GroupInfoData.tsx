import GroupInfoForm from "features/GroupInfoForm/ui/GroupInfoForm";

const GroupInfoData = ({
  isSupremeMentor = false,
}: {
  isSupremeMentor?: boolean;
}) => {
  return (
    <div>
      <GroupInfoForm isSupremeMentor={isSupremeMentor} />
    </div>
  );
};

export default GroupInfoData;

import { useOpenErrorAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { useCreateTeacherRequest } from 'entities/CreateTeacher/model/CreateTeacherRequest';
import { useCreateAvatar } from 'features/CreateAvatarInfo/model/CreateAvatarInfo';
import { useCreateInfos } from 'features/CreateInfos/model/CreateInfos';
import { FC } from 'react';
import { gmailRegex } from 'shared/lib/helpers/helpers';
import { Button, Loader } from 'shared/ui';
import { ThemeButton } from 'shared/ui/Button/Button';

const CreateTeacherButton: FC = () => {
  const { mutateAsync, isLoading } = useCreateTeacherRequest();

  const { image } = useCreateAvatar();
  const { inputs, setErrorInputs } = useCreateInfos();

  const openError = useOpenErrorAlert();

  const handleCreateTeacher = async (): Promise<void> => {
    const formData = new FormData();

    image && formData.append('photo', image);

    if (inputs.fio) {
      formData.append('full_name', inputs.fio);
    } else {
      setErrorInputs('fio', true);
      return openError('Заполните все обязательные поля');
    }

    if (inputs.login) {
      formData.append('username', inputs.login);
    } else {
      setErrorInputs('login', true);
      return openError('Заполните все обязательные поля');
    }

    if (inputs.password.length >= 5 || inputs.confirmPassword.length >= 5) {
      if (inputs.password && inputs.confirmPassword) {
        if (inputs.confirmPassword === inputs.password) {
          formData.append('confirm_password', inputs.confirmPassword);
          formData.append('password', inputs.password);
        } else {
          setErrorInputs('password', true);
          setErrorInputs('confirmPassword', true);
          return openError('Пароли не совпадают');
        }
      } else {
        setErrorInputs('password', true);
        setErrorInputs('confirmPassword', true);
        return openError('Заполните все обязательные поля');
      }
    } else {
      setErrorInputs('password', true);
      setErrorInputs('confirmPassword', true);
      return openError('Пароль должен содержать не менее 5 символов');
    }

    if (inputs.telegram) {
      formData.append('telegram', inputs.telegram);
    } else {
      setErrorInputs('telegram', true);
      return openError('Заполните все обязательные поля');
    }

    if (inputs.phone) {
      formData.append('phone', inputs.phone);
    } else {
      setErrorInputs('phone', true);
      return openError('Заполните все обязательные поля');
    }

    if (inputs.email) {
      if (gmailRegex.test(inputs.email)) {
        formData.append('email', inputs.email);
      } else {
        setErrorInputs('email', true);
        return openError(`Неверный формат email`);
      }
    }

    mutateAsync(formData);
  };
  return (
    <Button
      onClick={handleCreateTeacher}
      width='100%'
      theme={ThemeButton.contained}
    >
      {isLoading ? <Loader small /> : 'Сохранить'}
    </Button>
  );
};

export default CreateTeacherButton;

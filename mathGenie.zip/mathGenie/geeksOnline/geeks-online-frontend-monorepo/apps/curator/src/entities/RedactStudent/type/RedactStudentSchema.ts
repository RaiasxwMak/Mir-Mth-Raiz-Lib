export interface IStudentDetail {
  id: string;
  photo: string | null;
  full_name: string;
  login: string;
  telegram: string | null;
  birth_date: string | null;
  email: string | null;
  phone: string;
  payment_type: string;
  amount: number;
  requisite?: string;
  active_modules: IActiveModuleStudent[];
  archived_modules: IActiveModuleStudent[];
  created_at: string;
}

export interface IActiveModuleStudent {
  amount: number;
  course: string;
  group: string;
  module_title: string;
  month_id: string;
  payment_type: string;
}

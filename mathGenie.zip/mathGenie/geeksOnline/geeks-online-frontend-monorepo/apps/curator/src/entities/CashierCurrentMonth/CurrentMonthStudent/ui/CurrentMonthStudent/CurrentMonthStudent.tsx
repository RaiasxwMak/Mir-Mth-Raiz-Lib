import {
  Input,
  Loader,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import PrevAmounts from "features/PrevAmounts/ui/PrevAmounts";
import cls from "./CurrentMonthStudent.module.scss";
import { useFetchCurrentMonth } from "../../model/useFetchCurrentMonth";

const CurrentMonthStudent = () => {
  const { data, isLoading } = useFetchCurrentMonth();

  const infoStudentCureentMonth = {
    leftInfos: [
      {
        label: "Стоимость курса",
        value: data?.amount ?? "",
        disabled: true,
      },
      {
        label: "Скидка",
        value: data?.discount ?? "",
        disabled: true,
      },
      {
        label: "Переплата",
        value: data?.overpayment ?? "",
        disabled: true,
      },
      {
        label: "Долг",
        value: data?.debt ?? "",
        disabled: true,
      },
      {
        label: "Сумма к оплате",
        value: data?.for_payment ?? "",
        disabled: true,
      },
    ],
    rightInfos: [
      {
        label: "Направление",
        value: data?.course ?? "",
        disabled: true,
      },
      {
        label: "Группа",
        value: data?.group_title ?? "",
        disabled: true,
      },
      {
        label: "Месяц",
        value: data?.month_number ?? "",
        disabled: true,
      },
      {
        label: "Статус оплаты",
        value: data?.is_payed ? "Оплаченный" : "Неоплаченный",
        disabled: true,
      },
      {
        label: "Тип оплаты",
        value: data?.payment_type ?? "",
        disabled: true,
      },
    ],
  };

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={50} className={cls.wrapper}>
      <UIFlexColumn gap={30}>
        <UIFlexRow gap={100}>
          <UIFlexColumn gap={30} className={cls.fitContentWidth}>
            {infoStudentCureentMonth.leftInfos.map((item, index) => (
              <UIFlexColumn key={index} gap={4} className={cls.dontFullWidth}>
                <Typography variant="Text2_bold">{item.label}</Typography>
                <Input
                  value={item.value}
                  disabled={item.disabled}
                  fullWidth
                  className={cls.lightInput}
                />
              </UIFlexColumn>
            ))}
            <PrevAmounts
              titleLabel={"Оплаченная ранее сумма"}
              data={data?.payments || []}
              width={"500px"}
              prevValue={data?.paid_amount ?? 0}
              className={cls.lightInput}
            />
            <UIFlexColumn gap={4} className={cls.dontFullWidth}>
              <Typography variant="Text2_bold">Остаток</Typography>
              <Input
                value={data?.remains ?? ""}
                disabled={true}
                className={cls.lightInput}
                fullWidth
              />
            </UIFlexColumn>
          </UIFlexColumn>
          <UIFlexColumn gap={30} className={cls.fitContentWidth}>
            {infoStudentCureentMonth.rightInfos.map((item, index) => (
              <UIFlexColumn key={index} gap={4} className={cls.dontFullWidth}>
                <Typography variant="Text2_bold">{item.label}</Typography>
                <Input
                  value={item.value}
                  disabled={item.disabled}
                  fullWidth
                  className={cls.lightInput}
                />
              </UIFlexColumn>
            ))}
          </UIFlexColumn>
        </UIFlexRow>
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default CurrentMonthStudent;

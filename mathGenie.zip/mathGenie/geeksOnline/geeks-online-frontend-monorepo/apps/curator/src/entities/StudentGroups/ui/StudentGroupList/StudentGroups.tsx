import cls from "./StudentGroups.module.scss";
import useFetchStudentMonthsGroups from "entities/StudentGroups/model/useFetchStudentMonthsGroups";
import TableHeader from "../TableHeader/TableHeader";
import StudentGroupListContent from "./StudentGroupListContent";
import { IStudentMonthGroups } from "entities/StudentGroups/type/StudentMonthsSchema";
import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import StudentRecoverButton from "features/StudentRecover/StudentRecoverButton/StudentRecoverButton";
import StudentAddToGroup from "entities/StudentStatus/ui/StudentAddToGroup/StudentAddToGroup";
import { useParams } from "react-router-dom";
import { Loader, Typography } from "shared/ui";
import { EmptyState, TableAccordion } from "@geeks-online/uikit";

interface IStudentGroups {
  isArchive?: boolean;
  isSupremeMentor?: boolean;
}

const StudentGroups = ({
  isArchive = false,
  isSupremeMentor,
}: IStudentGroups) => {
  const { data, isLoading } = useFetchStudentMonthsGroups<IStudentMonthGroups>(
    false,
    isArchive
  );

  const { id } = useParams();
  if (isLoading) return <Loader />;
  if (!data?.length) return <EmptyState text={"Здесь пока ничего нет"} />;

  const isOneCourse = data[data.length - 1];

  return (
    <div>
      <UIFlexColumn gap={40}>
        {data?.map((item) => {
          const lastModule =
            item.student_modules[item.student_modules.length - 1];

          return (
            <div key={item.course} className={cls.table}>
              <TableHeader title={item.course} />
              <UIFlexColumn gap={40}>
                {item.student_modules.map((item, i) => (
                  <TableAccordion
                    key={i}
                    columns={[
                      {
                        dataIndex: "group",
                        className: cls.table_title,
                      },
                      {
                        dataIndex: "month",
                        width: "100%",
                      },
                    ]}
                    showHeader={false}
                    accordion={true}
                    dataSource={item.map((module, index) => ({
                      key: index,
                      group: (
                        <Typography variant="Text2" className={cls.group}>
                          {module.group}
                        </Typography>
                      ),
                      month: module.month,
                      description: (
                        <StudentGroupListContent
                          data={module}
                          isSupremeMentor={isSupremeMentor}
                        />
                      ),
                      expand: true,
                    }))}
                    rowExpandedColor="rgba(198, 198, 198, 0.12)"
                  />
                ))}
              </UIFlexColumn>
              {isArchive && (
                <div className={cls.button_recover}>
                  <StudentRecoverButton
                    data={lastModule[lastModule.length - 1]}
                    student_id={id ?? ""}
                  />
                </div>
              )}
            </div>
          );
        })}
      </UIFlexColumn>
      {isArchive && (
        <div className={cls.button_recover}>
          <StudentAddToGroup data={isOneCourse} student_id={id ?? ""} />
        </div>
      )}
    </div>
  );
};

export default StudentGroups;

import { useQuery } from '@tanstack/react-query';
import { requester } from 'shared/configs/axios/axiosConfig';
import { ICancelsCoins } from '../type/cancelsCoinsType';

export const queryKeyCancelsCoins = 'cancelscoins';

export const useCancelsCoins = (studentId: string) => {
  return useQuery<ICancelsCoins>(
    [queryKeyCancelsCoins, studentId],
    async () => {
      const { data } = await requester.get(
        `/api/v1/mentor/${studentId}/cancels_count`
      );
      return data;
    }
  );
};

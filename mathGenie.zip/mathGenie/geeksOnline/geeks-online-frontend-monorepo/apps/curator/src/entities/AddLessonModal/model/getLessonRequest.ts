import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useOpenAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { requester } from 'shared/configs/axios/axiosConfig';
import { UseQueryReservationKey } from 'widgets/CalendarForOneDay/model/calendarForOneDayRequests';

const ENDPOINTS = {
  LESSON: (id: string): string => `/api/v1/curator/schedule/lesson/${id}/`,
  DELETE: (id: string): string =>
    `/api/v1/curator/schedule/reservations/${id}/`,
};

const queryKeyLesson = 'getLessonRequest';

export interface IGETLESSON {
  title: string;
  course: IModule;
  group: IModule;
  module: IModule;
  lesson_type: {lesson_type: string};
  lesson_desc: {lesson_desc: string};
}

interface IModule {
  id: string;
  title: string;
}

export const useGetLesson = (id?: string | null) => {
  return useQuery<IGETLESSON>([queryKeyLesson, id], async () => {
    if (!id) return;
    const { data } = await requester.get(ENDPOINTS.LESSON(id));
    return data;
  });
};

export const useDeleteLesson = (id: string) => {
  const openSuccess = useOpenAlert();
  const client = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      try {
        await requester.delete(ENDPOINTS.DELETE(id));
        return id;
      } catch (error) {
        throw error;
      }
    },
    onSuccess: () => {
      openSuccess("Удалено");
      client.invalidateQueries([UseQueryReservationKey]);
    },
  });
};

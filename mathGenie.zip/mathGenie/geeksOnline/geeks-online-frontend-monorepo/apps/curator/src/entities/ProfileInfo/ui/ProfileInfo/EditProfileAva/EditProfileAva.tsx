import { useFetchProfileEdit } from 'entities/ProfileInfo/model/useFetchProfile';
import { useCreateAvatar } from 'features/CreateAvatarInfo/model/CreateAvatarInfo';
import { FC } from 'react';
import CreateAvatar from 'shared/ui/CreateAvatar/CreateAvatar';

interface IProps {
    photo: string;
}

const EditProfileAva: FC<IProps> = ({ photo }) => {
    const {  image, setImage } = useCreateAvatar();
    const { mutateAsync } = useFetchProfileEdit();
  
    const handleAsyncChange = async (param:File) => {
      return mutateAsync({ photo: param })
    };
  
    return (
      <CreateAvatar 
        asCb={handleAsyncChange}
        image={image} 
        setImage={setImage} 
        src={photo} 
        avatarSize={140}/>
    )
}

export default EditProfileAva;

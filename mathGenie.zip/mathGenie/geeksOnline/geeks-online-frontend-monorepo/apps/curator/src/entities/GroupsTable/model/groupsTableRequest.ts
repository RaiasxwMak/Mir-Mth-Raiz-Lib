import { useQuery } from '@tanstack/react-query';
import { IRes } from '../type/GroupsTableType';
import { useCoursesSelect } from 'features/CourseSelect/model/useCourseSelect';
import { useMonthsSelect } from 'features/MonthsSelects/model/useMonthsSelects';
import { requester } from 'shared/configs/axios/axiosConfig';
import { usePageChange } from 'shared/ui/CustomPagination/CustomPagination';
import { useEffect } from 'react';
import { useSearchInfo } from 'features/SearchInfo/model/useSearchInfo';

const ENDPOINTS: Record<string, string> = { GROUPS: 'api/v1/curator/group/' };

const queryKeyGroups = 'groupsList';

export const useFetchGroups = () => {
  const { search } = useSearchInfo((state) => state);
  const { courseValueSelect } = useCoursesSelect((state) => state);
  const { monthSelect } = useMonthsSelect();
  const { page, resetPage } = usePageChange();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [monthSelect?.value, courseValueSelect?.value, search]);

  const limit = 12;
  const offset = (page - 1) * limit;

  return useQuery<IRes>(
    [
      queryKeyGroups,
      page,
      search,
      monthSelect?.value,
      courseValueSelect?.value,
    ],
    async () => {
      const { data } = await requester.get(ENDPOINTS.GROUPS, {
        params: {
          limit,
          offset,
          course_id:
            courseValueSelect?.value === '0' ? '' : courseValueSelect?.value,
          search,
          month: !monthSelect?.value ? '' : monthSelect.value,
        },
      });
      return data;
    }
  );
};

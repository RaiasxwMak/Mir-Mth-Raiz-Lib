import { IOption } from 'shared/ui/Select/Select';
import { create } from 'zustand';

interface IuseGroupInfoSelect {
  valueSelect: IOption | null;
  changeSelect: (param: IOption | null) => void;
  resetSelect: () => void;
}

export const useGroupInfoSelect = create<IuseGroupInfoSelect>((set) => ({
  valueSelect: null,
  changeSelect: (param) => {
    set({ valueSelect: param });
  },
  resetSelect: () => {
    set({ valueSelect: null });
  },
}));

import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import cls from "./LessonMode.module.scss";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import SearchGroupsSelect from "features/SearchGroupsSelect/ui/SearchGroupsSelect/SearchGroupsSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { GroupInfoSelect } from "entities/GroupInfoSelect";
import { useGroupInfoSelect } from "entities/GroupInfoSelect/model/useGroupInfoSelect";
import { LessonSelect } from "features/LessonSelect/LessonSelect";
import { IGETLESSON } from "entities/AddLessonModal/model/getLessonRequest";
import { useEffect } from "react";
import { useLessonSelect } from "features/LessonSelect/model/useLessonSelect";
import { handleStrSlice } from "shared/lib/helpers/helpers";
import { useLessonDescription } from "features/LessonDescription/model/useLessonDescription";
import { useLessonTypeSelect } from "features/LessonTypeSelect/model/useLessonTypeSelect";

interface LessonModeProps {
  className?: string;
  lesson?: IGETLESSON;
  id?: string | null;
  isLoading?: boolean;
  lessonType?: string;
}

export const LessonMode = ({ lesson, id }: LessonModeProps) => {
  const { courseValueSelect, courseChangeSelect } = useCoursesSelect();
  const { groupsSelect, onChange, clearSelect } = useSearchGroupsSelect();
  const { changeSelectLesson, resetSelect: resetLesson } = useLessonSelect();
  const {
    valueSelect: monthSelect,
    changeSelect: changeMonthSelect,
    resetSelect: resetMonthSelect,
  } = useGroupInfoSelect();

  const { changeSelectLessonDescription } = useLessonDescription();
  const { changeSelectLessonType } = useLessonTypeSelect();

  useEffect(() => {
    if (!id) return;
    if (!lesson) return;

    courseChangeSelect({
      value: lesson?.course?.id ?? "",
      label: lesson?.course?.title,
    });

    changeMonthSelect({
      value: lesson?.module.id ?? "",
      label: handleStrSlice(lesson?.module?.title),
    });

    onChange(lesson?.group.title || "", {
      value: lesson?.group.id,
      label: lesson?.group.title,
      selectedOption: lesson.group.title,
    });

    changeSelectLesson({
      value: id ?? "",
      label: handleStrSlice(lesson?.title),
    });
    if (lesson.lesson_type.lesson_type === "Онлайн") {
      changeSelectLessonType({
        value: "Онлайн",
        label: "Онлайн",
      });
    }
    if (lesson.lesson_type.lesson_type === "Другое") {
      changeSelectLessonType({
        value: "Другое",
        label: "Другое",
      });
    }
    if (lesson.lesson_type.lesson_type === "Оффлайн") {
      changeSelectLessonType({
        value: "Оффлайн",
        label: "Оффлайн",
      });
    }
    changeSelectLessonDescription(lesson?.lesson_desc.lesson_desc || null);
  }, [lesson]);

  const handleResetMonthAndLesson = () => {
    resetMonthSelect();
    resetLesson();
  };

  return (
    <UIFlexColumn gap={20}>
      <label className={cls.label}>
        Направление
        <CourseSelect
          afterChange={clearSelect}
          width={"100%"}
          disabled={Boolean(id)}
        />
      </label>
      <label className={cls.label}>
        Группа
        <SearchGroupsSelect
          course_id={
            courseValueSelect?.value
              ? courseValueSelect?.value.toString()
              : undefined
          }
          className={[cls.autocomplete]}
          afterChange={handleResetMonthAndLesson}
          disabled={Boolean(id)}
        />
      </label>
      <label className={cls.label}>
        Месяц
        <GroupInfoSelect
          groupId={groupsSelect.value}
          width="100%"
          bordered={true}
          disabled={!groupsSelect.value || Boolean(id)}
          afterChange={resetLesson}
          height="40px"
          isSchedule
        />
      </label>
      <label className={cls.label}>
        Урок
        <LessonSelect
          group_id={groupsSelect.value}
          month_id={monthSelect?.value?.toString() ?? ""}
          width={"100%"}
          height="40px"
          disabled={Boolean(id)}
          isSchedule
        />
      </label>
    </UIFlexColumn>
  );
};

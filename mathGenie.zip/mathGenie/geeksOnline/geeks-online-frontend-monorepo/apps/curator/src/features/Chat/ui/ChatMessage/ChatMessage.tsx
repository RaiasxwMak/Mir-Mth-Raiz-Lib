import { FC, useMemo } from "react";
import cls from "./ChatMessage.module.scss";
import dayjs from "dayjs";
import { Typography } from "@geeks-online/uikit";
import { ReactComponent as ReadStatusIcon } from "shared/assets/icon/readStatusIcon.svg";
import { ReactComponent as RepliedIcon } from "shared/assets/icon/repliedicon.svg";
// import EditIcon from "shared/assets/icon/editMenu.svg";
// import RemoveIcon from "shared/assets/icon/deleteMenu.svg";
import { ReactComponent as DefaultAva } from "shared/assets/icon/ava.svg";
import classNames from "classnames";
import { IMessagesData } from "features/Chat/type/types";
import { Dropdown } from "antd";
import { MenuProps } from "antd/lib";
import { useGetChat } from "features/Chat/model/useGetChat";
dayjs.locale("en");

interface ChatMessageProps {
  message: IMessagesData;
  onReplied?: () => void;
  scrollToMessage: () => void;
  innerRef?: (el: HTMLDivElement | null) => void;
}

const ChatMessage: FC<ChatMessageProps> = ({
  message,
  onReplied,
  innerRef,
  scrollToMessage,
}) => {
  const formattedTime = dayjs(message.created_at).format("h:mm A");

  const { myId } = useGetChat();

  const isOwn = useMemo(() => myId === message.sender.user.id, [myId, message]);

  const getAvatar = useMemo(() => {
    return message.sender.user.photo ? (
      <img
        src={message.sender.user.photo}
        alt="Avatar"
        className={cls.avatar}
      />
    ) : (
      <DefaultAva className={cls.avatar} />
    );
  }, [message]);

  const menuDrop = useMemo(() => {
    const items: MenuProps["items"] = [
      {
        label: <div onClick={onReplied}>{"Ответить"}</div>,
        key: "0",
        icon: <RepliedIcon />,
      },
      // ...(isOwn /// FIX_ME
      //   ? [
      //       {
      //         label: <div>{"Изменить"}</div>,
      //         key: "1",
      //         icon: <EditIcon />,
      //       },
      //       {
      //         label: <div>{"Удалить"}</div>,
      //         key: "2",
      //         icon: <RemoveIcon />,
      //       },
      //     ]
      //   : []),
    ];
    return items;
  }, [isOwn]);

  return (
    <div
      ref={innerRef}
      className={classNames(
        cls.message,
        {
          [cls.ownMessage]: isOwn,
          [cls.otherMessage]: !isOwn,
          [cls.isTeacherAndCurator]:
            message.sender.user.is_curator || message.sender.user.is_teacher,
        },
        []
      )}
    >
      {!isOwn && getAvatar}
      <div className={cls.messageContent}>
        <div className={cls.bubble}>
          <div className={cls.user}>
            <Typography variant="Text1" className={cls.userName}>
              {message.sender.user.full_name}
            </Typography>
            <Dropdown
              menu={{ items: menuDrop }}
              trigger={["click"]}
              placement="bottomRight"
              className={cls.menuDrop}
            >
              <div className={cls.menuIcon}>...</div>
            </Dropdown>
          </div>
          {message.replied_message && (
            <div className={cls.repliedMessage} onClick={scrollToMessage}>
              <Typography variant="Text1" className={cls.repliedUserName}>
                {message.replied_message.sender.user.full_name}
              </Typography>
              <Typography variant="Text4" className={cls.repliedContent}>
                {message.replied_message.content}
              </Typography>
            </div>
          )}
          <Typography variant="Text2">{message.content}</Typography>
          {isOwn && <ReadStatusIcon className={cls.readStatus} />}
        </div>
        <div className={cls.meta}>
          <Typography variant="Text1" className={cls.time}>
            {formattedTime}
          </Typography>
        </div>
      </div>
      {isOwn && getAvatar}
    </div>
  );
};

export default ChatMessage;

import ChatMessage from "../ChatMessage/ChatMessage";
import cls from "./ChatList.module.scss";
import { useEffect, useRef } from "react";
import { IMessagesData } from "features/Chat/type/types";
import { useMenuMessage, useMessages } from "features/Chat/model/useGetChat";
import { useGetMessages } from "features/Chat/model/useRestApiMessages";
import { Loader } from "@geeks-online/uikit";
import { useScrollHandler } from "@geeks-online/shared";

const ChatList = () => {
  const { data, fetchNextPage, isFetching, isLoading } = useGetMessages();
  const {
    messages,
    setMessages,
    prependMessages,
    isNewMessage,
    setIsNewMessage,
  } = useMessages();

  const { onReplyMessage, scrollToMessage } = useMenuMessage();

  const chatListRef = useRef<HTMLDivElement>(null);
  const messageRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const isPrependingRef = useRef(false);

  const { restoreScrollPosition, scrollToBottom } = useScrollHandler({
    containerRef: chatListRef,
    onReachTop: () => {
      isPrependingRef.current = true;
      fetchNextPage();
    },
    isFetching,
  });

  useEffect(() => {
    if (!chatListRef.current || !messages?.length) return;
    scrollToBottom();
    setIsNewMessage(false);
  }, [isNewMessage]);

  useEffect(() => {
    if (!data || !data?.pages.length) return;

    const customData = (data?.pages ?? []).map((page) => ({
      ...page,
      data: [...(page?.data ?? [])],
    }));

    if (data?.pages?.length === 1 && !isPrependingRef.current) {
      const allMessages = customData.flatMap((page) => page?.data ?? []) ?? [];
      setMessages(allMessages.reverse());

      requestAnimationFrame(scrollToBottom);
    } else {
      prependMessages(customData[customData.length - 1]?.data.reverse() ?? []);
      requestAnimationFrame(restoreScrollPosition);

      isPrependingRef.current = false;
    }
  }, [data]);

  if (isLoading) return <Loader height="400px" />;
  return (
    <div className={cls.chatList} ref={chatListRef}>
      {isFetching && <Loader small />}
      {messages?.map((message: IMessagesData) => (
        <ChatMessage
          message={message}
          key={message.id}
          onReplied={() => onReplyMessage(message)}
          scrollToMessage={() =>
            scrollToMessage(
              message.replied_message.id,
              cls,
              messageRefs,
              chatListRef
            )
          }
          innerRef={(el) => {
            messageRefs.current[message?.id] = el;
          }}
        />
      ))}
    </div>
  );
};

export default ChatList;

export interface ISendMessagesType {
  content: string;
  chat_id: string;
  replied_message_id?: string;
  attachments?: {
    content: string;
    content_type: string;
  }[];
}

export interface IGetMessagesType {
  data: IMessagesData[];
  last_read_message_id: string;
}

export interface IMessagesData {
  id: string;
  content: string;
  sender: ISenderChat;
  chat_id: string;
  status: string;
  created_at: string;
  updated_at: string;
  is_edited: boolean;
  is_pinned: boolean;
  replied_message: {
    id: string;
    content: string;
    sender: ISenderChat;
  };
  attachments: [];
}

interface ISenderChat {
  id: string;
  joined_at: string;
  removed_at: string;
  role: string;
  user: {
    is_curator: boolean;
    is_student: boolean;
    is_teacher: boolean;
    id: string;
    username: string;
    full_name: string;
    photo: string;
  };
}

export interface IChatWsEvent {
  action: "send" | "edit" | "delete" | "pin" | "unpin" | "ack";
  message: IMessagesData;
}

export interface IGetChat {
  id: string;
  participants: IParticipants[];
}

export interface IParticipants {
  id: string;
  joined_at: string;
  removed_at: string;
  role: string;
  user: {
    is_curator: boolean;
    is_student: boolean;
    is_teacher: boolean;
    id: string;
    username: string;
    full_name: string;
    photo: string;
  };
}

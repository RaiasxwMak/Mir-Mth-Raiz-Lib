import { Button, Loader, Typography } from 'shared/ui';
import cls from './ArchiveTeacherRecovery.module.scss';
import { UIModal } from 'shared/ui/UIModal/UIModal';
import { ThemeButton } from 'shared/ui/Button/Button';
import { useState } from 'react';
import { useRestoreFromArchiveTeacher } from 'features/ArchiveTeacher/model/ArchiveTeacherRequests';
import { useNavigate } from 'react-router-dom';

const linkToArchiveTeachers = '/curator/archives/teachers';

const ArchiveTeacherRecovery = () => {
  const navigate = useNavigate();
  const [openModal, setOpenModal] = useState(false);
  const { mutateAsync, isLoading } = useRestoreFromArchiveTeacher();

  const handleClickRequest = async () => {
    try {
      await mutateAsync();
      setOpenModal(false);
      setTimeout(() => navigate(linkToArchiveTeachers), 500);
    } catch (e) {
      throw e;
    }
  };
  return (
    <div>
      <Button
        className={cls.button}
        theme={ThemeButton.contained}
        onClick={() => setOpenModal(true)}
      >
        Восстановить преподавателя
      </Button>
      <UIModal
        modalWidth={'400px'}
        className={cls.modal}
        themeCancelBtn={ThemeButton.outline}
        themeOkBtn={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        okTitle={isLoading ? <Loader small /> : 'Да'}
        cancelTitle={'Нет'}
        open={openModal}
        onOkRequest={handleClickRequest}
        onCancel={() => setOpenModal(false)}
      >
        <Typography variant='Title2' className={cls.modal_title}>
          Восстановить преподавателя
        </Typography>
        <Typography variant='Text1' className={cls.subtitle}>
          Вы уверены, что хотите восстановить ?
        </Typography>
      </UIModal>
    </div>
  );
};

export default ArchiveTeacherRecovery;

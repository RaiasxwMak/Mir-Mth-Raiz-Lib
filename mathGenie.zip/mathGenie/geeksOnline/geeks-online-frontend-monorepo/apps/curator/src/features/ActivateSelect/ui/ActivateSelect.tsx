import { selectsHeight } from "shared/lib/consts/consts";
import { Select } from "shared/ui";
import { useActivateSelect } from "../model/useActivateSelect";

const ActivateSelect = ({ width = "256px" }: { width?: string }) => {
  const { activateSelect, onChangeActivateSelects } = useActivateSelect();

  const options = [
    { label: "Все", value: "null" },
    { label: "Активированные", value: "1" },
    { label: "Неактивированные", value: "0" },
  ];
  return (
    <div>
      <Select
        isArrow
        width={width}
        onChange={onChangeActivateSelects}
        value={activateSelect}
        options={options}
        height={selectsHeight}
        placeholder={"Все"}
      />
    </div>
  );
};

export default ActivateSelect;

import { useQuery } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";

const keyUseCourseDirectionsQuery = [
  "course",
  "directions",
  "courseDirections",
];

export interface CourseDirectionsType {
  id: string;
  title: string;
}

export const useCourseDirectionsQuery = () => {
  return useQuery({
    queryFn: () => fetchCourseDirections(),
    queryKey: keyUseCourseDirectionsQuery,
  });
};

const fetchCourseDirections = async () => {
  const res = await requester.get<CourseDirectionsType[]>(
    "/api/v1/curator/course/list/"
  );
  return res.data;
};

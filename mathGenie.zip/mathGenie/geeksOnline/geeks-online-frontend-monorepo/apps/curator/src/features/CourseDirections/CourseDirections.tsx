import { Select, Typography } from "shared/ui";
import { UIFlexColumn } from "shared/ui/UIFlex/UIFlex";
import { useCourseDirectionsQuery } from "./model/courseDirectionsQuery";
import { useCourseDirections } from "./model/useCourseDirections";
import cls from "./CourseDirections.module.scss";

interface CourseDirectionsProps {
  error?: boolean;
}

export const CourseDirections = ({ error }: CourseDirectionsProps) => {
  const { data } = useCourseDirectionsQuery();
  const { directionValue, setDirectionValue } = useCourseDirections();

  return (
    <UIFlexColumn style={{ gap: "10px" }}>
      <Typography variant="Text1">
        Направление <span style={{ color: "red" }}>*</span>
      </Typography>
      <div style={{ width: "100%" }}>
        <Select
          bordered
          error={error}
          value={directionValue}
          placeholder={"Направление"}
          onChange={(param) => setDirectionValue(param)}
          width="100%"
          height="51px"
          options={
            data?.map((option) => ({
              value: option.id,
              label: option.title,
            })) || []
          }
          optionLabelProp="title"
          rootClass={cls.select}
          isArrow
        />
      </div>
    </UIFlexColumn>
  );
};

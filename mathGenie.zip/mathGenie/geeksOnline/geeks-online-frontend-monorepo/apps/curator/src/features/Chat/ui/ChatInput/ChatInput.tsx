import { useEffect, useMemo, useRef, useState } from "react";
import cls from "./ChatInput.module.scss";
import { ReactComponent as AttchIcon } from "shared/assets/icon/attachIcon.svg";
import { ReactComponent as EmojiIcon } from "shared/assets/icon/emoji.svg";
import { ReactComponent as MessageIcon } from "shared/assets/icon/messageIcon.svg";
import { ReactComponent as MicroIcon } from "shared/assets/icon/microphone.svg";
import classNames from "classnames";
import EmojiPicker, {
  EmojiClickData,
  EmojiStyle,
  Theme,
} from "emoji-picker-react";
import useClickOutside from "shared/lib/useClickOutside/useClickOutside";
import { Loader, Typography } from "@geeks-online/uikit";
import { useGetChat, useMenuMessage } from "features/Chat/model/useGetChat";
import { useSendMessage } from "features/Chat/model/useRestApiMessages";
import { ISendMessagesType } from "features/Chat/type/types";
import { ingnoreAny } from "shared/global/types";

const ChatInput = () => {
  const { mutateAsync, isLoading } = useSendMessage();
  const { chatId, participants: users } = useGetChat();

  const { action, selectedMessage, messageId, clearAction } = useMenuMessage();

  const [message, setMessage] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const [listening, setListening] = useState(false);

  const [mentionQuery, setMentionQuery] = useState("");
  const [showMentionList, setShowMentionList] = useState(false);
  const [cursorPosition, setCursorPosition] = useState<number | null>(null);

  const mentionRef = useRef<HTMLDivElement | null>(null);
  const emojiRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<ingnoreAny>(null);

  useClickOutside([mentionRef], () => {
    setShowMentionList(false);
  });
  useClickOutside([emojiRef], () => {
    setShowEmojiPicker(false);
  });

  const handleEmojiClick = (emojiData: EmojiClickData) =>
    setMessage((prev) => prev + emojiData.emoji);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const cursorPos = e.target.selectionStart ?? value.length;

    setMessage(value);
    setCursorPosition(cursorPos);

    const match = value.slice(0, cursorPos).match(/@(\w*)$/);
    if (match) {
      setMentionQuery(match[1]);
      setShowMentionList(true);
    } else {
      setShowMentionList(false);
    }
  };

  const filteredUsers = useMemo(
    () =>
      users?.filter((u) =>
        u.user.username.toLowerCase().startsWith(mentionQuery.toLowerCase())
      ),
    [users, mentionQuery]
  );

  const insertMention = (username: string) => {
    if (cursorPosition === null) return;

    const before = message.slice(0, cursorPosition);
    const after = message.slice(cursorPosition);
    const newMessage = before.replace(/@(\w*)$/, `@${username} `) + after;

    setMessage(newMessage);
    setShowMentionList(false);
  };

  const handleSendMessages = async () => {
    if (!message.trim() || !chatId) return;

    const body: ISendMessagesType = {
      content: message,
      chat_id: chatId,
    };

    if (action === "replied" && messageId) {
      body.replied_message_id = messageId;
    }

    const res = await mutateAsync(body);
    if (res.id) {
      setMessage("");
      clearAction();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessages();
    }
  };

  const startListening = () => {
    if (recognitionRef.current && !listening) {
      setMessage("");
      recognitionRef.current.start();
      setListening(true);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && listening) {
      recognitionRef.current.stop();
      setListening(false);
    }
  };

  useEffect(() => {
    const SpeechRecognition =
      (window as ingnoreAny).SpeechRecognition ||
      (window as ingnoreAny).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Ваш браузер не поддерживает распознавание речи.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "ru-RU";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event: ingnoreAny) => {
      const transcript = event?.results[0][0].transcript;
      setMessage((prev) => prev + " " + transcript);
    };

    recognition.onend = () => {
      setListening(false);
    };

    recognition.onerror = (event: ingnoreAny) => {
      console.error("Ошибка распознавания:", event.error);
      setListening(false);
    };

    recognitionRef.current = recognition;
  }, []);
  return (
    <div className={cls.chatInput}>
      <div className={cls.wrapInput}>
        <AttchIcon cursor={!message.trim() ? "not-allowed" : "pointer"} />
        <input
          className={cls.input}
          placeholder="Сообщение"
          value={message}
          maxLength={4096}
          onChange={handleChange}
          onKeyPress={handleKeyPress}
          disabled={isLoading}
        />
        {action === "replied" && (
          <div className={cls.repliedMessage}>
            <Typography variant="Text4">
              @{selectedMessage?.sender.user?.full_name}
            </Typography>
            <Typography variant="Text2">{selectedMessage?.content}</Typography>
            <span onClick={() => clearAction()} className={cls.close}>
              &times;
            </span>
          </div>
        )}
        {showMentionList &&
          message.trim() &&
          filteredUsers &&
          filteredUsers?.length > 0 && (
            <div
              ref={mentionRef}
              className={classNames(cls.repliedMessage, cls.noteList)}
            >
              {filteredUsers?.map((u, k) => (
                <div
                  className={cls.mentionUser}
                  key={k}
                  onClick={() => insertMention(u.user.username)}
                >
                  <Typography variant="Text4">@{u.user.username}</Typography>
                </div>
              ))}
            </div>
          )}
        <div className={cls.icons}>
          <button
            className={cls.microBtn}
            onClick={() => (!listening ? startListening() : stopListening())}
          >
            <MicroIcon />
          </button>
          <div
            onMouseEnter={() => setShowEmojiPicker(true)}
            onMouseLeave={() => setShowEmojiPicker(false)}
            ref={emojiRef}
            className={cls.emojiWrapper}
          >
            <EmojiIcon
              onClick={() => setShowEmojiPicker((prev) => !prev)}
              cursor={"pointer"}
              className={cls.emojIcon}
            />
            {showEmojiPicker && (
              <div className={cls.emojiPicker}>
                <EmojiPicker
                  onEmojiClick={handleEmojiClick}
                  theme={Theme.DARK}
                  emojiStyle={EmojiStyle.APPLE}
                />
              </div>
            )}
          </div>
          <button
            className={classNames(
              cls.message,
              { [cls.messageSend]: !!message.trim() },
              []
            )}
            onClick={handleSendMessages}
            disabled={!message.trim() || isLoading}
          >
            {isLoading ? <Loader small /> : <MessageIcon />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;

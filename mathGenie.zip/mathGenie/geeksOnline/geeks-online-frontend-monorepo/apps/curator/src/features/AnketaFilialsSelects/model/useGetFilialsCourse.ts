import { useQuery } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";

export interface IFilialsForm {
  id: string;
  title: string;
}

export const queryKeyAnketaCourse = "detailAnketaCourse";

const fetchAnketaCourse = async (id: string) => {
  const { data } = await requester.get(
    `/api/v1/administrator/application/course/?filial=${id}`
  );
  return data;
};

export const useGetAnketaCourse = (id: string | number) => {
  return useQuery<IFilialsForm[]>([queryKeyAnketaCourse], async () => {
    if (!id) return;
    return await fetchAnketaCourse(String(id));
  });
};

import cls from "./ChatPinnedMessage.module.scss";
import PinnedIcon from "shared/assets/icon/pinned.svg";

const ChatPinnedMessage = () => {
  const isPinned = true;

  if (isPinned) return <></>;
  return (
    <div className={cls.pinnedBlock}>
      <div className={cls.leftBlock}>
        <PinnedIcon />
        <p className={cls.pinnedTitle}>Закрепленное сообщение</p>
      </div>
      <p className={cls.text}>
        {
          "Добрый день! Ваши посещаемость и баллы за ДЗ, а также номер аудитории, где сегодня пройдет урок, Вы можете посмотреть в https://online.geeks.kg/"
        }
      </p>
    </div>
  );
};

export default ChatPinnedMessage;

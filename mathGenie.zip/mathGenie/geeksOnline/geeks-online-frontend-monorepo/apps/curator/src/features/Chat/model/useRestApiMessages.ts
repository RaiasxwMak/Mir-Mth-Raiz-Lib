import { useInfiniteQuery, useMutation } from "@tanstack/react-query";
import { ISendMessagesType } from "../type/types";
import { useGetChat } from "./useGetChat";
import { requester } from "shared/configs/axios/axiosConfig";
import { ingnoreAny } from "shared/global/types";

export const getMessagesKey = "messagesKey";

interface PageParam {
  before_message_id?: string;
}

interface GetMessagesParam {
  chat_id: string;
}

type FullMessagesParams = GetMessagesParam & PageParam;

export const useGetMessages = () => {
  const { chatId } = useGetChat();

  return useInfiniteQuery<ingnoreAny, ingnoreAny, ingnoreAny, ingnoreAny>({
    queryKey: [getMessagesKey, chatId],
    queryFn: async ({ pageParam }) => {
      try {
        if (!chatId) return;

        const params: FullMessagesParams = {
          chat_id: chatId,
          ...(pageParam?.before_message_id && {
            before_message_id: pageParam.before_message_id,
          }),
        };

        const { data } = await requester.get("/api/messages/v1", { params });

        return data;
      } catch (e) {
        console.error(e);
      }
    },
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage || lastPage.data.length === 0) return undefined;
      const last = allPages[allPages.length - 1];

      return { before_message_id: last.data[last.data.length - 1].id };
    },
    initialPageParam: {},
    enabled: !!chatId,
  });
};

export const useSendMessage = () => {
  return useMutation({
    mutationFn: async (param: ISendMessagesType) => {
      try {
        const { data } = await requester.post("/api/messages/v1", param);
        return data;
      } catch (e) {
        console.error(e);
        return e;
      }
    },
  });
};

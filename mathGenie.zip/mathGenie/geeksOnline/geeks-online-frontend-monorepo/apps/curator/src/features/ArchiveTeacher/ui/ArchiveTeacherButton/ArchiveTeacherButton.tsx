import { Button, Loader, Typography } from 'shared/ui';
import { ThemeButton } from 'shared/ui/Button/Button';
import cls from './ArchiveTeacherButton.module.scss';
import { UIModal } from 'shared/ui/UIModal/UIModal';
import { useState } from 'react';
import { useSendToArchiveTeacher } from 'features/ArchiveTeacher/model/ArchiveTeacherRequests';
import { useNavigate } from 'react-router-dom';

const linkToTeachersPage = '/curator/teachers';

const ArchiveTeacherButton = () => {
  const navigate = useNavigate();
  const [openModal, setOpenModal] = useState(false);
  const { mutateAsync, isLoading } = useSendToArchiveTeacher();

  const handleClickRequest = async () => {
    try {
      await mutateAsync();
      setOpenModal(false);
      setTimeout(() => navigate(linkToTeachersPage), 500);
    } catch (e) {
      throw e;
    }
  };

  return (
    <>
      <Button
        className={cls.button}
        theme={ThemeButton.contained}
        onClick={() => setOpenModal(true)}
      >
        Архивировать преподавателя
      </Button>
      <UIModal
        modalWidth={'400px'}
        className={cls.modal}
        themeOkBtn={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        okTitle={isLoading ? <Loader small /> : 'Да'}
        themeCancelBtn={ThemeButton.outline}
        cancelTitle={'Нет'}
        open={openModal}
        onCancel={() => setOpenModal(false)}
        onOkRequest={handleClickRequest}
      >
        <Typography variant='Title2' className={cls.modal_title}>
          Архивировать преподавателя
        </Typography>
        <Typography variant='Text1' className={cls.subtitle}>
          Вы уверены, что хотите архивировать ?
        </Typography>
      </UIModal>
    </>
  );
};

export default ArchiveTeacherButton;

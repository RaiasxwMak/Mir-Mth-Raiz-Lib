import { create } from "zustand";
import { IGetChat, IMessagesData, IParticipants } from "../type/types";
// import sound from "shared/assets/sound/notification.mp3";
import { AxiosResponse } from "axios";
import { MutableRefObject, RefObject } from "react";
import { requester } from "shared/configs/axios/axiosConfig";

interface useGetChatType {
  chatId: string | null;
  myId: string | undefined;
  participants: IParticipants[] | null;
  getMyId: (id?: string) => void;
  getChat: (id?: string) => Promise<void>;
  resetChatId: () => void;
}

interface MenuMessageType {
  messageId: string | null;
  action: "edit" | "delete" | "replied" | null;
  selectedMessage: IMessagesData | null;
  onReplyMessage: (message: IMessagesData) => void;
  scrollToMessage: (
    id: string,
    cls: any,
    messageRefs: MutableRefObject<Record<string, HTMLDivElement | null>>,
    chatListRef: RefObject<HTMLDivElement>
  ) => void;
  clearAction: () => void;
}
interface useMessagesType {
  messages: IMessagesData[] | null;
  setMessages: (param: IMessagesData[]) => void;
  prependMessages: (param: IMessagesData[]) => void;
  addMessage: (message: IMessagesData, myId?: string) => void;

  isNewMessage: boolean;
  setIsNewMessage: (param: boolean) => void;

  chatWs: WebSocket | null;
  setChatWs: (ws: WebSocket | null) => void;
}

export const useGetChat = create<useGetChatType>((set) => ({
  chatId: null,
  myId: undefined,
  participants: null,
  getMyId: (id) => set({ myId: id }),
  getChat: async (id?: string) => {
    try {
      if (!id) return;
      const res: AxiosResponse<IGetChat> = await requester.get(
        `/api/chats/v1/${id}`
      );
      if (res?.data.id) {
        set({ chatId: res.data.id, participants: res.data.participants ?? [] });
      }
    } catch (e) {
      console.error(e);
    }
  },
  resetChatId: () => set({ chatId: null }),
}));

export const useMessages = create<useMessagesType>((set) => {
  // const playNotificationSound = () => {
  //   const audio = new Audio(sound);
  //   audio.play().catch((error) => {
  //     console.error("Error playing notification sound:", error);
  //   });
  // };

  return {
    isNewMessage: false,
    setIsNewMessage: (param: boolean) => set({ isNewMessage: param }),
    messages: null,
    setMessages: (param: IMessagesData[]) =>
      set({
        messages: param,
      }),
    prependMessages: (param: IMessagesData[]) => {
      return set((state) => ({
        messages: state.messages ? [...param, ...state.messages] : param,
      }));
    },
    addMessage: (message: IMessagesData) =>
      set((state) => {
        const exists = state.messages?.some((msg) => msg.id === message.id);
        if (exists) return state;

        // if (myId && message.sender.user.id !== myId) playNotificationSound(); // FIX_ME needs to future
        return {
          messages: state.messages ? [...state.messages, message] : [message],
          isNewMessage: true,
        };
      }),

    chatWs: null,
    setChatWs: (ws) => {
      set({ chatWs: ws });
    },
  };
});

export const useMenuMessage = create<MenuMessageType>((set) => ({
  messageId: null,
  action: null,
  selectedMessage: null,
  onReplyMessage: (message: IMessagesData) => {
    set({ action: "replied", selectedMessage: message, messageId: message.id });
  },
  scrollToMessage: (
    id: string,
    cls: any,
    messageRefs: MutableRefObject<Record<string, HTMLDivElement | null>>,
    chatListRef: RefObject<HTMLDivElement>
  ) => {
    const tryScroll = () => {
      const el = messageRefs.current[id];
      if (el) {
        if (!el.dataset.highlighted) {
          const observer = new IntersectionObserver(
            (entries) => {
              const entry = entries[0];
              if (entry.isIntersecting) {
                el.dataset.highlighted = "true";
                el.classList.add(cls.highlighted);

                setTimeout(() => {
                  el.classList.remove(cls.highlighted);
                  delete el.dataset.highlighted;
                }, 1500);

                observer.disconnect();
              }
            },
            {
              root: chatListRef.current,
              threshold: 0.8,
            }
          );

          observer.observe(el);
        }

        el.scrollIntoView({ behavior: "smooth", block: "center" });
      } else {
        chatListRef.current?.scrollTo({
          top: 0,
          behavior: "smooth",
        });
        setTimeout(tryScroll, 300);
      }
    };

    tryScroll();
  },
  clearAction: () => {
    set({
      action: null,
      selectedMessage: null,
      messageId: null,
    });
  },
}));

import { Typography } from "@geeks-online/uikit";
import { ReactComponent as DefaultAva } from "shared/assets/icon/ava.svg";
import cls from "./ChatUsersList.module.scss";
import { FC, useState } from "react";
import classNames from "classnames";
import { useGetChat } from "features/Chat/model/useGetChat";

interface IProps {
  isMobile?: boolean;
}

const ChatUsersList: FC<IProps> = ({ isMobile }) => {
  const [openUsers, setOpenUsers] = useState(false);
  const { participants: users } = useGetChat();

  if (!users?.length) return <></>;
  return (
    <div
      onClick={() => isMobile && setOpenUsers((prev) => !prev)}
      className={classNames(
        cls.users,
        { [cls.mobileUsers]: isMobile, [cls.opened]: openUsers && isMobile },
        []
      )}
    >
      <Typography variant="Body3">Участники</Typography>
      <div
        className={classNames(
          cls.usersList,
          { [cls.mobileList]: isMobile },
          []
        )}
        style={
          isMobile
            ? {
                height: openUsers
                  ? `calc(${users?.length} * 32px + 54px + 188px)`
                  : 0,
                padding: openUsers ? "40px 0 0 20px" : 0,
              }
            : {}
        }
      >
        {users.map((user, key) => (
          <div className={cls.userCard} key={key}>
            {user?.user.photo ? (
              <div className={cls.img}>
                <img src={user.user.photo} alt="userAva" />
              </div>
            ) : (
              <DefaultAva width={32} height={32} />
            )}
            <Typography
              variant="Text4"
              className={classNames(
                cls.text,
                {
                  [cls.yellowColor]:
                    user.user.is_curator || user.user.is_teacher,
                },
                []
              )}
            >
              {user?.user.full_name}
            </Typography>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChatUsersList;

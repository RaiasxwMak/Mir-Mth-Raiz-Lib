import ChatList from "../ChatList/ChatList";
import ChatInput from "../ChatInput/ChatInput";
import cls from "./ChatWidget.module.scss";

const ChatWidget = () => {
  return (
    <div className={cls.wrapChat}>
      <div className={cls.chat}>
        <div className={cls.chatContainer}>
          <ChatList />
          <ChatInput />
        </div>
      </div>
    </div>
  );
};

export default ChatWidget;

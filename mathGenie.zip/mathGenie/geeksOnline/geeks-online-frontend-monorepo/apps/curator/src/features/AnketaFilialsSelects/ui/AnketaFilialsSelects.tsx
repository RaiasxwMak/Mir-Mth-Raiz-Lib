import {
  CustomSelect,
  IOption,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { FC, useEffect, useMemo, useState } from "react";
import { useGetAnketaCourse } from "../model/useGetFilialsCourse";
import { useAnketaForm } from "entities/RedactAnketa/model/anketaForm";

interface IAnketaFililalsProps {
  fililalId: string;
  course: string;
  course_id: string;
}

const AnketaFilialsSelects: FC<IAnketaFililalsProps> = ({
  fililalId,
  course,
  course_id,
}) => {
  const { setForm, setIsChange } = useAnketaForm();
  const [coursesSelect, setCoursesSelect] = useState<IOption | null>({
    label: course,
    value: course_id,
  });

  const { data: courses } = useGetAnketaCourse(fililalId);

  const coursesOptions = useMemo(() => {
    return (
      courses?.map((i) => ({
        value: i.id,
        label: i.title,
      })) ?? []
    );
  }, [courses]);

  const handleChangeCourseSelect = (param: IOption) => {
    setCoursesSelect(param);
    setForm((prev) => ({ ...prev, course_id: String(param?.value) }));
    setIsChange(true);
  };

  useEffect(() => {
    if (course_id) {
      setForm((prev) => ({ ...prev, course_id: course_id }));
    }
  }, [course_id]);
  return (
    <>
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">
          Выбранное направление <span style={{ color: "red" }}>*</span>
        </Typography>
        <CustomSelect
          isArrow
          onChange={handleChangeCourseSelect}
          value={coursesSelect}
          width={"100%"}
          height={"44px"}
          options={coursesOptions}
          disabled={!coursesOptions.length}
        />
      </UIFlexColumn>
    </>
  );
};

export default AnketaFilialsSelects;

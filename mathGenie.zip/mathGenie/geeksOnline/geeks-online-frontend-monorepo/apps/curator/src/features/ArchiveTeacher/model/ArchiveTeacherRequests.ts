import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useOpenAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';
import { queryKeyTeacher } from 'entities/InfoTeacher/model/useFetchInfoTeacher';
import { useParams } from 'react-router-dom';
import { requester } from 'shared/configs/axios/axiosConfig';

const ENDPOINTS = {
  SEND_TO_ARCHIVE: (teacher_id: string) =>
    `/api/v1/curator/teacher/send-to-archive/${teacher_id}/`,
  RESTORE_FROM_ARCHIVE: (teacher_id: string) =>
    `/api/v1/curator/teacher/restore-from-archive/${teacher_id}/`,
};

export const sendToArchiveTeacher = async (teacher_id: string) => {
  return await requester.post(ENDPOINTS.SEND_TO_ARCHIVE(teacher_id));
};
export const restoreFromArchiveTeacher = async (teacher_id: string) => {
  return await requester.post(ENDPOINTS.RESTORE_FROM_ARCHIVE(teacher_id));
};

const textArchiveSuccess = 'Данные успешно архивированы';
const textRestoreSuccess = 'Данные успешно восстановлены';

export const useSendToArchiveTeacher = () => {
  const alertSuccess = useOpenAlert();
  const { teacher_id } = useParams();
  const queryClient = useQueryClient();

  return useMutation(
    async () => {
      return await sendToArchiveTeacher(teacher_id ?? '');
    },
    {
      onSuccess() {
        alertSuccess(textArchiveSuccess);
        queryClient.invalidateQueries([queryKeyTeacher]);
      },
    }
  );
};

export const useRestoreFromArchiveTeacher = () => {
  const alertSuccess = useOpenAlert();
  const { teacher_id } = useParams();
  const queryClient = useQueryClient();

  const teacherEdit = useMutation(
    async () => {
      if (!teacher_id) throw new Error('error');
      return await restoreFromArchiveTeacher(teacher_id);
    },
    {
      onSuccess() {
        alertSuccess(textRestoreSuccess);
        queryClient.invalidateQueries([queryKeyTeacher]);
      },
    }
  );
  return teacherEdit;
};

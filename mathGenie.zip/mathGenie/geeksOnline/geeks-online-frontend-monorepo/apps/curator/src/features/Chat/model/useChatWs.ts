import { useGetChat, useMessages } from "./useGetChat";
import { useEffect, useRef } from "react";
import {
  COOKIE_ACCESS_TOKEN_KEY,
  COOKIE_TOKEN_TYPE_KEY,
} from "@geeks-online/shared";
import { IChatWsEvent } from "../type/types";
import { cookie } from "shared/lib/cookie/cookie";
import { BASE_URL_WS } from "shared/lib/consts/consts";

interface useChatWsType {
  chatWs: WebSocket | null;
}

const chatSocketUrl = (token: string) =>
  `wss://${BASE_URL_WS}/api/ws/v1?token=${token}`;

export const useChatWs = (): useChatWsType => {
  const { chatWs, setChatWs, addMessage } = useMessages();
  const { myId, chatId } = useGetChat();

  const myIdRef = useRef(myId);
  const chatIdRef = useRef(chatId);

  const initChatSocket = (
    token: string,
    onMessageCallback: (param: IChatWsEvent) => void
  ) => {
    const ws = new WebSocket(chatSocketUrl(token));
    setChatWs(ws);

    ws.onopen = () => {
      console.info("ChatSocket connected");
    };

    ws.onmessage = (ev: MessageEvent<string>) => {
      const messages: IChatWsEvent = JSON.parse(ev.data);
      onMessageCallback(messages);
    };

    ws.onclose = () => {
      console.info("ChatSocket closed");
    };

    ws.onerror = (ev) => {
      console.error("ChatSocket connection error: ", ev);
    };
  };

  const closeChatSocket = () => {
    if (chatWs) {
      chatWs.close();
      setChatWs(null);
    }
  };

  const getToken = (): string => {
    const token = cookie.getCookie(COOKIE_ACCESS_TOKEN_KEY);
    const token_type = cookie.getCookie(COOKIE_TOKEN_TYPE_KEY);

    return `${token_type} ${token}`;
  };

  useEffect(() => {
    myIdRef.current = myId;
  }, [myId]);

  useEffect(() => {
    chatIdRef.current = chatId;
  }, [chatId]);

  useEffect(() => {
    if (chatWs) return;

    initChatSocket(getToken(), (chat) => {
      if (chat.action === "send" && chatIdRef.current === chat.message.chat_id)
        addMessage(chat.message, myIdRef.current);
    });
    return () => {
      closeChatSocket();
    };
  }, [chatWs]);

  return {
    chatWs,
  };
};

import { IOption } from "shared/ui/Select/Select";
import { create } from "zustand";

export interface UseCourseDirections {
  directionValue: IOption | null;
  setDirectionValue: (value: IOption) => void;
  onClear: () => void;
}

export const useCourseDirections = create<UseCourseDirections>((set) => ({
  directionValue: null,
  setDirectionValue(value) {
    set({ directionValue: value });
  },
  onClear() {
    set({ directionValue: null });
  },
}));

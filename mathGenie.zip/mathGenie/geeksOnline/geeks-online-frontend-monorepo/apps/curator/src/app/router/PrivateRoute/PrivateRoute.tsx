import { useFetchProfile } from "entities/ProfileInfo/model/useFetchProfile";
import { Navigate, Outlet } from "react-router-dom";

const PrivateRoute = () => {
  const { data } = useFetchProfile();
  const isSupremeMentor = data?.user.is_supreme;
  return isSupremeMentor ? <Navigate to="/curator/" /> : <Outlet />;
};

export default PrivateRoute;

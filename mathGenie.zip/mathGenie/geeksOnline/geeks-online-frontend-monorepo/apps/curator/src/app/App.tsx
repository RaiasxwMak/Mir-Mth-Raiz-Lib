import { useState, useEffect } from 'react';
import { AppRouter } from './router/AppRouter/AppRouter';
import SmallScreenFiller from 'features/SmallScreenFiller/SmallScreenFiller';

function App() {
  useEffect(() => {
    console.info(`ENVIRONMENT = ${import.meta.env.MODE}`);
  }, []);
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  useEffect(() => {
    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 1280);
    };
    // Initial check
    checkScreenSize();
    // Add event listener for window resize
    window.addEventListener('resize', checkScreenSize);
    // Cleanup event listener on component unmount
    return () => window.removeEventListener('resize', checkScreenSize);
 }, []);


  return (
    <>
      {!isSmallScreen ? (<AppRouter />) : (<SmallScreenFiller/>)}
    </>);
}
export default App;

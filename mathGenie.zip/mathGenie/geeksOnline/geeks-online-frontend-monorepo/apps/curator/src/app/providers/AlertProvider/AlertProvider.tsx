import cls from "./AlertProvider.module.scss";
import { notification } from "antd";
import { FC, ReactNode, useEffect } from "react";
// import { ReactComponent as CloseIcon } from '../../../shared/assets/icon/close.svg';
import { ReactComponent as CookieIcon } from "../../../shared/assets/icon/cookieIcon.svg";
import { Button } from "shared/ui";
import Cookies from "js-cookie";
import classNames from "classnames";
import { AlertContext, IAlertContext } from "./model/context";
import { requester } from "shared/configs/axios/axiosConfig";

interface IAlertProvider {
  children: ReactNode;
}

const btnText = "Принять";

const AlertProvider: FC<IAlertProvider> = ({ children }) => {
  const [api, contextHolder] = notification.useNotification();

  const acceptCookies = (): void => {
    Cookies.set("acceptedCookies", "true", { expires: 365 });
    api.destroy();
  };

  const btn = (
    <Button onClick={acceptCookies} className={classNames(cls.btn, {}, [])}>
      {btnText}
    </Button>
  );

  const openNotification = (message: string): void => {
    api.open({
      message,
      className: cls.alert,
      duration: 3,
    });
  };

  const openFailNotification = (message: string): void => {
    api.open({
      message,
      className: `${cls.alert}  ${cls.fail}`,
      duration: 3,
    });
  };

  const getCookie = (): void => {
    api.open({
      btn,
      message: "Мы используем файлы cookie, чтобы улучшить работу сайта",
      className: `${cls.getCookie}`,
      duration: 0,
      placement: "bottom",
      icon: <CookieIcon />,
    });
  };

  useEffect(() => {
    const acceptedCookies = Cookies.get("acceptedCookies");
    if (acceptedCookies === "true") {
      api.destroy();
    }
  }, []);

  useEffect(() => {
    (window as unknown as IAlertContext).openNotification = openNotification;
    (window as unknown as IAlertContext).openFailNotification =
      openFailNotification;

    requester.interceptors.response.use(
      (config) => config,
      (error) => {
        if (error.response.data.message)
          openFailNotification(error.response.data.detail);
        return Promise.reject(error);
      }
    );
  }, []);
  return (
    <AlertContext.Provider
      value={{ openNotification, openFailNotification, getCookie }}
    >
      {contextHolder}
      {children}
    </AlertContext.Provider>
  );
};

export default AlertProvider;

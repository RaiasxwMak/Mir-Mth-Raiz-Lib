import { createContext } from 'react';

export interface IAlertContext {
  openNotification: (message: string) => void;
  openFailNotification: (message: string) => void;
  getCookie: () => void;
}

export const AlertContext = createContext<IAlertContext>({} as IAlertContext);

import { AppProvider } from "app/providers/AppProvider";
import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import { Layout } from "widgets/Layout/Layout";
import {
  CoursePage,
  CreateGroupPage,
  UsersPage,
  GroupsInfoPage,
  GroupsPage,
  CreateTeacherPage,
  StudentPage,
  TeacherInfoPage,
  ProfilePage,
  NotFoundPage,
  ArchivesPage,
  ArchiveStudents,
  ArchiveTeachersPage,
  ArchiveGroups,
  CreateMentorPage,
  MentorsPage,
  MentorPage,
  CashierPreview,
  CashierDetailStudent,
  AnketaListPage,
  AnketaDetailPage,
  VideosPage,
} from "pages";
import CreateStudentPage from "pages/CreateStudentPage/CreateStudentPage";
import TeachersPage from "pages/TeachersPage/TeachersPage";
import { SchedulePage } from "pages/SchedulePage/SchedulePage";
import { ScheduleOneDay } from "pages/ScheduleOneDay/ScheduleOneDay";
import PrivateRoute from "../PrivateRoute/PrivateRoute";

export const router = createBrowserRouter(
  createRoutesFromElements(
    <Route
      path="/"
      element={
        <AppProvider>
          <Layout />
        </AppProvider>
      }
    >
      <Route index path="/curator/" element={<GroupsPage />} />
      <Route path="/curator/students" element={<UsersPage />} />
      <Route path="/curator/students/:id/:user_id" element={<StudentPage />} />
      <Route path="/curator/groups/:group_id/" element={<GroupsInfoPage />} />
      <Route path="/curator/profile" element={<ProfilePage />} />
      <Route path="/curator/mentors" element={<MentorsPage />} />
      <Route path="/curator/mentors/:student_id" element={<MentorPage />} />
      <Route path="/curator/mentors/create" element={<CreateMentorPage />} />

      <Route element={<PrivateRoute />}>
        <Route path="/curator/course" element={<CoursePage />} />
        <Route path="/curator/groups/create" element={<CreateGroupPage />} />
        <Route
          path="/curator/students/student"
          element={<CreateStudentPage />}
        />
        <Route
          path="/curator/teachers/create"
          element={<CreateTeacherPage />}
        />
        <Route path="/curator/teachers" element={<TeachersPage />} />
        <Route path="/curator/cashier" element={<CashierPreview />} />
        <Route
          path="/curator/cashier/student/:student_id/:module_id/:group_id"
          element={<CashierDetailStudent />}
        />
        <Route path="/curator/archives" element={<ArchivesPage />} />
        <Route
          path="/curator/archives/students"
          element={<ArchiveStudents />}
        />
        <Route path="/curator/archives/groups" element={<ArchiveGroups />} />
        <Route
          path="/curator/archives/students/:id/:user_id"
          element={<StudentPage isArchive={true} />}
        />

        <Route
          path="/curator/archives/teachers"
          element={<ArchiveTeachersPage />}
        />
        <Route
          path="/curator/teachers/:user_id/:teacher_id"
          element={<TeacherInfoPage />}
        />
        <Route path="/curator/schedule" element={<SchedulePage />} />
        <Route path="/curator/schedule/:date" element={<ScheduleOneDay />} />

        <Route path="/curator/anketa" element={<AnketaListPage />} />
        <Route path="/curator/anketa/:id/" element={<AnketaDetailPage />} />

        <Route path="/curator/videos" element={<VideosPage />} />
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Route>
  )
);

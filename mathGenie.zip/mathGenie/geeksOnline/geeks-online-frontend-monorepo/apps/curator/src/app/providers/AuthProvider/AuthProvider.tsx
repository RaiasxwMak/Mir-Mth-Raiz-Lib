import { ReactNode, useEffect } from "react";
import { useAuthProvider } from "./model/useAuthProvider";
import { cookie } from "shared/lib/cookie/cookie";
import {
  COOKIE_ACCESS_TOKEN_KEY,
  COOKIE_REFRESH_TOKEN_KEY,
} from "shared/lib/consts/consts";
import { useFetchProfile } from "entities/ProfileInfo/model/useFetchProfile";
import { useNavigate } from "react-router-dom";

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const { data } = useFetchProfile();
  const navigate = useNavigate();

  const login = useAuthProvider((state) => state.login);
  const logout = useAuthProvider((state) => state.logout);

  useEffect(() => {
    if (data?.user.is_teacher) {
      navigate("/");
      location.reload();
    }
    if (data?.user.is_student && !data?.user.is_supreme) {
      navigate("/");
      location.reload();
    }
  }, [data]);

  useEffect(() => {
    const token = cookie.getCookie(COOKIE_ACCESS_TOKEN_KEY);
    const refreshToken = cookie.getCookie(COOKIE_REFRESH_TOKEN_KEY);

    if (token || refreshToken) {
      login();
    } else {
      logout();
      // navigate("https://geeks-online.geekstudio.kg/");
    }
  }, []);

  return children;
};

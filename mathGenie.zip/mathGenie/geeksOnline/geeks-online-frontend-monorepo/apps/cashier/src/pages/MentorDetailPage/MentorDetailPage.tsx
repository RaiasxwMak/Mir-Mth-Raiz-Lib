import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import MentorDetail from "entities/MentorDetail/ui/MentorDetail";

const MentorDetailPage = () => {
  return (
    <>
      <UIFlexColumn gap={40}>
        <GetBack title={"Назад"} />
        <Typography variant="Title1">Гиккоины</Typography>
        <MentorDetail />
      </UIFlexColumn>
    </>
  );
};

export default MentorDetailPage;

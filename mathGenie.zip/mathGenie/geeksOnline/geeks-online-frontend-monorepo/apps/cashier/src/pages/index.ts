import { lazy } from "react";

const MainPage = lazy(() => import("./MainPage/MainPage"));
const NotFoundPage = lazy(() => import("./NotFoundPage/NotFoundPage"));
const DetailStudentPage = lazy(
  () => import("./DetailStudentPage/DetailStudentPage")
);
const CashierProfilePage = lazy(
  () => import("./CashierProfilePage/CashierProfilePage")
);
const PaymentsPage = lazy(() => import("./PaymentsPage/PaymentsPage"));

const GeeksShopPage = lazy(() => import("./GeeksShopPage/GeeksShopPage"));

export {
  MainPage,
  NotFoundPage,
  DetailStudentPage,
  CashierProfilePage,
  PaymentsPage,
  GeeksShopPage,
};

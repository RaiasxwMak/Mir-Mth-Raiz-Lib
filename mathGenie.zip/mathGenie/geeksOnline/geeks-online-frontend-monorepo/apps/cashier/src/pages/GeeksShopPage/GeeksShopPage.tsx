import {
  Loader,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { useGeeksShopHistory } from "entities/GeeksShopHistory/model/useGeeksShopHistory";
import GeeksShopHistory from "entities/GeeksShopHistory/ui/GeeksShopHistory/GeeksShopHistory";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";

const GeeksShopPage = () => {
  const { data, isLoading } = useGeeksShopHistory();

  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <Typography variant="Title1">{"Geeks Shop"}</Typography>
        <UIFlexBetween>
          <UIFlexRow gap={20}>
            <SearchInfo />
            <DateRangePicker />
          </UIFlexRow>
          {isLoading ? (
            <Loader small />
          ) : (
            <Typography variant="Body1" style={{ color: "#afafaf" }}>
              Итоговый общий счет :{" "}
              <span style={{ paddingLeft: 32 }}>{data?.total_count ?? 0}</span>
            </Typography>
          )}
        </UIFlexBetween>
      </UIFlexColumn>
      <GeeksShopHistory />
    </UIFlexColumn>
  );
};

export default GeeksShopPage;

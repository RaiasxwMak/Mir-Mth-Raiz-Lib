import { TabsCustom, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { TabsProps } from "antd";
import Debitorka from "entities/Debitorka/ui/Debitorka/Debitorka";
import DebitorkaGeeksPro from "entities/Debitorka/ui/DebitorkaGeeksPro/DebitorkaGeeksPro";
import StudentsWrap from "entities/StudentsList/ui/StudentsWrap/StudentsWrap";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useFilterSelect } from "features/FilterSelect/model/useFilterSelect";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";

const MainPage = () => {
  const [activeTab, setActiveTab] = useState("1");
  const [tabParam, setTabParam] = useSearchParams();
  const { resetInputSearch } = useSearchInfo();
  const { courseResetSelect } = useCoursesSelect();
  const { onClearFilterSelects } = useFilterSelect();
  const { selectedDatesReset } = useDateRangePicker();

  const handleChangeTab = (key: string): void => {
    setActiveTab(key);
    setTabParam({ tab: key }, { replace: true });
  };

  const tabItems: TabsProps["items"] = [
    {
      key: "1",
      label: "Студенты",
      children: <StudentsWrap />,
    },
    {
      key: "2",
      label: "Дебиторка",
      children: <Debitorka />,
    },
    {
      key: "3",
      label: "Дебиторка Geeks Pro",
      children: <DebitorkaGeeksPro />,
    },
  ];

  const resetFilters = () => {
    resetInputSearch();
    courseResetSelect();
    onClearFilterSelects();
    selectedDatesReset();
  };

  useEffect(() => {
    setActiveTab(tabParam.get("tab") ?? "1");
    resetFilters();
  }, [tabParam]);

  useEffect(() => {
    setTabParam({ tab: "1" }, { replace: true });
  }, []);
  return (
    <>
      <UIFlexColumn gap={40}>
        <Typography variant="Title1">Студенты</Typography>
        <TabsCustom
          activeKey={activeTab}
          onChange={handleChangeTab}
          items={tabItems}
        />
      </UIFlexColumn>
    </>
  );
};

export default MainPage;

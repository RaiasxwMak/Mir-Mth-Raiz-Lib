import { Typography, UIFlexColumn } from "@geeks-online/uikit";
import ProfileInfo from "entities/ProfileInfo/ui/ProfileInfo";

const CashierProfilePage = () => {
  return (
    <UIFlexColumn gap={20}>
      <Typography variant="Title1">Профиль кассира</Typography>
      <ProfileInfo />
    </UIFlexColumn>
  );
};

export default CashierProfilePage;

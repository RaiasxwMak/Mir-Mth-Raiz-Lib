import { TabsCustom, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { TabsProps } from "antd";
import GeekCoinsMentors from "entities/GeekCoinsMentors/ui/GeekCoinsMentors";
import GeekCoinMonitoring from "entities/GeekCoinsStats/ui/GeekCoinMonitoring";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";

const GeekcoinsPage = () => {
  const [activeTab, setActiveTab] = useState("1");
  const [tabParam, setTabParam] = useSearchParams();
  const { resetInputSearch } = useSearchInfo();
  const { courseResetSelect } = useCoursesSelect();
  const { selectedDatesReset } = useDateRangePicker();

  const handleChangeTab = (key: string): void => {
    setActiveTab(key);
    setTabParam({ tab: key }, { replace: true });
  };

  const tabItems: TabsProps["items"] = [
    {
      key: "1",
      label: "Cтатистика",
      children: <GeekCoinMonitoring />,
    },
    {
      key: "2",
      label: "Менторы",
      children: <GeekCoinsMentors />,
    },
  ];

  const resetFilters = () => {
    resetInputSearch();
    courseResetSelect();
    selectedDatesReset();
  };

  useEffect(() => {
    setActiveTab(tabParam.get("tab") ?? "1");
    resetFilters();
  }, [tabParam]);

  return (
    <>
      <UIFlexColumn gap={40}>
        <Typography variant="Title1">Гиккоины</Typography>
        <TabsCustom
          activeKey={activeTab}
          onChange={handleChangeTab}
          items={tabItems}
        />
      </UIFlexColumn>
    </>
  );
};

export default GeekcoinsPage;

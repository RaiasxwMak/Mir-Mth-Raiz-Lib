import { Loader, TabsCustom, UIFlexColumn } from "@geeks-online/uikit";
import { TabsProps } from "antd";
import CurrentMonthStudent from "entities/CurrentMonthStudent/ui/CurrentMonthStudent/CurrentMonthStudent";
import PaymentHistoryStudent from "entities/PaymentHistoryStudent/ui/PaymentHistoryStudent";
import { useFetchProfileStudent } from "entities/ProfileStudent/model/useFetchProfileStudent";
import ProfileStudent from "entities/ProfileStudent/ui/ProfileStudent";
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { GetBack } from "shared/ui/GetBack/GetBack";

const DetailStudentPage = () => {
  const [activeTab, setActiveTab] = useState("1");
  const [tabParam, setTabParam] = useSearchParams();

  const { data, isLoading } = useFetchProfileStudent();

  const handleChangeTab = (key: string): void => {
    setActiveTab(key);
    setTabParam({ tab: key }, { replace: true });
  };

  const tabItems: TabsProps["items"] = [
    {
      key: "1",
      label: "Профиль студента",
      children: <ProfileStudent data={data} isLoading={isLoading} />,
    },
    {
      key: "2",
      label: "Нынешний месяц",
      children: <CurrentMonthStudent />,
    },
    {
      key: "3",
      label: "Просмотр истории оплаты",
      children: <PaymentHistoryStudent />,
    },
  ];

  useEffect(() => {
    setActiveTab(tabParam.get("tab") ?? "1");
  }, [tabParam]);

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={40}>
      <GetBack />
      <TabsCustom
        activeKey={activeTab}
        onChange={handleChangeTab}
        items={tabItems}
      />
    </UIFlexColumn>
  );
};

export default DetailStudentPage;

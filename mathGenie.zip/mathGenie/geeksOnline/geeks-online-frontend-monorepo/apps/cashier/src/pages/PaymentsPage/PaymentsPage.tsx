import {
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { usePaymentList } from "entities/PaymentsList/model/usePaymentList";
import PaymentsListSelects from "entities/PaymentsList/ui/PaymentsListSelects/PaymentsListSelects";
import PaymentList from "entities/PaymentsList/ui/PaymentList/PaymentList";
import PaymentDocument from "entities/PaymentsList/ui/PaymentDocument/PaymentDocument";

const PaymentsPage = () => {
  const { data } = usePaymentList();
  return (
    <UIFlexColumn gap={12} justifyContent="space-between">
      <UIFlexColumn gap={20}>
        <Typography variant="Title1">{"Оплаты"}</Typography>
        <UIFlexBetween>
          <SearchInfo />
          <UIFlexRow gap={40}>
            <Typography variant="Body1" style={{ color: "#afafaf" }}>
              Общее количество :{" "}
              <span style={{ paddingLeft: 32 }}>{data?.count ?? 0}</span>
            </Typography>
            <Typography variant="Body1" style={{ color: "#afafaf" }}>
              Сумма оплат :{" "}
              <span style={{ paddingLeft: 32 }}>{data?.total_amount ?? 0}</span>
            </Typography>
          </UIFlexRow>
        </UIFlexBetween>
        <PaymentsListSelects />
      </UIFlexColumn>
      <UIFlexColumn gap={8}>
        <PaymentDocument />
        <PaymentList />
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default PaymentsPage;

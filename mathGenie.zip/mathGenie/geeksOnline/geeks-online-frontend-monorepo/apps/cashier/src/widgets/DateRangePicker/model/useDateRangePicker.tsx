import { create } from "zustand";
import { Dayjs } from "dayjs";

export type DateRange = [Dayjs | null, Dayjs | null];

interface IuseDateRangePicker {
  selectedDates: DateRange;
  setSelectedDates: (dates: DateRange) => void;
  selectedDatesReset: () => void;

  selectedDatesByTab: Record<string, DateRange>;
  setSelectedDatesByTab: (dates: DateRange, tab: string) => void;
  selectedDatesResetByTab: (tab?: string) => void;
  getSelectedDatesForTab: (tab: string) => DateRange;
}

const DEFAULT_TAB = "default";

export const useDateRangePicker = create<IuseDateRangePicker>((set, get) => ({
  selectedDates: [null, null],

  selectedDatesByTab: {},

  setSelectedDates: (param) => {
    set({ selectedDates: param });
  },

  selectedDatesReset: () => {
    set({ selectedDates: [null, null] });
  },

  setSelectedDatesByTab: (param, tab) => {
    set((state) => ({
      selectedDatesByTab: {
        ...state.selectedDatesByTab,
        [tab]: param,
      },
      ...(tab === DEFAULT_TAB ? { selectedDates: param } : {}),
    }));
  },

  selectedDatesResetByTab: (tab) => {
    if (tab) {
      set((state) => ({
        selectedDatesByTab: {
          ...state.selectedDatesByTab,
          [tab]: [null, null],
        },
        ...(tab === DEFAULT_TAB ? { selectedDates: [null, null] } : {}),
      }));
    } else {
      set({
        selectedDatesByTab: {},
        selectedDates: [null, null],
      });
    }
  },

  getSelectedDatesForTab: (tab) => {
    const dates = get().selectedDatesByTab[tab];
    return dates ? [dates[0], dates[1]] : [null, null];
  },
}));

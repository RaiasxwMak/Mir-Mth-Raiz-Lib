import { EmptyState, Loader } from "@geeks-online/uikit";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  LinearScale,
  Title,
  CategoryScale,
  Tooltip,
  Legend,
} from "chart.js";
import type { ChartData, ChartDataset, ChartOptions, Point } from "chart.js";
import cls from "./LineChart.module.scss";
import { IStats } from "shared/globalTypes/globalTypes";
import { useEffect, useState, useCallback, useRef } from "react";
import { ILineCharts } from "widgets/StatisticsLineChart/type/statisticsChartsType";
import StatsFilter from "shared/ui/StatsFilter/StatsFilter";

ChartJS.register(
  LineElement,
  PointElement,
  LinearScale,
  Title,
  CategoryScale,
  Tooltip,
  Legend
);

interface Props {
  data: ILineCharts | null;
  loading: boolean;
  handleFilter: (param: string) => void;
  chartData?: ChartData<"line", (number | Point | null)[], unknown> | null;
  selectedDates?: [any, any] | null;
}

export const LineChart: React.FC<Props> = ({
  data,
  loading,
  handleFilter,
  chartData,
  selectedDates,
}) => {
  const [isResetChecked, setIsResetChecked] = useState(false);
  const previousResetState = useRef<boolean>(isResetChecked);
  const previousDates = useRef<string>("");
  const stableHandleFilter = useCallback(handleFilter, []);

  useEffect(() => {
    if (selectedDates && selectedDates[0] && selectedDates[1]) {
      const currentDatesKey = `${
        selectedDates[0].format?.("YYYY-MM-DD") || selectedDates[0]
      }_${selectedDates[1].format?.("YYYY-MM-DD") || selectedDates[1]}`;

      if (
        previousDates.current &&
        previousDates.current !== currentDatesKey &&
        isResetChecked
      ) {
        setIsResetChecked(false);
      }

      previousDates.current = currentDatesKey;
    }
  }, [selectedDates, isResetChecked]);

  const transformChartDataToStats = useCallback(
    (datasets: ChartDataset<"line", (number | Point | null)[]>[]): IStats[] => {
      return datasets.map((dataset) => {
        const values = dataset.data.filter(
          (v): v is number => typeof v === "number"
        );
        const total = values.reduce((sum, val) => sum + val, 0);

        return {
          type: (dataset as any).customType || dataset.label || "Без названия",
          color:
            typeof dataset.borderColor === "string"
              ? dataset.borderColor
              : "#000",
          value: total,
          originalValue: total,
          id: dataset.label || crypto.randomUUID(),
        };
      });
    },
    []
  );

  useEffect(() => {
    if (previousResetState.current !== isResetChecked) {
      previousResetState.current = isResetChecked;
      stableHandleFilter(isResetChecked ? "reset" : "show");
    }
  }, [isResetChecked, stableHandleFilter]);

  if (!data) return null;

  const chartOptions: ChartOptions<"line"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "bottom" as const,
        display: false,
        labels: {
          color: "#fff",
          boxWidth: 20,
          boxHeight: 8,
          padding: 25,
          textAlign: "center",
        },
      },
    },
    scales: {
      x: {
        ticks: {
          color: "#fff",
          maxRotation: 0,
          minRotation: 0,
        },
        grid: {
          color: "#444",
          drawOnChartArea: false,
        },
      },
      y: {
        ticks: {
          stepSize: 20,
          color: "#fff",
        },
        grid: {
          drawOnChartArea: true,
          color: "#D2D5DA",
          lineWidth: 1,
        },
      },
    },
    elements: {
      point: {
        radius: 0,
        hitRadius: 0,
        hoverRadius: 6,
      },
    },
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : chartData?.labels?.length ? (
        <>
          <div className={cls.lineChart}>
            <Line data={chartData} options={chartOptions} />
          </div>
          <StatsFilter
            data={transformChartDataToStats(chartData?.datasets || [])}
            handleFilter={stableHandleFilter}
            splitToColumns
            itemsPerColumn={5}
            hideValue
          />
        </>
      ) : (
        <EmptyState text={"Здесь пока ничего нет"} />
      )}
    </>
  );
};

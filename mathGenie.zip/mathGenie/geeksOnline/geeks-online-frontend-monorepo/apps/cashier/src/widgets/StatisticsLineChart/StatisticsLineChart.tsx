import { useEffect, useCallback, useRef } from "react";
import { useSelectedPeriod } from "widgets/LineChart/model/useSelectedPeriod";
import { useDateChangeSource } from "widgets/DateRangePicker/model/useDateChangeSource";
import {
  useDateRangePicker,
  DateRange,
} from "widgets/DateRangePicker/model/useDateRangePicker";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";
import dayjs from "dayjs";
import { CustomSelect, IOption, UIFlexRow } from "@geeks-online/uikit";
import cls from "./StatisticsLineChart.module.scss";
import { PERIOD_OPTION } from "shared/lib/consts/consts";
import { useStatisticsCharts } from "./model/useStatisticsCharts";
import { LineChart } from "widgets/LineChart/LineChart";

interface StatisticsLineChartProps {
  tab: string;
}

const StatisticsLineChart = ({ tab }: StatisticsLineChartProps) => {
  const {
    getStatistics,
    statisticsChartData,
    dataLoading: tatisticsChartLoading,
    handleFilter: handleStatisticsChart,
    getChartDataForTab,
  } = useStatisticsCharts();

  const { setSelectedDates, setSelectedDatesByTab } = useDateRangePicker();
  const selectedDates = useDateRangePicker(
    (state) => state.selectedDatesByTab[tab] || [null, null]
  );

  const { setSelectedPeriod } = useSelectedPeriod();
  const selectedPeriod = useSelectedPeriod(
    (state) => state.selectedPeriodByTab[tab] || null
  );

  const { isUserAction, setIsUserAction } = useDateChangeSource();

  const chartData = getChartDataForTab(tab);

  const isComponentMounted = useRef(false);
  const isInitialized = useRef(false);
  const lastRequestParams = useRef<string>("");

  const handleFilterWithTab = useCallback(
    (param: string) => {
      handleStatisticsChart(param, tab);
    },
    [handleStatisticsChart, tab]
  );

  const handleChange = useCallback(
    (val: IOption) => {
      setSelectedPeriod(val, tab);
      const months = Number(val.value);
      const newDates: DateRange = [dayjs().subtract(months, "month"), dayjs()];
      setIsUserAction(true);
      setSelectedDatesByTab(newDates, tab);
    },
    [setSelectedPeriod, setSelectedDates, setIsUserAction, tab]
  );

  useEffect(() => {
    if (!isComponentMounted.current) {
      isComponentMounted.current = true;
      const hasExistingDates =
        selectedDates && selectedDates.some((date) => date !== null);
      if (!hasExistingDates) {
        const defaultDates: DateRange = [dayjs().subtract(1, "month"), dayjs()];
        setSelectedDatesByTab(defaultDates, tab);
        return;
      }
    }

    const hasValidDates =
      selectedDates &&
      selectedDates.length === 2 &&
      selectedDates[0] &&
      selectedDates[1];

    if (!hasValidDates) {
      return;
    }

    const requestKey = `${selectedDates[0]!.format(
      "YYYY-MM-DD"
    )}_${selectedDates[1]!.format("YYYY-MM-DD")}_${tab}`;
    const cacheKey = `${selectedDates[0]!.format(
      "YYYY-MM-DD"
    )}_${selectedDates[1]!.format("YYYY-MM-DD")}`;

    if (lastRequestParams.current === requestKey) {
      return;
    }

    const existingData = getChartDataForTab(tab);
    if (existingData && (existingData as any).cacheKey === cacheKey) {
      lastRequestParams.current = requestKey;
      return;
    }
    lastRequestParams.current = requestKey;

    getStatistics(
      {
        start_date: selectedDates[0]!.format("YYYY-MM-DD"),
        end_date: selectedDates[1]!.format("YYYY-MM-DD"),
      },
      tab
    );

    if (isUserAction) {
      setIsUserAction(false);
    }
  }, [
    selectedDates,
    tab,
    getStatistics,
    getChartDataForTab,
    setSelectedDates,
    isUserAction,
    setIsUserAction,
  ]);

  useEffect(() => {
    return () => {
      isComponentMounted.current = false;
      isInitialized.current = false;
      lastRequestParams.current = "";
    };
  }, []);
  return (
    <div className={cls.wrap}>
      <UIFlexRow justifyContent="end" gap={20}>
        <CustomSelect
          isArrow
          width={"256px"}
          onChange={handleChange}
          value={selectedPeriod}
          options={PERIOD_OPTION}
          height={"40px"}
          placeholder={"Выберите период"}
        />
        <DateRangePicker
          placeholder={["Выберите", "дату"]}
          width="220px"
          tab={tab}
        />
      </UIFlexRow>
      <LineChart
        data={statisticsChartData}
        loading={tatisticsChartLoading}
        handleFilter={handleFilterWithTab}
        chartData={chartData}
        selectedDates={selectedDates}
      />
    </div>
  );
};

export default StatisticsLineChart;

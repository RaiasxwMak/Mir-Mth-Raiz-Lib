import { FC, useRef, useState, ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import cls from "./Sidebar.module.scss";
import { ButtonNavLink } from "shared/ui";
import GeeksLogo from "shared/assets/icon/geeksLogo.svg?react";
import MainSvg from "shared/assets/icon/student.svg?react";
import PaymentSvg from "shared/assets/icon/payment.svg?react";
import Geeks from "shared/assets/icon/geeks.svg?react";
import GeeksShopSvg from "shared/assets/icon/busket.svg?react";
import GeekcoinSvg from "shared/assets/icon/geekcoinSidebar.svg?react";
import OpenClose from "shared/assets/icon/open-close.svg?react";
import classNames from "classnames";
import { Button, TooltipWrapper, Typography } from "@geeks-online/uikit";
import { scrollTop } from "@geeks-online/shared";

interface SidebarProps {
  className?: string;
}

interface LinksItems {
  title: string;
  to: string;
  Icon: ReactNode;
}

const ANIMATION_OPENCLOSE_DELAY = 100;

export const Sidebar: FC<SidebarProps> = ({ className = "" }) => {
  const [collapsed, setCollapsed] = useState<boolean>(true);
  const navigate = useNavigate();
  const closeRef = useRef<null | ReturnType<typeof setTimeout>>(null);

  const handleChangeCollapse = (): void => {
    if (closeRef.current) {
      clearTimeout(closeRef.current);
    }
    closeRef.current = setTimeout(() => {
      setCollapsed((prev) => !prev);
    }, ANIMATION_OPENCLOSE_DELAY);
  };

  const links: LinksItems[] = [
    {
      title: "Студенты",
      to: "/cashier/",
      Icon: <MainSvg />,
    },
    {
      title: "Оплаты",
      to: "/cashier/payments",
      Icon: <PaymentSvg />,
    },
    {
      title: "Geeks Shop",
      to: "/cashier/geekshop",
      Icon: <GeeksShopSvg />,
    },
    {
      title: "Гиккоины",
      to: "/cashier/geekcoins",
      Icon: <GeekcoinSvg />,
    },
  ];

  return (
    <div className={cls.centerSidebar}>
      <div
        onClick={handleChangeCollapse}
        className={classNames(
          cls.sidebar,
          { [cls.collapsed]: collapsed },
          className
        )}
      >
        <div
          className={cls.logo}
          onClick={(e): void => {
            e.stopPropagation();
            navigate("/cashier/");
            scrollTop();
          }}
        >
          <Geeks className={cls.title} />
          <GeeksLogo className={cls.iconLogo} />
        </div>
        <div className={cls.links}>
          {links.map((elm: LinksItems, i) => (
            <ButtonNavLink
              tooltip={!collapsed}
              key={i}
              Icon={elm.Icon}
              to={elm.to}
              className={cls.buttonlink}
            >
              {elm.title}
            </ButtonNavLink>
          ))}
          <TooltipWrapper title={"Открыть"} show={!collapsed}>
            <Button
              className={classNames(
                cls.iconButton,
                { [cls.iconRotate]: !collapsed },
                []
              )}
            >
              <OpenClose />
              <Typography className={cls.iconTitle} variant="Body1">
                Закрыть
              </Typography>
            </Button>
          </TooltipWrapper>
        </div>
      </div>
    </div>
  );
};

import { ConfigProvider, DatePicker } from "antd";
import { useEffect } from "react";
import { DateRange, useDateRangePicker } from "../model/useDateRangePicker";
import { CalendarOutlined, CloseCircleOutlined } from "@ant-design/icons";
import cls from "./DateRangePicker.module.scss";
import ru from "antd/lib/locale/ru_RU";
import { useDateChangeSource } from "../model/useDateChangeSource";
import { Dayjs } from "dayjs";
import { useSelectedPeriod } from "widgets/LineChart/model/useSelectedPeriod";

const { RangePicker } = DatePicker;

const antdConfig: any = {
  components: {
    DatePicker: {
      hoverBg: "transparent",
      hoverBorderColor: "inherit",
      cellActiveWithRangeBg: "#ffe743",
      activeBg: "transparent",
    },
  },
  token: {
    colorPrimary: "transparent",
    colorBgBase: "transparent",
    colorBorder: "#a7a7a7",
    colorText: "#fff",
    colorTextPlaceholder: "#FFFFFFB2",
    colorBgElevated: "#1E1E22",
    controlItemBgActive: "#0097FF",
    colorIcon: "#ffff",
  },
};

interface DateRangePickerProps {
  placeholder?: [string, string];
  width?: string;
  tab?: string;
  periodValue?: DateRange;
  onChangePeriod?: (param: DateRange) => void;
}

const DateRangePicker = ({
  placeholder = ["Выберите", "период"],
  width,
  tab,
  periodValue,
  onChangePeriod,
}: DateRangePickerProps) => {
  const {
    selectedDates,
    setSelectedDates,
    selectedDatesReset,
    setSelectedDatesByTab,
    getSelectedDatesForTab,
  } = useDateRangePicker();
  const { selectedPeriodReset } = useSelectedPeriod();
  const { setIsUserAction } = useDateChangeSource();
  const currentSelectedDates = tab
    ? getSelectedDatesForTab(tab)
    : selectedDates;

  const rangePickerValue: [Dayjs | null, Dayjs | null] = periodValue
    ? [periodValue[0], periodValue[1]]
    : [currentSelectedDates[0] || null, currentSelectedDates[1] || null];

  useEffect(() => {
    return () => {
      if (!tab) {
        selectedDatesReset();
      }
    };
  }, [tab, selectedDatesReset]);

  const handleDateChange = (dates: [Dayjs | null, Dayjs | null] | null) => {
    setIsUserAction(true);
    const dateRange: DateRange = [dates?.[0] || null, dates?.[1] || null];
    if (onChangePeriod) {
      return onChangePeriod(dateRange);
    }
    if (tab) {
      setSelectedDatesByTab(dateRange, tab);
      selectedPeriodReset(tab);
    } else {
      setSelectedDates(dateRange);
    }
  };

  return (
    <ConfigProvider locale={ru} theme={antdConfig}>
      <div style={{ width: width || 200 }}>
        <RangePicker
          placeholder={placeholder}
          placement="bottomLeft"
          value={rangePickerValue}
          format={"DD.MM.YYYY"}
          clearIcon={<CloseCircleOutlined style={{ color: "#fff" }} />}
          suffixIcon={<CalendarOutlined style={{ color: "#fff" }} />}
          separator={false}
          onChange={handleDateChange}
          className={cls.date}
        />
      </div>
    </ConfigProvider>
  );
};

export default DateRangePicker;

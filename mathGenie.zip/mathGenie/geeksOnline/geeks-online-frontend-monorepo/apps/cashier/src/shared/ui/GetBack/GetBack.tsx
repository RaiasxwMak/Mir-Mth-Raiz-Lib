import { useNavigate } from "react-router-dom";
import IconLeft from "shared/assets/icon/arrowLeft.svg?react";
import { Typography, UIFlexRow } from "@geeks-online/uikit";
interface GetBackProps {
  title?: string;
  defaultUrl?: string;
}

export const GetBack = ({ title, defaultUrl }: GetBackProps) => {
  const navigate = useNavigate();

  const onBack = () => {
    if (defaultUrl) navigate(defaultUrl);
    else navigate(-1);
  };

  return (
    <UIFlexRow
      style={{
        alignItems: "center",
        gap: "4px",
        cursor: "pointer",
        padding: "8px 16px 8px 0",
        width: "max-content",
        transform: "translateX(-5px)",
      }}
      onClick={onBack}
    >
      <IconLeft />
      <Typography variant="Body4">{title || "Назад"}</Typography>
    </UIFlexRow>
  );
};

import { CloseOutlined } from "@ant-design/icons";
import { AutoComplete } from "antd";
import classNames from "classnames";
import { useEffect, useState } from "react";
import cls from "./AutocompleteSelector.module.scss";
import useDebounce from "shared/lib/useDebounce/useDebounce";
import { Loader } from "@geeks-online/uikit";

export interface IDefaultValueSelect {
  value: string;
  label?: string;
  selectedOption?: any;
}
export interface AutocompleteSelectorProps {
  className?: string[];
  placeholder?: string;
  value?: string;
  error?: boolean;
  onChange?: (value: string, option: any) => void;
  fetchBySearch?: (value: string) => Promise<any>;
  getOptionLabel?: (option: any) => any;
  getOptionValue?: (option: any) => any;
  disabled?: boolean;
  keysDeps?: unknown[];
  height?: string;
}

export const AutocompleteSelector = ({
  className,
  placeholder,
  value = "",
  error,
  onChange,
  fetchBySearch,
  getOptionLabel,
  getOptionValue,
  disabled,
  keysDeps = [],
  height,
}: AutocompleteSelectorProps) => {
  const [options, setOptions] = useState<{ value: string; label: string }[]>(
    []
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const dbCb = useDebounce(async () => {
    if (!fetchBySearch) return;
    setIsLoading(true);
    try {
      const res = await fetchBySearch(value);
      setOptions(
        res.map((elm: any) => ({
          label: getOptionLabel?.(elm) || elm.label,
          value: getOptionValue?.(elm) || elm.value,
        }))
      );
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
    }
  }, 400);

  const onChangeAutocomplete = (value: string, option: any) => {
    if (onChange) onChange(value, option);
  };

  useEffect(() => {
    if (fetchBySearch || keysDeps) {
      dbCb();
    }
  }, [value, ...keysDeps]);

  return (
    <AutoComplete
      className={classNames("", [cls.mySelect, ...(className || [])], {
        [cls.error]: error,
        [cls.disabled]: disabled,
      })}
      options={isLoading ? [] : options}
      value={value}
      popupClassName={classNames("", [cls.optionWrapper, cls.popupStyles])}
      onChange={onChangeAutocomplete}
      style={{ width: 200, alignItems: "center", height }}
      placeholder={placeholder || "Введите"}
      allowClear={{
        clearIcon: isLoading ? (
          <Loader small />
        ) : (
          <CloseOutlined style={{ background: "transperent" }} />
        ),
      }}
      disabled={disabled}
      notFoundContent={isLoading ? <Loader small /> : "Нет результатов"}
    />
  );
};

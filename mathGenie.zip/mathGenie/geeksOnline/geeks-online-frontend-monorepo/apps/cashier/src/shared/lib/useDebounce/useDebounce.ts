import { useCallback, useRef } from "react";

type callBackArg = any;

const useDebounce = (
  callBack: (...arg: callBackArg) => void,
  delay: number
) => {
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const debouncedCB = useCallback(
    (...args: callBackArg) => {
      if (timer.current) {
        clearTimeout(timer.current);
      }
      timer.current = setTimeout(() => {
        callBack(...args);
      }, delay);
    },
    [callBack, delay]
  );

  return debouncedCB;
};

export default useDebounce;

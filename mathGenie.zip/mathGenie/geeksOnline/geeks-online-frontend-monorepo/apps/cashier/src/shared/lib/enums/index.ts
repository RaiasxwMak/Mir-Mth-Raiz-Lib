export const PaymentWays = {
  monthly: "monthly",
  fixed: "fixed",
  full: "full",
} as const;

export type PaymentWaysType = (typeof PaymentWays)[keyof typeof PaymentWays];

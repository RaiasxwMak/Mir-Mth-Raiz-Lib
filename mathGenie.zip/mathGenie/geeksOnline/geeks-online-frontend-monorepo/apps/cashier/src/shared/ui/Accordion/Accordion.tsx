import { Collapse } from "antd";
import { FC, ReactNode } from "react";
import AccordionSvg from "shared/assets/icon/Accordion.svg?react";
import cls from "./Accordion.module.scss";
import classNames from "classnames";

export interface IItemCollapse {
  label: ReactNode;
  key: string;
  children: ReactNode;
}

interface IAccordion {
  items: IItemCollapse[];
  className?: string;
  isTable?: boolean;
  onChange?: (key: string | string[]) => void;
}

const Accordion: FC<IAccordion> = ({
  items,
  className = "",
  isTable = false,
  onChange,
}) => {
  return (
    <div>
      <Collapse
        expandIcon={AccordionSvg}
        rootClassName={classNames(cls.root, className, {
          [cls.table]: isTable,
        })}
        onChange={onChange}
        expandIconPosition="end"
        items={items}
        accordion
      />
    </div>
  );
};

export default Accordion;

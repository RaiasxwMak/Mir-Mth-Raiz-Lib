import { Checkbox } from "antd";
import cls from "./CustomCheckbox.module.scss";
import { FC } from "react";
import { Typography } from "@geeks-online/uikit";
import { useCheckbox } from "./model/useCheckbox";

interface ICheckBox {
  value: string | number;
  label: string;
}

const CustomCheckbox: FC<ICheckBox> = ({ value, label }) => {
  const { selectedValues, toggleValue } = useCheckbox();
  const checked = selectedValues.includes(value);

  const handleChange = () => {
    toggleValue(value);
  };

  return (
    <Checkbox
      onChange={handleChange}
      checked={checked}
      className={cls.check}
      value={value}
    >
      <Typography variant="Text2_bold">{label}</Typography>
    </Checkbox>
  );
};

export default CustomCheckbox;

import classNames from "classnames";
import cls from "./Button.module.scss";
import {
  ButtonHTMLAttributes,
  FC,
  FunctionComponent,
  ReactNode,
  SVGAttributes,
} from "react";
import BtnPlus from "shared/assets/icon/btnPlus.svg?react";
import { Loader } from "@geeks-online/uikit";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  className?: string;
  children?: ReactNode;
  theme?: ThemeButton;
  width?: number | string;
  height?: number | string;
  Icon?: FunctionComponent<SVGAttributes<SVGAElement>>;
  plus?: boolean;
  isLoading?: boolean;
}

export enum ThemeButton {
  bright = "bright",
  primary = "primary",
  outline_bright = "outline_bright",
  outline = "outline",
  contained = "contained",
  simple = "simple",
  disabled = "disabled",
  disableClickable = "disable_clickable",
  not_bordered = "not_bordered",
  bordered = "bordered",
}

const Button: FC<ButtonProps> = ({
  className = "",
  theme = ThemeButton.primary,
  children,
  width,
  height,
  plus,
  Icon,
  isLoading,
  ...otherProps
}) => {
  return (
    <button
      className={classNames(cls.button, {}, [cls[theme], className])}
      {...otherProps}
      style={{ width, height }}
      disabled={ThemeButton.disabled === theme}
    >
      {isLoading ? <Loader small /> : children} {plus && <BtnPlus />}
      {Icon && <Icon className={cls.icon} />}
    </button>
  );
};

export default Button;

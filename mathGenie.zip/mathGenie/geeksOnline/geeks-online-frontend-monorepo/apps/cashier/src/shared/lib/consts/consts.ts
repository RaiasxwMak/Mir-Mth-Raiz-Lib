import { cookie } from "../cookie/cookie";
import { IUser } from "./authSchema";

export const BASE_URL = import.meta.env.VITE_APP_BASE_URL;
export const BASE_URL_PAYMENT = import.meta.env.VITE_APP_BASE_URL_PAYMENT;

export const COOKIE_USER_KEY = "user";
export const COOKIE_ACCESS_TOKEN_KEY = "access_token";
export const COOKIE_REFRESH_TOKEN_KEY = "refresh_token";
export const COOKIE_TOKEN_TYPE_KEY = "token_type";
export const COOKIE_GROUP_KEY = "group";
export const COOKIE_USER_ROLE = "role";
export const COOKIE_DEFAULT_GROUP = "default_groups";

export const User: IUser | null = JSON.parse(
  cookie.getCookie(COOKIE_USER_KEY) ?? "null"
);

export const teacherStatus = {
  past: "Прошедший",
  current: "Нынешний",
  future: "Будущий",
  none: "-",
};

export type teacherStatusType = keyof typeof teacherStatus;

export type studentStatusType = "Активный" | "Пауза" | "Выпускник" | "Отказ";

export const selectsHeight = "40px";

export const CALENDAR_HOURS: string[] = [
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
];

export const formatMonthTime = "DD.MM.YYYY HH:mm";
export const formatToSend = "YYYY-MM-DD HH:mm";
export const formatToSendMonth = "YYYY-MM-DD";
export const formatMonth = "DD.MM.YYYY";

export const helperTextPassword = "Введите не менее 5 символов (цифры ,буквы)";
export const TextFailPasswordLength =
  "Пароль должен содержать не менее 5 символов.";
export const TextFailNotSame = "Пароли не совпадают";

export const failTextInput = "Заполните все обязательные поля";

export const failEmpty = "Заполните пустые поля";

export type TestType = "Тест №1" | "Тест №2";

export const testTypes: TestType[] = ["Тест №1", "Тест №2"];

export type repeatStatus = "Бесплатный повтор" | "Платный повтор" | "Дальше";

export const PaidMonthsConst = {
  true: "Оплаченный",
  false: "Неоплаченный",
};

export const failStatusCode = "alredyHasActive";

export const failDate = "Некорректная дата";

export const alreadyInCourse = "Current student already in this course";

export const alreadySupremeHasBeenMentor =
  "Supreme-Mentor for this course already exists";

export const alreadySupremeMentor = "Старший ментор уже выбран";

export const MentoromonthsError =
  "Cannot asign some months for this mentor, Seem like you sent month that not avaliable for this student";

export const MentromonthsErrorText = "Этот месяц недоступен для студента";

export const alreadyInGroup =
  "Student already exists in this group and in this module";

export const alreadyMentorError = "Mentor for this student already exists";

export const alreadyMentorText = "Данный ментор уже существует";

export const dateError: Record<string | number, string> = {
  400: "Не правильный формат даты",
  500: "Ошибка",
  [failStatusCode]: "Ученик уже учится в этом направлении",
};

export const PERIOD_OPTION = [
  { label: "1 месяц", value: "1" },
  { label: "3 месяца", value: "3" },
  { label: "6 месяцев", value: "6" },
  { label: "12 месяцев", value: "12" },
];

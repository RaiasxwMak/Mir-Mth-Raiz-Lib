import cls from './ButtonBack.module.scss';
import { useNavigate } from 'react-router-dom';
import ArrowBack  from 'shared/assets/icon/arrowBack.svg';
import { FC, ReactNode } from 'react';


interface IButtonBackProps {
  goBackWithPrompt?: () => void;
  children: ReactNode;
}



const ButtonBack:FC<IButtonBackProps> = ({ goBackWithPrompt, children }) => {
  const navigate = useNavigate();
  const handleClickGoBack = ():void => {
    if (goBackWithPrompt) return goBackWithPrompt();
    navigate(-1);
  };
  return (
    <button onClick={handleClickGoBack}
      className={cls.button }
    >
      <img src={ArrowBack} alt="" />
      <span>
        {children}
      </span>
    </button>
  );
};

export default ButtonBack

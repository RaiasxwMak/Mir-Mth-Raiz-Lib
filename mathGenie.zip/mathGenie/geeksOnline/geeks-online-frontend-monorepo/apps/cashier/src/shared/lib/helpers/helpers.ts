import dayjs from "dayjs";
import { ReactNode } from "react";
import { formatMonth } from "../consts/consts";

export const formatDate = (dateTimeString: string | undefined) => {
  if (!dateTimeString) return null;
  const time = dayjs(dateTimeString).format("HH:mm");
  return time;
};

export const gmailRegex = /^[a-zA-Zа-яА-Я0-9._%+-]+@gmail\.com$/;
export const telegramRegex = /^@[a-zA-Z0-9._%+-]+$/;
export const onlyTextRegex = /^[A-Za-zа-яА-ЯӨөҢңҮү()\s]*$/;

export const handleStrSlice = (str: string) => {
  const splitted = str.split(" ");
  if (splitted.length > 3) return splitted.slice(0, 2).join(" ");
  return splitted;
};

export const handlePhoneFormat = (formattedNumber: string): string => {
  return formattedNumber.replace(/\D/g, "");
};

export const getGroupTitle = (text: string): string =>
  text.match(/(группы:\s)\s?([\w\d-]+)/)?.[2] ?? text;

export const getMonthNumber = (text: string) =>
  text?.match(/(№(\d+))/)?.[0]?.slice(1) ?? text;

export const formatDateMonth = (date: string) => {
  const formatted = dayjs(String(date), formatMonth, true);
  if (!formatted.isValid()) {
    return;
  }
  return formatted.format("YYYY-MM-DD");
};

export const formatTimetoTime = (timeRange: string) => {
  const times = timeRange.split(" - ");

  if (times.length !== 2) {
    return;
  }

  const isValidTime = (time: string) => {
    const [hours, minutes] = time.split(":").map(Number);
    return hours >= 0 && hours < 24 && minutes >= 0 && minutes < 60;
  };

  if (!isValidTime(times[0]) || !isValidTime(times[1])) {
    return;
  }

  const startTime = dayjs(times[0], "HH:mm", true);
  const endTime = dayjs(times[1], "HH:mm", true);

  if (!startTime.isValid() || !endTime.isValid()) {
    return;
  }
  if (endTime.isBefore(startTime)) {
    return;
  }

  return `${startTime.format("HH:mm")} - ${endTime.format("HH:mm")}`;
};

export const getFormatDateMonth = (date: string | undefined | null) =>
  date ? dayjs(date).format(formatMonth) : "-";

const regExpGetExtra = /Доп\. Урок/;
export const getLessonNumber = (text: string): string | undefined => {
  const extraLesson = text.match(regExpGetExtra);
  if (extraLesson?.[0]) return extraLesson[0];
  return text.match(/(\d+)/) ? text.match(/(\d+)/)?.[0] : text;
};

export const standupRegex =
  /(?:Что сделал:|Проблемы:|Что буду делать:)\s*([^\n\r]+)(?:\n|\r|$)/g;

interface standup {
  whatIDid?: string;
  problems?: string;
  willDo?: string;
}

export const regexpStandUpCut = (text?: string): standup => {
  const matches = [];
  let match;
  while ((match = standupRegex.exec(text ?? "")) !== null) {
    matches.push(match[1].trim());
  }
  return {
    whatIDid: matches[0] ?? "",
    problems: matches[1] ?? "",
    willDo: matches[2] ?? "",
  };
};

export const formatRepeatStatus = (status: ReactNode | string) => {
  if (status === "Дальше" || status === "закончен" || status === "Закончен")
    return;
  return status;
};

export const maskInputDate = "99.99.9999";

export const handleSliceText = (
  text: string,
  startSlice: number,
  endSlice: number
): string => {
  if (text.length > endSlice) {
    return text.slice(startSlice, endSlice) + "...";
  }
  return text;
};

export const handleDownload = (data: any, fileName: string) => {
  const urlBlob = window.URL.createObjectURL(data);
  const a = document.createElement("a");
  a.style.display = "none";
  a.href = urlBlob;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(urlBlob);
  document.body.removeChild(a);
};

export const generateColor = (index: number): string => {
  const randomColor = (index * 1234567) % 0xffffff;
  return `#${randomColor.toString(16).padStart(6, "0").toUpperCase()}`;
};

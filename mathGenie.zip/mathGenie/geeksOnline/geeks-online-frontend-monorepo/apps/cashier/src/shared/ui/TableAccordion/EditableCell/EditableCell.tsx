import { useEffect, useState } from "react";
import { AsyncInput, IOption, SelectAsync } from "@geeks-online/uikit";

interface EditableCellProps {
  title: React.ReactNode;
  editable: boolean;
  children: React.ReactNode;
  dataIndex: keyof any;
  record: any;
  type: string;
  options: any[];
  onSave: (record: any, newValue: unknown) => Promise<any>;
}

export const EditableCell: React.FC<EditableCellProps> = ({
  title,
  editable,
  children,
  dataIndex,
  record,
  type,
  onSave,
  options,
  ...restProps
}) => {
  const save = async (value: unknown) => {
    return await onSave(record, value);
  };

  const editableCell = record?.editableCell === false ? false : true;
  const [valueSelect, setValueSelect] = useState<IOption | null>(null);

  useEffect(() => {
    setValueSelect(
      record?.[dataIndex]
        ? { label: record[dataIndex], value: record[dataIndex] }
        : null
    );
  }, [record?.[dataIndex]]);

  const handleChangeSelect = (param: IOption | null) => {
    setValueSelect(param);
  };
  if (type === "select" && editableCell) {
    return (
      <td {...restProps}>
        <SelectAsync
          valueData={valueSelect}
          onChange={handleChangeSelect}
          options={options}
          placeholder="Выберите значение"
          asyncSelect={save}
          width="100%"
          height="41px"
        />
      </td>
    );
  }

  return (
    <td {...restProps}>
      {editable && editableCell ? (
        <AsyncInput
          value={record[dataIndex]}
          asyncCallBack={save}
          style={{ width: "100%", background: "transparent" }}
          fullWidth
          width={"100%"}
          height="41px"
        />
      ) : (
        children
      )}
    </td>
  );
};

import { Typography } from "@geeks-online/uikit";
import cls from "./TooltipWrapper.module.scss";
import { Tooltip } from "antd";
import { FC, ReactNode, useState } from "react";

interface ITooltipWrapperProps {
  title: string | ReactNode;
  children: ReactNode;
  show: boolean;
  isDark?: boolean;
  caption?: boolean;
  captionText?: string;
}

const TooltipWrapper: FC<ITooltipWrapperProps> = ({
  title,
  children,
  show,
  isDark,
  caption,
}) => {
  const placeMent = isDark ? "bottomRight" : "right";
  const color = isDark ? "#141618" : "#FFE743";
  const classNameColor = isDark ? cls.tooltipWhite : cls.tooltip;

  const [isShow, setIsShow] = useState(false);

  if (caption)
    return (
      <div className={cls.wrap}>
        <div
          onMouseEnter={() => setIsShow(true)}
          onMouseLeave={() => setIsShow(false)}
        >
          {children}
        </div>
        {
          <div className={`${isShow ? cls.capAnimate : cls.caption}`}>
            <Typography variant="Text4">{title}</Typography>
          </div>
        }
      </div>
    );

  return (
    <Tooltip
      color={color}
      overlayClassName={`${classNameColor} ${show ? cls.tooltipNotShow : ""}`}
      placement={placeMent}
      title={title}
    >
      {children}
    </Tooltip>
  );
};

export default TooltipWrapper;

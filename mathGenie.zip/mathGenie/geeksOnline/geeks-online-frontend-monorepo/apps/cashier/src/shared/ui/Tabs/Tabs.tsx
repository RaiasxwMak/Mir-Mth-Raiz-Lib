import cls from './Tabs.module.scss';
import { FC } from 'react';
import { Tabs } from 'antd';
import type { TabsProps } from 'antd';

interface ITabs {
  items: TabsProps['items'];
  activeKey: string | null;
  onChange: (activeKey: string) => void;
  isLoading?: boolean;
}

const TabsCustom: FC<ITabs> = ({ items, activeKey, onChange, isLoading }) => {
  if (isLoading && isLoading !== undefined) {
    return <div className={cls.loading} />;
  }

  return (
    <Tabs
      rootClassName={cls['ant-tabs-tab']}
      items={items}
      activeKey={activeKey || ''}
      onChange={onChange}
    />
  );
};

export default TabsCustom;

export interface IStats {
  id?: string;
  type: string;
  value?: number;
  color: string;
  originalValue: number;
  unspent?: number;
}

export interface ILineChart {
  id: string;
  course: string;
  color: string | null;
  total: number | null;
  statistics: { count: number }[];
}

export interface ILineChartFilter {
  id: string;
  course: string;
  color: string | null;
  total: number | null;
  statistics?: { count: number }[];
  originalStatistics: { count: number }[];
}

export interface ILineCharts {
  total: number | null;
  labels: string[];
  datasets: ILineChart[];
}

import cls from "./CustomPagination.module.scss";
import { FC } from "react";
import { Pagination } from "antd";
import NextIcon from "shared/assets/icon/nextIcon.svg?react";
import PrevIcon from "shared/assets/icon/prevIcon.svg?react";
import { create } from "zustand";

interface IPropsPaginate {
  className?: string;
  count: number;
}

export interface IusePageChange {
  page: number;
  setPage: (page: number, pageSize?: number) => void;
  resetPage: () => void;
}

export const usePageChange = create<IusePageChange>((set) => ({
  page: 1,
  setPage: (page) => {
    set({ page: page });
  },
  resetPage: () => {
    set({ page: 1 });
  },
}));

const CustomPagination: FC<IPropsPaginate> = ({ className = "", count }) => {
  const { page, setPage } = usePageChange();

  return (
    <Pagination
      nextIcon={<NextIcon />}
      prevIcon={<PrevIcon />}
      current={page}
      total={Math.ceil(count / 12) * 10}
      showSizeChanger={false}
      onChange={(page, pgsize) => {
        setPage(page, pgsize);
        window.history.replaceState(
          {
            page: page,
          },
          "filters"
        );
      }}
      className={`${cls.paginate} ${className}`}
    />
  );
};

export default CustomPagination;

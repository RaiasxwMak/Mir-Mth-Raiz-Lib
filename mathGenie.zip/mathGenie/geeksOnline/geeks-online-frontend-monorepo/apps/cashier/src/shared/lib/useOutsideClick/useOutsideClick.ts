import { RefObject, useEffect } from 'react';

export function useOutsideClick<T>(
  ref: RefObject<T | any>,
  callback: () => void
) {
  useEffect(() => {
    function handleClickOutside(event: any) {
      /** Проверяем на наличие рефа и также наличие его в таргете на который нажали */
      if (ref.current && !ref.current.contains(event.target)) {
        callback();
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [ref]);
}

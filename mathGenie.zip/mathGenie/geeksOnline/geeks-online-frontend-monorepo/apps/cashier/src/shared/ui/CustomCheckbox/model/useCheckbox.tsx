import { create } from "zustand";

interface ICheckboxStore {
  selectedValues: Array<string | number>;
  toggleValue: (value: string | number) => void;
  setSelectedValues: (values: Array<string | number>) => void;
  resetSelectedValues: () => void;
}

export const useCheckbox = create<ICheckboxStore>((set, get) => ({
  selectedValues: [],

  toggleValue: (value) => {
    const current = get().selectedValues;
    const isSelected = current.includes(value);

    const updated = isSelected
      ? current.filter((v) => v !== value)
      : [...current, value];

    set({ selectedValues: updated });
  },

  setSelectedValues: (values) => {
    set({ selectedValues: values });
  },

  resetSelectedValues: () => {
    set({ selectedValues: [] });
  },
}));

import { FC, useState } from "react";
import {
  AutocompleteSelector,
  AutocompleteSelectorProps,
} from "@geeks-online/uikit";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { DefaultOptionType } from "antd/es/select";

interface IAutoCompleteSelectorAsync extends AutocompleteSelectorProps {
  asyncCallBack: (opt: DefaultOptionType) => Promise<unknown>;
  successText?: string;
  failText?: string;
}

const AutoCompleteSelectorAsync: FC<IAutoCompleteSelectorAsync> = ({
  onChange,
  asyncCallBack,
  successText,
  failText,
  ...otherProps
}) => {
  const [_, setStatus] = useState("");
  const successAlert = useOpenAlert();

  const handleOnBlurRequest = async (value: string, opt: DefaultOptionType) => {
    if (onChange) onChange(value, opt);
    if (!opt?.value) return;
    try {
      await asyncCallBack(opt);
      setStatus("success");
      successAlert(successText ?? "Данные успешно сохранены");
    } catch (e: unknown) {
      setStatus("error");
    }
  };
  return (
    <AutocompleteSelector onChange={handleOnBlurRequest} {...otherProps} />
  );
};

export default AutoCompleteSelectorAsync;

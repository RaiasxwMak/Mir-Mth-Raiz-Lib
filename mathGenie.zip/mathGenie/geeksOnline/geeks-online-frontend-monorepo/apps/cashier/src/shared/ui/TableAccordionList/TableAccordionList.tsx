import TableAccordion, {
  ITableAccordion,
} from '../TableAccordion/TableAccordion';
import cls from './TableAccordionList.module.scss';

export const rowClass = cls.rowTablist;
export const rowChildClass = cls.rowChild;

interface ITableAccordionList extends ITableAccordion {}
const TableAccordionList = (props: ITableAccordionList) => {
  return <TableAccordion className={cls.table} {...props} />;
};

export default TableAccordionList;

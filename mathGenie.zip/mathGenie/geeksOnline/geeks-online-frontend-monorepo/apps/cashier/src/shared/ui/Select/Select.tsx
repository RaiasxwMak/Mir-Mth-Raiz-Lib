import cls from "./Select.module.scss";
import { Select } from "antd";
import { FC, useState, useEffect, ReactNode, CSSProperties } from "react";
import {
  ScrollDirection,
  useScrollDirection,
} from "shared/lib/useScrollDirection/useScrollDirection";
import classNames from "classnames";
import { UpOutlined } from "@ant-design/icons";
import { Typography } from "@geeks-online/uikit";

export interface IOption<Value extends string | number = string | number> {
  value: Value;
  label: ReactNode;
  title?: string;
}

export interface ICustomSelectProps {
  children?: ReactNode;
  options: IOption[];
  defaultValue?: IOption | null;
  onChange?: (params: IOption) => void;
  popUpClass?: string;
  value?: IOption | null;
  bordered?: boolean;
  isInput?: boolean;
  isArrow?: boolean;
  rootClass?: string;
  helperText?: string;
  optionLabelProp?: string;
  width?: string;
  height?: string;
  placeholder?: string;
  wrappClass?: string;
  error?: boolean;
  style?: CSSProperties;
  disabled?: boolean;
}

const CustomSelect: FC<ICustomSelectProps> = ({
  isArrow = false,
  options,
  defaultValue,
  onChange,
  popUpClass = "",
  value,
  rootClass = "",
  isInput = false,
  bordered = false,
  helperText,
  width,
  placeholder,
  disabled,
  wrappClass = "",
  error,
  style,
  height,
}) => {
  const [isDropdownVisibleSelect, setIsDropdownVisibleSelect] =
    useState<boolean>(false);
  const scrollDirection: ScrollDirection = useScrollDirection();

  useEffect(() => {
    if (isDropdownVisibleSelect) {
      setIsDropdownVisibleSelect(false);
    }
  }, [scrollDirection]);

  return (
    <div
      className={`${cls.wrapper} ${wrappClass}`}
      style={{ width: width || 120 }}
    >
      <Select
        labelInValue={true}
        value={value}
        placeholder={placeholder}
        showSearch={isInput}
        defaultValue={defaultValue}
        bordered={bordered}
        onChange={onChange}
        disabled={disabled}
        style={{
          ...style,
          width: "100%",
          height,
        }}
        open={isDropdownVisibleSelect}
        rootClassName={classNames("", [cls.mySelect, rootClass], {
          [cls.error]: error,
        })}
        popupClassName={`${cls.optionWrapper} ${
          isDropdownVisibleSelect && cls.openSelect
        } ${disabled && cls.disabled} ${
          isDropdownVisibleSelect && cls.openSelect
        } ${popUpClass}`}
        onDropdownVisibleChange={(open): void =>
          setIsDropdownVisibleSelect(open)
        }
        suffixIcon={
          isArrow && (
            <UpOutlined
              onClick={() => setIsDropdownVisibleSelect((prev) => !prev)}
              style={{ color: "red !important", transform: "rotate(180deg)" }}
            />
          )
        }
        options={options}
      ></Select>
      {helperText && (
        <Typography
          variant="Text4"
          className={cls.helperText}
          style={{ width: width || 120 }}
        >
          {helperText}
        </Typography>
      )}
    </div>
  );
};

export default CustomSelect;

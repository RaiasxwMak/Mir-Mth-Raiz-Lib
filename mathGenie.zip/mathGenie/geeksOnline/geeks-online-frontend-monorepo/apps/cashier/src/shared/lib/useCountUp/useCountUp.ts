import { useEffect, useRef, useState } from 'react';

interface IuseCountUp {
  start?: number;
  end: number;
  time?: number;
}
export const useCountUp = ({ end, start = 0, time = 20 }: IuseCountUp) => {
  const [count, setCount] = useState<number | null>(null);
  const ref = useRef(start);

  const acc = end / 200;

  const updateCounterState = () => {
    if (ref.current < end) {
      const result = Math.ceil(ref.current + acc);
      if (result > end) return setCount(end);
      setCount(result);
      ref.current = result;
      setTimeout(updateCounterState, time);
    }
  };
  useEffect(() => {
    let isMounted = true;
    if (isMounted) {
      updateCounterState();
    }
    return () => {
      isMounted = false;
    };
  }, [end]);
  return count;
};

import { FC } from 'react';
import { Select } from '..';
import { ICustomSelectProps, IOption } from '../Select/Select';
import { useOpenAlert } from 'app/providers/AlertProvider/selectors/useOpenAlert';

export interface IPropsSelectAsync extends ICustomSelectProps {
  asyncSelect: (val: IOption) => Promise<unknown>;
  width?: string;
  valueData: IOption | null;
  failText?: string;
  successText?: string;
  onSuccess?: () => void;
  onChange: (param: IOption | null, notShowAlert?: boolean) => void;
}

const SelectAsync: FC<IPropsSelectAsync> = ({
  options,
  width = 'fit-content',
  valueData,
  asyncSelect,
  failText,
  successText,
  onSuccess,
  height,
  onChange,
  ...otherProps
}) => {
  const successAlert = useOpenAlert();

  const changeSelect = async (param: IOption) => {
    if (!onChange) return;
    try {
      const response = await asyncSelect(param);
      onChange({ value: param.value, label: `${param.label}` });
      onSuccess?.();
      if (response === 'none') return;
      if (
        !(
          response &&
          typeof response === 'object' &&
          'notShowAlert' in response
        )
      )
        successAlert(successText ?? "Данные успешно сохранены");
    } catch (e: any) {
      console.log('Error');
    }
  };

  return (
    <Select
      isArrow
      onChange={changeSelect}
      value={valueData || undefined}
      width={width}
      height={height}
      options={options}
      {...otherProps}
    />
  );
};

export default SelectAsync;

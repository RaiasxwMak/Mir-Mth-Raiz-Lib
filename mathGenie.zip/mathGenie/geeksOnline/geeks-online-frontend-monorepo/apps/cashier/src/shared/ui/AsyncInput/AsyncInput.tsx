import classNames from "classnames";
import cls from "./AsyncInput.module.scss";
import { ChangeEvent, FC, useEffect, useState } from "react";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import { IPropsInput, Input } from "@geeks-online/uikit";

interface IAsyncInput extends IPropsInput {
  className?: string;
  asyncCallBack: (val: string) => Promise<unknown>;
  successText?: string;
  failText?: string;
  customError?: Record<number, string>;
}

type statusInput = "success" | "error" | "";

const AsyncInput: FC<IAsyncInput> = ({
  value,
  className = "",
  asyncCallBack,
  failText,
  successText,
  customError,
  ...otherProps
}) => {
  const [origValue, setOrigValue] = useState("");
  const [status, setStatus] = useState<statusInput>("");
  const successAlert = useOpenAlert();
  const failAlert = useOpenErrorAlert();
  const handleOnBlurRequest = async () => {
    if (value === origValue) return;
    if (origValue === "") {
      setStatus("error");
      failAlert("Заполните пустое поле");
      return;
    }
    try {
      await asyncCallBack(origValue);
      setStatus("success");
      successAlert(successText ?? "Данные успешно сохранены");
    } catch (e: any) {
      setStatus("error");
    }
  };

  useEffect(() => {
    if (!status) return;
    let timeout = setTimeout(() => {
      setStatus("");
    }, 2000);

    return () => {
      clearTimeout(timeout);
    };
  }, [status]);
  useEffect(() => {
    setOrigValue(value);
  }, [value]);
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setOrigValue(e.target.value);
  };
  return (
    <Input
      value={origValue}
      onChange={handleChange}
      onClick={(e) => e.stopPropagation()}
      onBlur={handleOnBlurRequest}
      className={classNames(cls.input, className, cls[status])}
      {...otherProps}
    />
  );
};

export default AsyncInput;

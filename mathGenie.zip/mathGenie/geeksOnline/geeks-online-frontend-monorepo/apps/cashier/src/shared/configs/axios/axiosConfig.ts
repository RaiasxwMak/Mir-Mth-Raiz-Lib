import axios from "axios";
import {
  BASE_URL,
  COOKIE_ACCESS_TOKEN_KEY,
  COOKIE_REFRESH_TOKEN_KEY,
  COOKIE_TOKEN_TYPE_KEY,
} from "shared/lib/consts/consts";
import { cookie } from "shared/lib/cookie/cookie";

// Set config defaults when creating the instance
export const requester = axios.create({ baseURL: BASE_URL });

const url = new URL(window.location.href);
const urlParams = new URLSearchParams(url.search);

requester.interceptors.request.use((config) => {
  const token_local = urlParams.get(COOKIE_ACCESS_TOKEN_KEY);
  const token_type_local = urlParams.get(COOKIE_TOKEN_TYPE_KEY);
  const token = cookie.getCookie(COOKIE_ACCESS_TOKEN_KEY);
  const token_type = cookie.getCookie(COOKIE_TOKEN_TYPE_KEY);

  if (!token && !token_local) {
    if (import.meta.env.DEV) {
      window.location.assign(
        import.meta.env.VITE_APP_BASE_URL +
          "?" +
          `refererUrl=${import.meta.env.VITE_APP_REFERER_URL}`
      );
    } else window.location.assign(import.meta.env.VITE_APP_BASE_URL);
  }

  if (token || token_local) {
    config.headers.Authorization = `${token_type || token_type_local} ${
      token || token_local
    }`;
  }

  if (token_local && token_type_local) {
    cookie.setCookie(COOKIE_ACCESS_TOKEN_KEY, token_local, 1);
    cookie.setCookie(COOKIE_TOKEN_TYPE_KEY, token_type_local, 1);

    urlParams.delete(COOKIE_ACCESS_TOKEN_KEY);
    urlParams.delete(COOKIE_TOKEN_TYPE_KEY);

    window.history.replaceState(null, "", import.meta.env.VITE_APP_REFERER_URL);
  }

  return config;
});

requester.interceptors.response.use(
  (config) => {
    return config;
  },
  async (error) => {
    const originalRequest = error.config;
    if (
      error.response.data?.code === "token_not_valid" &&
      !error.config._isRetry
    ) {
      originalRequest._isRetry = true;
      try {
        const refresh_token = cookie.getCookie(COOKIE_REFRESH_TOKEN_KEY);

        const config = { refresh: refresh_token };
        const response = await requester.post("/api/v1/auth/refresh/", config);

        if (!response.data.access) {
          cookie.removeCookie(COOKIE_ACCESS_TOKEN_KEY);
          cookie.removeCookie(COOKIE_REFRESH_TOKEN_KEY);
          cookie.removeCookie(COOKIE_TOKEN_TYPE_KEY);
          window.location.assign("https://geeks-online.geekstudio.kg/");
          return Promise.reject("Error");
        }

        cookie.setCookie(COOKIE_ACCESS_TOKEN_KEY, response.data.access, 1);

        return requester.request(originalRequest);
      } catch (e) {
        return null;
      }
    }
    throw error;
  }
);
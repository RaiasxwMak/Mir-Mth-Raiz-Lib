import { CSSProperties, FC, Key, ReactNode, useEffect, useState } from "react";
import { Table } from "antd";
import type { ColumnsType, TableProps } from "antd/es/table";
import cls from "./TableAccordion.module.scss";
import { EditableCell } from "./EditableCell/EditableCell";
import ArrowDown from "shared/assets/icon/arrowAccordion.svg?react";
import classNames from "classnames";
import { ExpandableConfig } from "antd/es/table/interface";
import { GetComponentProps } from "rc-table/lib/interface";
export interface DataType {
  key: number;
  name?: string;
  age?: number;
  address?: string;
  description: ReactNode | ((isExpanded?: boolean) => ReactNode);
  expand?: boolean;
  onClick?: () => void;
  style?: CSSProperties;
  className?: string;
  children?: DataType[];
}

export interface ITableAccordion {
  columns: ColumnsType<any>;
  dataSource: any;
  showHeader?: boolean;
  accordion?: boolean;
  isLoading?: boolean;
  cellComponent?: FC<any>;
  className?: string;
  expanableClass?: string[];
  rowExpandedColor?: CSSProperties["color"];
  showEmpty?: boolean;
  onChangeExpanded?: (exp: Key[]) => void;
}

const TableAccordion = ({
  columns,
  dataSource,
  isLoading,
  showHeader = true,
  accordion = true,
  cellComponent,
  className = "",
  expanableClass,
  rowExpandedColor,
  showEmpty = true,
  onChangeExpanded,
}: ITableAccordion) => {
  const [hasData] = useState(true);
  const ellipsis = false;
  const yScroll = false;

  const scroll: { x?: number | string; y?: number | string } = {};
  if (yScroll) {
    scroll.y = 240;
  }

  const [expandedKeys, setExpandedKeys] = useState<Key[]>([]);

  useEffect(() => {
    onChangeExpanded?.(expandedKeys);
  }, [expandedKeys]);

  const onChangeExpandedKeys = (keys: Key[]) => {
    if (keys.length > 1) {
      setExpandedKeys([keys[1]]);
      return;
    }

    if (expandedKeys?.[0] === keys?.[0]) {
      setExpandedKeys([]);
      return;
    }
    setExpandedKeys(keys);
  };

  const isExpandedRow = (key: number) => {
    return !!expandedKeys.find((elm) => elm === key);
  };

  const rowExpandedBg = (record: DataType) =>
    rowExpandedColor ? (isExpandedRow(record.key) ? rowExpandedColor : "") : "";

  const customExpandIcon = ({ expanded, onExpand, record }: any) => {
    if (typeof record?.expand === "boolean" && record.expand === false) return;
    return (
      <ArrowDown
        style={{
          transition: "all 0.2s ease",
          transform: expanded ? "rotate(180deg)" : "rotate(0deg)",
        }}
        onClick={(e: any) => onExpand(record, e)}
      />
    );
  };

  const onRow: GetComponentProps<DataType> = (record) => {
    return {
      onClick: record?.onClick,
      style: {
        transition: "all 0.2s ease",
        background: rowExpandedBg(record),
        cursor: accordion ? "pointer" : "default",
        ...record.style,
      },
      className: classNames(
        record.className,
        { [cls.expanded]: isExpandedRow(record.key) },
        []
      ),
    };
  };

  const tableColumns = columns.map((item: any) => ({
    ...item,
    ellipsis,
    onCell: (record: DataType) => ({
      record,
      editable: item.editable,
      dataIndex: item.dataIndex,
      title: item.title,
      onSave: item.onSave,
      type: item?.type,
      options: item?.options,
    }),
  }));

  const tableProps: TableProps<DataType> = {
    bordered: false,
    loading: isLoading,
    size: "middle",
    scroll,
  };

  const accordionConfig: ExpandableConfig<DataType> = {
    expandedRowRender: (record) => {
      return (
        <div className={classNames("expandable-content", expanableClass, {})}>
          {typeof record.description === "function"
            ? record.description(isExpandedRow(record.key))
            : record.description}
        </div>
      );
    },
    rowExpandable: (record) => {
      if (typeof record?.expand === "boolean" && record.expand === false)
        return false;
      return true;
    },
    expandIcon: customExpandIcon,
    expandRowByClick: true,
    onExpandedRowsChange(expandedKeys) {
      onChangeExpandedKeys(expandedKeys as Key[]);
    },
    expandedRowKeys: expandedKeys,
  };

  return (
    <Table
      {...tableProps}
      rowClassName="expandable-row"
      style={{ borderCollapse: "collapse", borderSpacing: 0 }}
      expandable={accordion ? accordionConfig : undefined}
      columns={[...tableColumns, Table.EXPAND_COLUMN]}
      onRow={onRow}
      dataSource={hasData ? dataSource : []}
      scroll={scroll}
      className={classNames(cls.overrides, className)}
      showHeader={showHeader}
      pagination={{ position: ["none" as any, "none" as any], pageSize: 100 }}
      components={{ body: { cell: cellComponent || EditableCell } }}
      locale={{ emptyText: showEmpty ? "Нет данных" : "" }}
      bordered={false}
    />
  );
};

export default TableAccordion;

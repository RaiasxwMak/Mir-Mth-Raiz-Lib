import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useNavigate } from "react-router-dom";
import { IOption } from "shared/ui/Select/Select";

export interface SelectValue {
  id?: string;
  value: string;
  selectedOption: any;
}

export interface IStateWithFilters {
  page?: number;
  courseValueSelect?: IOption | null;
  monthSelect?: IOption | null;
  search?: string;
  searchGroupsValue?: SelectValue;
  statusSelect?: IOption | null;
  paymentSelect?: IOption | null;
  monthStatusSelect?: IOption | null;
  groupsSelect?: IOption | null;
}

const useFilterMemoryNavigate = () => {
  const navigate = useNavigate();
  const { search } = useSearchInfo();
  const { groupsSelect: searchGroupsValue } = useSearchGroupsSelect();

  const navigateWithFilter = (path: string, state?: object) => {
    const stateWithFilters = {
      search,
      searchGroupsValue,
      ...state,
    };
    window.history.pushState(stateWithFilters, "filters");
    navigate(path, {
      state: stateWithFilters,
    });
  };
  return navigateWithFilter;
};

export default useFilterMemoryNavigate;

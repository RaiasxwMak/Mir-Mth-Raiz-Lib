import { ReactNode, useEffect } from "react";
import { cookie } from "shared/lib/cookie/cookie";
import {
  COOKIE_ACCESS_TOKEN_KEY,
  COOKIE_REFRESH_TOKEN_KEY,
} from "shared/lib/consts/consts";
import { useAuthProvider } from "./model/useAuthProvider";

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const login = useAuthProvider((state) => state.login);
  const logout = useAuthProvider((state) => state.logout);

  useEffect(() => {
    const token = cookie.getCookie(COOKIE_ACCESS_TOKEN_KEY);
    const refreshToken = cookie.getCookie(COOKIE_REFRESH_TOKEN_KEY);

    if (token || refreshToken) {
      login();
    } else {
      logout();
      //   navigate("https://geeks-online.geekstudio.kg/");
    }
  }, []);

  return children;
};

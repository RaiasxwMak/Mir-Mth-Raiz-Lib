import { AppProvider } from "app/providers/AppProviders";
import {
  CashierProfilePage,
  DetailStudentPage,
  GeeksShopPage,
  MainPage,
  NotFoundPage,
  PaymentsPage,
} from "pages";
import GeekcoinsPage from "pages/GeekcoinsPage/GeekcoinsPage";
import MentorDetailPage from "pages/MentorDetailPage/MentorDetailPage";
import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import { Layout } from "widgets/Layout/Layout";

export const router = createBrowserRouter(
  createRoutesFromElements(
    <Route
      path="/"
      element={
        <AppProvider>
          <Layout />
        </AppProvider>
      }
    >
      <Route index path="/cashier/" element={<MainPage />} />
      <Route
        path="/cashier/student/:student_id/:module_id/:group_id"
        element={<DetailStudentPage />}
      />
      <Route path="/cashier/profile" element={<CashierProfilePage />} />

      <Route index path="/cashier/payments" element={<PaymentsPage />} />

      <Route index path="/cashier/geekshop" element={<GeeksShopPage />} />

      <Route index path="/cashier/geekcoins" element={<GeekcoinsPage />} />

      <Route path="/cashier/mentor/:mentor_id" element={<MentorDetailPage />} />

      <Route path="*" element={<NotFoundPage />} />
    </Route>
  )
);

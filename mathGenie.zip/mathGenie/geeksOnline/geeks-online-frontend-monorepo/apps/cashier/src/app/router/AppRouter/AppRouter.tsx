import { RouterProvider } from "react-router-dom";
import { router } from "../routerConfig/routerConfig";

export const AppRouter = () => {
  return <RouterProvider router={router} />;
};

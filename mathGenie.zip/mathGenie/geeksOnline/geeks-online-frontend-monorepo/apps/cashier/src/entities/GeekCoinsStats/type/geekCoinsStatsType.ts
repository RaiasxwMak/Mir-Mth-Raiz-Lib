import { IStats } from "shared/globalTypes/globalTypes";

export interface MentorData {
  full_name: string;
  mentor_id: string;
  balance: string;
  course: string[];
  experience: string;
  geekshop: string;
}

export interface MentorsResponse {
  total_count: number;
  total_amount: string;
  mentors: MentorData[];
}

export interface MentorsParamsType {
  offset?: number;
  limit?: number;
  q?: string;
  course?: string;
}

export interface IGeekCoinMonitoring {
  course: string;
  amount: number;
  unspent?: number;
}

export interface IGeekCoinData {
  monitoring: IGeekCoinMonitoring[];
  total: number;
  total_unspent?: number;
}

export interface IGeekCoinStatsParams {
  course?: string;
  start_date?: string;
  end_date?: string;
}

export type FilterAction = "reset" | "show" | string;

export interface GeekCoinStatsDataByTab {
  statsData: IGeekCoinData | null;
  stats: IStats[] | null;
  originalStats: IStats[] | null;
}

export interface GeekCoinStatsDataByTabWithCache
  extends GeekCoinStatsDataByTab {
  cacheKey: string;
}

export interface useGeekCoinStatsType {
  loadingByTab: Record<string, boolean>;
  statsByTab: Record<string, GeekCoinStatsDataByTabWithCache>;
  getStats: (
    params: {
      type: "issued" | "spent";
    } & IGeekCoinStatsParams,
    tab: string
  ) => Promise<void>;
  handleFilterStats: (param: FilterAction, tab: string) => void;
  getStatsForTab: (tab: string) => GeekCoinStatsDataByTab;
  clearTabData: (tab: string) => void;
}

export interface IDebitorkaList {
  count: number;
  total: number | null;
  total_students: number | null;
  next: string | null;
  previous: string | null;
  results: IDebitorka[];
}

export interface IDebitorka {
  full_name: string;
  requisite: string;
  course: string;
  phone: string | null;
  comment: string | null;
  duration: number;
  month_amount: number;
  total_amount: number;
  status: string;
  tariff: string;
  receivable: string;
  latest_month: number | null;
  modules: IDebitorkaModule[];
}

export interface IDebitorkaModule {
  id: string;
  month_number: string;
  discount: string;
  paid_repeat: boolean;
  paid_amount: number;
}

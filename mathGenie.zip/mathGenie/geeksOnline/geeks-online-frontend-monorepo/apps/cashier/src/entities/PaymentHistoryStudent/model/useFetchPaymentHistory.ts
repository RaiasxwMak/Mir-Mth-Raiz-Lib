import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";

export const queryKeyHistoryPayment = "historyPayment";

export interface IMarkPaymentHistory {
  students_module_id: string;
  paid_amount: number;
  payment_method: string;
  comment: string;
  payment_date?: string;
}

export interface IHistoryPayments {
  amount: string;
  debt: string;
  course: string;
  discount: string;
  for_payment: string;
  group_title: string;
  id: string;
  is_payed: boolean;
  module_status: string;
  month_number: string;
  month_title: string;
  overpayment: string;
  paid_amount: number;
  payment_type: string;
  payments: IMarkPaymentHistory[];
  remains: string;
  student_full_name: string;
  student_id: string;
}

export const usePaymentHistory = () => {
  const { group_id, student_id } = useParams();
  return useQuery<IHistoryPayments[]>({
    queryKey: [queryKeyHistoryPayment, group_id, student_id],
    queryFn: async () => {
      try {
        if (!group_id || !student_id) return;

        const { data } = await requester.get(
          `api/v1/cashier/group/${group_id}/student/${student_id}/student_modules/`
        );
        return data;
      } catch {}
    },
  });
};

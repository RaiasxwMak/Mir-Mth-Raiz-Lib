import { FC } from "react";
import StatisticsLineChart from "widgets/StatisticsLineChart/StatisticsLineChart";
import GeekCoinStats from "./GeekCoinStats";

const GeekCoinMonitoring: FC = () => {
  return (
    <>
      <GeekCoinStats
        title={"Количество выпущенных GeekCoin"}
        tab="issued"
        courseSelect
        isPeriodDate
        type="issued"
      />
      <GeekCoinStats
        title={"Количество использованных GeekCoin"}
        tab="spent"
        courseSelect
        isPeriodDate
        type="spent"
      />
      <StatisticsLineChart tab={"1"} />
    </>
  );
};

export default GeekCoinMonitoring;

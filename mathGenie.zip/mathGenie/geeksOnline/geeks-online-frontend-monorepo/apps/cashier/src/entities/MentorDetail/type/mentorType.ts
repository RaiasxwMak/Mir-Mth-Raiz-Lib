export type TransactionStatus = "Пополнение" | "Списывание";

export interface MentorHistoryItem {
  full_name: string;
  status: TransactionStatus;
  note: string;
  amount: string;
  date: string;
}

export interface MentorDetailResponse {
  mentors_name: string;
  balance: string;
  total_count: number;
  history: MentorHistoryItem[];
}

export interface MentorDetailParams {
  status?: TransactionStatus;
  start_date?: string;
  end_date?: string;
  offset?: number;
  limit?: number;
}

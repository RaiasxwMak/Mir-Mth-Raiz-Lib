export interface IShopHistoryList {
  count: number;
  total_count: number | null;
  next: string | null;
  previous: string | null;
  results: IShopHistory[];
}

export interface IShopHistory {
  id: string;
  full_name: string;
  status: string;
  confirm_total_price_head: string;
  confirm_total_price_gc: string;
  order_date: string;
  items: IShopOrder[];
}

export interface IShopOrder {
  id: string;
  title: string;
  quantity: string;
  confirm_quantity: string;
}

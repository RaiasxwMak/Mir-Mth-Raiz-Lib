import { requester } from "shared/configs/axios/axiosConfig";
import { IPaymentParams } from "../type/paymentListType";
import { useQuery } from "@tanstack/react-query";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";
import { usePayemtMethods } from "features/PaymentMethodsSelect/model/usePayemtMethods";

export const paymentDocumentQueryKey = "paymentDocument";

export const usePaymentDownload = () => {
  const { search: q } = useSearchInfo();
  const { courseValueSelect } = useCoursesSelect();
  const { groupsSelect } = useSearchGroupsSelect();
  const { selectedDates } = useDateRangePicker();
  const { paymentMethodsSelect } = usePayemtMethods();

  const params = {
    q,
    course_id: courseValueSelect ? String(courseValueSelect?.value) : "",
    group_id: groupsSelect.value ?? "",
    method: paymentMethodsSelect?.value ?? "",
    start_date: selectedDates[0]?.format("YYYY-MM-DD"),
    end_date: selectedDates[1]?.format("YYYY-MM-DD"),
  };

  return useQuery({
    queryFn: async () => fetchPaymentDocument(params),
    queryKey: [
      paymentDocumentQueryKey,
      q,
      courseValueSelect?.value,
      groupsSelect.value,
      selectedDates,
      paymentMethodsSelect,
    ],
  });
};

export const fetchPaymentDocument = async (params: IPaymentParams) => {
  const res = await requester.get("/api/v1/cashier/payments/download/", {
    params,
    responseType: "blob",
  });
  return res.data;
};

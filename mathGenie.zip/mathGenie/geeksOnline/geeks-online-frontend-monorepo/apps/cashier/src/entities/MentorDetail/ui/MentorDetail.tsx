import React, { useMemo } from "react";
import {
  Typography,
  UIFlexColumn,
  UIFlexBetween,
  TableAccordionList,
  rowClass,
  UIFlexRow,
} from "@geeks-online/uikit";
import dayjs from "dayjs";
import classNames from "classnames";
import cls from "./MentorDetail.module.scss";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";
import { useMentorDetailQuery } from "../model/useMentorQuery";
import TransactionStatusSelect from "features/TransactionStatusSelect/ui/TransactionStatusSelect";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";

const MentorDetail: React.FC = () => {
  const { data } = useMentorDetailQuery();
  const historyColumns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Дата",
      dataIndex: "date",
      width: "100px",
      render: (date: string) => dayjs(date).format("DD.MM.YYYY"),
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
      width: "200px",
    },
    {
      title: "Тип",
      dataIndex: "status",
      width: "120px",
      render: (status: string) => (
        <span
          className={classNames(cls.type, {
            [cls.green]: status === "Пополнение",
            [cls.red]: status !== "Пополнение",
          })}
        >
          {status}
        </span>
      ),
    },
    {
      title: "Примечание",
      dataIndex: "note",
      width: "200px",
    },
    {
      title: "Сумма",
      dataIndex: "amount",
      width: "200px",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.history.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
      };
    });
  }, [data]);

  return (
    <UIFlexColumn gap={30}>
      <UIFlexBetween>
        <UIFlexRow gap={16} alignItems="center">
          <TransactionStatusSelect />
          <DateRangePicker />
        </UIFlexRow>
        <Typography variant="Body1" className={cls.totalAmount}>
          Итоговая сумма: : {data?.balance ?? 0}
        </Typography>
      </UIFlexBetween>
      <UIFlexColumn gap={20}>
        <TableAccordionList columns={historyColumns} dataSource={dataSource} />
        <div className={cls.pagination}>
          {data && data.total_count > 12 && (
            <CustomPagination
              count={data.total_count}
              className={cls.paginate}
            />
          )}
        </div>
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default MentorDetail;

import { UIFlexColumn } from "@geeks-online/uikit";
import DebitorkaFilters from "../DebitorkaFilters/DebitorkaFilters";
import DebitorkaList from "../DebitorkaList/DebitorkaList";
import { useDebitorkaGeeksPro } from "entities/Debitorka/model/useDebitorkaGeeksPro";

const DebitorkaGeeksPro = () => {
  const { data, isLoading } = useDebitorkaGeeksPro({
    isFile: false,
    isGeeksPro: true,
  });
  return (
    <UIFlexColumn gap={24}>
      <DebitorkaFilters
        total={data?.total ?? 0}
        total_students={data?.total_students ?? 0}
        isGeeksPro
      />
      <DebitorkaList
        data={data}
        isLoading={isLoading}
        moduleColumnLength={3}
        isGeeksPro
      />
    </UIFlexColumn>
  );
};

export default DebitorkaGeeksPro;

import { studentStatusType } from "shared/lib/consts/consts";

export interface StudentsListParamsType {
  search?: string;
  month?: string;
  year?: string;
  course_id?: string;
  group_id?: string;
  limit?: number;
  offset?: number;
  payment_status?: string;
  status?: string;
  q?: string;
  payment_type?: string;
}

export interface IStudentList {
  count: number;
  next: string | null;
  previous: string | null;
  stats: {
    active_student: number;
    ignore_student: number;
    pause_student: number;
    reject_student: number;
    card_payment_amount: number;
    cash_payment_amount: number;
    total: number;
    remains: number;
    student_count: number;
  };
  results: IStudent[];
}

export interface IStudent {
  course: string;
  group_id: string;
  group_title: string;
  id: string;
  title: string;
  number: number;
  start_date: string;
  end_date: string;
  techer_full_name: string;
  module_students: StudentGroup[];
  status: string;
  total_students: number;
  total_remains: number;
}

export interface StudentGroup {
  id: string;
  student_id: string;
  student_full_name: string;
  payment_type: string;
  repeat_status: string;
  amount: string;
  discount: string;
  for_payment: string;
  overpayment: string;
  deposit: string;
  debt: string;
  archive_debt: string;
  debt_paid: boolean;
  paid_amount: string;
  remained_payment: string;
  module_status: string;
  last_payment_comment: string;
  next_module_debt: string;
  next_module_has_debt: boolean;
  is_graduated: boolean;
  notes_count: number;
  notes: INotes[];
}

export interface Group {
  title: string;
  course: string;
  is_graduated: boolean;
  module?: string;
}

export interface Course {
  id: string;
  title: string;
}

export interface Month {
  id: string;
  title: string;
  status: Status;
}

type Status = studentStatusType | null;

export interface PostNotesType {
  student_module: string;
  student: string;
  description: string;
}

export interface INotes {
  created_at: string;
  description: string;
  id: string;
  name: string;
}

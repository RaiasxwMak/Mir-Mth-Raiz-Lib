import { FC, useCallback, useEffect, useState, useRef } from "react";
import { IOption } from "@geeks-online/uikit";
import { useGeekCoinStats } from "../model/useGeekCoinStats";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { DateRange } from "widgets/DateRangePicker/model/useDateRangePicker";
import dayjs from "dayjs";
import { IGeekCoinStatsParams } from "../type/geekCoinsStatsType";
import Statistics from "widgets/Statistics/ui/Statistics";

interface IProps {
  title: string;
  tab: string;
  type: string;
  courseSelect?: boolean;
  isPeriodDate?: boolean;
}

const GeekCoinStats: FC<IProps> = ({
  tab,
  title,
  type,
  courseSelect,
  isPeriodDate,
}) => {
  const { getStats, handleFilterStats, getStatsForTab, loadingByTab } =
    useGeekCoinStats();

  const { getCourseValueSelect } = useCoursesSelect();
  const courseValueSelect = getCourseValueSelect(tab);
  const [periodValue, setPeriodValue] = useState<DateRange>([null, null]);
  const [selectPeriod, setSelectPeriod] = useState<IOption | null>(null);

  const { statsData, stats } = getStatsForTab(tab);

  const lastRequestParams = useRef<string>("");
  const isComponentMounted = useRef(false);

  const buildStatsParams = useCallback((): {
    type: "issued" | "spent";
  } & IGeekCoinStatsParams => {
    const base: IGeekCoinStatsParams = {};

    if (courseSelect) {
      base.course = courseValueSelect ? String(courseValueSelect.value) : "";
    }

    if (isPeriodDate) {
      base.start_date =
        periodValue[0]?.format("YYYY-MM-DD") ??
        dayjs().subtract(30, "day").format("YYYY-MM-DD");
      base.end_date =
        periodValue[1]?.format("YYYY-MM-DD") ?? dayjs().format("YYYY-MM-DD");
    }

    return {
      ...base,
      type: type as "issued" | "spent",
    };
  }, [type, isPeriodDate, courseSelect, courseValueSelect, periodValue]);

  const createRequestKey = useCallback(
    (params: IGeekCoinStatsParams) => {
      return `${params.course || ""}_${params.start_date || ""}_${
        params.end_date || ""
      }_${tab}`;
    },
    [tab]
  );

  useEffect(() => {
    if (!isComponentMounted.current) {
      isComponentMounted.current = true;
    }
    const params = buildStatsParams();
    const requestKey = createRequestKey(params);

    if (lastRequestParams.current === requestKey) {
      return;
    }

    lastRequestParams.current = requestKey;
    getStats(params, tab);
  }, [tab, buildStatsParams, getStats, createRequestKey]);

  useEffect(() => {
    if (selectPeriod) {
      const months = Number(selectPeriod.value);
      setPeriodValue([dayjs().subtract(months, "month"), dayjs()]);
    }
  }, [selectPeriod]);

  useEffect(() => {
    return () => {
      isComponentMounted.current = false;
      lastRequestParams.current = "";
    };
  }, []);

  const handleFilterStatsWithTab = useCallback(
    (param: string) => {
      handleFilterStats(param, tab);
    },
    [handleFilterStats, tab]
  );

  return (
    <>
      <Statistics
        title={title}
        count={statsData?.total ?? 0}
        loader={loadingByTab[tab]}
        handleFilter={handleFilterStatsWithTab}
        stats={stats}
        courseSelect={courseSelect}
        isPeriodDate={isPeriodDate}
        periodValue={periodValue}
        setPeriodValue={(param) => {
          setSelectPeriod(null);
          setPeriodValue(param);
        }}
        selectPeriod={selectPeriod}
        setSelectPeriod={setSelectPeriod}
        tab={tab}
        total_unspent={statsData?.total_unspent}
      />
    </>
  );
};

export default GeekCoinStats;

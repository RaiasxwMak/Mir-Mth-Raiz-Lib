import { Typography, UIModal } from "@geeks-online/uikit";
import { FC, useState } from "react";
import { requesterPayment } from "shared/configs/axios/requesterPayment";
import { useQueryClient } from "@tanstack/react-query";
import { paymentListQueryKey } from "entities/PaymentsList/model/usePaymentList";

interface ActiveGroupModalProps {
  open: boolean;
  onClose: () => void;
  payElm: { id: string };
}

const ActiveGroupModal: FC<ActiveGroupModalProps> = ({
  open,
  onClose,
  payElm,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const queryClient = useQueryClient();

  const onCloseMessage = async () => {
    try {
      if (payElm.id) {
        setIsLoading(true);
        await requesterPayment.get("api/v1/cashier/payments/check-message/", {
          params: { payments_id: payElm.id },
        });
        onClose();
        queryClient.invalidateQueries([paymentListQueryKey]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <UIModal
      open={open}
      onCancel={onClose}
      onOkRequest={onCloseMessage}
      cancelTitle={"Нет"}
      okTitle={"Да"}
      isLoading={isLoading}
      noCancel
    >
      <div style={{ padding: 15 }} key={payElm.id}>
        <Typography style={{ textAlign: "center" }} variant="Text2_bold">
          Вы уверены?
        </Typography>
      </div>
    </UIModal>
  );
};

export default ActiveGroupModal;

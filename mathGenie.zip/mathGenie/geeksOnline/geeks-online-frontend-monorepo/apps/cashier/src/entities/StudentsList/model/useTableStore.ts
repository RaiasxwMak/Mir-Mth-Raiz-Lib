import { create } from "zustand";

type TableStore = {
  openTables: string[];
  toggleTable: (id: string) => void;
  setTables: (ids: string[]) => void;
  module_id: string;
};

export const useTableStore = create<TableStore>((set) => ({
  module_id: "",
  openTables: [],
  toggleTable: (id) => {
    set((state) => {
      const isOpen = state.openTables.includes(id);
      return {
        openTables: isOpen
          ? state.openTables.filter((tableId) => tableId !== id)
          : [id],
      };
    });
    set({ module_id: id });
  },
  setTables: (ids) => set({ openTables: ids }),
}));

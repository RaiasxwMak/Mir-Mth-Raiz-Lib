export interface MentorData {
  full_name: string;
  mentor_id: string;
  balance: string;
  course: string[];
  experience: string;
  geekshop: string;
}

export interface MentorsResponse {
  total_count: number;
  total_amount: string;
  mentors: MentorData[];
}

export interface MentorsParamsType {
  offset?: number;
  limit?: number;
  q?: string;
  course?: string;
}

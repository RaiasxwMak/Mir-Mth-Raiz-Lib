import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";

export const queryKeyProfileStudent = "profileStudent";

export interface IProfileStident {
  id: string;
  photo: string | null;
  full_name: string;
  login: string;
  telegram: string;
  email: string;
  phone: string;
  active_module: boolean;
}

export const useFetchProfileStudent = () => {
  const { module_id } = useParams();
  return useQuery<IProfileStident>({
    queryKey: [queryKeyProfileStudent, module_id],
    queryFn: async () => {
      try {
        if (!module_id) return;
        const { data } = await requester.get(
          `/api/v1/cashier/students/${module_id}/`
        );
        return data;
      } catch {}
    },
  });
};

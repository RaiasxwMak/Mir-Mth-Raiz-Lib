import { useQuery } from "@tanstack/react-query";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";
import { IDebitorkaList } from "../type/types";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useFilterSelect } from "features/FilterSelect/model/useFilterSelect";
import { useCheckbox } from "shared/ui/CustomCheckbox/model/useCheckbox";

export const useDebitorkaList = ({
  isFile,
  isGeeksPro,
}: {
  isFile: boolean;
  isGeeksPro: boolean;
}) => {
  const { page, resetPage } = usePageChange();
  const { search: q } = useSearchInfo();
  const { selectedDates } = useDateRangePicker();
  const { courseValueSelectMultiple } = useCoursesSelect();
  const { filterSelectMultiple } = useFilterSelect();
  const { selectedValues } = useCheckbox();
  const isChecked = selectedValues.includes("debitorka");

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [selectedDates, courseValueSelectMultiple, filterSelectMultiple, q]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    q,
    offset,
    limit,
    course_id: courseValueSelectMultiple?.map((i) => i.value).join(",") ?? "",
    status: filterSelectMultiple?.map((i) => i.value).join(",") ?? "",
    start_date: selectedDates[0]?.format("YYYY-MM-DD"),
    end_date: selectedDates[1]?.format("YYYY-MM-DD"),
    receivable_only: isChecked,
  };

  return useQuery<IDebitorkaList>({
    enabled: !isGeeksPro,
    queryFn: async () => {
      if (isFile) {
        const { data } = await requester.get(
          "api/v1/cashier/receivable/download/",
          {
            params,
            responseType: "blob",
          }
        );
        return data;
      }
      const { data } = await requester.get("/api/v1/cashier/receivable/", {
        params,
      });
      return data;
    },
    queryKey: [
      "debitorkaList",
      page,
      selectedDates,
      courseValueSelectMultiple,
      filterSelectMultiple,
      q,
      isFile,
      isChecked,
    ],
  });
};

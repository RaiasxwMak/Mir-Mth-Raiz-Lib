import { useStudentsModules } from "entities/StudentsList/model/useFetchStudentsTable";
import { INotes, StudentGroup } from "entities/StudentsList/type/StudentSchema";
import { useNavigate } from "react-router-dom";
import TableAccordionList from "shared/ui/TableAccordionList/TableAccordionList";
import { bgtable } from "../StudentsInfos/StudentsInfos";
import { useMemo, useState } from "react";
import {
  Loader,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { PlusOutlined } from "@ant-design/icons";
import { INotesInfo } from "../StudentsTable/StudentsTable";
import { useTableStore } from "entities/StudentsList/model/useTableStore";
import StatusBlock from "shared/ui/StatusBlock/StatusBlock";
import { NotesModal } from "../NotesModal/NotesModal";
import PaymentsModal from "../PaymentsModal/PaymentsModal";
import PaidModal from "../PaidModal/PaidModal";
import cls from "../StudentsInfos/StudentsTable.module.scss";

const StudentsModules = ({ students }: { students: any }) => {
  const { data, isLoading } = useStudentsModules();
  const navigate = useNavigate();

  const [openNotes, setOpenNotes] = useState(false);
  const [notes, setNotes] = useState<INotesInfo | null>(null);

  const [openPayments, setOpenPayments] = useState(false);
  const [payments, setPayments] = useState({ id: "", name: "" });

  const [openPaid, setOpenPaid] = useState(false);
  const [paidElm, setPaidElm] = useState<StudentGroup | null>(null);

  const { openTables } = useTableStore();

  const isCurrentModule = students.status === "current";

  const handleOpenNotes = (
    name: string,
    student_id: string,
    id: string,
    notes_count: number,
    notes: INotes[]
  ) => {
    setOpenNotes(true);
    setNotes({
      notes_count,
      name,
      student_id,
      id,
      notes,
    });
  };

  const handleOpenPayments = (id: string, name: string) => {
    setOpenPayments(true);
    setPayments({ id, name });
  };

  const handleOpenPaid = (elm: StudentGroup | null) => {
    setOpenPaid(true);
    setPaidElm(elm);
  };

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "50px",
    },
    {
      title: "ФИО",
      dataIndex: "student_full_name",
      render: (text: string, record: StudentGroup) => {
        return (
          <span
            className={"link"}
            onClick={() =>
              navigate(
                `/cashier/student/${record.student_id}/${record?.id}/${students.group_id}/?tab=1`
              )
            }
          >
            {text}
          </span>
        );
      },
      width: "350px",
    },
    {
      title: "Лиц. счет",
      dataIndex: "requisite",
      width: "200px",
    },
    {
      title: "Стоимость курса",
      dataIndex: "amount",
      width: "350px",
    },
    {
      title: "",
      dataIndex: "paymentType",
    },
    {
      title: "",
      dataIndex: "repeat_status",
    },
    {
      title: "",
      dataIndex: "module_status",
      width: "150px",
    },
    {
      title: "",
      dataIndex: "discount",
      width: "200px",
    },
    {
      title: "К оплате",
      dataIndex: "to_paid",
      width: "250px",
    },
    {
      title: "Оплачено",
      dataIndex: "paid_amount",
      width: "250px",
    },
    {
      title: "Остаток",
      dataIndex: "remained_payment",
      width: "200px",
    },
    {
      title: "Заметки",
      dataIndex: "notes",
      width: "300px",
    },
  ];

  const dataSource = useMemo(() => {
    return (
      (Array.isArray(data) &&
        data?.map((elm, index: number) => {
          return {
            ...elm,
            key: index + 1,
            index: index + 1,
            id: elm.id,
            className: bgtable,
            expand: false,
            student_full_name: elm.student_full_name,
            amount: elm.amount ?? 0,
            paymentType: elm.payment_type,
            for_payment: elm.for_payment ?? 0,
            repeat_status: elm.repeat_status ? (
              <StatusBlock yellow>{elm.repeat_status}</StatusBlock>
            ) : (
              ""
            ),
            module_status: (
              <StatusBlock
                yellow={
                  elm.module_status === "Пауза" ||
                  elm.module_status === "На повтор"
                }
                red={
                  elm.module_status === "Отказ" || elm.module_status === "Игнор"
                }
              >
                {elm.module_status}
              </StatusBlock>
            ),
            notes: (
              <div
                className={cls.notes}
                onClick={() =>
                  handleOpenNotes(
                    elm.student_full_name,
                    elm.student_id,
                    elm.id,
                    elm.notes_count,
                    elm.notes
                  )
                }
              >
                <UIFlexColumn gap={5}>
                  {elm.notes.map((item) => (
                    <div key={item.id}>
                      <Typography variant="Text2">
                        <strong>{item.name}</strong>: <br /> {item.description}
                      </Typography>
                    </div>
                  ))}
                </UIFlexColumn>
              </div>
            ),
            discount: (
              <UIFlexColumn gap={10} justifyContent="center">
                <span className={cls.amount}>
                  Скидка: <strong>{elm.discount ?? 0}</strong>
                </span>
                <span className={cls.amount}>
                  Переплата: <strong>{elm.overpayment ?? 0}</strong>
                </span>
                {elm.deposit !== "0.00" && (
                  <span className={cls.amount}>
                    Депозит: <strong>{elm.deposit}</strong>
                  </span>
                )}
                <span className={cls.amount}>
                  Долг:{" "}
                  {elm.debt_paid && (
                    <strong
                      style={{ textDecoration: "line-through", marginRight: 5 }}
                    >
                      {elm.archive_debt ?? 0}
                    </strong>
                  )}
                  <strong className={elm.debt !== "0.00" ? cls.redColor : ""}>
                    {elm.debt ?? 0}
                  </strong>
                </span>
              </UIFlexColumn>
            ),
            paid_amount: (
              <UIFlexRow gap={10} alignItems="center">
                <div
                  style={{ cursor: "pointer", width: 83 }}
                  onClick={() =>
                    handleOpenPayments(elm.id, elm.student_full_name)
                  }
                >
                  {elm.paid_amount ?? `0.00`}
                </div>
                <div className={cls.plus} onClick={() => handleOpenPaid(elm)}>
                  <PlusOutlined width={11} height={12} />
                </div>
              </UIFlexRow>
            ),
            remained_payment: isCurrentModule ? (
              <StatusBlock
                width={100}
                red={elm.remained_payment !== "0.00" ? true : false}
                green={elm.remained_payment === "0.00" ? true : false}
              >
                {elm.remained_payment ?? "0.00"}
              </StatusBlock>
            ) : (elm.next_module_has_debt && elm.next_module_debt !== "0.00") ||
              (elm.is_graduated && elm.remained_payment !== "0.00") ? (
              <StatusBlock red>{elm.remained_payment}</StatusBlock>
            ) : elm.is_graduated && elm.remained_payment !== "0.00" ? (
              <StatusBlock red>{elm.remained_payment}</StatusBlock>
            ) : (
              elm.remained_payment
            ),
          };
        })) ||
      []
    );
  }, [data]);

  const studentsCount = isLoading ? 100 : data?.length;

  return (
    <>
      <div
        style={{
          maxHeight: openTables.includes(students.id)
            ? `calc(${studentsCount} * 107px + 60px)`
            : "0",
        }}
        className={cls.collapse}
      >
        {isLoading && (
          <div className={cls.loader}>
            <Loader small />
          </div>
        )}
        {!isLoading && (
          <TableAccordionList columns={columns} dataSource={dataSource} />
        )}
      </div>
      <NotesModal
        open={openNotes}
        onClose={() => setOpenNotes(false)}
        notes={notes}
        key={String(openNotes)}
      />
      <PaymentsModal
        open={openPayments}
        onClose={() => setOpenPayments(false)}
        payments={payments}
      />
      <PaidModal
        open={openPaid}
        onClose={() => setOpenPaid(false)}
        student={paidElm}
      />
    </>
  );
};

export default StudentsModules;

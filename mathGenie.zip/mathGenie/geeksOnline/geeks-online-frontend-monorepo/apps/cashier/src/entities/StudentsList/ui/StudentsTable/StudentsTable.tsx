import cls from "../StudentsInfos/StudentsTable.module.scss";
import { FC } from "react";
import { INotes, IStudent } from "../../type/StudentSchema";
import { Typography, UIFlexColumn, UIFlexRow } from "@geeks-online/uikit";
import ArrowDown from "shared/assets/icon/arrowDown.svg?react";
import {
  getFormatDateMonth,
  handleSliceText,
} from "shared/lib/helpers/helpers";
import { useTableStore } from "entities/StudentsList/model/useTableStore";
import StudentsModules from "../StudentsModules/StudentsModules";
import StatusBlock from "shared/ui/StatusBlock/StatusBlock";
import classNames from "classnames";

interface IStudentsListProps {
  students: IStudent;
}

export interface INotesInfo {
  id: string;
  student_id: string;
  name: string;
  notes: INotes[];
  notes_count: number;
}

const StudentsTable: FC<IStudentsListProps> = ({ students }) => {
  const { openTables, toggleTable } = useTableStore();

  return (
    <div className={cls.tableWrapper}>
      <div className={cls.users}>
        <UIFlexRow
          className={cls.headTable}
          justifyContent="space-between"
          onClick={() => toggleTable(students.id)}
          gap={20}
        >
          <UIFlexRow gap={32} alignItems="center">
            <UIFlexColumn gap={10} style={{ width: 300 }}>
              <Typography
                variant="Body1"
                className={cls.textBox}
                title={`${students?.course} - ${students?.number}}м.`}
              >
                {students?.course} - {students?.number}м.
              </Typography>
              <Typography
                variant="Body1"
                className={classNames(cls.strongWeight, cls.textBox)}
                title={students?.group_title}
              >
                {students?.group_title}
              </Typography>
            </UIFlexColumn>
            <UIFlexColumn gap={10} style={{ width: 110 }}>
              <Typography variant="Body4">Дата старта:</Typography>
              <Typography variant="Body1" className={cls.strongWeight}>
                {getFormatDateMonth(students?.start_date)}
              </Typography>
            </UIFlexColumn>
            <UIFlexColumn gap={10} style={{ width: 130 }}>
              <Typography variant="Body4">Дата финиша:</Typography>
              <Typography variant="Body1" className={cls.strongWeight}>
                {getFormatDateMonth(students?.end_date)}
              </Typography>
            </UIFlexColumn>
            <Typography variant="Body1" title={students?.techer_full_name}>
              {students?.techer_full_name
                ? handleSliceText(String(students?.techer_full_name), 0, 22)
                : ""}
            </Typography>
          </UIFlexRow>
          <UIFlexColumn gap={10} width={270}>
            <UIFlexRow gap={32} alignItems="center" mr={50}>
              <UIFlexColumn gap={10} width={250}>
                <Typography variant="Body4">Количество:</Typography>
                <Typography variant="Body1" className={cls.strongWeight}>
                  {students?.total_students}
                </Typography>
              </UIFlexColumn>
              <StatusBlock red>{students?.total_remains}</StatusBlock>
            </UIFlexRow>
          </UIFlexColumn>
          <ArrowDown
            className={`${cls.icon} ${
              openTables.includes(students.id) ? cls.animIcon : cls.notAnimIcon
            }`}
          />
        </UIFlexRow>
        <StudentsModules students={students} />
      </div>
    </div>
  );
};

export default StudentsTable;

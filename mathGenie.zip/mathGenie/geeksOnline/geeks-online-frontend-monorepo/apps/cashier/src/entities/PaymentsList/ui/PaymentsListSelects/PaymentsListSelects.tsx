import { UIFlexRow } from "@geeks-online/uikit";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { usePayemtMethods } from "features/PaymentMethodsSelect/model/usePayemtMethods";
import PaymentMethodsSelect from "features/PaymentMethodsSelect/ui/PaymentMethodsSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import SearchGroupsSelect from "features/SearchGroupsSelect/ui/SearchGroupsSelect";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect } from "react";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";

const PaymentsListSelects = () => {
  const { courseValueSelect, courseResetSelect } = useCoursesSelect();
  const { clearSelect } = useSearchGroupsSelect();
  const { selectedDatesReset } = useDateRangePicker();
  const { paymentMethodsResetSelect } = usePayemtMethods();
  const { setInput, setSearch } = useSearchInfo();

  useEffect(() => {
    courseResetSelect();
    clearSelect();
    selectedDatesReset();
    paymentMethodsResetSelect();
    setInput("");
    setSearch("");
  }, []);
  return (
    <UIFlexRow gap={12}>
      <CourseSelect afterChange={clearSelect} />
      <div style={{ width: 256 }}>
        <SearchGroupsSelect
          course_id={
            courseValueSelect?.value
              ? courseValueSelect?.value.toString()
              : undefined
          }
        />
      </div>
      <DateRangePicker />
      <PaymentMethodsSelect />
    </UIFlexRow>
  );
};

export default PaymentsListSelects;

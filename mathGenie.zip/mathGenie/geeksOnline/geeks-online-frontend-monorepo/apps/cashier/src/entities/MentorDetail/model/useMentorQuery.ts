import { useQuery } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";
import {
  MentorDetailParams,
  MentorDetailResponse,
  TransactionStatus,
} from "../type/mentorType";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";
import { useParams } from "react-router-dom";
import { useTransactionStatusSelect } from "features/TransactionStatusSelect/model/useTransactionStatusSelect";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useEffect } from "react";

const ENDPOINTS = {
  MENTOR: `/api/v1/cashier/monitoring-geekcoin/mentors/`,
};

export const mentor = "mentor";

export const useMentorDetailQuery = () => {
  const { page, resetPage } = usePageChange();
  const { mentor_id } = useParams();
  const { selectedDates } = useDateRangePicker();
  const { transactionStatusSelect } = useTransactionStatusSelect();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [transactionStatusSelect, selectedDates]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const getStatusValue = (): TransactionStatus | undefined => {
    if (
      !transactionStatusSelect?.value ||
      transactionStatusSelect.value === ""
    ) {
      return undefined;
    }
    return transactionStatusSelect.value as TransactionStatus;
  };

  const params: MentorDetailParams = {
    start_date: selectedDates[0]?.format("YYYY-MM-DD"),
    end_date: selectedDates[1]?.format("YYYY-MM-DD"),
    offset,
    limit,
    status: getStatusValue(),
  };
  return useQuery<MentorDetailResponse>({
    enabled: !!mentor_id,
    queryFn: async () => {
      const res = await requester.get(`${ENDPOINTS.MENTOR}${mentor_id}`, {
        params,
      });
      return res.data;
    },
    queryKey: [mentor, mentor_id, selectedDates, transactionStatusSelect, page],
  });
};

import { EmptyState, Loader, Typography } from "@geeks-online/uikit";
import { usePaymentList } from "entities/PaymentsList/model/usePaymentList";
import { bgtable } from "entities/StudentsList/ui/StudentsInfos/StudentsInfos";
import { useMemo, useState } from "react";
import { CloseOutlined } from "@ant-design/icons";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import TableAccordionList from "shared/ui/TableAccordionList/TableAccordionList";
import ActiveGroupModal from "./ActiveGroupModal";
import cls from "./PaymentList.module.scss";

const PaymentList = () => {
  const { data, isLoading } = usePaymentList();

  const [openModal, setOpenModal] = useState(false);
  const [payElm, setPayElm] = useState({ id: "" });

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
    },
    {
      title: "ID транзакции",
      dataIndex: "qid",
    },
    {
      title: "Лиц. счет",
      dataIndex: "requisite",
    },
    {
      title: "Направление",
      dataIndex: "course",
    },
    {
      title: "Месяц",
      dataIndex: "month",
    },
    {
      title: "Сумма",
      dataIndex: "amount",
    },
    {
      title: "Источник",
      dataIndex: "method",
    },
    {
      title: "Дата",
      dataIndex: "dts",
    },
    {
      title: "",
      dataIndex: "message",
    },
  ];

  const setPayModal = (id: string) => {
    setOpenModal(true);
    setPayElm({ id });
  };

  const dataSource = useMemo(() => {
    return data?.results?.map((elm, index: number) => {
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: bgtable,
        expand: false,
        amount: <strong>{elm?.amount}</strong>,
        method: <strong>{elm?.method}</strong>,
        message: elm.message ? (
          <div className={cls.message}>
            <Typography variant="Text4">{elm.message}</Typography>
            <CloseOutlined
              onClick={() => setPayModal(elm.id)}
              className={cls.close}
              width={14}
              height={14}
            />
          </div>
        ) : (
          ""
        ),
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={"tableWidth"}>
        <TableAccordionList columns={columns} dataSource={dataSource} />
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
      <ActiveGroupModal
        payElm={payElm}
        open={openModal}
        onClose={() => setOpenModal(false)}
      />
    </div>
  );
};

export default PaymentList;

import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { useMentorsQuery } from "../model/useFetchMentors";
import {
  Loader,
  rowClass,
  TableAccordionList,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import useFilterMemoryNavigate from "shared/lib/useFillterMemoryNavigate/useFillterMemoryNavigate";
import { useMemo } from "react";
import dayjs from "dayjs";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import cls from "./GeekCoinsMentors.module.scss";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import { MentorData } from "../type/mentorsType";

const GeekCoinsMentors = () => {
  const { data, isLoading } = useMentorsQuery();
  const navigateWithMemory = useFilterMemoryNavigate();
  const { clearSelect } = useSearchGroupsSelect();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "ФИО ментора",
      dataIndex: "full_name",
      width: "226px",
      render: (text: string, record: MentorData) => {
        return (
          <span
            className={"link"}
            onClick={() =>
              navigateWithMemory(`/cashier/mentor/${record.mentor_id}`)
            }
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Направление",
      dataIndex: "course",
      render: (course: string[]) =>
        Array.isArray(course) ? course.join(", ") : course,
    },
    {
      title: "Опыт меторства",
      dataIndex: "experience",
      width: "200px",
      render: (text: string) => {
        return <span>c {dayjs(text).format("DD.MM.YY")}</span>;
      },
    },
    {
      title: "Geeks Shop",
      dataIndex: "geekshop",
    },
    {
      title: "Сумма",
      dataIndex: "balance",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.mentors.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
      };
    });
  }, [data]);
  return (
    <UIFlexColumn gap={40}>
      <UIFlexBetween gap={20} style={{ flexWrap: "wrap" }}>
        <SearchInfo />
        <CourseSelect afterChange={clearSelect} />
        <UIFlexRow gap={46}>
          <Typography variant="Body1" style={{ color: "#afafaf" }}>
            Итоговая сумма: : {data?.total_amount ?? 0}
          </Typography>
        </UIFlexRow>
      </UIFlexBetween>
      {isLoading ? (
        <Loader />
      ) : (
        <TableAccordionList columns={columns} dataSource={dataSource} />
      )}
      <div className={cls.pagination}>
        {data && data.total_count > 12 && (
          <CustomPagination count={data.total_count} className={cls.paginate} />
        )}
      </div>
    </UIFlexColumn>
  );
};

export default GeekCoinsMentors;

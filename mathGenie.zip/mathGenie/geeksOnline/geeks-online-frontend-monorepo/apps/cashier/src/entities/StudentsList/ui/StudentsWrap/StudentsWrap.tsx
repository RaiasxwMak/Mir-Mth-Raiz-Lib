import {
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { StudentsSelects } from "../StudentsSelects/StudentsSelects";
import StudentsInfos from "../StudentsInfos/StudentsInfos";
import { useCashierStudentsQuery } from "entities/StudentsList/model/useFetchStudentsTable";

const StudentsWrap = () => {
  const { data } = useCashierStudentsQuery();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexBetween gap={20} style={{ flexWrap: "wrap" }}>
        <SearchInfo />
        <UIFlexRow gap={46}>
          <Typography variant="Body1" style={{ color: "#afafaf" }}>
            Активных студентов : {data?.stats.active_student ?? 0}
          </Typography>
          <Typography variant="Body1" style={{ color: "#afafaf" }}>
            Пауза : {data?.stats.pause_student ?? 0}
          </Typography>
          <Typography variant="Body1" style={{ color: "#afafaf" }}>
            Игнор : {data?.stats.ignore_student ?? 0}
          </Typography>
          <Typography variant="Body1" style={{ color: "#afafaf" }}>
            Отказ : {data?.stats.reject_student ?? 0}
          </Typography>
        </UIFlexRow>
      </UIFlexBetween>
      <StudentsSelects />
      <StudentsInfos />
    </UIFlexColumn>
  );
};

export default StudentsWrap;

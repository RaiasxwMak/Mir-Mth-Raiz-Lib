import { useQuery } from "@tanstack/react-query";
import { IPaymentParams, IPaymentType } from "../type/paymentListType";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useEffect } from "react";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";
import { usePayemtMethods } from "features/PaymentMethodsSelect/model/usePayemtMethods";
import { requesterPayment } from "shared/configs/axios/requesterPayment";

export const paymentListQueryKey = "paymentList";

export const usePaymentList = () => {
  const { page, resetPage } = usePageChange();
  const { search: q } = useSearchInfo();
  const { courseValueSelect } = useCoursesSelect();
  const { groupsSelect } = useSearchGroupsSelect();
  const { selectedDates } = useDateRangePicker();
  const { paymentMethodsSelect } = usePayemtMethods();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [
    q,
    courseValueSelect?.value,
    groupsSelect.value,
    selectedDates,
    paymentMethodsSelect,
  ]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    offset,
    limit,
    q,
    course_id: courseValueSelect ? String(courseValueSelect?.value) : "",
    group_id: groupsSelect.value ?? "",
    method: paymentMethodsSelect?.value ?? "",
    start_date: selectedDates[0]?.format("YYYY-MM-DD"),
    end_date: selectedDates[1]?.format("YYYY-MM-DD"),
  };

  return useQuery<IPaymentType>({
    queryFn: async () => fetchPaymentList(params),
    queryKey: [
      paymentListQueryKey,
      q,
      page,
      courseValueSelect?.value,
      groupsSelect.value,
      selectedDates,
      paymentMethodsSelect,
    ],
  });
};

export const fetchPaymentList = async (params: IPaymentParams) => {
  const res = await requesterPayment.get("/api/v1/cashier/payments/", {
    params,
  });
  return res.data;
};

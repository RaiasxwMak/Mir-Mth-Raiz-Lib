import { create } from "zustand";
import { requester } from "shared/configs/axios/axiosConfig";
import { AxiosResponse } from "axios";
import { generateColor } from "shared/lib/helpers/helpers";
import {
  GeekCoinStatsDataByTab,
  GeekCoinStatsDataByTabWithCache,
  IGeekCoinData,
  IGeekCoinMonitoring,
  IGeekCoinStatsParams,
  useGeekCoinStatsType,
} from "../type/geekCoinsStatsType";
import { IStats } from "shared/globalTypes/globalTypes";

const mapMonitoringToStats = (monitoring: IGeekCoinMonitoring[]): IStats[] => {
  return monitoring.map((item, index) => ({
    type: item.course,
    value: Number(item.amount),
    originalValue: Number(item.amount),
    color: generateColor(index),
    id: String(index),
    unspent: Number(item.unspent ?? 0),
  }));
};

export const useGeekCoinStats = create<useGeekCoinStatsType>((set, get) => ({
  loadingByTab: {},
  statsByTab: {},

  getStats: async (params, tab: string) => {
    try {
      set((state) => ({
        loadingByTab: {
          ...state.loadingByTab,
          [tab]: true,
        },
      }));

      const state = get();
      const existingData = state.statsByTab[tab];
      const cacheKey = `${params.type}_${params.course || ""}_${
        params.start_date || ""
      }_${params.end_date || ""}`;

      if (existingData && existingData.cacheKey === cacheKey) {
        set((state) => ({
          loadingByTab: {
            ...state.loadingByTab,
            [tab]: false,
          },
        }));
        return;
      }

      const url = `api/v1/cashier/monitoring-geekcoin/${params.type}/`;
      const requestParams: IGeekCoinStatsParams = {};
      if (params.course) requestParams.course = params.course;
      if (params.start_date) requestParams.start_date = params.start_date;
      if (params.end_date) requestParams.end_date = params.end_date;

      const response: AxiosResponse<IGeekCoinData> = await requester.get(url, {
        params: requestParams,
      });

      const processedStats = mapMonitoringToStats(response.data.monitoring);
      const tabData: GeekCoinStatsDataByTab & { cacheKey: string } = {
        statsData: response.data,
        stats: processedStats,
        originalStats: [...processedStats],
        cacheKey,
      };

      set((state) => ({
        loadingByTab: {
          ...state.loadingByTab,
          [tab]: false,
        },
        statsByTab: {
          ...state.statsByTab,
          [tab]: tabData,
        },
      }));
    } catch (error) {
      console.error("Error fetching GeekCoin stats:", error);
      const errorTabData: GeekCoinStatsDataByTabWithCache = {
        statsData: null,
        stats: [],
        originalStats: [],
        cacheKey: "",
      };

      set((state) => ({
        loadingByTab: {
          ...state.loadingByTab,
          [tab]: false,
        },
        statsByTab: {
          ...state.statsByTab,
          [tab]: errorTabData,
        },
      }));
    }
  },

  handleFilterStats: (param: string, tab: string) => {
    const state = get();
    const current = state.statsByTab[tab];

    if (!current || !current.stats || !current.originalStats) return;

    const updateStatsForTab = (newStats: IStats[]) => {
      set((state) => ({
        statsByTab: {
          ...state.statsByTab,
          [tab]: {
            ...current,
            stats: newStats,
          },
        },
      }));
    };

    if (param === "reset") {
      const resetStats = current.stats.map((item) => ({
        ...item,
        value: undefined,
      }));
      updateStatsForTab(resetStats);
      return;
    }

    if (param === "show") {
      updateStatsForTab([...current.originalStats]);
      return;
    }

    const updatedData = current.stats.map((item) =>
      item.type === param
        ? {
            ...item,
            value: item.value === undefined ? item.originalValue : undefined,
          }
        : item
    );

    updateStatsForTab(updatedData);
  },

  getStatsForTab: (tab: string): GeekCoinStatsDataByTab => {
    const state = get();
    const tabData = state.statsByTab[tab];

    if (!tabData) {
      return {
        statsData: null,
        stats: null,
        originalStats: null,
      };
    }
    return {
      statsData: tabData.statsData,
      stats: tabData.stats,
      originalStats: tabData.originalStats,
    };
  },

  clearTabData: (tab: string) => {
    set((state) => {
      const newStatsByTab = { ...state.statsByTab };
      const newLoadingByTab = { ...state.loadingByTab };

      delete newStatsByTab[tab];
      delete newLoadingByTab[tab];

      return {
        statsByTab: newStatsByTab,
        loadingByTab: newLoadingByTab,
      };
    });
  },
}));

import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordion,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { IDebitorka, IDebitorkaList } from "entities/Debitorka/type/types";
import { useMemo } from "react";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import cls from "./DebitorkaList.module.scss";

const DebitorkaList = ({
  data,
  isLoading,
  moduleColumnLength,
  isGeeksPro = false,
}: {
  data?: IDebitorkaList;
  isLoading: boolean;
  moduleColumnLength: number;
  isGeeksPro?: boolean;
}) => {
  const geeksProModuleColumns = Array.from({
    length: moduleColumnLength,
  }).flatMap((_, i) => {
    const month = i + 1;
    return [
      {
        title: `${month} месяц`,
        dataIndex: `month_${month}`,
        width: "160px",
        render: (_: any, record: IDebitorka) => {
          const mod = record.modules?.find(
            (m) => m.month_number === String(month) && !m.paid_repeat
          );
          return mod?.paid_amount ?? "";
        },
      },
    ];
  });

  const moduleColumns = Array.from({ length: moduleColumnLength }).flatMap(
    (_, i) => {
      const month = i + 1;
      const notFirstMonth = month !== 1;
      return [
        {
          title: `${month} месяц`,
          dataIndex: `month_${month}`,
          width: "160px",
          render: (_: any, record: IDebitorka) => {
            const mod = record.modules?.find(
              (m) => m.month_number === String(month) && !m.paid_repeat
            );
            return mod?.paid_amount ?? "";
          },
        },
        {
          title: `Скидка ${notFirstMonth ? month : ""}`,
          dataIndex: `discount_${month}`,
          width: "160px",
          render: (_: any, record: IDebitorka) => {
            const mod = record.modules?.find(
              (m) => m.month_number === String(month)
            );
            return mod?.discount ?? "";
          },
        },
        {
          title: `ПП${notFirstMonth ? month : ""}`,
          dataIndex: `paid_${month}`,
          width: "160px",
          render: (_: any, record: IDebitorka) => {
            const mod = record.modules?.find(
              (m) => m.month_number === String(month) && m.paid_repeat
            );
            return mod?.paid_amount ?? "";
          },
        },
      ];
    }
  );

  const columns: any = [
    {
      title: "№",
      dataIndex: "index",
      width: "30px",
      fixed: "left",
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
      fixed: "left",
    },
    {
      title: "Тариф",
      dataIndex: "tariff",
      fixed: "left",
    },
    {
      title: "Л.счет",
      dataIndex: "requisite",
      fixed: "left",
    },
    {
      title: "Направление",
      dataIndex: "course",
      fixed: "left",
      width: "70px",
    },
    {
      title: "Прод.",
      dataIndex: "duration",
      fixed: "left",
    },
    {
      title: "Цена",
      dataIndex: "month_amount",
      fixed: "left",
    },
    {
      title: "Итого",
      dataIndex: "total_amount",
      fixed: "left",
    },
    {
      title: "Дебиторка",
      dataIndex: "receivable",
      fixed: "left",
      width: "160px",
      className: "debt-column",
    },
    {
      title: "Статус",
      dataIndex: "status",
    },
    {
      title: "Ушел",
      dataIndex: "latest_month",
    },
    ...(isGeeksPro ? geeksProModuleColumns : moduleColumns),
    {
      title: "Контакты",
      dataIndex: "phone",
      width: "160px",
      render: (phone: string) => {
        const trimmedPhone = phone?.trim?.();
        if (!trimmedPhone || trimmedPhone === "+") {
          return "-";
        }
        return trimmedPhone.startsWith("+") ? trimmedPhone : `+${trimmedPhone}`;
      },
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results?.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: !!elm.comment,
        description: (
          <div className={cls.acordBody}>
            <UIFlexColumn gap={10}>
              <Typography variant="Text1">
                {"Причина перевода в архив:"}
              </Typography>
              {elm.comment}
            </UIFlexColumn>
          </div>
        ),
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={"tableWidth"}>
        <TableAccordion
          className={cls.table}
          accordion
          columns={columns}
          dataSource={dataSource}
          scrollProps={{ x: "max-content" }}
        />
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default DebitorkaList;

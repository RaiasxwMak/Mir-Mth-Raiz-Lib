import { useQuery } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";
import { MentorsParamsType, MentorsResponse } from "../type/mentorsType";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useSearchParams } from "react-router-dom";
import { useEffect } from "react";

const ENDPOINTS = {
  MENTORS: `/api/v1/cashier/monitoring-geekcoin/mentors/`,
};
export const mentorsMonitoringList = "mentorsMonitoringList";

export const useMentorsQuery = () => {
  const { page, resetPage } = usePageChange();
  const { courseValueSelect } = useCoursesSelect();
  const { search } = useSearchInfo();
  const [tabParam] = useSearchParams();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [search, courseValueSelect?.value]);

  const limit = 12;
  const offset = (page - 1) * limit;
  const params: MentorsParamsType = {
    offset,
    limit,
    q: search,
    course: courseValueSelect ? String(courseValueSelect?.value) : "",
  };

  return useQuery<MentorsResponse>({
    enabled: tabParam.get("tab") === "2",
    queryFn: async () => {
      const res = await requester.get(ENDPOINTS.MENTORS, { params });
      return res.data;
    },
    queryKey: [mentorsMonitoringList, page, search, courseValueSelect?.value],
  });
};

import { UIFlexColumn } from "@geeks-online/uikit";
import DebitorkaFilters from "../DebitorkaFilters/DebitorkaFilters";
import DebitorkaList from "../DebitorkaList/DebitorkaList";
import { useDebitorkaList } from "entities/Debitorka/model/useDebitorkaList";

const Debitorka = () => {
  const { data, isLoading } = useDebitorkaList({
    isFile: false,
    isGeeksPro: false,
  });
  return (
    <UIFlexColumn gap={24}>
      <DebitorkaFilters
        total={data?.total ?? 0}
        total_students={data?.total_students ?? 0}
      />
      <DebitorkaList data={data} isLoading={isLoading} moduleColumnLength={7} />
    </UIFlexColumn>
  );
};

export default Debitorka;

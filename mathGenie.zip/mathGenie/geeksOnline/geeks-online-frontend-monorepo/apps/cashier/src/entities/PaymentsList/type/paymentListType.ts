export interface IPaymentType {
  count: number;
  total_amount: number;
  results: IPaymentList[];
}

export interface IPaymentList {
  user_uuid: string;
  dts: string;
  amount: number;
  method: string;
  group: string;
  course: string;
  month: number;
  full_name: string;
  requisite: number;
  message: string;
  id: string;
}

export interface IPaymentParams {
  q?: string;
  group_id?: string;
  course_id?: string;
  start_date?: string;
  end_date?: string;
  limit?: number;
  offset?: number;
  method?: string | number;
}

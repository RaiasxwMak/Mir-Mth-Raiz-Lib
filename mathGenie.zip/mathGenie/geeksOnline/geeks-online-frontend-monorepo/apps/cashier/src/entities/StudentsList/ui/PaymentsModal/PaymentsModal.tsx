import {
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIModal,
} from "@geeks-online/uikit";
import { FC, useEffect, useState } from "react";
import { requester } from "shared/configs/axios/axiosConfig";

interface PayemntsModalProps {
  open: boolean;
  onClose: () => void;
  payments: { id: string; name: string };
}

interface PaymentsAmountType {
  id: string;
  paid_amount: string;
  bank_method: string;
  id_payments_bank: string;
  payment_date: string;
}

const PaymentsModal: FC<PayemntsModalProps> = ({ open, onClose, payments }) => {
  const [paymentsAmount, setPaymentsAmount] = useState<PaymentsAmountType[]>(
    []
  );

  const getPaymentsAmount = async () => {
    try {
      const res = await requester.get(
        `/api/v1/cashier/student_modules/${payments.id}/payments/`
      );
      setPaymentsAmount(res.data);
    } catch {}
  };

  useEffect(() => {
    if (payments.id) {
      getPaymentsAmount();
    }
  }, [payments.id]);

  useEffect(() => {
    return () => setPaymentsAmount([]);
  }, []);
  return (
    <UIModal title={payments.name} open={open} onCancel={onClose} confirm>
      <div style={{ borderTop: "1px solid #aaaa" }}>
        <UIFlexColumn gap={12} mt={17}>
          {paymentsAmount.length ? (
            paymentsAmount?.map((item, key) => (
              <UIFlexBetween key={key} style={{ padding: "8px 16px" }}>
                <Typography variant="Text2_bold">
                  {item.payment_date.split("-").reverse().join(".")}
                </Typography>
                <Typography variant="Text2_bold">
                  {item.paid_amount}
                  {item.bank_method && ` - ${item.bank_method}`}
                </Typography>
              </UIFlexBetween>
            ))
          ) : (
            <></>
          )}
        </UIFlexColumn>
      </div>
    </UIModal>
  );
};

export default PaymentsModal;

import { useCashierStudentsQuery } from "entities/StudentsList/model/useFetchStudentsTable";
import {
  EmptyState,
  Loader,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import cls from "./StudentsTable.module.scss";
import StudentsTable from "../StudentsTable/StudentsTable";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { usePaymentSelect } from "features/PaymentSelect/model/usePaymentSelect";
import { usePaymentTypeSelect } from "features/PaymentTypeSelect/model/usePaymentTypeSelect";
import { useYearsSelect } from "features/YearsSelect/model/useYearsSelect";
import { useMonthsSelect } from "features/MonthsSelect/model/useMonthsSelect";
export const bgtable = cls.bgtable;

const StudentsInfos = () => {
  const { data, isLoading } = useCashierStudentsQuery();

  const { courseValueSelect } = useCoursesSelect();
  const { value } = useSearchGroupsSelect();
  const { paymentSelect } = usePaymentSelect();
  const { paymentTypeSelect } = usePaymentTypeSelect();
  const { yearsSelect } = useYearsSelect();
  const { monthsSelect } = useMonthsSelect();

  const isFiltersForRemains =
    courseValueSelect?.value ||
    value ||
    paymentSelect?.value ||
    paymentTypeSelect?.value ||
    yearsSelect?.value ||
    monthsSelect?.value;

  if (isLoading) return <Loader />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <UIFlexColumn gap={100}>
      <UIFlexRow className={cls.block} alignItems="center" gap={5}>
        <UIFlexColumn gap={16}>
          <UIFlexRow gap={63}>
            <Typography variant="Body1" className={cls.samewidht}>
              Наличный расчет :
            </Typography>
            <Typography variant="Body1" className={cls.strongWeight}>
              {data?.stats.cash_payment_amount ?? 0}
            </Typography>
          </UIFlexRow>
          <UIFlexRow gap={63}>
            <Typography variant="Body1" className={cls.samewidht}>
              Безналичный расчет :
            </Typography>
            <Typography variant="Body1" className={cls.strongWeight}>
              {data?.stats.card_payment_amount ?? 0}
            </Typography>
          </UIFlexRow>
        </UIFlexColumn>
        <UIFlexRow gap={63}>
          <Typography variant="Body1">Итого оплачено :</Typography>
          <Typography variant="Body1" className={cls.strongWeight}>
            {data?.stats.total ?? 0}
          </Typography>
        </UIFlexRow>
        {!isFiltersForRemains && (
          <UIFlexRow gap={63}>
            <Typography variant="Body1">Остаток :</Typography>
            <Typography variant="Body1" className={cls.strongWeight}>
              {data?.stats.remains ?? 0}
            </Typography>
          </UIFlexRow>
        )}
      </UIFlexRow>
      <UIFlexColumn gap={25}>
        {data &&
          data.results?.map((students, key) => (
            <StudentsTable students={students} key={key} />
          ))}
        <div className={cls.pagination}>
          {data && data.count > 12 && (
            <CustomPagination count={data.count} className={cls.paginate} />
          )}
        </div>
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default StudentsInfos;

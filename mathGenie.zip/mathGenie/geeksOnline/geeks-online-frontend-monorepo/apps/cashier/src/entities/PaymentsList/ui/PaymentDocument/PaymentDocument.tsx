import { CustomDropDown, Loader, Typography } from "@geeks-online/uikit";
import { DownOutlined } from "@ant-design/icons";
import { usePaymentDownload } from "entities/PaymentsList/model/usePaymentDownload";
import { useMemo } from "react";
import DownloadSvg from "shared/assets/icon/download.svg?react";
import cls from "./PaymentDocument.module.scss";
import { handleDownload } from "shared/lib/helpers/helpers";

const PaymentDocument = () => {
  const { data, isLoading } = usePaymentDownload();

  const fileName = "Geeksonline_payments.xlsx";

  const menuItems = useMemo(() => {
    return [
      {
        label: (
          <div onClick={() => handleDownload(data, fileName)}>{"Excel"}</div>
        ),
        key: "0",
        icon: "",
      },
    ];
  }, [data]);

  if (isLoading)
    return (
      <div className={cls.select}>
        <Loader small />
      </div>
    );
  return (
    <CustomDropDown MenuItems={menuItems}>
      <div className={cls.select} style={{ cursor: "pointer" }}>
        <Typography variant="Text2_bold">{"Скачать"}</Typography>
        <DownloadSvg />
        <DownOutlined />
      </div>
    </CustomDropDown>
  );
};

export default PaymentDocument;

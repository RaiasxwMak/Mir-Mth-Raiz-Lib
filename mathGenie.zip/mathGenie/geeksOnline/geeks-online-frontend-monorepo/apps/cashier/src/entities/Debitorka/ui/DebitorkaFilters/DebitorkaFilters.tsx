import {
  CustomDropDown,
  Loader,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import DownloadSvg from "shared/assets/icon/download.svg?react";
import Arrow from "shared/assets/icon/arrowAccordion.svg?react";
import { useMemo } from "react";
import cls from "./DebitorkaFilters.module.scss";
import FilterSelect from "features/FilterSelect/ui/FilterSelect";
import { useDebitorkaList } from "entities/Debitorka/model/useDebitorkaList";
import { handleDownload } from "shared/lib/helpers/helpers";
import { useDebitorkaGeeksPro } from "entities/Debitorka/model/useDebitorkaGeeksPro";
import CustomCheckbox from "shared/ui/CustomCheckbox/CustomCheckbox";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";

const fileName = "GeeksOnline_Debitorka.xlsx";
const fileNameGeeksPro = "GeeksOnline_Debitorka_GeeksPro.xlsx";

const DebitorkaFilters = ({
  total,
  total_students,
  isGeeksPro = false,
}: {
  total: number;
  total_students: number;
  isGeeksPro?: boolean;
}) => {
  const { data, isLoading } = useDebitorkaList({ isFile: true, isGeeksPro });
  const { data: geeksProData, isLoading: geeksProLoading } =
    useDebitorkaGeeksPro({ isFile: true, isGeeksPro });

  const menuItems = useMemo(() => {
    return [
      {
        label: (
          <div
            onClick={() =>
              isGeeksPro
                ? handleDownload(geeksProData, fileNameGeeksPro)
                : handleDownload(data, fileName)
            }
          >
            {"Excel"}
          </div>
        ),
        key: "0",
        icon: "",
      },
    ];
  }, [data, isGeeksPro, geeksProData]);

  const statusOptions = [
    { label: "На повтор", value: "На повтор" },
    { label: "Активный", value: "Активный" },
    { label: "Отказ", value: "Отказ" },
    { label: "Пауза", value: "Пауза" },
    { label: "Выпускник", value: "Выпускник" },
    { label: "Закончен", value: "Закончен" },
    { label: "Игнор", value: "Игнор" },
    { label: "Перевод", value: "Перевод" },
    { label: "ПП", value: "ПП" },
    { label: "БП", value: "БП" },
  ];

  return (
    <>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <SearchInfo />
          <UIFlexColumn style={{ width: "max-content" }} gap={5}>
            <Typography variant="Body1" style={{ color: "#afafaf" }}>
              Итоговая сумма:{" "}
              <span style={{ paddingLeft: 32 }}>
                {total.toLocaleString("ru-RU")}
              </span>
            </Typography>
            <Typography variant="Body1" style={{ color: "#afafaf" }}>
              Количество студентов:{" "}
              <span style={{ paddingLeft: 32 }}>{total_students}</span>
            </Typography>
          </UIFlexColumn>
        </UIFlexBetween>
        <UIFlexBetween>
          <UIFlexRow gap={16} alignItems="center">
            {!isGeeksPro && <CourseSelect />}
            <FilterSelect
              multiple
              placeholder="Статус"
              options={statusOptions}
            />
            <DateRangePicker />
            {!isGeeksPro && (
              <CustomCheckbox
                value={"debitorka"}
                label="Показать только должников"
              />
            )}
          </UIFlexRow>
          {(isGeeksPro ? geeksProLoading : isLoading) && (
            <div className={cls.select}>
              <Loader small />
            </div>
          )}
          {(isGeeksPro ? !geeksProLoading : !isLoading) && (
            <CustomDropDown MenuItems={menuItems}>
              <div className={cls.select} style={{ cursor: "pointer" }}>
                <Typography variant="Text2_bold">{"Скачать"}</Typography>
                <DownloadSvg />
                <Arrow />
              </div>
            </CustomDropDown>
          )}
        </UIFlexBetween>
      </UIFlexColumn>
    </>
  );
};

export default DebitorkaFilters;

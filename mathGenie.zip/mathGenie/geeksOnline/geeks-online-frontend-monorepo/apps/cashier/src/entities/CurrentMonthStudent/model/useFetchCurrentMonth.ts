import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import { isAxiosError } from "axios";
import { useParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";

export const queryKeyCurrentMonth = "currentMonth";

export interface IMarkPayemt {
  students_module_id: string;
  paid_amount: number;
  payment_method: string;
  comment: string;
  payment_date?: string;
  bank_method?: string;
}

export interface ICurrentMonth {
  amount: string;
  debt: string;
  course: string;
  discount: string;
  for_payment: string;
  group_title: string;
  id: string;
  is_payed: boolean;
  module_status: string;
  month_number: string;
  month_title: string;
  overpayment: string;
  paid_amount: number;
  payment_type: string;
  payments: IMarkPayemt[];
  remains: string;
  student_full_name: string;
  student_id: string;
}

export const useFetchCurrentMonth = () => {
  const { module_id } = useParams();
  return useQuery<ICurrentMonth>({
    queryKey: [queryKeyCurrentMonth, module_id],
    queryFn: async () => {
      try {
        if (!module_id) return;
        const { data } = await requester.get(
          `api/v1/cashier/student_modules/${module_id}/`
        );
        return data;
      } catch {}
    },
  });
};

export const useFetchMarkPayment = () => {
  const queryClient = useQueryClient();
  const openAlert = useOpenAlert();
  const openErrorAlert = useOpenErrorAlert();
  const profileEdit = useMutation({
    mutationFn: async (param: IMarkPayemt) => {
      const response = await requester.post(
        "api/v1/cashier/students/student_modules/payment/",
        param
      );
      return response.data;
    },
    onSuccess() {
      openAlert("Данные успешно сохранены");
      queryClient.invalidateQueries({ queryKey: [queryKeyCurrentMonth] });
    },
    onError(e) {
      if (isAxiosError(e) && Array.isArray(e.response?.data?.paid_amount)) {
        openErrorAlert(e.response.data?.paid_amount[0]);
      }
    },
  });

  return profileEdit;
};

import { Input, Typography, UIFlexColumn, UIModal } from "@geeks-online/uikit";
import { useQueryClient } from "@tanstack/react-query";
import { Radio, Space } from "antd";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import dayjs from "dayjs";
import { useFetchMarkPayment } from "entities/CurrentMonthStudent/model/useFetchCurrentMonth";
import { cashierStudentsModules } from "entities/StudentsList/model/useFetchStudentsTable";
import { StudentGroup } from "entities/StudentsList/type/StudentSchema";
import { ChangeEvent, FC, useEffect, useState } from "react";
import { failDate, formatMonth } from "shared/lib/consts/consts";
import { formatDateMonth } from "shared/lib/helpers/helpers";

interface PaidModalProps {
  open: boolean;
  onClose: () => void;
  student: StudentGroup | null;
}

const PaidModal: FC<PaidModalProps> = ({ open, onClose, student }) => {
  const [valueRadio, setValueRadio] = useState("card");
  const [paidAmount, setPaidAmount] = useState("");
  const [comment, setComment] = useState("");
  const [date, setDate] = useState("");

  const errorAlert = useOpenErrorAlert();
  const queryClient = useQueryClient();

  const { mutateAsync, isLoading } = useFetchMarkPayment();

  const handleChangeAmount = (e: ChangeEvent<HTMLInputElement>) => {
    let inputValue = e.target.value;

    if (inputValue.includes(".")) {
      const parts = inputValue.split(".");
      if (parts.length > 1 && parts[1].length > 2) {
        return;
      }
    }

    inputValue = inputValue.replace(/[^0-9.]/g, "");

    if (inputValue !== "") {
      setPaidAmount(inputValue);
    } else {
      setPaidAmount("");
    }
  };

  const handleClose = () => {
    setComment("");
    setDate(String(dayjs().format(formatMonth)));
    setPaidAmount("");
    setValueRadio("card");
    onClose();
  };

  const handleMarkPayemt = async () => {
    if (student) {
      if (!student.id) return;
      if (!paidAmount.trim() || !date.trim())
        return errorAlert("Заполните все обязательные поля");

      await mutateAsync({
        students_module_id: student.id,
        payment_method: valueRadio,
        comment,
        paid_amount: parseFloat(paidAmount),
        payment_date: formatDateMonth(date),
      });

      queryClient.invalidateQueries([cashierStudentsModules]);
      handleClose();
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const { value } = e.target;
    if (!value.trim()) return;
    const isValidDate = dayjs(value, "DD.MM.YYYY", true).isValid();
    if (!isValidDate) {
      errorAlert(failDate);
      setDate("");
    }
  };

  useEffect(() => {
    setDate(String(dayjs().format(formatMonth)));
  }, []);
  return (
    <UIModal
      cancelTitle={"Отмена"}
      okTitle={"Сохранить"}
      title={student?.student_full_name}
      open={open}
      onCancel={handleClose}
      onOk={handleMarkPayemt}
      isLoading={isLoading}
    >
      <div style={{ borderTop: "1px solid #aaaa" }}>
        <UIFlexColumn gap={20} mt={20} mb={20}>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2_bold">
              Оплачено <span style={{ color: "red" }}>*</span>
            </Typography>
            <Input value={paidAmount} onChange={handleChangeAmount} fullWidth />
          </UIFlexColumn>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2_bold">
              Дата оплаты <span style={{ color: "red" }}>*</span>
            </Typography>
            <Input
              value={date}
              onChange={(e) => setDate(e.target.value)}
              mask={"99.99.9999"}
              placeholder="12.12.2024"
              onBlur={handleBlur}
              fullWidth
            />
          </UIFlexColumn>
          <Radio.Group
            buttonStyle={"solid"}
            onChange={(e) => setValueRadio(e.target.value)}
            value={valueRadio}
          >
            <Space direction="vertical">
              <Radio value={"cash"}>Наличный расчет</Radio>
              <Radio value={"card"}>Безналичный расчет</Radio>
            </Space>
          </Radio.Group>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2_bold">Комментарии</Typography>
            <Input
              value={comment}
              maxLength={200}
              onChange={(e) => setComment(e.target.value)}
              fullWidth
            />
          </UIFlexColumn>
        </UIFlexColumn>
      </div>
    </UIModal>
  );
};

export default PaidModal;

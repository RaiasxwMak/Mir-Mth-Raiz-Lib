import { Input, Typography, UIFlexBetween, UIModal } from "@geeks-online/uikit";
import { FC, useState } from "react";
import Arrow from "shared/assets/icon/notesArrow.svg?react";
import cls from "./NotesModal.module.scss";
import { useFetchPostNotes } from "entities/StudentsList/model/useFetchStudentsTable";
import { INotesInfo } from "../StudentsTable/StudentsTable";
import dayjs from "dayjs";
import { INotes } from "entities/StudentsList/type/StudentSchema";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";

interface NotesModalProps {
  open: boolean;
  onClose: () => void;
  notes: INotesInfo | null;
}

interface IDataNotes {
  notes: INotes[];
  notes_count: number;
}

export const NotesModal: FC<NotesModalProps> = ({ open, onClose, notes }) => {
  const { mutateAsync } = useFetchPostNotes();
  const openAlert = useOpenAlert();
  const [description, setDescription] = useState("");
  const [dataNotes, setDataNotes] = useState<IDataNotes | null>(null);

  if (!notes) return;

  const arrNotes = dataNotes ? [...dataNotes.notes] : [...notes.notes];

  const postDescription = async () => {
    try {
      const res = await mutateAsync({
        description,
        student: notes.student_id,
        student_module: notes.id,
      });
      setDataNotes(res.data);
      setDescription("");
      openAlert("Сохранено");
    } catch {}
  };

  const onKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.code === "Enter") {
      postDescription();
    }
  };

  const isInput = arrNotes.length === 3 || arrNotes.length > 3;

  return (
    <UIModal title={notes.name} open={open} onCancel={onClose} confirm>
      <div className={cls.notesModal}>
        <div className={cls.cards}>
          {arrNotes?.map((item) => (
            <div className={cls.card} key={item.id}>
              <UIFlexBetween>
                <Typography variant="Body2">{item.name}</Typography>
                <span className={cls.date}>
                  {dayjs(item.created_at).format("DD.MM.YYYY")}
                </span>
              </UIFlexBetween>
              <Typography variant="Text2">{item.description}</Typography>
            </div>
          ))}
        </div>
        {!isInput && (
          <div className={cls.inp}>
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Оставить заметку"
              fullWidth
              maxLength={49}
              onKeyPress={onKeyPress}
            />
            {description && (
              <div className={cls.btn} onClick={postDescription}>
                <Arrow />
              </div>
            )}
          </div>
        )}
      </div>
    </UIModal>
  );
};

import { EmptyState, Loader } from "@geeks-online/uikit";
import { bgtable } from "entities/StudentsList/ui/StudentsInfos/StudentsInfos";
import { useMemo } from "react";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import { useGeeksShopHistory } from "../../model/useGeeksShopHistory";
import dayjs from "dayjs";
import TableAccordion from "shared/ui/TableAccordion/TableAccordion";
import ShopOrders from "../ShopOrders/ShopOrders";

const GeeksShopHistory = () => {
  const { data, isLoading } = useGeeksShopHistory();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Дата",
      dataIndex: "order_date",
      width: "226px",
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
    },
    {
      title: "Сумма заказа",
      dataIndex: "confirm_total_price_head",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results?.map((elm, index: number) => {
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: bgtable,
        expand: !!elm.items.length,
        order_date: dayjs(elm.order_date).format("DD.MM.YYYY"),
        description: <ShopOrders orders={elm.items} />,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={"tableWidth"}>
        <TableAccordion accordion columns={columns} dataSource={dataSource} />
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default GeeksShopHistory;

import { useQuery } from "@tanstack/react-query";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { IDebitorkaList } from "../type/types";
import { useFilterSelect } from "features/FilterSelect/model/useFilterSelect";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";

export const useDebitorkaGeeksPro = ({
  isFile,
  isGeeksPro,
}: {
  isFile: boolean;
  isGeeksPro: boolean;
}) => {
  const { page, resetPage } = usePageChange();
  const { search: q } = useSearchInfo();
  const { selectedDates } = useDateRangePicker();
  const { filterSelectMultiple } = useFilterSelect();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [selectedDates, filterSelectMultiple, q]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    q,
    offset,
    limit,
    status: filterSelectMultiple?.map((i) => i.value).join(",") ?? "",
    start_date: selectedDates[0]?.format("YYYY-MM-DD"),
    end_date: selectedDates[1]?.format("YYYY-MM-DD"),
  };

  return useQuery<IDebitorkaList>({
    enabled: isGeeksPro,
    queryFn: async () => {
      if (isFile) {
        const { data } = await requester.get(
          "api/v1/cashier/receivable/geeks_pro/download/",
          {
            params,
            responseType: "blob",
          }
        );
        return data;
      }
      const { data } = await requester.get(
        "/api/v1/cashier/receivable/geeks_pro/",
        {
          params,
        }
      );
      return data;
    },
    queryKey: [
      "debitorkageekspro",
      page,
      selectedDates,
      filterSelectMultiple,
      q,
      isFile,
    ],
  });
};

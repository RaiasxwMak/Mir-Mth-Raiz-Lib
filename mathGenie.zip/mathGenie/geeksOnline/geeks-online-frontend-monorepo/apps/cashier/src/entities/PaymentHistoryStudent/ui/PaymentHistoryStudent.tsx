import { EmptyState, Loader } from "@geeks-online/uikit";
import { usePaymentHistory } from "../model/useFetchPaymentHistory";
import { rowClass } from "shared/ui/TableAccordionList/TableAccordionList";
import { useMemo } from "react";
import HistoryPaymentInfo from "./HistoryPaymentInfo";
import cls from "./HistoryPaymentInfo.module.scss";
import TableAccordion from "shared/ui/TableAccordion/TableAccordion";

const PaymentHistoryStudent = () => {
  const { data, isLoading } = usePaymentHistory();

  const columns = [
    {
      title: "ФИО",
      dataIndex: "fullName",
    },
    {
      title: "Направление",
      dataIndex: "course",
    },
    {
      title: "Группа",
      dataIndex: "group",
    },
    {
      title: "Месяц",
      dataIndex: "month",
    },
  ];

  const dataSource = useMemo(() => {
    return (
      (Array.isArray(data) &&
        data?.map((elm, index: number) => {
          const even = (index + 1) % 2 === 0;
          return {
            ...elm,
            key: index + 1,
            index: index + 1,
            className: even ? rowClass : "",
            expand: true,
            fullName: elm.student_full_name,
            course: elm.course,
            group: elm.group_title,
            month: elm.month_number,
            description: <HistoryPaymentInfo info={elm} />,
          };
        })) ||
      []
    );
  }, [data]);

  if (isLoading) return <Loader />;
  if (!data?.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordion
        columns={columns}
        dataSource={dataSource}
        rowExpandedColor="rgba(198, 198, 198, 0.12)"
        className={cls.tableAccordion}
      />
    </div>
  );
};

export default PaymentHistoryStudent;

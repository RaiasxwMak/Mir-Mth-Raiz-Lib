import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useDateRangePicker } from "widgets/DateRangePicker/model/useDateRangePicker";
import { IShopHistoryList } from "../type/types";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";

export const useGeeksShopHistory = () => {
  const { page, resetPage } = usePageChange();
  const { search: q } = useSearchInfo();
  const { selectedDates } = useDateRangePicker();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [selectedDates, q]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    q,
    offset,
    limit,
    start_date: selectedDates[0]?.format("YYYY-MM-DD"),
    end_date: selectedDates[1]?.format("YYYY-MM-DD"),
  };

  return useQuery<IShopHistoryList>({
    queryFn: async () => {
      const res = await requester.get("/api/v1/cashier/orders/", { params });
      return res.data;
    },
    queryKey: ["shopHistoryKey", page, selectedDates, q],
  });
};

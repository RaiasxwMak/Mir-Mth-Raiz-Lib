import { Input, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { IShopOrder } from "entities/GeeksShopHistory/type/types";
import cls from "./ShopOrders.module.scss";

const ShopOrders = ({ orders }: { orders: IShopOrder[] }) => {
  if (!orders.length) return null;
  return (
    <div className={cls.info}>
      <div className={cls.list}>
        {orders.map((item) => (
          <div className={cls.card} key={item.id}>
            <UIFlexColumn gap={4}>
              <Typography variant="Text1">{"Товар"}</Typography>
              <Input value={item.title} disabled fullWidth />
            </UIFlexColumn>
            <UIFlexColumn gap={4}>
              <Typography variant="Text1">{"Количество"}</Typography>
              <Input value={item.confirm_quantity} disabled fullWidth />
            </UIFlexColumn>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ShopOrders;

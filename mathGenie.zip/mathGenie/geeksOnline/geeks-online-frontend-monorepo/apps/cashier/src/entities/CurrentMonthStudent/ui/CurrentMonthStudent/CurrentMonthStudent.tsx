import {
  Button,
  Input,
  Loader,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { Radio, Space } from "antd";
import PrevAmounts from "features/PrevAmounts/ui/PrevAmounts";
import { ChangeEvent, useEffect, useState } from "react";
import {
  useFetchCurrentMonth,
  useFetchMarkPayment,
} from "entities/CurrentMonthStudent/model/useFetchCurrentMonth";
import { useParams } from "react-router-dom";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import cls from "./CurrentMonthStudent.module.scss";
import { failDate, formatMonth } from "shared/lib/consts/consts";
import { formatDateMonth } from "shared/lib/helpers/helpers";
import dayjs from "dayjs";

const CurrentMonthStudent = () => {
  const { data, isLoading } = useFetchCurrentMonth();
  const { mutateAsync, isLoading: markPaidLoad } = useFetchMarkPayment();
  const { module_id } = useParams();
  const errorAlert = useOpenErrorAlert();

  const [valueRadio, setValueRadio] = useState("card");
  const [paidAmount, setPaidAmount] = useState("");
  const [comment, setComment] = useState("");
  const [date, setDate] = useState("");

  const infoStudentCureentMonth = {
    leftInfos: [
      {
        label: "Стоимость курса",
        value: data?.amount ?? "",
        disabled: true,
      },
      {
        label: "Скидка",
        value: data?.discount ?? "",
        disabled: true,
      },
      {
        label: "Переплата",
        value: data?.overpayment ?? "",
        disabled: true,
      },
      {
        label: "Долг",
        value: data?.debt ?? "",
        disabled: true,
      },
      {
        label: "Сумма к оплате",
        value: data?.for_payment ?? "",
        disabled: true,
      },
    ],
    rightInfos: [
      {
        label: "Направление",
        value: data?.course ?? "",
        disabled: true,
      },
      {
        label: "Группы",
        value: data?.group_title ?? "",
        disabled: true,
      },
      {
        label: "Месяц",
        value: data?.month_number ?? "",
        disabled: true,
      },
      {
        label: "Статус оплаты",
        value: data?.is_payed ? "Оплаченный" : "Неоплаченный",
        disabled: true,
      },
      {
        label: "Тип оплаты",
        value: data?.payment_type ?? "",
        disabled: true,
      },
    ],
  };

  const handleChangeAmount = (e: ChangeEvent<HTMLInputElement>) => {
    let inputValue = e.target.value;

    if (inputValue.includes(".")) {
      const parts = inputValue.split(".");
      if (parts.length > 1 && parts[1].length > 2) {
        return;
      }
    }

    inputValue = inputValue.replace(/[^0-9.]/g, "");

    if (inputValue !== "") {
      setPaidAmount(inputValue);
    } else {
      setPaidAmount("");
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const { value } = e.target;
    if (!value.trim()) return;
    const isValidDate = dayjs(value, "DD.MM.YYYY", true).isValid();
    if (!isValidDate) {
      errorAlert(failDate);
      setDate("");
    }
  };

  const handleMarkPayemt = async () => {
    if (!paidAmount.trim() || !date.trim())
      return errorAlert("Заполните все обязательные поля");

    if (!module_id) return;

    await mutateAsync({
      students_module_id: module_id,
      payment_method: valueRadio,
      comment,
      paid_amount: parseFloat(paidAmount),
      payment_date: formatDateMonth(date),
    });

    setComment("");
    setDate(String(dayjs().format(formatMonth)));
    setPaidAmount("");
    setValueRadio("card");
  };

  useEffect(() => {
    setDate(String(dayjs().format(formatMonth)));
  }, []);
  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={50} className={cls.wrapper}>
      <UIFlexColumn gap={30}>
        <UIFlexRow gap={100}>
          <UIFlexColumn gap={30} className={cls.fitContentWidth}>
            {infoStudentCureentMonth.leftInfos.map((item, index) => (
              <UIFlexColumn key={index} gap={4} className={cls.dontFullWidth}>
                <Typography variant="Text2_bold">{item.label}</Typography>
                <Input
                  value={item.value}
                  disabled={item.disabled}
                  fullWidth
                  className={cls.lightInput}
                />
              </UIFlexColumn>
            ))}
            <PrevAmounts
              titleLabel={"Оплаченная ранее сумма"}
              data={data?.payments || []}
              width={"500px"}
              prevValue={data?.paid_amount ?? 0}
              className={cls.lightInput}
            />
            <UIFlexColumn gap={4} className={cls.dontFullWidth}>
              <Typography variant="Text2_bold">Остаток</Typography>
              <Input
                value={data?.remains ?? ""}
                disabled={true}
                className={cls.lightInput}
                fullWidth
              />
            </UIFlexColumn>
          </UIFlexColumn>
          <UIFlexColumn gap={30} className={cls.fitContentWidth}>
            {infoStudentCureentMonth.rightInfos.map((item, index) => (
              <UIFlexColumn key={index} gap={4} className={cls.dontFullWidth}>
                <Typography variant="Text2_bold">{item.label}</Typography>
                <Input
                  value={item.value}
                  disabled={item.disabled}
                  fullWidth
                  className={cls.lightInput}
                />
              </UIFlexColumn>
            ))}
          </UIFlexColumn>
        </UIFlexRow>
        <UIFlexRow gap={32}>
          <UIFlexColumn gap={4} className={cls.dontFullWidth}>
            <Typography variant="Text2_bold">
              Оплачено <span style={{ color: "red" }}>*</span>
            </Typography>
            <Input value={paidAmount} onChange={handleChangeAmount} fullWidth />
          </UIFlexColumn>
          <div className={cls.alignCenter}>
            <Input
              value={date}
              onChange={(e) => setDate(e.target.value)}
              onBlur={handleBlur}
              style={{ width: "140px" }}
              mask={"99.99.9999"}
              placeholder="12.12.2024"
            />
          </div>
          <Radio.Group
            buttonStyle={"solid"}
            onChange={(e) => setValueRadio(e.target.value)}
            value={valueRadio}
            className={cls.radioBtn}
          >
            <Space direction="vertical">
              <Radio value={"cash"}>Наличный расчет</Radio>
              <Radio value={"card"}>Безналичный расчет</Radio>
            </Space>
          </Radio.Group>
        </UIFlexRow>
        <UIFlexColumn gap={30}>
          <UIFlexColumn gap={4}>
            <Typography variant="Text2_bold">Комментарии</Typography>
            <textarea
              placeholder="Комментарии"
              value={comment}
              maxLength={200}
              onChange={(e) => setComment(e.target.value)}
              className={cls.textarea}
            />
          </UIFlexColumn>
        </UIFlexColumn>
      </UIFlexColumn>
      <Button
        isLoading={markPaidLoad}
        theme={ThemeButton.contained}
        className={cls.dontFullWidth}
        onClick={handleMarkPayemt}
      >
        Подтвердить
      </Button>
    </UIFlexColumn>
  );
};

export default CurrentMonthStudent;

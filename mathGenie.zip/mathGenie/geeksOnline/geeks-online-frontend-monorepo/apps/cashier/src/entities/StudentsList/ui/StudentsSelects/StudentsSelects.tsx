import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import SearchGroupsSelect from "features/SearchGroupsSelect/ui/SearchGroupsSelect";
import PaymentSelect from "features/PaymentSelect/ui/PaymentSelect";
import PaymentTypeSelect from "features/PaymentTypeSelect/ui/PaymentTypeSelect";
import cls from "./StudentsSelects.module.scss";
import MonthsSelect from "features/MonthsSelect/ui/MonthsSelect";
import YearsSelect from "features/YearsSelect/ui/YearsSelect";

export const StudentsSelects = () => {
  const { courseValueSelect } = useCoursesSelect();
  const { clearSelect } = useSearchGroupsSelect();

  return (
    <div className={cls.selects}>
      <CourseSelect afterChange={clearSelect} />
      <div className={cls.wrapper}>
        <SearchGroupsSelect
          course_id={
            courseValueSelect?.value
              ? courseValueSelect?.value.toString()
              : undefined
          }
          className={[cls.autocomplete]}
        />
      </div>
      <PaymentSelect />
      <PaymentTypeSelect />
      <YearsSelect />
      <MonthsSelect />
    </div>
  );
};

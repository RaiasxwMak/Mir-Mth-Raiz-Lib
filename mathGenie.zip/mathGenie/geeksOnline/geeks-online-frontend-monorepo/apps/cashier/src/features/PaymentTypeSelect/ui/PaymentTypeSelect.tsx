import { FC } from "react";
import { selectsHeight } from "shared/lib/consts/consts";
import { Select } from "shared/ui";
import { usePaymentTypeSelect } from "../model/usePaymentTypeSelect";

export interface IPaymentType {
  width?: string;
}

const PaymentTypeSelect: FC<IPaymentType> = ({ width = "256px" }) => {
  const { paymentTypeSelect, onChangePaymentTypeSelect } =
    usePaymentTypeSelect();

  const paymentWays = [
    { label: "Все", value: "0" },
    { label: "Полная оплата", value: "Полная оплата" },
    { label: "Фиксированная оплата", value: "Фиксированная оплата" },
    { label: "Ежемесячная оплата", value: "Ежемесячная оплата" },
  ];
  return (
    <div>
      <Select
        isArrow
        width={width}
        onChange={onChangePaymentTypeSelect}
        value={paymentTypeSelect}
        options={paymentWays}
        height={selectsHeight}
        placeholder={"Тип оплаты"}
      />
    </div>
  );
};

export default PaymentTypeSelect;

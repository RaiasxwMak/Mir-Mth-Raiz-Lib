import { IOption } from "@geeks-online/uikit";
import { create } from "zustand";

interface IusePayemtMethodsSelect {
  paymentMethodsSelect: IOption | null;
  paymentMethodsChangeSelect: (param: IOption) => void;
  paymentMethodsResetSelect: () => void;
}

export const usePayemtMethods = create<IusePayemtMethodsSelect>((set) => ({
  paymentMethodsSelect: null,

  paymentMethodsChangeSelect: (param) => {
    if (param.value === "0") set({ paymentMethodsSelect: null });
    else set({ paymentMethodsSelect: param });
  },

  paymentMethodsResetSelect: () => {
    set({ paymentMethodsSelect: null });
  },
}));

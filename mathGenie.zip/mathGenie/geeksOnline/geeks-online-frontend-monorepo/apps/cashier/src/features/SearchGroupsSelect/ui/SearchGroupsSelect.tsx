import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { fetchGroupsSearchForSelect } from "features/SearchGroupsSelect/model/useFetchSearchGroupsSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";
import { FC } from "react";
import { selectsHeight } from "shared/lib/consts/consts";
import { AutocompleteSelector } from "@geeks-online/uikit";
import { IOption } from "shared/ui/Select/Select";

interface ISearchGroupsSelect {
  course_id?: string;
  className?: string[];
  disabled?: boolean;
  afterChange?: (param?: IOption) => void;
  errorInput?: boolean;
}
const SearchGroupsSelect: FC<ISearchGroupsSelect> = ({
  course_id,
  className,
  disabled,
  afterChange,
  errorInput,
}) => {
  const { onChange, value } = useSearchGroupsSelect();
  const { courseValueSelect } = useCoursesSelect();
  const courseValue_id =
    courseValueSelect?.value === "0" ? "" : courseValueSelect?.value;

  const handleOnChangeDecorator = (value: string, option: IOption) => {
    onChange(value, option);
    if (afterChange) afterChange();
  };

  return (
    <AutocompleteSelector
      placeholder={"Группы"}
      value={value}
      fetchBySearch={(search) =>
        fetchGroupsSearchForSelect({
          q: search,
          course_id: course_id?.toString() || courseValue_id?.toString(),
        })
      }
      keysDeps={[course_id || courseValue_id]}
      onChange={handleOnChangeDecorator}
      getOptionLabel={(opt) => opt.title}
      getOptionValue={(opt) => opt.id}
      className={className}
      disabled={disabled}
      error={errorInput}
      height={selectsHeight}
    />
  );
};

export default SearchGroupsSelect;

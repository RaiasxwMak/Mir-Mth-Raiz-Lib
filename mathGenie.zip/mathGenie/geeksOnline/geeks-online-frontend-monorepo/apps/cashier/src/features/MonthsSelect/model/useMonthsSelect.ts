import { IOption } from "shared/ui/Select/Select";
import { create } from "zustand";

interface useMonthsSelectType {
  monthsSelect: IOption | null;
  onChangeMonthsSelects: (param: IOption) => void;
  onClearMonthsSelects: () => void;
}

export const useMonthsSelect = create<useMonthsSelectType>((set) => ({
  monthsSelect: null,
  onChangeMonthsSelects: (param) => {
    if (param?.value === "0") {
      set({ monthsSelect: null });
    } else set({ monthsSelect: param });
  },
  onClearMonthsSelects: () => {
    set({ monthsSelect: null });
  },
}));

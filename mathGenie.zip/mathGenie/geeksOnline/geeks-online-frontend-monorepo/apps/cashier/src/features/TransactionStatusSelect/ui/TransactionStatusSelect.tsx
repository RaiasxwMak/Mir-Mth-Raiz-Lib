import { FC } from "react";
import { Select } from "shared/ui";
import { selectsHeight } from "shared/lib/consts/consts";
import { useTransactionStatusSelect } from "../model/useTransactionStatusSelect";

export interface ITransactionStatusSelect {
  width?: string;
}

const TransactionStatusSelect: FC<ITransactionStatusSelect> = ({
  width = "256px",
}) => {
  const { transactionStatusSelect, onChangeTransactionStatusSelects } =
    useTransactionStatusSelect();

  const statusOptions = [
    { label: "Все", value: "" },
    { label: "Пополнение", value: "Пополнение" },
    { label: "Списывание", value: "Списывание" },
  ];
  return (
    <div>
      <Select
        isArrow
        width={width}
        onChange={onChangeTransactionStatusSelects}
        value={transactionStatusSelect}
        options={statusOptions}
        height={selectsHeight}
        placeholder={"Выберите тип"}
      />
    </div>
  );
};

export default TransactionStatusSelect;

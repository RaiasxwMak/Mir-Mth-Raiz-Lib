import { FC, useEffect, useMemo } from "react";
import { CustomSelect, IOption, Typography } from "@geeks-online/uikit";
import { useCoursesSelect } from "../model/useCourseSelect";
import { useFetchDirections } from "../model/useFetchCourses";
import cls from "./CourseSelect.module.scss";

interface IProps {
  isStudent?: boolean;
  width?: string;
  afterChange?: (param?: IOption) => void;
  disabled?: boolean;
  placeholder?: string;
  tab?: string;
}

const CourseSelect: FC<IProps> = ({
  isStudent,
  width,
  afterChange,
  placeholder,
  disabled = false,
  tab,
}) => {
  const { data: direction } = useFetchDirections();
  const {
    courseValueSelect,
    courseChangeSelect,
    courseResetSelect,
    getCourseValueSelect,
    courseChangeSelectByTab,
  } = useCoursesSelect();
  const value = tab ? getCourseValueSelect(tab) : courseValueSelect;
  const allOption = { label: "Все", value: "0" };

  let newSelect = useMemo(() => {
    return (
      direction?.map((i) => ({
        value: i.id,
        label: i.title,
      })) ?? []
    );
  }, [direction]);

  newSelect = [allOption, ...newSelect];

  const handleChangeSelectDecorator = (param: IOption) => {
    if (tab) {
      courseChangeSelectByTab(tab, param);
    } else {
      courseChangeSelect(param);
    }
    if (afterChange) afterChange(param);
  };

  useEffect(() => {
    return () => {
      if (!tab) courseResetSelect();
    };
  }, []);

  return (
    <div className={cls.rowBlock}>
      {isStudent && <Typography variant="Text2">Направление</Typography>}
      <CustomSelect
        isArrow={disabled ? false : true}
        onChange={handleChangeSelectDecorator}
        value={value}
        width={width ? width : isStudent ? "400px" : "256px"}
        height={"40px"}
        options={newSelect}
        placeholder={placeholder || "Направление"}
        disabled={disabled}
      />
    </div>
  );
};

export default CourseSelect;

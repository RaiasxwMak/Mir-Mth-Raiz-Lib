import { CustomSelect, IOption } from "@geeks-online/uikit";
import { useFilterSelect } from "../model/useFilterSelect";
import { useEffect } from "react";

const FilterSelect = ({
  width = "256px",
  placeholder = "",
  multiple,
  options,
}: {
  width?: string;
  placeholder?: string;
  multiple?: boolean;
  options: IOption[];
}) => {
  const {
    onChangeFilterSelects,
    filterSelect,
    onClearFilterSelects,
    filterSelectMultiple,
    onChangeFilterSelectsMultiple,
  } = useFilterSelect();

  useEffect(() => {
    return () => onClearFilterSelects();
  }, []);
  return (
    <CustomSelect
      isArrow={multiple ? false : true}
      multiple={multiple}
      width={width}
      onChange={
        multiple
          ? (onChangeFilterSelectsMultiple as any)
          : onChangeFilterSelects
      }
      value={multiple ? (filterSelectMultiple as any) : filterSelect}
      options={options}
      height={"40px"}
      placeholder={placeholder}
    />
  );
};

export default FilterSelect;

import { create } from "zustand";
import { IOption } from "shared/ui/Select/Select";

interface IuseYearsSelect {
  yearsSelect: IOption | null;
  yearsChangeSelect: (param: IOption) => void;
  yearsResetSelect: () => void;
}

export const useYearsSelect = create<IuseYearsSelect>((set) => ({
    yearsSelect: null,

    yearsChangeSelect: (param) => {
    if (param.value === "0") set({ yearsSelect: null });
    else set({ yearsSelect: param });
  },

  yearsResetSelect: () => {
    set({ yearsSelect: null });
  },
}));

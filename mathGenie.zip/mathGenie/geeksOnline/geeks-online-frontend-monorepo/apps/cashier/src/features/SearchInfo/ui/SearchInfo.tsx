import { useSearchInfo } from "../model/useSearchInfo";
import cls from "./SearchInfo.module.scss";
import { useDebounce } from "@geeks-online/shared";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { Input } from "@geeks-online/uikit";
import { useEffect } from "react";

type InputChangeEvent = React.ChangeEvent<HTMLInputElement>;

export const SearchInfo = () => {
  const { input, setInput, setSearch, resetInputSearch } = useSearchInfo();
  const { page, resetPage } = usePageChange();
  const debouncedGetSearch = useDebounce(setSearch, 500);

  const searchChange = (value: string) => {
    setInput(value);
    if (!value.trim()) {
      debouncedGetSearch("");
    } else {
      debouncedGetSearch(value);
    }
  };

  const handleChange = ({ target }: InputChangeEvent) => {
    searchChange(target.value);
    if (page !== 1) resetPage();
  };

  useEffect(() => {
    return () => resetInputSearch();
  }, []);
  return (
    <Input
      placeholder={"Поиск"}
      type="text"
      value={input}
      searchIcon
      className={cls.input}
      onChange={handleChange}
    />
  );
};

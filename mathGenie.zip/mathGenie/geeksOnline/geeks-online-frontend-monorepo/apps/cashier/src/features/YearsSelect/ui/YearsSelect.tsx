import { useMemo } from "react";
import { Select } from "shared/ui";
import { useYearsSelect } from "../model/useYearsSelect";
import { selectsHeight } from "shared/lib/consts/consts";
import { useFetchYears } from "../model/useFetchYearsSelect";

const YearsSelect = () => {
  const { yearsChangeSelect, yearsSelect } = useYearsSelect();
  const { data } = useFetchYears();

  const allOption = { label: "Все", value: "0" };
  let yearsOptions = useMemo(() => {
    return (
      data?.map((year) => ({ label: String(year), value: String(year) })) || []
    );
  }, [data]);

  yearsOptions = [allOption, ...yearsOptions];
  return (
    <div>
      <Select
        isArrow
        onChange={yearsChangeSelect}
        value={yearsSelect}
        width={"256px"}
        height={selectsHeight}
        options={yearsOptions}
        placeholder={"Год"}
      />
    </div>
  );
};

export default YearsSelect;

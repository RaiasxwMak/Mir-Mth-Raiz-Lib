import { IOption } from "shared/ui/Select/Select";
import { create } from "zustand";

interface UsePaymentSelectType {
  paymentSelect: IOption | null;
  onChangePaymentSelect: (param: IOption) => void;
  onClearPaymentSelect: () => void;
}

export const usePaymentSelect = create<UsePaymentSelectType>((set) => ({
  paymentSelect: null,

  onChangePaymentSelect: (param) => {
    if (param?.value === "0") {
      set({ paymentSelect: null });
    } else set({ paymentSelect: param });
  },

  onClearPaymentSelect: () => {
    set({ paymentSelect: null });
  },
}));

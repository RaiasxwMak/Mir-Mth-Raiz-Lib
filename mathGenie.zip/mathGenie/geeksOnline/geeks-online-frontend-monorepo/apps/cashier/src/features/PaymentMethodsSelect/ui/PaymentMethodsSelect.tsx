import { CustomSelect } from "@geeks-online/uikit";
import { usePayemtMethods } from "../model/usePayemtMethods";
import { selectsHeight } from "shared/lib/consts/consts";
import { useEffect } from "react";

const PaymentMethodsSelect = () => {
  const {
    paymentMethodsSelect,
    paymentMethodsChangeSelect,
    paymentMethodsResetSelect,
  } = usePayemtMethods();

  const paymentsOption = [
    { label: "Все", value: "0" },
    { label: "mbank", value: "mbank" },
    { label: "optima", value: "optima" },
    { label: "bakai", value: "bakai" },
    { label: "obank", value: "obank" },
    { label: "visa", value: "visa" },
  ];

  useEffect(() => {
    return () => {
      paymentMethodsResetSelect();
    };
  }, []);
  return (
    <div>
      <CustomSelect
        isArrow
        onChange={paymentMethodsChangeSelect}
        value={paymentMethodsSelect}
        width={"256px"}
        height={selectsHeight}
        options={paymentsOption}
        placeholder={"Источник оплаты"}
      />
    </div>
  );
};

export default PaymentMethodsSelect;

import { IOption } from "shared/ui/Select/Select";
import { create } from "zustand";

interface UsePaymentType {
  paymentTypeSelect: IOption | null;
  onChangePaymentTypeSelect: (param: IOption) => void;
  onClearPaymentTypeSelect: () => void;
}

export const usePaymentTypeSelect = create<UsePaymentType>((set) => ({
  paymentTypeSelect: null,

  onChangePaymentTypeSelect: (param) => {
    if (param?.value === "0") {
      set({ paymentTypeSelect: null });
    } else set({ paymentTypeSelect: param });
  },

  onClearPaymentTypeSelect: () => {
    set({ paymentTypeSelect: null });
  },
}));

import { IOption } from "shared/ui/Select/Select";
import { create } from "zustand";

interface useTransactionStatusSelectType {
  transactionStatusSelect: IOption | null;
  onChangeTransactionStatusSelects: (param: IOption) => void;
  onClearTransactionStatusSelects: () => void;
}

export const useTransactionStatusSelect =
  create<useTransactionStatusSelectType>((set) => ({
    transactionStatusSelect: null,
    onChangeTransactionStatusSelects: (param) => {
      if (param?.value === "") {
        set({ transactionStatusSelect: null });
      } else set({ transactionStatusSelect: param });
    },
    onClearTransactionStatusSelects: () => {
      set({ transactionStatusSelect: null });
    },
  }));

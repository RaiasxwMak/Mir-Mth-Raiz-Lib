import { FC } from "react";
import { Select } from "shared/ui";
import { selectsHeight } from "shared/lib/consts/consts";
import { usePaymentSelect } from "../model/usePaymentSelect";

export interface IStatusSelects {
  width?: string;
  isStudent?: boolean;
}

const PaymentSelect: FC<IStatusSelects> = ({ width = "256px", isStudent }) => {
  const { paymentSelect, onChangePaymentSelect } = usePaymentSelect();

  const statusSelects = [
    { label: "Все", value: "0" },
    { label: "Оплаченные", value: "paid" },
    { label: "Неоплаченные", value: "unpaid" },
  ];

  const statusSelectsStudent = [
    { label: "Оплаченный", value: "True" },
    { label: "Неоплаченный", value: "False" },
  ];
  return (
    <div>
      <Select
        isArrow
        width={width}
        onChange={onChangePaymentSelect}
        value={paymentSelect}
        options={isStudent ? statusSelectsStudent : statusSelects}
        height={selectsHeight}
        placeholder={"Статус оплаты"}
      />
    </div>
  );
};

export default PaymentSelect;

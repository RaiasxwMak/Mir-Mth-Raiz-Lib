import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS: Record<string, string> = {
  GROUPS: "/api/v1/cashier/groups/",
};

export const fetchGroupsSearchForSelect = async (params: {
  q?: string;
  course_id?: string;
}) => {
  const response = await requester.get(ENDPOINTS.GROUPS, { params });
  return response.data;
};

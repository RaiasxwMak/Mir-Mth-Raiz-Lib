import { FC } from "react";
import { Select } from "shared/ui";
import { selectsHeight } from "shared/lib/consts/consts";
import { useMonthsSelect } from "../model/useMonthsSelect";

export interface IMonthsSelect {
  width?: string;
}

const MonthsSelect: FC<IMonthsSelect> = ({ width = "256px" }) => {
  const { monthsSelect, onChangeMonthsSelects } = useMonthsSelect();

  const endPauseSelects = [
    { label: "Все", value: "0" },
    { label: "Январь", value: "1" },
    { label: "Февраль", value: "2" },
    { label: "Март", value: "3" },
    { label: "Апрель", value: "4" },
    { label: "Май", value: "5" },
    { label: "Июнь", value: "6" },
    { label: "Июль", value: "7" },
    { label: "Август", value: "8" },
    { label: "Сентябрь", value: "9" },
    { label: "Октябрь", value: "10" },
    { label: "Ноябрь", value: "11" },
    { label: "Декабрь", value: "12" },
  ];
  return (
    <div>
      <Select
        isArrow
        width={width}
        onChange={onChangeMonthsSelects}
        value={monthsSelect}
        options={endPauseSelects}
        height={selectsHeight}
        placeholder={"Месяц"}
      />
    </div>
  );
};

export default MonthsSelect;

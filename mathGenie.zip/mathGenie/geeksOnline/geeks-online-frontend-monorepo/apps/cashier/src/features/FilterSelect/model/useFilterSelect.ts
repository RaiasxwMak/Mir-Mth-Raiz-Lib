import { IOption } from "@geeks-online/uikit";
import { create } from "zustand";

interface useFilterSelectType {
  filterSelect: IOption | null;
  filterSelectMultiple: IOption[] | null;

  onChangeFilterSelects: (param: IOption) => void;
  onChangeFilterSelectsMultiple: (param: IOption[]) => void;

  onClearFilterSelects: () => void;
}

export const useFilterSelect = create<useFilterSelectType>((set) => ({
  filterSelect: null,
  filterSelectMultiple: [],

  onChangeFilterSelects: (param) => {
    if (param?.value === "null") {
      set({ filterSelect: null });
    } else set({ filterSelect: param });
  },

  onChangeFilterSelectsMultiple: (param) => {
    set({ filterSelectMultiple: param });
  },

  onClearFilterSelects: () => {
    set({ filterSelect: null, filterSelectMultiple: [] });
  },
}));

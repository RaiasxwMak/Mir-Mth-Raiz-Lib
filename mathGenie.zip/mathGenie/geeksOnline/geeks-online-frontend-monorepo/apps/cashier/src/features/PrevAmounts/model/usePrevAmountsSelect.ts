import { IOption } from "shared/ui/Select/Select";
import { create } from "zustand";

interface UsePrevAmountsSelectType {
  prevAmountsSelect: IOption | null;
  onChangePrevAmountsSelect: (param: IOption) => void;
  onClearPrevAmountsSelect: () => void;
}

export const usePrevAmountsSelect = create<UsePrevAmountsSelectType>((set) => ({
  prevAmountsSelect: null,

  onChangePrevAmountsSelect: (param) => {
    if (param?.value === "0") {
      set({ prevAmountsSelect: null });
    } else set({ prevAmountsSelect: param });
  },

  onClearPrevAmountsSelect: () => {
    set({ prevAmountsSelect: null });
  },
}));

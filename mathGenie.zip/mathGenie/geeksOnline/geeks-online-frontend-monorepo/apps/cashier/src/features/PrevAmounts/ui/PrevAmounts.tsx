import { Select as SharedSelect } from "shared/ui";
import { usePrevAmountsSelect } from "../model/usePrevAmountsSelect";
import { selectsHeight } from "shared/lib/consts/consts";
import { FC, ReactNode, useEffect } from "react";
import { Input, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { Tooltip } from "antd";
import cls from "./PrevAmounts.module.scss";
import { IMarkPayemt } from "entities/CurrentMonthStudent/model/useFetchCurrentMonth";
import {
  getFormatDateMonth,
  handleSliceText,
} from "shared/lib/helpers/helpers";

interface IPrevAmountsSelect {
  width?: string;
  titleLabel?: ReactNode | string;
  data: IMarkPayemt[];
  prevValue: number;
  className?: string;
}

const PrevAmounts: FC<IPrevAmountsSelect> = ({
  width = "256px",
  titleLabel,
  data,
  prevValue,
  className,
}) => {
  const { onChangePrevAmountsSelect, onClearPrevAmountsSelect } =
    usePrevAmountsSelect();

  const renderOptionsWithTooltips = (options: IMarkPayemt[]) => {
    return options.map((option) => ({
      value: option.students_module_id,
      label:
        option?.comment?.length > 25 ? (
          <Tooltip title={option.comment} placement="rightTop">
            <div className={cls.tooltipLabel}>
              <div>{getFormatDateMonth(option.payment_date)}</div>
              <div>{handleSliceText(option.comment, 0, 25)}</div>
              <div>
                {option.paid_amount}
                {option.bank_method && ` - ${option.bank_method}`}
              </div>
            </div>
          </Tooltip>
        ) : (
          <div className={cls.tooltipLabel}>
            <div>{getFormatDateMonth(option.payment_date)}</div>
            <div>{option.comment}</div>
            <div>
              {option.paid_amount}
              {option.bank_method && ` - ${option.bank_method}`}
            </div>
          </div>
        ),
    }));
  };

  useEffect(() => {
    return () => {
      onClearPrevAmountsSelect();
    };
  }, []);
  return (
    <UIFlexColumn gap={4}>
      {titleLabel && <Typography variant="Text2_bold">{titleLabel}</Typography>}
      {data?.length ? (
        <SharedSelect
          isArrow={Boolean(data.length)}
          width={width}
          onChange={onChangePrevAmountsSelect}
          value={{ label: prevValue, value: prevValue }}
          options={renderOptionsWithTooltips(data)}
          height={selectsHeight}
          disabled={!data.length}
          placeholder={titleLabel?.toString() || ""}
        />
      ) : (
        <Input
          className={className}
          value={String(prevValue)}
          disabled
          style={{ width }}
        />
      )}
    </UIFlexColumn>
  );
};

export default PrevAmounts;

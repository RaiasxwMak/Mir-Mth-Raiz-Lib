import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import EditProduct from "entities/GeeksShopEssence/ui/EditProduct/EditProduct";

const ProductPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Добавить товар</Typography>
      <EditProduct />
    </UIFlexColumn>
  );
};

export default ProductPage;

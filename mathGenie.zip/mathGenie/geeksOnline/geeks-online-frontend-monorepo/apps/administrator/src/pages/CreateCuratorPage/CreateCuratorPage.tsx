import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { CreateCurator } from "entities/CuratorEssence/ui/CreateCurator/CreateCurator";

const CreateCuratorPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Куратор</Typography>
      <CreateCurator />
    </UIFlexColumn>
  );
};

export default CreateCuratorPage;

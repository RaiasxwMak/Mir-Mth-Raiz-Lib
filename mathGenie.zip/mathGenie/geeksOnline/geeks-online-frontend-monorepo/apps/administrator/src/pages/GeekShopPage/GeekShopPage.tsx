import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import ProductsTable from "entities/GeeksShopEssence/ui/ProductsTable/ProductsTable";
import ProductWell from "entities/GeeksShopEssence/ui/ProductsTable/ProductWell/ProductWell";
import ActivateSelect from "features/ActivateSelect/ui/ActivateSelect";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { useNavigate } from "react-router-dom";

const GeekShopPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">{"Geeks Shop"}</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("create")}
          >
            {"Добавить товар"}
          </Button>
        </UIFlexBetween>
        <UIFlexRow gap={20}>
          <SearchInfo width="300px" />
          <ActivateSelect />
        </UIFlexRow>
      </UIFlexColumn>
      <ProductWell />
      <ProductsTable />
    </UIFlexColumn>
  );
};

export default GeekShopPage;

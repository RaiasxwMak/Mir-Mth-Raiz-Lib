import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import CreateProduct from "entities/GeeksShopEssence/ui/CreateProduct/CreateProduct";

const CreateProductPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Добавить товар</Typography>
      <CreateProduct />
    </UIFlexColumn>
  );
};

export default CreateProductPage;

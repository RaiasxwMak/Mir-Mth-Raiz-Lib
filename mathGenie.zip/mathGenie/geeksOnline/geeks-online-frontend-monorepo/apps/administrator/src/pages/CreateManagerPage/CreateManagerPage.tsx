import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import CreateManager from "entities/ManagersEssence/ui/CreateManager";

const CreateManagerPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Менеджер</Typography>
      <CreateManager />
    </UIFlexColumn>
  );
};

export default CreateManagerPage;

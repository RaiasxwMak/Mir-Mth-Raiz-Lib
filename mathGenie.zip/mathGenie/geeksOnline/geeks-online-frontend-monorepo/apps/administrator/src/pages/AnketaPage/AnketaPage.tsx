import { Typography, UIFlexColumn } from "@geeks-online/uikit";
import AnketaEssence from "entities/AnketaEssence/ui/AnketaEssence/AnketaEssence";

const AnketaPage = () => {
  return (
    <UIFlexColumn gap={39}>
      <Typography variant="Title1">Анкеты</Typography>
      <AnketaEssence />
    </UIFlexColumn>
  );
};

export default AnketaPage;

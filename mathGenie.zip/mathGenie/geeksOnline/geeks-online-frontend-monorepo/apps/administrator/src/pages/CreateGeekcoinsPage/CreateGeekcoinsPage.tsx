import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { CreateGeekcoins } from "entities/GeekcoinEssence/ui/CreateGeekcoins/CreateGeekcoins";

const CreateGeekcoinsPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Гиккоины</Typography>
      <CreateGeekcoins />
    </UIFlexColumn>
  );
};

export default CreateGeekcoinsPage;

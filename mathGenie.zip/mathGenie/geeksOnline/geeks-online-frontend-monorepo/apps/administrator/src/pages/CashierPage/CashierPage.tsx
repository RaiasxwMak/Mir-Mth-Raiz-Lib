import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import EditCashier from "entities/CashierEssence/ui/EditCashier/EditCashier";

const CashierPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Кассир</Typography>
      <EditCashier />
    </UIFlexColumn>
  );
};

export default CashierPage;

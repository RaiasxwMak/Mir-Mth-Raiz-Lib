import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import EditGeekcoin from "entities/GeekcoinEssence/ui/EditGeekcoin/EditGeekcoin";

const GeekcoinPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Гиккоины</Typography>
      <EditGeekcoin />
    </UIFlexColumn>
  );
};

export default GeekcoinPage;

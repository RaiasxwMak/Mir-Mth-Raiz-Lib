import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { CreateDiscounts } from "entities/DiscountEssence/ui/CreateDiscounts/CreateDiscounts";

const CreateDiscountsPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Скидки по направлениям</Typography>
      <CreateDiscounts />
    </UIFlexColumn>
  );
};

export default CreateDiscountsPage;

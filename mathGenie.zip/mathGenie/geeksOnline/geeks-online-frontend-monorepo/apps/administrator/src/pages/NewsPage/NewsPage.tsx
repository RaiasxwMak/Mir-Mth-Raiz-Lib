import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import NewsTable from "entities/GeeksNews/ui/NewsTable/NewsTable";
import { useNavigate } from "react-router-dom";

const NewsPage = () => {
  const navigate = useNavigate();

  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">Новости</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("create")}
          >
            {"Добавить новости"}
          </Button>
        </UIFlexBetween>
      </UIFlexColumn>
      <NewsTable />
    </UIFlexColumn>
  );
};

export default NewsPage;

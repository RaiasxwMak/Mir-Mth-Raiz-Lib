import { Typography, UIFlexColumn } from "@geeks-online/uikit";
import ProfileInfo from "entities/ProfileInfo/ui/ProfileInfo";

const AdminProfile = () => {
  return (
    <UIFlexColumn gap={20}>
      <Typography variant="Title1">Профиль администратора филиала</Typography>
      <ProfileInfo />
    </UIFlexColumn>
  );
};

export default AdminProfile;

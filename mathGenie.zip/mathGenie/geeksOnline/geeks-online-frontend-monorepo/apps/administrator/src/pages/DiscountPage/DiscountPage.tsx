import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import EditDiscount from "entities/DiscountEssence/ui/EditDiscount/EditDiscount";

const DiscountPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Скидки по направлениям</Typography>
      <EditDiscount />
    </UIFlexColumn>
  );
};

export default DiscountPage;

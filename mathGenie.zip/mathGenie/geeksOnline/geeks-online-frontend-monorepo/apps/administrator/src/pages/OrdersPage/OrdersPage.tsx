import { Typography, UIFlexColumn, UIFlexRow } from "@geeks-online/uikit";
import OrderList from "entities/OrdersEssence/ui/OrderList/OrderList";
import FilterSelect from "features/FilterSelect/ui/FilterSelect";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";

const options = [
  { label: "Все", value: "null" },
  { label: "Ожидает подтверждения", value: "Ожидает подтверждения" },
  { label: "Заказ подтвержден", value: "Заказ подтвержден" },
  { label: "Заказ получен", value: "Заказ получен" },
  { label: "Заказ отменен", value: "Заказ отменен" },
];

const OrdersPage = () => {
  return (
    <UIFlexColumn gap={24}>
      <UIFlexColumn gap={20}>
        <Typography variant="Title1">Geeks Shop</Typography>
        <UIFlexRow gap={20}>
          <SearchInfo />
          <FilterSelect options={options} />
        </UIFlexRow>
      </UIFlexColumn>
      <OrderList />
    </UIFlexColumn>
  );
};

export default OrdersPage;

import {
  GetBack,
  TabsCustom,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { TabsProps } from "antd";
import { EditCurriculum } from "entities/DirectionEssence/ui/EditCurriculum/EditCurriculum";
import EditDirection from "entities/DirectionEssence/ui/EditDirection/EditDirection";
import { useState } from "react";

const DirectionPage = () => {
  const [activeTab, setActiveTab] = useState("1");

  const handleChangeTab = (key: string): void => {
    setActiveTab(key);
  };

  const tabItems: TabsProps["items"] = [
    {
      key: "1",
      label: "Направления филиала",
      children: <EditDirection />,
    },
    {
      key: "2",
      label: "Учебный план",
      children: <EditCurriculum key={activeTab} />,
    },
  ];

  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} defaultUrl="/administrator/directions/" />
      <Typography variant="Title1">Направления филиала</Typography>
      <TabsCustom
        activeKey={activeTab}
        onChange={handleChangeTab}
        items={tabItems}
      />
    </UIFlexColumn>
  );
};

export default DirectionPage;

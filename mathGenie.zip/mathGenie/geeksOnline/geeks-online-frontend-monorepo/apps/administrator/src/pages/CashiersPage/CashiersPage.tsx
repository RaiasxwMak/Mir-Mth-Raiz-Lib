import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import CashiersTable from "entities/CashierEssence/ui/CashiersTable/CashiersTable";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { useNavigate } from "react-router-dom";

const CashiersPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">Кассиры</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("/administrator/cashiers/create")}
          >
            Добавить кассира
          </Button>
        </UIFlexBetween>
        <SearchInfo />
      </UIFlexColumn>
      <CashiersTable />
    </UIFlexColumn>
  );
};

export default CashiersPage;

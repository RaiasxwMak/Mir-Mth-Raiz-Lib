import { useNavigate } from "react-router-dom";
import cls from "./NotFoundPage.module.scss";
import { FC } from "react";
import NotFound from "shared/assets/icon/notFound.svg?react";
import NotFoundBln from "shared/assets/icon/notFoundBln.svg?react";
import { Button, Typography } from "@geeks-online/uikit";

const NotFoundPage: FC = () => {
  const navigate = useNavigate();
  return (
    <div className={cls.nfpage}>
      <div className={cls.flexBox}>
        <div className={cls.box}>
          <NotFound />
          <div className={cls.line} />
          <div className={cls.texBox}>
            <Typography variant="Text1">Страница не найдена</Typography>
            <Button onClick={(): void => navigate("/administrator/")}>
              На главную
            </Button>
          </div>
          <NotFoundBln />
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;

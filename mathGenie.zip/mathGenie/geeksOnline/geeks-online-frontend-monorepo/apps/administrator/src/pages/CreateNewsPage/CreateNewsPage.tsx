import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import CreateNews from "entities/GeeksNews/ui/CreateNews/CreateNews";

const CreateNewsPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Добавить новости</Typography>
      <CreateNews />
    </UIFlexColumn>
  );
};

export default CreateNewsPage;

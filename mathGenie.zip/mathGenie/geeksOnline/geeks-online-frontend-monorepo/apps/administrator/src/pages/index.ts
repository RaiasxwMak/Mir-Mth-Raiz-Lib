import { lazy } from "react";

// profile
const AdminProfile = lazy(() => import("./AdminProfile/AdminProfile"));

// notFoundPage
const NotFoundPage = lazy(() => import("./NotFoundPage/NotFoundPage"));

//  Curator
const MainPage = lazy(() => import("./MainPage/MainPage"));
const CreateCuratorPage = lazy(
  () => import("./CreateCuratorPage/CreateCuratorPage")
);
const CuratorPage = lazy(() => import("./CuratorPage/CuratorPage"));

//  Cashier
const CashiersPage = lazy(() => import("./CashiersPage/CashiersPage"));
const CreateCashierPage = lazy(
  () => import("./CreateCashierPage/CreateCashierPage")
);
const CashierPage = lazy(() => import("./CashierPage/CashierPage"));

// DirectionsPage
const DirectionsPage = lazy(() => import("./DirectionsPage/DirectionsPage"));
const CreateDirectionsPage = lazy(
  () => import("./CreateDirectionsPage/CreateDirectionsPage")
);
const DirectionPage = lazy(() => import("./DirectionPage/DirectionPage"));

// Dicounts
const DiscountsPage = lazy(() => import("./DiscountsPage/DiscountsPage"));
const CreateDiscountsPage = lazy(
  () => import("./CreateDiscountsPage/CreateDiscountsPage")
);
const DiscountPage = lazy(() => import("./DiscountPage/DiscountPage"));

// Geekcoins
const GeekcoinsPage = lazy(() => import("./GeekcoinsPage/GeekcoinsPage"));
const CreateGeekcoinsPage = lazy(
  () => import("./CreateGeekcoinsPage/CreateGeekcoinsPage")
);
const GeekcoinPage = lazy(() => import("./GeekcoinPage/GeekcoinPage"));

const AnketaPage = lazy(() => import("./AnketaPage/AnketaPage"));

const StatisticsPage = lazy(() => import("./StatisticsPage/StatisticsPage"));

const GeekShopPage = lazy(() => import("./GeekShopPage/GeekShopPage"));
const ProductPage = lazy(() => import("./ProductPage/ProductPage"));
const CreateProductPage = lazy(
  () => import("./CreateProductPage/CreateProductPage")
);

const CreateNewsPage = lazy(() => import("./CreateNewsPage/CreateNewsPage"));
const NewsPage = lazy(() => import("./NewsPage/NewsPage"));
const NewsOnePage = lazy(() => import("./NewsOnePage/NewsOnePage"));

const ManagersPage = lazy(() => import("./ManagersPage/ManagersPage"));
const CreateManagerPage = lazy(
  () => import("./CreateManagerPage/CreateManagerPage")
);
const ManagerPage = lazy(() => import("./ManagerPage/ManagerPage"));

const OrdersPage = lazy(() => import("./OrdersPage/OrdersPage"));

export {
  MainPage,
  NotFoundPage,
  AdminProfile,
  CreateCuratorPage,
  CuratorPage,
  CashiersPage,
  CreateCashierPage,
  CashierPage,
  DirectionsPage,
  CreateDirectionsPage,
  DirectionPage,
  DiscountsPage,
  CreateDiscountsPage,
  DiscountPage,
  GeekcoinsPage,
  CreateGeekcoinsPage,
  GeekcoinPage,
  AnketaPage,
  StatisticsPage,
  GeekShopPage,
  CreateProductPage,
  ProductPage,
  NewsPage,
  CreateNewsPage,
  NewsOnePage,
  ManagersPage,
  CreateManagerPage,
  ManagerPage,
  OrdersPage,
};

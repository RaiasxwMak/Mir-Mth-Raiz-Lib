import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import ManagersTable from "entities/ManagersEssence/ui/ManagersTable";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { useNavigate } from "react-router-dom";

const ManagersPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">Менеджеры</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("/administrator/managers/create")}
          >
            Добавить менеджера
          </Button>
        </UIFlexBetween>
        <SearchInfo />
      </UIFlexColumn>
      <ManagersTable />
    </UIFlexColumn>
  );
};

export default ManagersPage;

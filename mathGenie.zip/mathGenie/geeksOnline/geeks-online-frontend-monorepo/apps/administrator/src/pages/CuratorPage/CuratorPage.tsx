import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import EditCurator from "entities/CuratorEssence/ui/EditCurator/EditCurator";

const CuratorPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Куратор</Typography>
      <EditCurator />
    </UIFlexColumn>
  );
};

export default CuratorPage;

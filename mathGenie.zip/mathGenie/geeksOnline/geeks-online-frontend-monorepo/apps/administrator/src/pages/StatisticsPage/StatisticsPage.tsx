import { TabsCustom, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { TabsProps } from "antd";
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import Transitions from "entities/StatisticsEssence/ui/Transitions/Transitions";
import StatsAndLineChart from "entities/StatisticsEssence/ui/StatsAndLineChart/StatsAndLineChart";
import MentorStatistics from "entities/StatisticsEssence/ui/MentorStatistics/MentorStatistics";

const StatisticsPage = () => {
  const [activeTab, setActiveTab] = useState("1");
  const [tabParam, setTabParam] = useSearchParams();

  const tabItems: TabsProps["items"] = [
    {
      key: "1",
      label: "Активные студенты",
      children: (
        <StatsAndLineChart
          title="Количество активных студентов: "
          tab={"1"}
          type="active-statistics"
        />
      ),
    },
    {
      key: "2",
      label: "Архивные студенты",
      children: (
        <StatsAndLineChart
          title="Количество архивных студентов: "
          tab={"2"}
          type="not-active-statistics"
          courseSelect
          isPeriodDate
        />
      ),
    },
    {
      key: "3",
      label: "Выпускники",
      children: (
        <StatsAndLineChart
          title="Количество выпускников: "
          tab={"3"}
          type="graduate-statistics"
          isPeriodDate
        />
      ),
    },
    {
      key: "4",
      label: "Переходы",
      children: <Transitions />,
    },
    {
      key: "5",
      label: "Менторы",
      children: <MentorStatistics isPeriodDate tab={"5"} />,
    },
  ];

  const handleChangeTab = (key: string): void => {
    setActiveTab(key);
    setTabParam(
      (prev) => {
        return { ...prev, tab: key };
      },
      { replace: true }
    );
  };

  useEffect(() => {
    if (!tabParam.get("tab")) {
      setTabParam(
        (prev) => {
          return { ...prev, tab: "1" };
        },
        { replace: true }
      );
    } else {
      setActiveTab(tabParam.get("tab") ?? "1");
    }
  }, [tabParam]);
  return (
    <UIFlexColumn gap={40}>
      <Typography variant="Title1">{"Статистика"}</Typography>
      <TabsCustom
        activeKey={activeTab}
        onChange={handleChangeTab}
        items={tabItems}
      />
    </UIFlexColumn>
  );
};

export default StatisticsPage;

import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { CreateCashier } from "entities/CashierEssence/ui/CreateCashier/CreateCashier";

const CreateCashierPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Кассир</Typography>
      <CreateCashier />
    </UIFlexColumn>
  );
};

export default CreateCashierPage;

import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import EditNews from "entities/GeeksNews/ui/EditNews/EditNews";

const NewsOnePage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Редактировать новость</Typography>
      <EditNews />
    </UIFlexColumn>
  );
};

export default NewsOnePage;

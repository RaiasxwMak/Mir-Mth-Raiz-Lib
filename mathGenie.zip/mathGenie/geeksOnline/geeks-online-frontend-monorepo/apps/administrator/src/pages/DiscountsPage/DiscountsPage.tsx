import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useNavigate } from "react-router-dom";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import DiscountsTable from "entities/DiscountEssence/ui/DiscountsTable/DiscountsTable";

const DiscountsPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">
            Скидки по направлениям
          </Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("/administrator/discounts/create")}
          >
            Добавить скидку
          </Button>
        </UIFlexBetween>
        <CourseSelect />
      </UIFlexColumn>
      <DiscountsTable />
    </UIFlexColumn>
  );
};

export default DiscountsPage;

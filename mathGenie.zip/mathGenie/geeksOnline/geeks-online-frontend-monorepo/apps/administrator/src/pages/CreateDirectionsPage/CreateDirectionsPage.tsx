import {
  GetBack,
  TabsCustom,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { TabsProps } from "antd";
import { CreateDirections } from "entities/DirectionEssence/ui/CreateDirections/CreateDirections";
import { useState } from "react";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";

const CreateDirectionsPage = () => {
  const openError = useOpenErrorAlert();

  const [activeTab, setActiveTab] = useState("1");

  const handleChangeTab = (key: string): void => {
    if (key === "2") {
      openError("Сначала создайте направление");
      return;
    }
    setActiveTab(key);
  };

  const tabItems: TabsProps["items"] = [
    {
      key: "1",
      label: "Направления филиала",
      children: <CreateDirections />,
    },
    {
      key: "2",
      label: "Учебный план",
      children: <></>,
    },
  ];

  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Направления филиала</Typography>
      <TabsCustom
        activeKey={activeTab}
        onChange={handleChangeTab}
        items={tabItems}
      />
    </UIFlexColumn>
  );
};

export default CreateDirectionsPage;

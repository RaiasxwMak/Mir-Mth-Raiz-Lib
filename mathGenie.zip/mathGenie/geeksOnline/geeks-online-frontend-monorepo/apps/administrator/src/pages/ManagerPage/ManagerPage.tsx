import { GetBack, Typography, UIFlexColumn } from "@geeks-online/uikit";
import { EditManager } from "entities/ManagersEssence/ui/EditManager";

const ManagerPage = () => {
  return (
    <UIFlexColumn gap={20}>
      <GetBack title={"Назад"} />
      <Typography variant="Title1">Менеджер</Typography>
      <EditManager />
    </UIFlexColumn>
  );
};

export default ManagerPage;

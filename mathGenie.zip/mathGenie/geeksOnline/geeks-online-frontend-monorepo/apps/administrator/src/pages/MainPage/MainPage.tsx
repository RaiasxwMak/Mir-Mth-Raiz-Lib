import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import CuratorsTable from "entities/CuratorEssence/ui/CuratorsTable/CuratorsTable";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { useNavigate } from "react-router-dom";

const MainPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">Кураторы</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("/administrator/curator/create")}
          >
            Добавить куратора
          </Button>
        </UIFlexBetween>
        <SearchInfo />
      </UIFlexColumn>
      <CuratorsTable />
    </UIFlexColumn>
  );
};

export default MainPage;

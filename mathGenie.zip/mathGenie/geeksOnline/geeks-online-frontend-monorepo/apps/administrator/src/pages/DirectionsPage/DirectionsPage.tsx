import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import DirectionsTable from "entities/DirectionEssence/ui/DirectionsTable/DirectionsTable";
import { SearchInfo } from "features/SearchInfo/ui/SearchInfo";
import { useNavigate } from "react-router-dom";

const DirectionsPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">Направления филиала</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("/administrator/directions/create")}
          >
            Добавить направление
          </Button>
        </UIFlexBetween>
        <SearchInfo />
      </UIFlexColumn>
      <DirectionsTable />
    </UIFlexColumn>
  );
};

export default DirectionsPage;

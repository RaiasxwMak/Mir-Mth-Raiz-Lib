import {
  Button,
  ThemeButton,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
} from "@geeks-online/uikit";
import GeekcoinsTable from "entities/GeekcoinEssence/ui/GeekcoinsTable/GeekcoinsTable";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useNavigate } from "react-router-dom";

const GeekcoinsPage = () => {
  const navigate = useNavigate();
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={20}>
        <UIFlexBetween>
          <Typography variant="Title1">Номиналы гиккоинов</Typography>
          <Button
            plus
            theme={ThemeButton.outline}
            onClick={() => navigate("/administrator/geekcoins/create")}
          >
            Добавить гиккоин
          </Button>
        </UIFlexBetween>
        <CourseSelect />
      </UIFlexColumn>
      <GeekcoinsTable />
    </UIFlexColumn>
  );
};

export default GeekcoinsPage;

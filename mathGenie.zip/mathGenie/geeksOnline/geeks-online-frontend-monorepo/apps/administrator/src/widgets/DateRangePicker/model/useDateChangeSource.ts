import { create } from "zustand";

interface IuseDateChangeSource {
  isUserAction: boolean;
  setIsUserAction: (value: boolean) => void;
}

export const useDateChangeSource = create<IuseDateChangeSource>((set) => ({
  isUserAction: false,

  setIsUserAction: (value) => {
    set({ isUserAction: value });
  },
}));

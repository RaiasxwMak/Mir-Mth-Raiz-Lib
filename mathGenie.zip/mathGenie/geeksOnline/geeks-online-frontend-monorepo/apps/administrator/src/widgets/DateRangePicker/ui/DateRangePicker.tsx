import { ConfigProvider, DatePicker } from "antd";
import { useEffect } from "react";
import { DateRange, useDateRangePicker } from "../model/useDateRangePicker";
import { CalendarOutlined, CloseCircleOutlined } from "@ant-design/icons";
import cls from "./DateRangePicker.module.scss";
import ru from "antd/lib/locale/ru_RU";
import { useDateChangeSource } from "../model/useDateChangeSource";
import { useSelectedPeriod } from "widgets/LineChart/model/useSelectedPeriod";
import { Dayjs } from "dayjs";

const { RangePicker } = DatePicker;

const antdConfig: any = {
  components: {
    DatePicker: {
      hoverBg: "transparent",
      hoverBorderColor: "inherit",
      cellActiveWithRangeBg: "#ffe743",
      activeBg: "transparent",
    },
  },
  token: {
    colorPrimary: "transparent",
    colorBgBase: "transparent",
    colorBorder: "#a7a7a7",
    colorText: "#fff",
    colorTextPlaceholder: "#FFFFFFB2",
    colorBgElevated: "#1E1E22",
    controlItemBgActive: "#0097FF",
    colorIcon: "#ffff",
  },
};

interface DateRangePickerProps {
  placeholder?: [string, string];
  width?: string;
  tab?: string;
  periodValue?: DateRange;
  onChangePeriod?: (param: DateRange) => void;
}

const DateRangePicker = ({
  placeholder,
  width,
  tab = "default",
  periodValue,
  onChangePeriod,
}: DateRangePickerProps) => {
  const { setSelectedDates } = useDateRangePicker();
  const { selectedPeriodReset } = useSelectedPeriod();

  const selectedDates = useDateRangePicker((state) =>
    tab ? state.selectedDatesByTab[tab] || [null, null] : [null, null]
  );

  const { setIsUserAction } = useDateChangeSource();

  const rangePickerValue: [Dayjs | null, Dayjs | null] = periodValue
    ? [periodValue[0], periodValue[1]]
    : [selectedDates[0] || null, selectedDates[1] || null];

  useEffect(() => {
    return () => {};
  }, [tab]);

  return (
    <ConfigProvider locale={ru} theme={antdConfig}>
      <div style={{ width: width || 200 }}>
        <RangePicker
          placeholder={placeholder}
          placement="bottomLeft"
          value={rangePickerValue}
          format={"DD.MM.YYYY"}
          clearIcon={<CloseCircleOutlined style={{ color: "#fff" }} />}
          suffixIcon={<CalendarOutlined style={{ color: "#fff" }} />}
          separator={false}
          onChange={(dates) => {
            setIsUserAction(true);

            const dateRange: DateRange = [
              dates?.[0] || null,
              dates?.[1] || null,
            ];

            if (onChangePeriod) {
              return onChangePeriod(dateRange);
            }

            if (tab) {
              setSelectedDates(dateRange, tab);
              selectedPeriodReset(tab);
            }
          }}
          className={cls.date}
        />
      </div>
    </ConfigProvider>
  );
};

export default DateRangePicker;

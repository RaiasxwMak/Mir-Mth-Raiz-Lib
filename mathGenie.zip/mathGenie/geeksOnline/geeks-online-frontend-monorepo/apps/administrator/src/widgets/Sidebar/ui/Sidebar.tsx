import { FC, useRef, useState, ReactNode, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import cls from "./Sidebar.module.scss";
import GeeksLogo from "shared/assets/icon/geeksLogo.svg?react";
import MainSvg from "shared/assets/icon/student.svg?react";
import CashiersSvg from "shared/assets/icon/teacher.svg?react";
import DirectionsSvg from "shared/assets/icon/directions.svg?react";
import DiscountsSvg from "shared/assets/icon/dicounts.svg?react";
import GeekcoinSvg from "shared/assets/icon/geekcoinSidebar.svg?react";
import AnketaSvg from "shared/assets/icon/anketaSvg.svg?react";
import NewSvg from "shared/assets/icon/news.svg?react";
import StatisticsSvg from "shared/assets/icon/statistics.svg?react";
import ShopSvg from "shared/assets/icon/shopIcon.svg?react";
import Geeks from "shared/assets/icon/geeks.svg?react";
import OpenClose from "shared/assets/icon/open-close.svg?react";
import classNames from "classnames";
import { Button, TooltipWrapper, Typography } from "@geeks-online/uikit";
import { COOKIE_USER_ROLE, scrollTop } from "@geeks-online/shared";
import { ButtonNavLink } from "shared/ui";
import { cookie } from "shared/lib/cookie/cookie";
import { ROLE_MANAGER } from "shared/lib/consts/consts";

interface SidebarProps {
  className?: string;
}

interface LinksItems {
  title: string;
  to: string;
  Icon: ReactNode;
}

const links: LinksItems[] = [
  {
    title: "Кураторы",
    to: "/administrator/",
    Icon: <MainSvg />,
  },
  {
    title: "Менеджеры",
    to: "/administrator/managers",
    Icon: <MainSvg />,
  },
  {
    title: "Кассиры",
    to: "/administrator/cashiers/",
    Icon: <CashiersSvg />,
  },
  {
    title: "Направления",
    to: "/administrator/directions/",
    Icon: <DirectionsSvg />,
  },
  {
    title: "Скидки",
    to: "/administrator/discounts",
    Icon: <DiscountsSvg />,
  },
  {
    title: "Гиккоины",
    to: "/administrator/geekcoins",
    Icon: <GeekcoinSvg />,
  },
  {
    title: "Анкеты",
    to: "/administrator/anketa",
    Icon: <AnketaSvg />,
  },
  {
    title: "Статистика",
    to: "/administrator/statistics",
    Icon: <StatisticsSvg />,
  },
  {
    title: "Новости",
    to: "/administrator/news",
    Icon: <NewSvg />,
  },
];

const managerLinks = [
  {
    title: "Geeks Shop",
    to: "/administrator/geekshop",
    Icon: <NewSvg />,
  },
  {
    title: "Geeks Shop заказы",
    to: "/administrator/geekshop/orders",
    Icon: <ShopSvg />,
  },
];

const ANIMATION_OPENCLOSE_DELAY = 100;

export const Sidebar: FC<SidebarProps> = ({ className = "" }) => {
  const isManager = cookie.getCookie(COOKIE_USER_ROLE) === ROLE_MANAGER;

  const [collapsed, setCollapsed] = useState<boolean>(true);
  const navigate = useNavigate();
  const closeRef = useRef<null | ReturnType<typeof setTimeout>>(null);
  const handleChangeCollapse = (): void => {
    if (closeRef.current) {
      clearTimeout(closeRef.current);
    }
    closeRef.current = setTimeout(() => {
      setCollapsed((prev) => !prev);
    }, ANIMATION_OPENCLOSE_DELAY);
  };

  const sidebarLinks = useMemo(
    () => (isManager ? managerLinks : links),
    [isManager]
  );

  return (
    <div className={cls.centerSidebar}>
      <div
        onClick={handleChangeCollapse}
        className={classNames(
          cls.sidebar,
          { [cls.collapsed]: collapsed },
          className
        )}
      >
        <div
          className={cls.logo}
          onClick={(e): void => {
            e.stopPropagation();
            navigate("/administrator/");
            scrollTop();
          }}
        >
          <Geeks className={cls.title} />
          <GeeksLogo className={cls.iconLogo} />
        </div>
        <div className={cls.links}>
          {sidebarLinks.map((elm: LinksItems, i) => (
            <ButtonNavLink
              tooltip={!collapsed}
              key={i}
              Icon={elm.Icon}
              to={elm.to}
              className={cls.buttonlink}
            >
              {elm.title}
            </ButtonNavLink>
          ))}
          <TooltipWrapper title={"Открыть"} show={!collapsed}>
            <Button
              className={classNames(
                cls.iconButton,
                { [cls.iconRotate]: !collapsed },
                []
              )}
            >
              <OpenClose />
              <Typography className={cls.iconTitle} variant="Body1">
                Закрыть
              </Typography>
            </Button>
          </TooltipWrapper>
        </div>
      </div>
    </div>
  );
};

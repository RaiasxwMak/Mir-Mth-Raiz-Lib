import { create } from "zustand";
import dayjs, { Dayjs } from "dayjs";

interface IuseSelectDate {
  selectDate: Dayjs | null;
  changeSelectDate: (param: Dayjs | null) => void;
  resetSelectDate: () => void;

  selectDateByTab: Record<string, Dayjs | null>;
  changeSelectDateForTab: (param: Dayjs | null, tab: string) => void;
  resetSelectDateForTab: (tab: string) => void;
  getSelectDateForTab: (tab: string) => Dayjs | null;
}

export const useSelectDate = create<IuseSelectDate>((set, get) => ({
  selectDate: dayjs(),

  changeSelectDate: (param: Dayjs | null) => {
    set({ selectDate: param });
  },

  resetSelectDate: () => {
    set({ selectDate: dayjs() });
  },

  selectDateByTab: {},

  changeSelectDateForTab: (param: Dayjs | null, tab: string) => {
    set((state) => ({
      selectDateByTab: {
        ...state.selectDateByTab,
        [tab]: param,
      },
    }));
  },

  resetSelectDateForTab: (tab: string) => {
    set((state) => ({
      selectDateByTab: {
        ...state.selectDateByTab,
        [tab]: dayjs(),
      },
    }));
  },

  getSelectDateForTab: (tab: string) => {
    const state = get();
    return state.selectDateByTab[tab] || dayjs();
  },
}));

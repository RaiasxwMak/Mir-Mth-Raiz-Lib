import cls from "./Header.module.scss";
import { FC, useMemo, useRef } from "react";
import { Avatar } from "antd";
import { UserOutlined } from "@ant-design/icons";
import classNames from "classnames";
import ArrowDrop from "shared/assets/icon/arrowDrop.svg?react";
import ProfileMan from "shared/assets/icon/profileMan.svg?react";
import Arrow from "shared/assets/icon/arrowAccordion.svg?react";
import type { MenuProps } from "antd";
import { Link, useNavigate } from "react-router-dom";
import { cookie } from "shared/lib/cookie/cookie";
import { useFetchProfile } from "entities/ProfileInfo/model/useFetchProfile";
import { ScrollDirection, useScrollDirection } from "@geeks-online/shared";
import { CustomDropDown, Typography } from "@geeks-online/uikit";
import {
  COOKIE_ACCESS_TOKEN_KEY,
  COOKIE_REFRESH_TOKEN_KEY,
  COOKIE_TOKEN_TYPE_KEY,
  COOKIE_USER_KEY,
  COOKIE_USER_ROLE,
} from "shared/lib/consts/consts";

const sizeOFAvatar = 44;

export const Header: FC = () => {
  const { data } = useFetchProfile();

  const navigate = useNavigate();
  const scrollDirection: ScrollDirection = useScrollDirection();

  const User = data?.user;
  const fullName = User?.full_name.split(" ");
  const headerRef = useRef<HTMLHeadElement | null>(null);
  const name: string | undefined = fullName?.[0];
  const surName: string | undefined = fullName?.[1];
  const AvatarIconName = `${name?.[0]} ${surName?.[0] ? surName[0] : ""}`;
  const url: string | undefined = User?.photo && User.photo;
  const isScrollDown = scrollDirection === "down";

  const handleLogOut = (): void => {
    cookie.removeCookie(COOKIE_ACCESS_TOKEN_KEY);
    cookie.removeCookie(COOKIE_REFRESH_TOKEN_KEY);
    cookie.removeCookie(COOKIE_TOKEN_TYPE_KEY);
    cookie.removeCookie(COOKIE_USER_KEY);
    cookie.removeCookie(COOKIE_USER_ROLE);
    navigate("/");
    location.reload();
  };

  const menuDrop = (): MenuProps["items"] =>
    useMemo(() => {
      const items: MenuProps["items"] = [
        ...(data?.user.is_manager
          ? []
          : [
              {
                label: <Link to={"/administrator/profile"}>Профиль</Link>,
                key: "0",
                icon: <ProfileMan />,
              },
            ]),
        {
          label: (
            <Link to={"/"} onClick={() => handleLogOut()}>
              Выйти
            </Link>
          ),
          key: "1",
          icon: <ArrowDrop />,
        },
      ];
      return items;
    }, [data]);

  return (
    <header
      ref={headerRef}
      className={classNames(cls.header, { [cls.hidden]: isScrollDown }, [])}
    >
      <CustomDropDown classForDropdown={cls.dropdown} MenuItems={menuDrop()}>
        <div className={cls.profile}>
          <Avatar
            src={url ?? <UserOutlined />}
            size={sizeOFAvatar}
            className={cls.avatar}
          >
            {AvatarIconName}
          </Avatar>
          <Typography className={cls.name} variant="Text4">
            {name ?? "User"}
            <br />
            {surName ?? "User"}
          </Typography>
          <Arrow className={cls.arrowSvg} />
        </div>
      </CustomDropDown>
    </header>
  );
};

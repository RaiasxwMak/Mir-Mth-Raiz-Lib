import { FC } from "react";
import classes from "./SmallScreenFiller.module.scss";
import logo from "shared/assets/icon/logo.svg";

const SmallScreenFiller: FC = () => {
  return (
    <div className={classes.container}>
      <div className={classes.wrapper}>
        <img src={logo} alt="logo" className={classes.logo} />
        <div className={classes.textContent}>
          <p className={classes.title}>Geeks Online</p>
          <p className={classes.subTitle}>
            доступен для использования только на ПК
          </p>
        </div>
      </div>
    </div>
  );
};

export default SmallScreenFiller;

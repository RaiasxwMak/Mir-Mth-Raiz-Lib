import { FC, useMemo } from "react";
import {
  CustomSelect,
  EmptyState,
  IOption,
  Loader,
  Typography,
  UIFlexBetween,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { Pie } from "@ant-design/charts";
import { StatsFilter } from "shared/ui";
import { IStats } from "shared/globalTypes/globalTypes";
import CalendarDate from "widgets/CalendarDate/ui/CalendarDate";
import cls from "./Statistics.module.scss";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { Dayjs } from "dayjs";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";
import { DateRange } from "widgets/DateRangePicker/model/useDateRangePicker";
import { PERIOD_OPTION } from "shared/lib/consts/consts";

interface StatisticsProps {
  title: string;
  count: number;
  handleFilter: (param: string) => void;
  stats: IStats[] | null;
  loader: boolean;
  courseSelect?: boolean;
  dateValue?: Dayjs | null;
  onChangeDate?: (param: Dayjs | null) => void;
  isPeriodDate?: boolean;
  periodValue?: DateRange;
  setPeriodValue?: (param: DateRange) => void;
  selectPeriod?: IOption | null;
  setSelectPeriod?: (param: IOption | null) => void;
  tab: string;
}

const Statistics: FC<StatisticsProps> = ({
  title,
  count,
  handleFilter,
  stats,
  loader,
  courseSelect,
  dateValue,
  onChangeDate,
  isPeriodDate,
  periodValue,
  setPeriodValue,
  selectPeriod,
  setSelectPeriod,
  tab,
}) => {
  const filteredStats = useMemo(() => {    
    return (stats ?? []).filter((item: IStats) => item?.value !== undefined);
  }, [stats]);
  const total = useMemo(() => {
    return filteredStats.reduce(
      (acc, item: IStats) => acc + (item?.value ?? 0),
      0
    );
  }, [filteredStats]);

  const config = useMemo(() => {
    return {
      data: filteredStats,
      scale: {
        color: {
          palette: filteredStats.map((item) => item.color),
        },
      },
      angleField: "value",
      colorField: "type",
      innerRadius: 0.5,
      label: {
        text: (data:IStats) => (data.value ?? 0) > 0 ? data.value : '',
        style: {
          fontSize: 14,
        },
      },
      tooltip: (data: IStats) => {
        const percent = total ? ((data.value! / total) * 100).toFixed(1) : "0";
        return {
          name: data.type,
          value: `${data.value} (${percent}%)`,
        };
      },
      legend: false,
    };
  }, [filteredStats, total]);

  const hasData = stats && stats.length > 0;
  const hasVisibleData = filteredStats.length > 0;

  return (
    <div className={cls.wrap}>
      <UIFlexBetween>
        <Typography variant="Title1">
          {title}
          {count}
        </Typography>
        <UIFlexRow gap={20}>
          {courseSelect && <CourseSelect tab={tab} />}
          {!isPeriodDate && (
            <CalendarDate
              dateValue={dateValue}
              onChangeDate={onChangeDate}
              tab={tab}
            />
          )}
          {isPeriodDate && (
            <UIFlexColumn gap={20}>
              <CustomSelect
                isArrow
                width={"256px"}
                onChange={setSelectPeriod}
                value={selectPeriod}
                options={PERIOD_OPTION}
                height={"40px"}
                placeholder={"Выберите период"}
              />
              <DateRangePicker
                periodValue={periodValue}
                onChangePeriod={setPeriodValue}
                placeholder={["Выберите", "дату"]}
                width="256px"
              />
            </UIFlexColumn>
          )}
        </UIFlexRow>
      </UIFlexBetween>

      {hasData ? (
        <div className={cls.wrapStats}>
          <div className={cls.stats}>
            {loader ? (
              <Loader height="360px" />
            ) : hasVisibleData ? (
              <Pie {...config} width={360} height={360} />
            ) : (
              <EmptyState
                text={
                  "Нет данных для отображения. Попробуйте изменить фильтры."
                }
              />
            )}
          </div>
          <div className={cls.filters}>
            <StatsFilter
              data={stats ?? []}
              handleFilter={handleFilter}
              hideValue={false}
            />
          </div>
        </div>
      ) : (
        <EmptyState text={"Здесь пока ничего нет"} />
      )}
    </div>
  );
};

export default Statistics;

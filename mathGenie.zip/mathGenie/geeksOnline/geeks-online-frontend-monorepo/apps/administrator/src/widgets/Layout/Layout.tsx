import { Loader } from "@geeks-online/uikit";
import { Suspense } from "react";
import { Outlet } from "react-router-dom";
import { Header } from "widgets/Header";
import { Sidebar } from "widgets/Sidebar";

export const Layout = () => {
  return (
    <div className="app">
      <Header />
      <Sidebar />
      <Suspense fallback={<Loader />}>
        <div className="page-wrapper">
          <Outlet />
        </div>
      </Suspense>
    </div>
  );
};

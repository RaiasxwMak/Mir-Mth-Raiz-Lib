import { create } from "zustand";
import { Dayjs } from "dayjs";

export type DateRange = [Dayjs | null, Dayjs | null];

interface IuseDateRangePicker {
  selectedDatesByTab: Record<string, DateRange>;
  setSelectedDates: (dates: DateRange, tab: string) => void;
  selectedDatesReset: (tab?: string) => void;
  getSelectedDatesForTab: (tab: string) => DateRange;
}

export const useDateRangePicker = create<IuseDateRangePicker>((set, get) => ({
  selectedDatesByTab: {},

  setSelectedDates: (param, tab) => {
    set((state) => ({
      selectedDatesByTab: {
        ...state.selectedDatesByTab,
        [tab]: param,
      },
    }));
  },

  selectedDatesReset: (tab) => {
    if (tab) {
      set((state) => ({
        selectedDatesByTab: {
          ...state.selectedDatesByTab,
          [tab]: [null, null],
        },
      }));
    } else {
      set({ selectedDatesByTab: {} });
    }
  },

  getSelectedDatesForTab: (tab) => {
    const dates = get().selectedDatesByTab[tab];
    return dates ? [dates[0], dates[1]] : [null, null];
  },
}));

import { create } from "zustand";
import { IOption } from "@geeks-online/uikit";

interface IuseSelectedPeriod {
  selectedPeriodByTab: Record<string, IOption | null>;
  setSelectedPeriod: (option: IOption | null, tab: string) => void;
  selectedPeriodReset: (tab?: string) => void;
  getSelectedPeriodForTab: (tab: string) => IOption | null;
}

export const useSelectedPeriod = create<IuseSelectedPeriod>((set, get) => ({
  selectedPeriodByTab: {},

  setSelectedPeriod: (param, tab) => {
    set((state) => ({
      selectedPeriodByTab: {
        ...state.selectedPeriodByTab,
        [tab]: param,
      },
    }));
  },

  selectedPeriodReset: (tab) => {
    if (tab) {
      set((state) => ({
        selectedPeriodByTab: {
          ...state.selectedPeriodByTab,
          [tab]: null,
        },
      }));
    } else {
      set({ selectedPeriodByTab: {} });
    }
  },

  getSelectedPeriodForTab: (tab) => {
    return get().selectedPeriodByTab[tab] || null;
  },
}));

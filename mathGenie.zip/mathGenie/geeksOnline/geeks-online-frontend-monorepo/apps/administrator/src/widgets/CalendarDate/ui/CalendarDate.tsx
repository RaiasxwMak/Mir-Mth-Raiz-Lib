import { useSelectDate } from "../model/useSelectDate";
import { ConfigProvider, DatePicker } from "antd";
import { Dayjs } from "dayjs";
import ru_RU from "antd/lib/locale/ru_RU";
import { ThemeConfig } from "antd/lib";
import IconArrow from "shared/assets/icon/arrowAccordion.svg?react";
import cls from "./CalendarDate.module.scss";
import { FC } from "react";

const antdConfig: ThemeConfig = {
  token: {
    colorPrimary: "#DDDBDA",
    colorBgBase: "#a7a7a7",
    colorBorder: "#a7a7a7",
    colorText: "#fff",
    colorTextPlaceholder: "#FFFFFFB2",
    colorBgElevated: "#1E1E22",
    controlItemBgActive: "#0097FF",
    colorIcon: "#fff",
  },
};

interface IProps {
  dateValue?: Dayjs | null;
  onChangeDate?: (param: Dayjs | null) => void;
  tab?: string;
}

const CalendarDate: FC<IProps> = ({ dateValue, onChangeDate, tab }) => {
  const {
    selectDate,
    changeSelectDate,
    getSelectDateForTab,
    changeSelectDateForTab,
  } = useSelectDate();

  const currentDate = tab ? getSelectDateForTab(tab) : selectDate;
  const handleChange = tab
    ? (date: Dayjs | null) => changeSelectDateForTab(date, tab)
    : changeSelectDate;

  const handleDatePickerChange = (e?: Dayjs | null): void => {
    if (e) {
      if (onChangeDate) {
        onChangeDate(e);
      } else {
        handleChange(e);
      }
    }
  };

  return (
    <ConfigProvider locale={ru_RU} theme={antdConfig}>
      <DatePicker
        value={dateValue || currentDate}
        className={cls.datePicker}
        format={"DD-MM-YYYY"}
        allowClear={false}
        bordered={false}
        inputReadOnly
        superNextIcon={false}
        superPrevIcon={false}
        showToday={false}
        suffixIcon={<IconArrow />}
        onChange={handleDatePickerChange}
      />
    </ConfigProvider>
  );
};

export default CalendarDate;

import { LineChart } from "widgets/LineChart/LineChart";
import { useEffect, useCallback, useRef } from "react";
import { useSelectedPeriod } from "widgets/LineChart/model/useSelectedPeriod";
import { useDateChangeSource } from "widgets/DateRangePicker/model/useDateChangeSource";
import {
  useDateRangePicker,
  DateRange,
} from "widgets/DateRangePicker/model/useDateRangePicker";
import DateRangePicker from "widgets/DateRangePicker/ui/DateRangePicker";
import dayjs from "dayjs";
import { CountBy } from "entities/StatisticsEssence/type/statisticsChartsType";
import { useStatisticsCharts } from "entities/StatisticsEssence/model/useStatisticsCharts";
import { CustomSelect, IOption, UIFlexRow } from "@geeks-online/uikit";
import cls from "./StatisticsLineChart.module.scss";
import { useSearchParams } from "react-router-dom";
import { PERIOD_OPTION } from "shared/lib/consts/consts";

interface StatisticsLineChartProps {
  countBy: CountBy;
  tab: string;
}

const StatisticsLineChart = ({ countBy, tab }: StatisticsLineChartProps) => {
  const {
    getStatistics,
    statisticsChartData,
    dataLoading: tatisticsChartLoading,
    handleFilter: handleStatisticsChart,
    getChartDataForTab,
  } = useStatisticsCharts();

  const [tabParam] = useSearchParams();

  const { setSelectedDates } = useDateRangePicker();
  const selectedDates = useDateRangePicker(
    (state) => state.selectedDatesByTab[tab] || [null, null]
  );

  const { setSelectedPeriod } = useSelectedPeriod();
  const selectedPeriod = useSelectedPeriod(
    (state) => state.selectedPeriodByTab[tab] || null
  );

  const { isUserAction, setIsUserAction } = useDateChangeSource();

  const chartData = getChartDataForTab(tab);

  const isComponentMounted = useRef(false);
  const isInitialized = useRef(false);
  const lastRequestParams = useRef<string>("");

  const handleFilterWithTab = useCallback(
    (param: string) => {
      handleStatisticsChart(param, tab);
    },
    [handleStatisticsChart, tab]
  );

  const handleChange = useCallback(
    (val: IOption) => {
      setSelectedPeriod(val, tab);
      const months = Number(val.value);
      const newDates: DateRange = [dayjs().subtract(months, "month"), dayjs()];
      setIsUserAction(true);
      setSelectedDates(newDates, tab);
    },
    [setSelectedPeriod, setSelectedDates, setIsUserAction, tab]
  );

  useEffect(() => {
    const currentTab = tabParam.get("tab");
    const isActiveTab = currentTab === tab;
    if (!isComponentMounted.current) {
      isComponentMounted.current = true;
      const hasExistingDates =
        selectedDates && selectedDates.some((date) => date !== null);
      if (!hasExistingDates) {
        const defaultDates: DateRange = [dayjs().subtract(1, "month"), dayjs()];
        setSelectedDates(defaultDates, tab);
        return;
      }
    }

    if (!isActiveTab) {
      return;
    }

    const hasValidDates =
      selectedDates &&
      selectedDates.length === 2 &&
      selectedDates[0] &&
      selectedDates[1];

    if (!hasValidDates) {
      return;
    }

    const requestKey = `${selectedDates[0]!.format(
      "YYYY-MM-DD"
    )}_${selectedDates[1]!.format("YYYY-MM-DD")}_${countBy}_${tab}`;
    const cacheKey = `${selectedDates[0]!.format(
      "YYYY-MM-DD"
    )}_${selectedDates[1]!.format("YYYY-MM-DD")}_${countBy}`;

    if (lastRequestParams.current === requestKey) {
      return;
    }

    const existingData = getChartDataForTab(tab);
    if (existingData && (existingData as any).cacheKey === cacheKey) {
      lastRequestParams.current = requestKey;
      return;
    }
    lastRequestParams.current = requestKey;

    getStatistics(
      {
        start_date: selectedDates[0]!.format("YYYY-MM-DD"),
        end_date: selectedDates[1]!.format("YYYY-MM-DD"),
        count_by: countBy,
      },
      tab
    );

    if (isUserAction) {
      setIsUserAction(false);
    }
  }, [
    selectedDates,
    tab,
    tabParam,
    countBy,
    getStatistics,
    getChartDataForTab,
    setSelectedDates,
    isUserAction,
    setIsUserAction,
  ]);

  useEffect(() => {
    return () => {
      isComponentMounted.current = false;
      isInitialized.current = false;
      lastRequestParams.current = "";
    };
  }, []);

  return (
    <div className={cls.wrap}>
      <UIFlexRow justifyContent="end" gap={20}>
        <CustomSelect
          isArrow
          width={"256px"}
          onChange={handleChange}
          value={selectedPeriod}
          options={PERIOD_OPTION}
          height={"40px"}
          placeholder={"Выберите период"}
        />
        <DateRangePicker
          placeholder={["Выберите", "дату"]}
          width="220px"
          tab={tab}
        />
      </UIFlexRow>
      <LineChart
        data={statisticsChartData}
        loading={tatisticsChartLoading}
        handleFilter={handleFilterWithTab}
        chartData={chartData}
        selectedDates={selectedDates}
      />
    </div>
  );
};

export default StatisticsLineChart;

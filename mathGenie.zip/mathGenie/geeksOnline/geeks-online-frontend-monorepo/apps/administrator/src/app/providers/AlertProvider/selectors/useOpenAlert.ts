import { useContext } from "react";
import { AlertContext } from "../model/context";

export const useOpenAlert = () => {
  const alertConfig = useContext(AlertContext);

  return alertConfig.openNotification;
};

export const useOpenErrorAlert = () => {
  const alertConfig = useContext(AlertContext);

  return alertConfig.openFailNotification;
};

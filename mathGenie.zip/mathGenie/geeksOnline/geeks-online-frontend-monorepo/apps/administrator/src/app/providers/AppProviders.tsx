import { ReactNode } from "react";
import { AuthProvider } from "./AuthProvider/AuthProvider";
import AlertProvider from "./AlertProvider/AlertProvider";

export const AppProvider = ({ children }: { children: ReactNode }) => {
  return (
    <AlertProvider>
      <AuthProvider>{children}</AuthProvider>
    </AlertProvider>
  );
};

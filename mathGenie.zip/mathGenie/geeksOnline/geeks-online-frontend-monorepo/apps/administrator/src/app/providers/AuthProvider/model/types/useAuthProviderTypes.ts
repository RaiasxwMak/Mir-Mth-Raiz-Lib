export interface IAuthResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user: IUser;
}

export interface IUser {
  email: string;
  full_name: string;
  //   groups: IGroup[];
  is_active: boolean;
  is_deleted: boolean;
  is__staff: boolean;
  is_student: boolean;
  is_teacher: boolean;
  phone: string;
  telegram: string;
  username: string;
  photo: string;
  id: string;
  role: string;
}

import { create } from "zustand";
import { IAuthResponse } from "./types/useAuthProviderTypes";

export interface UseAuthProviderType {
  authData: IAuthResponse | null;
  isAuth: boolean;
  login: () => void;
  logout: () => void;
}

export const useAuthProvider = create<UseAuthProviderType>((set) => ({
  authData: null,
  isAuth: false,
  login: () => set({ isAuth: true }),
  logout: () => set({ isAuth: false }),
}));

import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider,
} from "react-router-dom";
import { AppProvider } from "app/providers/AppProviders";
import { Layout } from "widgets/Layout/Layout";
import { adminRoutes, managerRoutes } from "../routerConfig/routes";
import { NotFoundPage } from "pages";
import { cookie } from "shared/lib/cookie/cookie";
import { COOKIE_USER_ROLE } from "@geeks-online/shared";
import { ROLE_MANAGER } from "shared/lib/consts/consts";
import { useMemo } from "react";

export const AppRouter = () => {
  const isManager = cookie.getCookie(COOKIE_USER_ROLE) === ROLE_MANAGER;

  const roleRoutes = useMemo(
    () => (isManager ? managerRoutes : adminRoutes),
    [isManager]
  );

  const router = createBrowserRouter(
    createRoutesFromElements(
      <Route
        path="/"
        element={
          <AppProvider>
            <Layout />
          </AppProvider>
        }
      >
        {roleRoutes.map(({ path, element, index }) => (
          <Route key={path} index={index} path={path} element={element} />
        ))}
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    )
  );

  return <RouterProvider router={router} />;
};

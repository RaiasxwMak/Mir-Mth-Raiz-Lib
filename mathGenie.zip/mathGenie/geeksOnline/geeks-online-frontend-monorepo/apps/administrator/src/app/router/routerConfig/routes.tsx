import {
  AdminProfile,
  AnketaPage,
  CashierPage,
  CashiersPage,
  CreateCashierPage,
  CreateCuratorPage,
  CreateDirectionsPage,
  CreateDiscountsPage,
  CreateGeekcoinsPage,
  CreateManagerPage,
  CreateNewsPage,
  CreateProductPage,
  CuratorPage,
  DirectionPage,
  DirectionsPage,
  DiscountPage,
  DiscountsPage,
  GeekcoinPage,
  GeekcoinsPage,
  GeekShopPage,
  MainPage,
  ManagerPage,
  ManagersPage,
  NewsOnePage,
  NewsPage,
  OrdersPage,
  ProductPage,
  StatisticsPage,
} from "pages";

import { RouteObject } from "react-router-dom";

export const adminRoutes: RouteObject[] = [
  { path: "/administrator/", element: <MainPage />, index: true },

  { path: "/administrator/managers", element: <ManagersPage /> },
  { path: "/administrator/managers/create", element: <CreateManagerPage /> },
  { path: "/administrator/manager/:id/:user_id", element: <ManagerPage /> },

  { path: "/administrator/profile", element: <AdminProfile /> },

  { path: "/administrator/curator/create", element: <CreateCuratorPage /> },
  { path: "/administrator/curator/:id/:user_id", element: <CuratorPage /> },

  { path: "/administrator/cashiers/", element: <CashiersPage /> },
  { path: "/administrator/cashiers/create/", element: <CreateCashierPage /> },
  { path: "/administrator/cashiers/:id/:user_id", element: <CashierPage /> },

  { path: "/administrator/directions/", element: <DirectionsPage /> },
  {
    path: "/administrator/directions/create",
    element: <CreateDirectionsPage />,
  },
  { path: "/administrator/directions/:id", element: <DirectionPage /> },

  { path: "/administrator/discounts", element: <DiscountsPage /> },
  { path: "/administrator/discounts/create", element: <CreateDiscountsPage /> },
  { path: "/administrator/discounts/:id", element: <DiscountPage /> },

  { path: "/administrator/geekcoins", element: <GeekcoinsPage /> },
  { path: "/administrator/geekcoins/create", element: <CreateGeekcoinsPage /> },
  { path: "/administrator/geekcoins/:id", element: <GeekcoinPage /> },

  { path: "/administrator/anketa", element: <AnketaPage /> },

  { path: "/administrator/statistics", element: <StatisticsPage /> },

  { path: "/administrator/news", element: <NewsPage /> },
  { path: "/administrator/news/:id/", element: <NewsOnePage /> },
  { path: "/administrator/news/create", element: <CreateNewsPage /> },
];

export const managerRoutes: RouteObject[] = [
  { path: "/administrator/geekshop", element: <GeekShopPage />, index: true },
  { path: "/administrator/geekshop/:id/", element: <ProductPage /> },
  { path: "/administrator/geekshop/create", element: <CreateProductPage /> },
  { path: "/administrator/geekshop/orders", element: <OrdersPage /> },
];

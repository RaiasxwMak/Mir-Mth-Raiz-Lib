import cls from "./AlertProvider.module.scss";
import { notification } from "antd";
import { FC, ReactNode, useEffect } from "react";
import { AlertContext, IAlertContext } from "./model/context";
import { requester } from "shared/configs/axios/axiosConfig";

interface IAlertProvider {
  children: ReactNode;
}

const AlertProvider: FC<IAlertProvider> = ({ children }) => {
  const [api, contextHolder] = notification.useNotification();

  const openNotification = (message: string): void => {
    api.open({
      message,
      className: cls.alert,
      duration: 3,
    });
  };

  const openFailNotification = (message: string): void => {
    api.open({
      message,
      className: `${cls.alert}  ${cls.fail}`,
      duration: 3,
    });
  };

  useEffect(() => {
    (window as unknown as IAlertContext).openNotification = openNotification;
    (window as unknown as IAlertContext).openFailNotification =
      openFailNotification;

    requester.interceptors.response.use(
      (config) => config,
      (error) => {
        if (error.response.data.message)
          openFailNotification(error.response.data.detail);
        return Promise.reject(error);
      }
    );
  }, []);
  return (
    <AlertContext.Provider value={{ openNotification, openFailNotification }}>
      {contextHolder}
      {children}
    </AlertContext.Provider>
  );
};

export default AlertProvider;

import ReactDOM from "react-dom/client";
import "app/styles/index.scss";
import App from "app/App";
import { ErrorBoundary } from "widgets/ErrorBoundary";
import { ErrorBlock } from "@geeks-online/uikit";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import dayjs from "dayjs";
import "dayjs/locale/ru";
import customPlugin from "dayjs/plugin/customParseFormat";

dayjs.extend(customPlugin);
dayjs.locale("ru");

const client = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
    },
  },
});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <QueryClientProvider client={client}>
    <ErrorBoundary fallback={<ErrorBlock />}>
      <App />
    </ErrorBoundary>
  </QueryClientProvider>
);

import { CustomSelect, IOption } from "@geeks-online/uikit";
import { useFilterSelect } from "../model/useFilterSelect";
import { useEffect } from "react";

const FilterSelect = ({
  width = "256px",
  options,
}: {
  width?: string;
  options: IOption[];
}) => {
  const { onChangeFilterSelects, filterSelect, onClearFilterSelects } =
    useFilterSelect();

  useEffect(() => {
    return () => onClearFilterSelects();
  }, []);
  return (
    <CustomSelect
      isArrow
      width={width}
      onChange={onChangeFilterSelects}
      value={filterSelect}
      options={options}
      height={"40px"}
      placeholder={"Все"}
    />
  );
};

export default FilterSelect;

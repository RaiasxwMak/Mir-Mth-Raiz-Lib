import {
  Button,
  Loader,
  ThemeButton,
  Typography,
  UIModal,
} from "@geeks-online/uikit";
import { useState } from "react";
import cls from "./RecoveryFromArchive.module.scss";

const RecoveryFromArchive = ({
  mutateAsync,
  isLoading,
  title,
}: {
  mutateAsync: () => Promise<unknown>;
  isLoading: boolean;
  title: string;
}) => {
  const [openModal, setOpenModal] = useState(false);

  const handleClickRequest = async () => {
    try {
      await mutateAsync();
      setOpenModal(false);
    } catch (e) {
      throw e;
    }
  };
  return (
    <div>
      <Button
        className={cls.button}
        theme={ThemeButton.contained}
        onClick={() => setOpenModal(true)}
      >
        {title}
      </Button>
      <UIModal
        modalWidth={"400px"}
        className={cls.modal}
        themeCancelBtn={ThemeButton.outline}
        themeOkBtn={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        okTitle={isLoading ? <Loader small /> : "Да"}
        cancelTitle={"Нет"}
        open={openModal}
        onOkRequest={handleClickRequest}
        onCancel={() => setOpenModal(false)}
      >
        <Typography variant="Title2" className={cls.modal_title}>
          {title}
        </Typography>
        <Typography variant="Text1" className={cls.subtitle}>
          Вы уверены, что хотите восстановить ?
        </Typography>
      </UIModal>
    </div>
  );
};

export default RecoveryFromArchive;

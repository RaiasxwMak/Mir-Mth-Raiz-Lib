import { useQuery } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS: Record<string, string> = {
  YEARS: "/api/v1/cashier/years/",
};

const queryKeyYears= "years";

export const useFetchYears = () => {
  return useQuery<number[]>({
    queryKey: [queryKeyYears],
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.YEARS);
      return data;
    },
  });
};

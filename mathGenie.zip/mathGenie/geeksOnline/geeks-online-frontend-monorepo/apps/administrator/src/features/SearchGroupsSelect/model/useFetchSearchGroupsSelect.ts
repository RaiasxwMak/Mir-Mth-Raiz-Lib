import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS: Record<string, string> = {
  GROUPS: "/api/v1/administrator/course/groups/dropdown/",
};

export const fetchGroupsSearchForSelect = async (params: {
  q?: string;
  course_id?: string;
}) => {
  const { data } = await requester.get(ENDPOINTS.GROUPS, { params });
  return data;
};

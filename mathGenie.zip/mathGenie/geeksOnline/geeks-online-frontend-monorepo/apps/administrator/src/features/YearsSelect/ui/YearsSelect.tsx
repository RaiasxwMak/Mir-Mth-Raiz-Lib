import { useEffect, useMemo } from "react";
import { useYearsSelect } from "../model/useYearsSelect";
import { useFetchYears } from "../model/useFetchYearsSelect";
import { CustomSelect } from "@geeks-online/uikit";

const YearsSelect = () => {
  const { yearsChangeSelect, yearsSelect, yearsResetSelect } = useYearsSelect();
  const { data } = useFetchYears();

  const allOption = { label: "Все", value: "0" };
  let yearsOptions = useMemo(() => {
    return (
      data?.map((year) => ({ label: String(year), value: String(year) })) || []
    );
  }, [data]);

  yearsOptions = [allOption, ...yearsOptions];

  useEffect(() => {
    return () => yearsResetSelect();
  }, []);
  return (
    <div>
      <CustomSelect
        isArrow
        onChange={yearsChangeSelect}
        value={yearsSelect}
        width={"256px"}
        height={"40px"}
        options={yearsOptions}
        placeholder={"Год"}
      />
    </div>
  );
};

export default YearsSelect;

export interface IInfo {
  id: number | string;
  title: string | number;
  months: number;
}

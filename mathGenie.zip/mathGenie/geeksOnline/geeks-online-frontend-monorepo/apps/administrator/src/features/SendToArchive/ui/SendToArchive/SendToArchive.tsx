import {
  Button,
  Loader,
  ThemeButton,
  Typography,
  UIModal,
} from "@geeks-online/uikit";
import { useState } from "react";
import cls from "./SendToArchive.module.scss";
import { useNavigate } from "react-router-dom";

const SendToArchive = ({
  mutateAsync,
  isLoading,
  title,
  bodyTitle,
}: {
  mutateAsync: () => Promise<unknown>;
  isLoading: boolean;
  title: string;
  bodyTitle?: string;
}) => {
  const navigate = useNavigate();
  const [openModal, setOpenModal] = useState(false);

  const handleClickRequest = async () => {
    try {
      await mutateAsync();
      setOpenModal(false);
      navigate(-1);
    } catch (e) {
      throw e;
    }
  };

  return (
    <>
      <Button
        className={cls.button}
        theme={ThemeButton.contained}
        onClick={() => setOpenModal(true)}
      >
        {title}
      </Button>
      <UIModal
        modalWidth={"400px"}
        className={cls.modal}
        themeOkBtn={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        okTitle={isLoading ? <Loader small /> : "Да"}
        themeCancelBtn={ThemeButton.outline}
        cancelTitle={"Нет"}
        open={openModal}
        onCancel={() => setOpenModal(false)}
        onOkRequest={handleClickRequest}
      >
        <Typography variant="Title2" className={cls.modal_title}>
          {title}
        </Typography>
        <Typography variant="Text1" className={cls.subtitle}>
          {bodyTitle || "Вы уверены, что хотите архивировать ?"}
        </Typography>
      </UIModal>
    </>
  );
};

export default SendToArchive;

import { IOption } from "@geeks-online/uikit";
import { create } from "zustand";

interface IuseCoursesSelect {
  courseValueSelect: IOption | null;
  courseChangeSelect: (param: IOption) => void;
  courseResetSelect: () => void;
  courseValueSelectByTab: Record<string, IOption | null>;
  getCourseValueSelect: (tab: string) => IOption | null;
  courseChangeSelectByTab: (tab: string, param: IOption) => void;
  courseResetSelectByTab: (tab?: string) => void;
}

const DEFAULT_TAB = "default";

export const useCoursesSelect = create<IuseCoursesSelect>((set, get) => ({
  courseValueSelect: null,

  courseValueSelectByTab: {},

  getCourseValueSelect: (tab) => {
    return get().courseValueSelectByTab[tab] || null;
  },

  courseChangeSelect: (param) => {
    if (param.value === "0") {
      set({ courseValueSelect: null });
    } else {
      set({ courseValueSelect: param });
    }
  },

  courseResetSelect: () => {
    set({ courseValueSelect: null });
  },

  courseChangeSelectByTab: (tab, param) => {
    if (param.value === "0") {
      set((state) => ({
        courseValueSelectByTab: {
          ...state.courseValueSelectByTab,
          [tab]: null,
        },
        ...(tab === DEFAULT_TAB ? { courseValueSelect: null } : {}),
      }));
    } else {
      set((state) => ({
        courseValueSelectByTab: {
          ...state.courseValueSelectByTab,
          [tab]: param,
        },
        ...(tab === DEFAULT_TAB ? { courseValueSelect: param } : {}),
      }));
    }
  },

  courseResetSelectByTab: (tab) => {
    if (tab) {
      set((state) => ({
        courseValueSelectByTab: {
          ...state.courseValueSelectByTab,
          [tab]: null,
        },
        ...(tab === DEFAULT_TAB ? { courseValueSelect: null } : {}),
      }));
    } else {
      set({
        courseValueSelectByTab: {},
        courseValueSelect: null,
      });
    }
  },
}));

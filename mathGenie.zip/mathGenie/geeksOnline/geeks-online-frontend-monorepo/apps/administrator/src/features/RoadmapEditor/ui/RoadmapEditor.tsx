import { useEffect, useMemo, useState } from "react";
import {
  Input,
  IOption,
  CustomSelect,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import {
  IProgressItem,
  RoadmapItem,
  TaskDifficulty,
} from "entities/DirectionEssence/type/DirectionsTypes";
import { ComplexityOptions } from "@geeks-online/shared";

type RoadmapEditorProps = {
  months: string | number;
  roadmap: RoadmapItem[];
  setRoadmap: React.Dispatch<React.SetStateAction<RoadmapItem[]>>;
};

const ComplexityCircle = ({
  color,
  label,
}: {
  color: string;
  label: string;
}) => (
  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
    <div
      style={{
        width: 16,
        height: 16,
        borderRadius: "50%",
        backgroundColor: color,
      }}
    />
    <span>{label}</span>
  </div>
);

export const getFormattedComplexityOptions = () => {
  const baseOptions = ComplexityOptions;
  return baseOptions.map((option) => ({
    ...option,
    label: <ComplexityCircle color={option.color} label={option.label} />,
  }));
};

export const convertProgressDataToRoadmapItems = (
  progressData: IProgressItem[]
): RoadmapItem[] => {
  const formattedOptions = getFormattedComplexityOptions();

  return progressData.map((item) => {
    const complexityOption =
      formattedOptions.find((opt) => opt.value === item.status) ||
      formattedOptions[0];

    return {
      month: item.month,
      percentage: String(item.percentage),
      status: item.status as TaskDifficulty,
      complexityOption: complexityOption,
    };
  });
};

export const validateRoadmapData = (
  roadmap: RoadmapItem[]
): { isValid: boolean; errorMessage?: string } => {
  const isRoadmapComplete = roadmap.every(
    (item) => item.percentage && !isNaN(Number(item.percentage))
  );

  if (!isRoadmapComplete) {
    return {
      isValid: false,
      errorMessage: "Заполните процент прогресса для всех месяцев в Roadmap",
    };
  }

  const totalPercentage = roadmap.reduce(
    (sum, item) => sum + Number(item.percentage),
    0
  );

  if (totalPercentage !== 100) {
    return {
      isValid: false,
      errorMessage: "Общая сумма процентов в Roadmap должна равняться 100%",
    };
  }

  return { isValid: true };
};

export const getRoadmapProgressDistribution = (
  roadmap: RoadmapItem[]
): IProgressItem[] => {
  return roadmap.map((item) => ({
    month: item.month,
    percentage: Number(item.percentage),
    status: item.status,
  }));
};

export const RoadmapEditor = ({
  months,
  roadmap,
  setRoadmap,
}: RoadmapEditorProps) => {
  const formattedComplexityOptions = useMemo(getFormattedComplexityOptions, []);
  const [totalPercentage, setTotalPercentage] = useState(0);
  const monthsValue = Number(months);

  const handleRoadmapInputChange = (month: number, value: string) => {
    const updatedRoadmap = roadmap.map((item) => {
      if (item.month === month) {
        return { ...item, percentage: value };
      }
      return item;
    });

    setRoadmap(updatedRoadmap);
  };

  useEffect(() => {
    const total = roadmap.reduce(
      (sum, item) => sum + (Number(item.percentage) || 0),
      0
    );
    setTotalPercentage(total);
  }, [roadmap]);

  useEffect(() => {
    if (monthsValue && !isNaN(monthsValue)) {
      if (roadmap.length !== monthsValue) {
        const newRoadmap: RoadmapItem[] = Array.from(
          { length: monthsValue },
          (_, i) => {
            const existingItem = roadmap.find((item) => item.month === i + 1);

            if (existingItem) {
              return existingItem;
            } else {
              const formattedOption =
                formattedComplexityOptions.find(
                  (opt) => opt.value === "easy"
                ) || formattedComplexityOptions[0];
              return {
                month: i + 1,
                percentage: "",
                status: "easy" as const,
                complexityOption: formattedOption,
              };
            }
          }
        );

        setRoadmap(newRoadmap);
      }
    }
  }, [months, formattedComplexityOptions, setRoadmap]);

  useEffect(() => {
    const total = roadmap.reduce(
      (sum, item) => sum + (Number(item.percentage) || 0),
      0
    );
    setTotalPercentage(total);
  }, [months]);

  const handleComplexityChange = (month: number, option: IOption | null) => {
    if (!option) return;

    const updatedRoadmap = roadmap.map((item) => {
      if (item.month === month) {
        const newFormattedOption = formattedComplexityOptions.find(
          (opt) => opt.value === option.value
        );

        return {
          ...item,
          status: option.value as TaskDifficulty,
          complexityOption: newFormattedOption || null,
        };
      }
      return item;
    });

    setRoadmap(updatedRoadmap);
  };

  return (
    <div>
      <UIFlexColumn gap={8}>
        <Typography variant="Title1">Roadmap</Typography>
        <UIFlexRow alignItems="center">
          <Typography
            variant="Text1"
            style={{ color: totalPercentage === 100 ? "white" : "red" }}
          >
            Общий процент:{" "}
          </Typography>
          <Typography
            variant="Text2_bold"
            style={{ color: totalPercentage === 100 ? "white" : "red" }}
          >
            {totalPercentage}%{" "}
            {totalPercentage === 100 ? "" : "(должно быть 100%)"}
          </Typography>
        </UIFlexRow>
      </UIFlexColumn>
      {roadmap.map((item) => (
        <UIFlexColumn
          width={400}
          key={`month-${item.month}`}
          style={{ marginTop: 12 }}
        >
          <UIFlexRow gap={16}>
            <UIFlexColumn gap={4}>
              <Typography variant="Text1" style={{ width: 80 }}>
                {item.month} месяц
              </Typography>
              <Input
                type="text"
                value={item.percentage}
                onChange={(e) => {
                  const value = e.target.value;
                  const regex = /^[0-9]*$/;
                  if (regex.test(value)) {
                    if (value === "0") return;
                    handleRoadmapInputChange(item.month, value);
                  }
                }}
                placeholder="Процент"
                style={{ width: 160 }}
              />
            </UIFlexColumn>
            <UIFlexColumn gap={4} width={"100%"}>
              <Typography variant="Text1" style={{ width: "100%" }}>
                Сложность
              </Typography>
              <CustomSelect
                isArrow
                onChange={(option: IOption | null) =>
                  handleComplexityChange(item.month, option)
                }
                value={item.complexityOption}
                width={"220px"}
                height={"44px"}
                options={formattedComplexityOptions}
              />
            </UIFlexColumn>
          </UIFlexRow>
        </UIFlexColumn>
      ))}
    </div>
  );
};

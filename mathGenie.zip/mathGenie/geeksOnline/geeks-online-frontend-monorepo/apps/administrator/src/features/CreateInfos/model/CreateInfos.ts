import { create } from "zustand";

export interface IInputs {
  full_name: string;
  username: string;
  password: string;
  password_confirm: string;
  telegram: string;
  email: string;
  phone: string;
}
export interface IErrorInputs {
  fio: boolean;
  login: boolean;
  password: boolean;
  confirmPassword: boolean;
  telegram: boolean;
  email: boolean;
  phone: boolean;
  group?: boolean;
  sum?: boolean;
}

interface IuseCreateInfosStudent {
  inputs: IInputs;
  setInputs: (
    param: Partial<IInputs> | ((prev: IInputs) => Partial<IInputs>)
  ) => void;
  errorInputs: IErrorInputs;
  setErrorInputs: (name: string, param: boolean) => void;
  clearAllInputs: () => void;
}

const defaultInputs: IInputs = {
  full_name: "",
  username: "",
  password: "",
  password_confirm: "",
  telegram: "",
  email: "",
  phone: "",
};

const errorInputs = {
  fio: false,
  login: false,
  password: false,
  confirmPassword: false,
  telegram: false,
  email: false,
  phone: false,
  group: false,
};

export const useCreateInfos = create<IuseCreateInfosStudent>((set) => ({
  inputs: defaultInputs,
  setInputs: (param) => {
    set(({ inputs }) => ({
      inputs: {
        ...inputs,
        ...(typeof param === "function" ? param(inputs) : param),
      },
    }));
  },
  errorInputs: errorInputs,
  setErrorInputs: (name, param) => {
    set((state) => ({
      errorInputs: { ...state.errorInputs, [name]: param },
    }));
    setTimeout(() => {
      set((state) => ({
        errorInputs: { ...state.errorInputs, [name]: false },
      }));
    }, 3000);
  },
  clearAllInputs: () => {
    set({ inputs: defaultInputs });
  },
}));

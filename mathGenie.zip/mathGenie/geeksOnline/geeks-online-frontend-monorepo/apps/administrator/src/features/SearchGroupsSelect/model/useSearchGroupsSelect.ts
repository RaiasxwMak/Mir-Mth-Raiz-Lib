import { uniqueId } from "lodash";
import { create } from "zustand";

export interface SelectValue {
  id?: string;
  value: string;
  selectedOption: any;
}

const defaultValue: SelectValue = {
  id: uniqueId("id-"),
  value: "",
  selectedOption: null,
};

export interface groupsSelect {
  value: string;
  groupsSelect: SelectValue;
  onChange: (value: string, option?: any) => void;
  clearSelect: () => void;
}

export const useSearchGroupsSelect = create<groupsSelect>((set) => ({
  value: "",
  groupsSelect: defaultValue,
  onChange: (value, opt) => {
    if (opt?.value) {
      set({ groupsSelect: opt, value: opt.label });
    } else set({ groupsSelect: opt, value });
  },
  clearSelect: () => {
    set({ groupsSelect: defaultValue, value: "" });
  },
}));

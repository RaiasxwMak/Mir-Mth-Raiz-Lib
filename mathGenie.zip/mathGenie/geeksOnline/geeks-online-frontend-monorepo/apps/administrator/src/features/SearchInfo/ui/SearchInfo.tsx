import { useEffect } from "react";
import { useSearchInfo } from "../model/useSearchInfo";
import { IStateWithFilters } from "shared/lib/useFillterMemoryNavigate/useFillterMemoryNavigate";
import cls from "./SearchInfo.module.scss";
import { useDebounce } from "@geeks-online/shared";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { Input } from "@geeks-online/uikit";

type InputChangeEvent = React.ChangeEvent<HTMLInputElement>;

export const SearchInfo = ({ width }: { width?: string }) => {
  const { input, setInput, resetInputSearch, setSearch } = useSearchInfo();
  const { page, resetPage } = usePageChange();
  const debouncedGetSearch = useDebounce(setSearch, 500);

  const searchChange = (value: string) => {
    setInput(value);
    if (!value.trim()) {
      debouncedGetSearch("");
    } else {
      debouncedGetSearch(value);
    }
  };

  const handleChange = ({ target }: InputChangeEvent) => {
    searchChange(target.value);
    if (page !== 1) resetPage();
  };

  useEffect(() => {
    const state = window.history.state as IStateWithFilters;
    if (state?.search) searchChange(state.search);
    return () => {
      resetInputSearch();
    };
  }, []);
  return (
    <Input
      placeholder={"Поиск"}
      type="text"
      value={input}
      searchIcon
      style={{ width }}
      className={cls.input}
      onChange={handleChange}
    />
  );
};

import { FC, useEffect } from "react";
import { useMonthsSelect } from "../model/useMonthsSelect";
import { CustomSelect } from "@geeks-online/uikit";

export interface IMonthsSelect {
  width?: string;
}

const MonthsSelect: FC<IMonthsSelect> = ({ width = "256px" }) => {
  const { monthsSelect, onChangeMonthsSelects, onClearMonthsSelects } =
    useMonthsSelect();

  const endPauseSelects = [
    { label: "Все", value: "0" },
    { label: "Январь", value: "1" },
    { label: "Февраль", value: "2" },
    { label: "Март", value: "3" },
    { label: "Апрель", value: "4" },
    { label: "Май", value: "5" },
    { label: "Июнь", value: "6" },
    { label: "Июль", value: "7" },
    { label: "Август", value: "8" },
    { label: "Сентябрь", value: "9" },
    { label: "Октябрь", value: "10" },
    { label: "Ноябрь", value: "11" },
    { label: "Декабрь", value: "12" },
  ];

  useEffect(() => {
    return () => onClearMonthsSelects();
  }, []);
  return (
    <div>
      <CustomSelect
        isArrow
        width={width}
        onChange={onChangeMonthsSelects}
        value={monthsSelect}
        options={endPauseSelects}
        height={"40px"}
        placeholder={"Месяц"}
      />
    </div>
  );
};

export default MonthsSelect;

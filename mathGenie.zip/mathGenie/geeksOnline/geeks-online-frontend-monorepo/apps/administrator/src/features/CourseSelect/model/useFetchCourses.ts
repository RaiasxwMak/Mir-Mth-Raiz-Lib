import { useQuery } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";
import { IInfo } from "../type/CoursesSchema";

const ENDPOINTS: Record<string, string> = {
  DIRECTIONS: "/api/v1/administrator/course/dropdown/",
};

const queryKeyDirections = "directions";

export const useFetchDirections = () => {
  return useQuery<IInfo[]>({
    queryKey: [queryKeyDirections],
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.DIRECTIONS);
      return data;
    },
  });
};

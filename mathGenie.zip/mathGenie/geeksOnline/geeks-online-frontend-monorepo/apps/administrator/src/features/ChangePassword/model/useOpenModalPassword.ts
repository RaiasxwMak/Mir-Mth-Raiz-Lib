import { create } from 'zustand';

export interface IuseOpenModalPassword {
  open: boolean;
  toOpen: () => void;
  toClose: () => void;
}

export const useOpenModalPasswords = create<IuseOpenModalPassword>((set) => ({
  open: false,
  toOpen: () => {
    set({ open: true });
  },
  toClose: () => {
    set({ open: false });
  },
}));

import { useActivateSelect } from "../model/useActivateSelect";
import { CustomSelect } from "@geeks-online/uikit";

const ActivateSelect = ({ width = "256px" }: { width?: string }) => {
  const { activateSelect, onChangeActivateSelects } = useActivateSelect();

  const options = [
    { label: "Все", value: "null" },
    { label: "Активные", value: "0" },
    { label: "Неактивные", value: "1" },
  ];

  return (
    <div>
      <CustomSelect
        isArrow
        width={width}
        onChange={onChangeActivateSelects}
        value={activateSelect}
        options={options}
        height={"40px"}
        placeholder={"Все"}
      />
    </div>
  );
};

export default ActivateSelect;

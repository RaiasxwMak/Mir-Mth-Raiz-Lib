import { IOption } from "@geeks-online/uikit";
import { create } from "zustand";

interface useActivateSelectType {
  activateSelect: IOption | null;
  onChangeActivateSelects: (param: IOption) => void;
  onClearActivateSelects: () => void;
}

export const useActivateSelect = create<useActivateSelectType>((set) => ({
  activateSelect: null,
  onChangeActivateSelects: (param) => {
    if (param?.value === "null") {
      set({ activateSelect: null });
    } else set({ activateSelect: param });
  },
  onClearActivateSelects: () => {
    set({ activateSelect: null });
  },
}));

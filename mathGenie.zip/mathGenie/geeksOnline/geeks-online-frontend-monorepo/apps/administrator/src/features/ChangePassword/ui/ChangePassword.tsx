import {
  Button,
  Input,
  Loader,
  ThemeButton,
  Typography,
  UIModal,
} from "@geeks-online/uikit";
import IconRedact from "shared/assets/icon/redactingPen.svg?react";
import cls from "./ChangePassword.module.scss";
import { ChangeEvent } from "react";
import { IPasswordParam, useChangePassword } from "../model/useChangePassword";
import { useInputPasswords } from "../model/useInputPasswords";
import { useOpenModalPasswords } from "../model/useOpenModalPassword";

interface IformInputs {
  label: string;
  placeholder: string;
  helperText?: string;
  name: keyof IPasswordParam;
}

const ChangePassword = () => {
  const { open, toOpen, toClose } = useOpenModalPasswords();
  const { values, onChangeSet, resetValues, errors } = useInputPasswords();

  const { mutate, isPending } = useChangePassword();
  const handleChangeInputs = (e: ChangeEvent<HTMLInputElement>) => {
    const name = e.target.name;
    onChangeSet({ [name]: e.target.value });
  };

  const handleSubmit = () => {
    mutate(values);
  };

  const handleClose = () => {
    resetValues();
    toClose();
  };

  const modalConstTexts = {
    title: "Сменить пароль",
    cancelTitle: "Отмена",
    okTitle: "Сохранено",
  };

  const formInputs: IformInputs[] = [
    {
      label: "Пароль",
      placeholder: "Новый пароль",
      name: "new_password",
      helperText: "Введите не менее 5 символов (цифры, буквы)",
    },
    {
      label: "Подтверждение пароля",
      placeholder: "Подтверждение пароля",
      name: "new_password_confirm",
    },
  ];
  return (
    <div>
      <Button
        className={cls.button}
        theme={ThemeButton.outline}
        onClick={toOpen}
      >
        <IconRedact />
          Сменить пароль
      </Button>
      <UIModal
        {...modalConstTexts}
        okTitle={isPending ? <Loader small /> : modalConstTexts.okTitle}
        className={cls.modal}
        onCancel={handleClose}
        open={open}
        onOk={handleSubmit}
        modalWidth="450px"
      >
        <div className={cls.form}>
          {formInputs.map((item) => (
            <label className={cls.input_label} key={item.name}>
              <Typography variant="Text2">{item.label}</Typography>
              <Input
                helperText={item.helperText}
                className={cls.input}
                name={item.name}
                minLength={5}
                wrapperClass={cls.inputWrapper}
                value={values[item.name] ?? ""}
                error={errors[item.name]}
                onChange={handleChangeInputs}
                placeholder={item.placeholder}
              />
            </label>
          ))}
        </div>
      </UIModal>
    </div>
  );
};

export default ChangePassword;

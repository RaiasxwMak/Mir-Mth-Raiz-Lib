import { create } from "zustand";

interface IuseCreateAvatar {
  image: File | null;
  setImage: (param: File | null) => void;
}

export const useCreateAvatar = create<IuseCreateAvatar>((set) => ({
  image: null,
  setImage: (param) => {
    set({ image: param });
  },
}));

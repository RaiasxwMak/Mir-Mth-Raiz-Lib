import { IOption } from "@geeks-online/uikit";
import { create } from "zustand";

interface useFilterSelectType {
  filterSelect: IOption | null;
  onChangeFilterSelects: (param: IOption) => void;
  onClearFilterSelects: () => void;
}

export const useFilterSelect = create<useFilterSelectType>((set) => ({
  filterSelect: null,
  onChangeFilterSelects: (param) => {
    if (param?.value === "null") {
      set({ filterSelect: null });
    } else set({ filterSelect: param });
  },
  onClearFilterSelects: () => {
    set({ filterSelect: null });
  },
}));

import { create } from 'zustand';
import { IPasswordParam } from './useChangePassword';

export interface IuseInputPasswords {
  values: IPasswordParam;
  onChangeSet: (newValue: IPasswordParam) => void;
  setError: (newValue: IError) => void;
  resetValues: () => void;
  errors: IError;
}

interface IError {
  new_password?: boolean;
  new_password_confirm?: boolean;
}

const defaultValues = {
  new_password: '',
  new_password_confirm: '',
};

const defaultErrors = {
  new_password: false,
  new_password_confirm: false,
};

export const useInputPasswords = create<IuseInputPasswords>((set) => ({
  values: defaultValues,
  errors: defaultErrors,
  onChangeSet: (newValue) => {
    set((prev) => ({
      values: { ...prev.values, ...newValue },
      errors:
        prev.errors.new_password || prev.errors.new_password_confirm
          ? defaultErrors
          : prev.errors,
    }));
  },
  resetValues: () => {
    set({ values: defaultValues, errors: defaultErrors });
  },
  setError: (newError) => {
    set((prev) => ({ errors: { ...prev.errors, ...newError } }));
  },
}));

import { create } from "zustand";

interface IuseSearchInfo {
  input: string;
  setInput: (str: string) => void;
  resetInputSearch: () => void;
  search: string;
  setSearch: (str: string) => void;
}

export const useSearchInfo = create<IuseSearchInfo>((set) => ({
  input: "",
  setInput(str) {
    set({ input: str });
  },

  resetInputSearch() {
    set({ input: "", search: "" });
  },

  search: "",
  setSearch(str) {
    set({ search: str });
  },
}));

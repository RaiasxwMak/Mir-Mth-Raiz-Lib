import { useMutation } from "@tanstack/react-query";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useParams } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { useInputPasswords } from "./useInputPasswords";
import { useOpenModalPasswords } from "./useOpenModalPassword";

const ENDPOINTS = {
  PASSWORD: (id: string) =>
    `/api/v1/administrator/curator/${id}/password_change/`,
};

export interface IPasswordParam {
  new_password?: string;
  new_password_confirm?: string;
}

const changePassword = async (user_id: string, param: IPasswordParam) => {
  return await requester.post(ENDPOINTS.PASSWORD(user_id), param);
};

const keyErrorSame = "not same";
const keyErrorLength = "length less than 5";
const keyErrorFill = "fill password";

export const useChangePassword = () => {
  const { user_id } = useParams();
  const openSuccess = useOpenAlert();
  const openFail = useOpenErrorAlert();
  const { setError, resetValues } = useInputPasswords();
  const { toClose } = useOpenModalPasswords();

  const changePasswordMutation = useMutation({
    mutationFn: async (param: IPasswordParam) => {
      const { new_password, new_password_confirm } = param;
      if (!user_id) return;
      if (!new_password && !new_password_confirm) {
        throw keyErrorFill;
      }
      if (new_password && new_password?.length < 5) {
        throw keyErrorLength;
      }
      if (new_password !== new_password_confirm) {
        throw keyErrorSame;
      }
      const response = await changePassword(user_id, param);
      return response.data;
    },
    onSuccess: () => {
      openSuccess("Пароль успешно изменен");
      toClose();
      resetValues();
    },
    onError: (e: any) => {
      if (e === keyErrorFill) {
        setError({ new_password: true, new_password_confirm: true });
        return openFail("Заполните поля");
      }
      if (e === keyErrorSame) {
        setError({ new_password: true, new_password_confirm: true });
        return openFail("Пароли не совпадают");
      }
      if (e === keyErrorLength) {
        setError({ new_password: true });
        return openFail("Пароль должен содержать не менее 5 символов");
      }
    },
  });
  return changePasswordMutation;
};

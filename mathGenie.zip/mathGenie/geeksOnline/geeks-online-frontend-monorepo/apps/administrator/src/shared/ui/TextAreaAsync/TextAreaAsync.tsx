import { Textarea, TextareaProps } from "shared/ui/Textarea/Textarea";
import { useState, useEffect, FC, ChangeEvent } from "react";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import classNames from "classnames";
import cls from "./TextAreaAsync.module.scss";

interface ITextArea extends TextareaProps {
  className?: string;
  asyncCallBack: (val: string) => Promise<unknown>;
  successText?: string;
  failText?: string;
  customError?: Record<number, string>;
  value: string;
}

type statusInput = "success" | "error" | "";

const TextAreaAsync: FC<ITextArea> = ({
  value,
  className = "",
  asyncCallBack,
  failText,
  successText,
  customError,
  ...otherProps
}) => {
  const [origValue, setOrigValue] = useState(value);
  const [status, setStatus] = useState<statusInput>("");
  const successAlert = useOpenAlert();
  const failAlert = useOpenErrorAlert();
  const handleOnBlurRequest = async () => {
    if (value === origValue) return;
    if (origValue === "") {
      setStatus("error");
      failAlert("Заполните пустое поле");
      return;
    }
    try {
      await asyncCallBack(origValue);
      setStatus("success");
      successAlert(successText ?? "Данные успешно сохранены");
    } catch (e: any) {
      setStatus("error");
      console.log("Error");
    }
  };

  useEffect(() => {
    if (!status) return;
    let timeout = setTimeout(() => {
      setStatus("");
    }, 2000);

    return () => {
      clearTimeout(timeout);
    };
  }, [status]);

  const handleChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setOrigValue(e.target.value);
  };

  return (
    <Textarea
      className={classNames(cls.input, className, cls[status])}
      value={origValue}
      onBlur={handleOnBlurRequest}
      onChange={handleChange}
      {...otherProps}
    />
  );
};

export default TextAreaAsync;

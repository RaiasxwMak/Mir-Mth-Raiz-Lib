import Cookie from "js-cookie";

export const cookie = {
  /**
   * @param expires: 1 means 1 day - 2 means 2 days and so on...
   */
  setCookie: (key: string, value: string, expires: number) => {
    Cookie.set(key, value, {
      expires: expires,
      secure: true,
      sameSite: "strict",
      path: "/",
    });
  },
  getCookie: (key: string) => {
    return Cookie.get(key);
  },
  removeCookie: (key: string) => {
    Cookie.remove(key);
  },
};

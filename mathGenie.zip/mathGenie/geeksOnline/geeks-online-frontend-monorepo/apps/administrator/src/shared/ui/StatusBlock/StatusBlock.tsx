import { ReactNode, FC } from "react";
import cls from "./StatusBlock.module.scss";
import classNames from "classnames";
import { Typography } from "@geeks-online/uikit";

interface IStatusBlock {
  children: ReactNode;
  red?: boolean;
  height?: number;
  width?: number;
  yellow?: boolean;
  green?: boolean;
  silver?: boolean;
}

const StatusBlock: FC<IStatusBlock> = ({
  children,
  red = false,
  height,
  width,
  green,
  yellow,
  silver,
}) => {
  return (
    <div
      style={{ height, width }}
      className={classNames(cls.block, {
        [cls.block_red]: red,
        [cls.block_yellow]: yellow,
        [cls.block_green]: green,
        [cls.block_silver]: silver,
      })}
    >
      <Typography variant="Text4">{children}</Typography>
    </div>
  );
};

export default StatusBlock;

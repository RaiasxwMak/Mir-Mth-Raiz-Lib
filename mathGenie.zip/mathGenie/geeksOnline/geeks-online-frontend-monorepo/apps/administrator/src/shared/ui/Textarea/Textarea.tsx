import { TextareaHTMLAttributes } from "react";
import cls from "./Textarea.module.scss";
import classNames from "classnames";

export interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  className?: string;
  label?: string;
  height?: string;
  notShow?: boolean;
}

export const Textarea = ({
  className,
  label,
  value,
  maxLength,
  height,
  style,
  notShow = false,
  ...otherProps
}: TextareaProps) => {
  return (
    <label>
      {label && <span className={cls.label}>{label}</span>}
      <textarea
        {...otherProps}
        value={value}
        className={classNames(cls.textarea, {}, [className])}
        maxLength={maxLength}
        style={{ ...style, height: height }}
      />
      {!notShow && (
        <div className={cls.lengthBlock}>
          {(value && value.toString().length) || "0"}/{maxLength}
        </div>
      )}
    </label>
  );
};

export const BASE_URL = import.meta.env.VITE_APP_BASE_URL;

export const COOKIE_USER_KEY = "user";
export const COOKIE_ACCESS_TOKEN_KEY = "access_token";
export const COOKIE_REFRESH_TOKEN_KEY = "refresh_token";
export const COOKIE_TOKEN_TYPE_KEY = "token_type";
export const COOKIE_GROUP_KEY = "group";
export const COOKIE_USER_ROLE = "role";
export const COOKIE_DEFAULT_GROUP = "default_groups";

export const ROLE_MANAGER = "manager";

export const PERIOD_OPTION = [
  { label: "1 месяц", value: "1" },
  { label: "3 месяца", value: "3" },
  { label: "6 месяцев", value: "6" },
  { label: "12 месяцев", value: "12" },
];

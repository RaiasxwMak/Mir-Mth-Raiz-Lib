import { Checkbox } from "antd";
import cls from "./CustomCheckbox.module.scss";
import { FC } from "react";
import { CheckboxChangeEvent } from "antd/es/checkbox";
import { Typography } from "@geeks-online/uikit";

interface ICheckBox {
  value: string | number;
  label: string;
  onChange?: (e: CheckboxChangeEvent) => void;
  checked?: boolean;
}

const CustomCheckbox: FC<ICheckBox> = ({ value, label, onChange, checked }) => {
  return (
    <>
      <Checkbox
        onChange={onChange}
        checked={checked}
        className={cls.check}
        value={value}
      >
        <Typography variant="Text2_bold">{label}</Typography>
      </Checkbox>
    </>
  );
};

export default CustomCheckbox;

import { IOption } from "@geeks-online/uikit";
import { useNavigate } from "react-router-dom";

export interface SelectValue {
  id?: string;
  value: string;
  selectedOption: any;
}

export interface IStateWithFilters {
  page?: number;
  courseValueSelect?: IOption | null;
  monthSelect?: IOption | null;
  search?: string;
  searchGroupsValue?: SelectValue;
  statusSelect?: IOption | null;
  paymentSelect?: IOption | null;
  monthStatusSelect?: IOption | null;
  groupsSelect?: IOption | null;
}

const useFilterMemoryNavigate = () => {
  const navigate = useNavigate();

  const navigateWithFilter = (path: string, state?: object) => {
    const stateWithFilters = {
      ...state,
    };
    window.history.pushState(stateWithFilters, "filters");
    navigate(path, {
      state: stateWithFilters,
    });
  };
  return navigateWithFilter;
};

export default useFilterMemoryNavigate;

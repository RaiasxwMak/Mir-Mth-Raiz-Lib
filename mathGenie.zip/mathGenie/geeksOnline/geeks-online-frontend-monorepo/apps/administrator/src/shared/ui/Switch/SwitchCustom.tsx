import cls from './Switch.module.scss';
import { FC } from 'react';

interface ISwitch {
  disabled?: boolean;
  switched: boolean;
  setSwitch: () => void;
  afterChange?: () => void;
}

const SwitchCustom: FC<ISwitch> = ({
  disabled,
  switched,
  setSwitch,
  afterChange,
}) => {
  const onChangeSwitch = () => {
    if (!disabled) {
      setSwitch();
      if (afterChange) afterChange();
    }
  };

  return (
    <div
      onClick={onChangeSwitch}
      className={`${cls.switch} ${switched && cls.switchanimate}`}
    >
      <div className={`${cls.switchSlide} ${switched && cls.slideanimate}`} />
    </div>
  );
};

export default SwitchCustom;

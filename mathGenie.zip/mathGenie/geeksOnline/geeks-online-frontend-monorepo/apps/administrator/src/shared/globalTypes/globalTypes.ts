export type TServerResponse<T> = {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
};

export interface UserInfoType {
  id: string;
  user: UserType;
  created_at: string;
  updated_at: string;
  is_deleted: boolean;
}

export interface UserCreateType {
  photo?: File | null;
  full_name?: string;
  email?: string;
  phone?: string;
  telegram?: string;
  username?: string;
  password?: string;
  password_confirm?: string;
}

export interface UserType {
  id: string;
  full_name: string;
  photo: string;
  telegram: string;
  email: string;
  phone: string;
  username: string;
}

export interface ParamsType {
  search?: string;
  limit?: number;
  offset?: number;
  q?: string;
  course_id?: string;
}

export interface IUserEdit {
  photo?: string | File;
  full_name?: string;
  email?: string;
  phone?: string;
  telegram?: string;
  username?: string;
  is_deleted?: boolean;
  is_active?: boolean;
}

export interface IStats {
  id?: string;
  type: string;
  value?: number;
  color: string;
  originalValue: number;
}

export interface ILineChart {
  id: string;
  title: string;
  color: string | null;
  total: number | null;
  statistics: { count: number }[];
}

export interface ILineChartFilter {
  id: string;
  title: string;
  color: string | null;
  total: number | null;
  statistics?: { count: number }[];
  originalStatistics: { count: number }[];
}

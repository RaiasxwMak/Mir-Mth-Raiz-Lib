import { TooltipWrapper, Typography } from "@geeks-online/uikit";
import cls from "./ButtonLink.module.scss";
import { FC, ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import IconDefault from "shared/assets/icon/arrow-right.svg?react";

interface ButtonLinkProps {
  className?: string;
  children?: ReactNode;
  Icon?: ReactNode;
  to: string;
  tooltip?: boolean;
}

const ButtonLink: FC<ButtonLinkProps> = ({
  children,
  Icon = <IconDefault />,
  to,
  tooltip = false,
}) => {
  const { pathname } = useLocation();
  const activeClass = pathname.endsWith(to) ? "active" : "";
  return (
    <TooltipWrapper title={children} show={tooltip}>
      <Link
        onClick={(e): void => e.stopPropagation()}
        to={to}
        className={`${cls.itemLink} ${activeClass}`}
      >
        <div className={cls.icon}>{Icon}</div>
        <Typography className={cls.title} variant="Body1">
          {children}
        </Typography>
      </Link>
    </TooltipWrapper>
  );
};

export default ButtonLink;

export interface AuthSchema {
  authStatus: string;
  authData: IAuthResponse | null;
  isAuth: boolean;
}

export interface IAuthResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user: IUser;
}

export interface IUser {
  email: string;
  full_name: string;
  groups: IGroup[];
  is_active: boolean;
  is_deleted: boolean;
  is__staff: boolean;
  is_student: boolean;
  is_teacher: boolean;
  is_curator: boolean;
  is_manager: boolean;
  phone: string;
  telegram: string;
  username: string;
  photo: string;
  id: string;
  role: string;
}

export interface IGroup {
  course: string;
  id: string;
  is_graduated: boolean;
  status: string;
  title: string;
}

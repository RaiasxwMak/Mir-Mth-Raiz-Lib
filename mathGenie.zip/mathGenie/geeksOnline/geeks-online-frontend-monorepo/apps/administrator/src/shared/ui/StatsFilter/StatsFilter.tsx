import { FC } from "react";
import { Typography, UIFlexColumn, UIFlexRow } from "@geeks-online/uikit";
import { IStats } from "shared/globalTypes/globalTypes";

interface StatsFilterProps {
  data: IStats[];
  handleFilter?: (filter: string) => void;
  splitToColumns?: boolean;
  hideValue?: boolean;
  itemsPerColumn?: number;
}

const columnsArray = <T,>(arr: T[], size: number): T[][] => {
  const columns: T[][] = [];
  for (let i = 0; i < arr.length; i += size) {
    columns.push(arr.slice(i, i + size));
  }
  return columns;
};

const StatsFilter: FC<StatsFilterProps> = ({
  data,
  handleFilter,
  splitToColumns,
  itemsPerColumn = 8,
  hideValue = true,
}) => {
  const renderItem = (item: IStats) => (
    <UIFlexRow gap={14} justifyContent="space-between" key={item.type}>
      <UIFlexRow
        gap={14}
        alignItems="center"
        style={{ cursor: "pointer" }}
        onClick={() => handleFilter?.(item.type)}
      >
        <div style={{ background: item.color, width: 16, height: 8 }} />
        <Typography
          variant="Text4"
          style={{ color: !item?.value ? "gray" : "" }}
        >
          {item.type}
        </Typography>
      </UIFlexRow>
      {!hideValue && (
        <Typography variant="Text4">{item.originalValue}</Typography>
      )}
    </UIFlexRow>
  );

  if (splitToColumns) {
    const columns = columnsArray(data, itemsPerColumn);
    return (
      <UIFlexRow gap={40} alignItems="flex-start">
        {columns.map((column, index) => (
          <UIFlexColumn key={index} gap={6} width={"max-content"}>
            {column.map((item) => renderItem(item))}
          </UIFlexColumn>
        ))}
      </UIFlexRow>
    );
  }

  return (
    <UIFlexColumn gap={6} width={"max-content"}>
      {data.map((item) => renderItem(item))}
    </UIFlexColumn>
  );
};

export default StatsFilter;

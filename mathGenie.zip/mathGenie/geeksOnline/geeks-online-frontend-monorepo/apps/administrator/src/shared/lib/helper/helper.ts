export const generateColor = (index: number): string => {
  const randomColor = (index * 1234567) % 0xffffff;
  return `#${randomColor.toString(16).padStart(6, "0").toUpperCase()}`;
};

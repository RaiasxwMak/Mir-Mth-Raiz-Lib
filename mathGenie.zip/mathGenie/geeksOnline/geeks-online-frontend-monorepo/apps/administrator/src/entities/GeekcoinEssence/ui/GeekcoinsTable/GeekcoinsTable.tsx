import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { CustomPagination } from "shared/ui";
import { useNavigate } from "react-router-dom";
import { useMemo } from "react";
import { IDiscountsListType } from "entities/DiscountEssence/type/DiscountsType";
import { useGeekcoinsListQuery } from "entities/GeekcoinEssence/model/GeekcoinsList/useFetchGeekcoinsList";

const GeekcoinsTable = () => {
  const { data, isLoading } = useGeekcoinsListQuery();
  const navigate = useNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Направление",
      dataIndex: "course",
      render: (text: string, record: IDiscountsListType) => {
        return (
          <span
            className={"link"}
            onClick={() => navigate(`/administrator/geekcoins/${record.id}`)}
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Номер месяца",
      dataIndex: "monthNumber",
    },
    {
      title: "Номинал",
      dataIndex: "nominal",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
        course: elm.course.title,
        monthNumber: elm.month_number,
        nominal: elm.nominal,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordionList columns={columns} dataSource={dataSource} />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default GeekcoinsTable;

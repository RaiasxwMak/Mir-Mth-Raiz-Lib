/////

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { IRate } from "entities/GeeksShopEssence/type/types";
import { requester } from "shared/configs/axios/axiosConfig";
import { productsKey } from "../productsTable/useFetchProducts";

///
const rateKey = "rateKey";
export const useFetchRate = () => {
  return useQuery<IRate>({
    queryFn: async () => {
      const res = await requester.get("/api/v1/manager/rate/");
      return res.data;
    },
    queryKey: [rateKey],
  });
};

export const useFetchSendRate = () => {
  const successAlert = useOpenAlert();
  const query = useQueryClient();
  return useMutation({
    mutationFn: async (param: IRate) => {
      const res = await requester.post("/api/v1/manager/rate/", param);
      return res;
    },
    onSuccess: () => {
      successAlert("Сохранено");
      query.invalidateQueries({ queryKey: [rateKey] });
      query.invalidateQueries({ queryKey: [productsKey] });
    },
  });
};

import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { CustomPagination } from "shared/ui";
import { useNavigate } from "react-router-dom";
import { useMemo } from "react";
import { useDiscountsListQuery } from "entities/DiscountEssence/model/DiscountsList/useFetchDiscountsList";
import { IDiscountsListType } from "entities/DiscountEssence/type/DiscountsType";

const DiscountsTable = () => {
  const { data, isLoading } = useDiscountsListQuery();
  const navigate = useNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Направление",
      dataIndex: "course",
      render: (text: string, record: IDiscountsListType) => {
        return (
          <span
            className={"link"}
            onClick={() => navigate(`/administrator/discounts/${record.id}`)}
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Сумма скидки",
      dataIndex: "disAmount",
    },
    {
      title: "Баллы за ДЗ",
      dataIndex: "pointHw",
    },
    {
      title: "Баллы за тесты",
      dataIndex: "pointTest",
    },
    {
      title: "Минимальное количество посещений",
      dataIndex: "minTotalAttandance",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
        course: elm.course.title,
        disAmount: elm.amount,
        pointHw: `${elm.min_hw_point}-${elm.max_hw_point}`,
        pointTest: `${elm.min_test_point}-${elm.max_test_point}`,
        minTotalAttandance: elm.min_attandance_count,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordionList columns={columns} dataSource={dataSource} />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default DiscountsTable;

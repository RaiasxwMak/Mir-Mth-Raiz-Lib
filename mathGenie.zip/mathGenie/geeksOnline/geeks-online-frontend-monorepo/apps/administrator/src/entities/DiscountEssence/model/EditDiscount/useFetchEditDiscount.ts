import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  IDiscountsListType,
  IDiscountsType,
} from "entities/DiscountEssence/type/DiscountsType";
import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS = {
  DISCOUNT: (id: string) => `/api/v1/administrator/course/discount/${id}/`,
  DISCOUNT_EDIT: (id: string) =>
    `/api/v1/administrator/course/discount/${id}/update/`,
};

export const queryKeyDiscountDetail = "discountKeyInfo";

export const useFetchInfoDiscount = (id: string) => {
  return useQuery<IDiscountsListType>({
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.DISCOUNT(id));
      return data;
    },
    queryKey: [queryKeyDiscountDetail],
  });
};

export const useFetchDiscountEdit = (id: string) => {
  const query = useQueryClient();
  return useMutation({
    mutationFn: async (param: IDiscountsType) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        ENDPOINTS.DISCOUNT_EDIT(id),
        formdata
      );
      return response.data;
    },
    onSuccess: (param) => {
      if (!param.is_deleted) {
        query.invalidateQueries({ queryKey: [queryKeyDiscountDetail] });
      }
    },
  });
};

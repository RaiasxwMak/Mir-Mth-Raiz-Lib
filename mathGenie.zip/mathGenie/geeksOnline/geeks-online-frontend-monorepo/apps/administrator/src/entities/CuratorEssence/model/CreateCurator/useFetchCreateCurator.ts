import { useMutation } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useNavigate } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { UserCreateType } from "shared/globalTypes/globalTypes";

export const useCreateCuratorRequest = () => {
  const navigate = useNavigate();
  const successAlert = useOpenAlert();
  return useMutation({
    mutationFn: async (param: UserCreateType) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        if (item[1]) {
          formdata.append(item[0], item[1]);
        }
      });
      try {
        const res = await requester.post(
          "/api/v1/administrator/curator/create/",
          formdata
        );
        return res;
      } catch {}
    },
    onSuccess: (res) => {
      if (res && res.status >= 200) {
        successAlert("Сохранено");
        setTimeout(() => navigate(-1), 500);
      }
    },
  });
};

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { isAxiosError } from "axios";
import { IProduct, IProductParam } from "entities/GeeksShopEssence/type/types";
import { requester } from "shared/configs/axios/axiosConfig";

export const queryKeyProductDetail = "productKey";

export const useFetchInfoProduct = (id: string) => {
  return useQuery<IProduct>({
    queryFn: async () => {
      const { data } = await requester.get(`/api/v1/manager/products/${id}/`);
      return data;
    },
    queryKey: [queryKeyProductDetail],
  });
};

export const useFetchEditProduct = (id: string) => {
  const query = useQueryClient();
  const openError = useOpenErrorAlert();
  return useMutation({
    mutationFn: async (param: IProductParam) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        `/api/v1/manager/products/${id}/`,
        formdata
      );
      return response.data;
    },
    onSuccess: () => {
      query.invalidateQueries({ queryKey: [queryKeyProductDetail] });
    },
    onError: (e) => {
      if (isAxiosError(e) && e.response?.data.price_head.length) {
        openError(e.response?.data.price_head[0]);
        query.invalidateQueries({ queryKey: [queryKeyProductDetail] });
      }
    },
  });
};

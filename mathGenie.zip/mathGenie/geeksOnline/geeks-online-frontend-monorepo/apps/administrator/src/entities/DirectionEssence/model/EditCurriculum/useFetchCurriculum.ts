import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ICurriculumEditType,
  ICurriculumType,
} from "entities/DirectionEssence/type/DirectionsTypes";
import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS = {
  CURRICULUM: (id: string) => `/api/v1/administrator/course/${id}/plans/`,
  COURSE_PLAN: (planId: string) =>
    `/api/v1/administrator/course/plan/${planId}/`,
};

export const queryKeyCurriculum = "curriculumKey";
export const queryKeyCurriculumDetail = "curriculumDetailKeyInfo";

export const useFetchCurriculum = (id: string) => {
  return useQuery<ICurriculumType[]>({
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.CURRICULUM(id));
      return data;
    },
    queryKey: [queryKeyCurriculum, id],
  });
};

export const useFetchCurriculumEdit = (planId: string) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (param: ICurriculumEditType) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        ENDPOINTS.COURSE_PLAN(planId),
        formdata
      );
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeyCurriculum] });
      queryClient.invalidateQueries({ queryKey: [queryKeyCurriculumDetail] });
    },
  });
};

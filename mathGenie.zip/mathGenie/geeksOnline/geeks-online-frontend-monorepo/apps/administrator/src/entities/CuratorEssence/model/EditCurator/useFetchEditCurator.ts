import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { isAxiosError } from "axios";
import { requester } from "shared/configs/axios/axiosConfig";
import { IUserEdit, UserInfoType } from "shared/globalTypes/globalTypes";

const ENDPOINTS = {
  CURATOR: (id: string) => `/api/v1/administrator/curator/${id}/`,
  CURATOR_EDIT: (id: string) => `/api/v1/administrator/curator/${id}/update/`,
};

export const queryKeyCuratorDetail = "curatorKeyInfo";

export const useFetchInfoCurator = (id: string) => {
  return useQuery<UserInfoType>({
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.CURATOR(id));
      return data;
    },
    queryKey: [queryKeyCuratorDetail],
  });
};

export const useFetchCuratorEdit = (id: string) => {
  const query = useQueryClient();
  const openError = useOpenErrorAlert();
  return useMutation({
    mutationFn: async (param: IUserEdit) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        ENDPOINTS.CURATOR_EDIT(id),
        formdata
      );
      return response.data;
    },
    onSuccess: (param) => {
      if (!param.is_deleted) {
        query.invalidateQueries({ queryKey: [queryKeyCuratorDetail] });
      }
    },
    onError: (e) => {
      if (isAxiosError(e) && e.response?.data?.email) {
        openError(e.response?.data?.email[0]);
      }
    },
  });
};

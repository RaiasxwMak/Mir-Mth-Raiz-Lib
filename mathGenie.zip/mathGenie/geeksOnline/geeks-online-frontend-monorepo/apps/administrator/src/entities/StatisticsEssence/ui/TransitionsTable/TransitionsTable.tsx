import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { useMemo } from "react";
import { CustomPagination } from "shared/ui";
import { useTransitionsListQuery } from "entities/StatisticsEssence/model/useTransitionsListQuery";
import { ColumnsType } from "antd/es/table";
import { ITransitions } from "entities/StatisticsEssence/type/transitionsType";

const columns: ColumnsType<ITransitions> = [
  {
    title: "№",
    dataIndex: "index",
    width: "60px",
  },
  {
    title: "Группа",
    dataIndex: "group",
    width: "30%",
  },
  {
    title: "Месяц",
    dataIndex: "number",
    width: "60px",
    align: "center",
  },
  {
    title: "Студенты",
    dataIndex: "students",
    width: "60px",
    align: "center",
  },
  {
    title: "Новые",
    dataIndex: "new",
    width: "60px",
    align: "center",
  },
  {
    title: "БП",
    dataIndex: "free_repeats",
    width: "60px",
    align: "center",
  },
  {
    title: "ПП",
    dataIndex: "pays_repeats",
    width: "60px",
    align: "center",
  },
  {
    title: "Пауза",
    dataIndex: "pause",
    width: "60px",
    align: "center",
  },
  {
    title: "Игнор",
    dataIndex: "ignore",
    width: "60px",
    align: "center",
  },
  {
    title: "Отказ",
    dataIndex: "reject",
    width: "60px",
    align: "center",
  },
  {
    title: "Вернувшиеся",
    dataIndex: "returns",
    width: "60px",
    align: "center",
  },
  {
    title: "Перевелись",
    dataIndex: "transfers",
    width: "60px",
    align: "center",
  },
  {
    title: "На повторе",
    dataIndex: "in_repeat",
    width: "60px",
    align: "center",
  },
  {
    title: "Остались",
    dataIndex: "stayed",
    width: "60px",
    align: "center",
  },
  {
    title: "Переход",
    dataIndex: "moved_next_module",
    width: "60px",
    align: "center",
  },
  {
    title: "Переход новые",
    dataIndex: "moved_next_module_new",
    width: "60px",
    align: "center",
  },
];

const TransitionsTable = () => {
  const { data, isLoading } = useTransitionsListQuery();

  const dataSource = useMemo(() => {
    return (
      data?.results.map((elm, index: number) => {
        const even = (index + 1) % 2 === 0;
        return {
          ...elm,
          key: index + 1,
          index: index + 1,
          className: even ? rowClass : "",
          expand: false,
        };
      }) || []
    );
  }, [data]);

  const total = useMemo(
    () => ({
      key: Date.now(),
      index: "",
      className: rowClass,
      expand: false,
      group: "Итого",
      number: "",
      students: data?.total.students ?? "-",
      free_repeats: data?.total.free_repeats ?? "-",
      pays_repeats: data?.total.pays_repeats ?? "-",
      moved_next_module: data?.total.moved_next_module ?? "-",
      stayed: data?.total.stayed ?? "-",
      pause: data?.total.pause ?? "-",
      ignore: data?.total.ignore ?? "-",
      reject: data?.total.reject ?? "-",
      returns: data?.total.returns ?? "-",
      transfers: data?.total.transfers ?? "-",
      in_repeat: data?.total.in_repeat ?? "-",
      new: data?.total.new ?? "-",
      moved_next_module_new: data?.total.moved_next_module_new ?? "-",
    }),
    [data]
  );

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordionList
        columns={columns}
        dataSource={[...dataSource, total]}
      />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default TransitionsTable;

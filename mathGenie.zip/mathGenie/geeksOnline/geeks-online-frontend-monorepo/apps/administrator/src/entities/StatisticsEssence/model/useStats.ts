import { create } from "zustand";
import { requester } from "shared/configs/axios/axiosConfig";
import { AxiosResponse } from "axios";
import { generateColor } from "shared/lib/helper/helper";
import { IStatsData } from "../type/statsType";

const notActiveStatusColor = {
  pause: "#36A2EB",
  reject: "#E91517",
  ignore: "#FFE743",
};

const notActiveStatus = {
  pause: "Пауза",
  reject: "Отказ",
  ignore: "Игнор",
};

const mapCoursesToStats = (courses: IStatsData["courses"], indexOffset = 0) => {
  return courses.map((item, index) => ({
    type: item.course ?? item.title,
    value: Number(item.count),
    originalValue: Number(item.count),
    color: item.color ?? generateColor(index + indexOffset),
    id: item.id,
  }));
};

interface StatsDataByTab {
  statsData: IStatsData | null;
  stats: any[] | null;
  originalStats: any[] | null;
}

interface useStatsTypeExtended {
  dataLoading: boolean;
  statsByTab: Record<string, StatsDataByTab>;
  getStats: (params: any, tab: string) => Promise<void>;
  handleFilterStats: (param: string, tab: string) => void;
  getStatsForTab: (tab: string) => StatsDataByTab;
  clearTabData: (tab: string) => void;
}

export const useStats = create<useStatsTypeExtended>((set, get) => ({
  dataLoading: false,
  statsByTab: {},

  getStats: async (
    { url, date, course_id, start_date, end_date },
    tab: string
  ) => {
    try {
      set({ dataLoading: true });

      const state = get();
      const existingData = state.statsByTab[tab];
      const cacheKey = `${url}_${date || ""}_${course_id || ""}_${
        start_date || ""
      }_${end_date || ""}`;

      if (existingData && (existingData as any).cacheKey === cacheKey) {
        set({ dataLoading: false });
        return;
      }

      const response: AxiosResponse<IStatsData> = await requester.get(
        `api/v1/administrator/course/${url}/`,
        { params: { date, course_id, start_date, end_date } }
      );

      let processedStats;
      if (url === "not-active-statistics") {
        processedStats = response.data.courses.map((item) => ({
          type: notActiveStatus[item.type as keyof typeof notActiveStatus],
          value: item.count,
          originalValue: item.count,
          color:
            notActiveStatusColor[
              item.type as keyof typeof notActiveStatusColor
            ],
          id: item.id,
        }));
      } else {
        processedStats = mapCoursesToStats(response.data.courses);
      }

      const tabData: StatsDataByTab & { cacheKey: string } = {
        statsData: response.data,
        stats: processedStats,
        originalStats: [...processedStats],
        cacheKey,
      };

      set((state) => ({
        dataLoading: false,
        statsByTab: {
          ...state.statsByTab,
          [tab]: tabData,
        },
      }));
    } catch {
      set((state) => ({
        dataLoading: false,
        statsByTab: {
          ...state.statsByTab,
          [tab]: {
            statsData: null,
            stats: [],
            originalStats: [],
          },
        },
      }));
    } finally {
      set({ dataLoading: false });
    }
  },

  handleFilterStats: (param: string, tab: string) => {
    const state = get();
    const current = state.statsByTab[tab];

    if (!current || !current.stats || !current.originalStats) return;

    const updateStatsForTab = (newStats: any[]) => {
      set((state) => ({
        statsByTab: {
          ...state.statsByTab,
          [tab]: {
            ...current,
            stats: newStats,
          },
        },
      }));
    };

    if (param === "reset") {
      updateStatsForTab(
        current.stats.map((item) => ({ ...item, value: undefined }))
      );
      return;
    }

    if (param === "show") {
      updateStatsForTab([...current.originalStats]);
      return;
    }

    const updatedData = current.stats.map((item) =>
      item.type === param
        ? {
            ...item,
            value: item.value === undefined ? item.originalValue : undefined,
          }
        : item
    );

    updateStatsForTab(updatedData);
  },

  getStatsForTab: (tab: string) => {
    const state = get();
    return (
      state.statsByTab[tab] || {
        statsData: null,
        stats: null,
        originalStats: null,
      }
    );
  },

  clearTabData: (tab: string) => {
    set((state) => {
      const newStatsByTab = { ...state.statsByTab };
      delete newStatsByTab[tab];
      return { statsByTab: newStatsByTab };
    });
  },
}));

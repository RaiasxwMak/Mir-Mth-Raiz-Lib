import {
  AsyncInput,
  CreateAvatar,
  Loader,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { useParams } from "react-router-dom";
import {
  useFetchInfoManager,
  useFetchManagerEdit,
} from "../model/editmanager/useEditManager";
import { TMangerInfo } from "./CreateManager";
import ChangePassword from "features/ChangePassword/ui/ChangePassword";
import SendToArchive from "features/SendToArchive/ui/SendToArchive/SendToArchive";

export const EditManager = () => {
  const { id = "" } = useParams();
  const { image, setImage } = useCreateAvatar();
  const { data, isLoading } = useFetchInfoManager(id);
  const { mutateAsync, isPending } = useFetchManagerEdit(data?.user.id ?? "");

  const managerInfo: TMangerInfo[] = [
    {
      name: "full_name",
      label: "ФИО",
      star: "*",
      type: "text",
      value: data?.user.full_name ?? "",
      isNotRequired: false,
    },
    {
      name: "username",
      label: "Логин",
      star: "*",
      type: "text",
      value: data?.user.username ?? "",
      isNotRequired: false,
    },
    {
      name: "phone",
      label: "Номер телефона",
      star: "*",
      type: "text",
      mask: "+***************************************",
      value: data?.user.phone ?? "",
      isNotRequired: false,
    },
    {
      name: "telegram",
      label: "Телеграм",
      type: "text",
      value: data?.user.telegram ?? "",
      isNotRequired: true,
    },
    {
      name: "email",
      label: "Почта",
      type: "text",
      value: data?.user.email ?? "",
      isNotRequired: true,
    },
  ];

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  const handleAsyncChange = async (param: File) => {
    return mutateAsync({ photo: param });
  };

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={20}>
      <CreateAvatar
        src={data?.user.photo}
        image={image}
        setImage={setImage}
        avatarSize={140}
        asCb={handleAsyncChange}
      />
      <UIFlexColumn gap={8} style={{ width: 400 }}>
        {managerInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <AsyncInput
              mask={item?.mask}
              value={String(item.value)}
              asyncCallBack={(val) => handleChangeAsync(val, item.name)}
              id={item.name}
              name={item.name}
              isNotRequired={item.isNotRequired}
              fullWidth
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <ChangePassword />
      <SendToArchive
        title={"Архивировать менеджера"}
        mutateAsync={() => mutateAsync({ is_deleted: true, is_active: false })}
        isLoading={isPending}
      />
    </UIFlexColumn>
  );
};

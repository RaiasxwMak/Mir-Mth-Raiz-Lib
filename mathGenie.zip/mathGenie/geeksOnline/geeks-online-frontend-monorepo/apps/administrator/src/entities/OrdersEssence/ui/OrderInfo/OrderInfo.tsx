import { ChangeEvent, FC, useEffect, useState } from "react";
import cls from "./OrderInfo.module.scss";
import { IOrderItem } from "entities/OrdersEssence/type/types";
import BusketSvg from "shared/assets/icon/trash.svg?react";
import {
  Button,
  Input,
  Loader,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import {
  useChangeOrder,
  usePostOrder,
  useRemoveOrder,
} from "entities/OrdersEssence/model/useOrder";

interface IProps {
  items: IOrderItem[];
  status: string;
  id: string;
}

const OrderInfo: FC<IProps> = ({ items, status, id }) => {
  const { mutateAsync, isPending } = usePostOrder();

  const getStatusOrder: Record<string, string> = {
    "Ожидает подтверждения": "Заказ подтвержден",
    "Заказ подтвержден": "Заказ получен",
    "Заказ получен": "Заказ получен",
  };

  if (!items.length) return null;
  return (
    <div className={cls.info}>
      <div className={cls.list}>
        {items.map((item) => (
          <UIFlexColumn key={item.id} gap={24}>
            <OrderCard
              id={item.id}
              title={item.title}
              quantity={item.confirm_quantity}
              status={status}
              description={item.description}
            />
          </UIFlexColumn>
        ))}
        {status !== "Заказ получен" && (
          <Button
            width={400}
            theme={ThemeButton.contained}
            onClick={() =>
              mutateAsync({
                id,
                status: getStatusOrder[status],
              })
            }
          >
            {isPending ? <Loader small /> : getStatusOrder[status]}
          </Button>
        )}
      </div>
    </div>
  );
};

export default OrderInfo;

function OrderCard({
  id,
  title,
  quantity,
  status,
  description,
}: {
  id: string;
  title: string;
  quantity: number;
  status: string;
  description: string | null;
}) {
  const { mutateAsync: mutate } = useChangeOrder();
  const { mutateAsync, isPending } = useRemoveOrder();

  const [count, setCount] = useState("");

  const handleChangeCount = (e: ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    if (!/^\d*$/.test(value)) return;
    if (quantity < +value) return;
    setCount(value);
  };

  const handleBlur = async (e: ChangeEvent<HTMLInputElement>) => {
    try {
      const { value } = e.target;
      if (!value) return setCount(quantity.toString());
      await mutate({ id, confirm_quantity: +value });
    } catch {}
  };

  const isLastStatus = status === "Ожидает подтверждения";

  useEffect(() => {
    setCount(quantity.toString());
  }, []);
  return (
    <UIFlexColumn gap={8}>
      <UIFlexColumn gap={4} style={{ width: isLastStatus ? 600 : 400 }}>
        <Typography variant="Text1">{"Товар"}</Typography>
        <UIFlexRow gap={12}>
          <Input value={title} disabled fullWidth />
          {isLastStatus && (
            <div className={cls.delete} onClick={() => mutateAsync(id)}>
              {isPending ? (
                <div className={cls.load}>
                  <Loader small />
                </div>
              ) : (
                "Удалить товар"
              )}{" "}
              <BusketSvg />{" "}
            </div>
          )}
        </UIFlexRow>
      </UIFlexColumn>
      <UIFlexColumn gap={4} style={{ width: 400 }}>
        <Typography variant="Text1">{"Количество"}</Typography>
        <Input
          value={count}
          onChange={handleChangeCount}
          onBlur={handleBlur}
          disabled={!isLastStatus}
          fullWidth
        />
      </UIFlexColumn>
      {description && (
        <UIFlexColumn gap={4} style={{ width: 400 }}>
          <Typography variant="Text1">{"Описание"}</Typography>
          <Typography variant="Text2">{description}</Typography>
        </UIFlexColumn>
      )}
    </UIFlexColumn>
  );
}

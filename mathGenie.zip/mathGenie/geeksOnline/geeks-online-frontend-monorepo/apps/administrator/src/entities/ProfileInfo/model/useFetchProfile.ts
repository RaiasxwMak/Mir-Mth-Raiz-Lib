import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";
import { IProfile } from "../type/profileType";

const ENDPOINTS = { PROFILE: `/api/v1/auth/profile/` };

const queryKeyProfile = "profile";

interface IProfileEdit {
  photo?: string | File;
  full_name?: string;
  email?: string;
  phone?: string;
  telegram?: string;
  username?: string;
}

export const useFetchProfile = () => {
  return useQuery<IProfile>({
    queryKey: [queryKeyProfile],
    queryFn: async () => {
      try {
        const { data } = await requester.get(ENDPOINTS.PROFILE);
        return data;
      } catch {}
    },
  });
};

export const useFetchProfileEdit = () => {
  const queryClient = useQueryClient();
  const profileEdit = useMutation({
    mutationFn: async (param: IProfileEdit) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(ENDPOINTS.PROFILE, formdata);
      return response.data;
    },
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: [queryKeyProfile] });
    },
  });

  return profileEdit;
};

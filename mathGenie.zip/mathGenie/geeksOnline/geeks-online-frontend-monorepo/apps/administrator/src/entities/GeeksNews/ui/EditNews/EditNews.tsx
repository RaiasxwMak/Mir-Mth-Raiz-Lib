import {
  Button,
  CreateAvatar,
  Loader,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIModal,
} from "@geeks-online/uikit";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { useNavigate, useParams } from "react-router-dom";
import {
  useFetchDeleteNews,
  useFetchEditNews,
  useFetchInfoNews,
} from "entities/GeeksNews/model/editNews/useFetchEditNews";
import TextAreaAsync from "shared/ui/TextAreaAsync/TextAreaAsync";
import cls from "./EditNews.module.scss";
import { useState } from "react";

const EditNews = () => {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const { image, setImage } = useCreateAvatar();
  const { data, isLoading } = useFetchInfoNews(id);
  const { mutateAsync } = useFetchEditNews(id);
  const { mutateAsync: deleteNews } = useFetchDeleteNews();
  const [openModal, setOpenModal] = useState(false);

  const openAlert = useOpenAlert();

  const newsInfo = [
    {
      name: "title",
      label: "Заголовок",
      placeholder: "Заголовок",
      type: "text",
      width: "400px",
      height: "80px",
      value: data?.title ?? "",
      isNotRequired: false,
      maxLength: 255,
      notShow: false,
    },
    {
      name: "description",
      label: "Описание",
      placeholder: "Описание",
      type: "text",
      width: "770px",
      height: "150px",
      value: data?.description ?? "",
      isNotRequired: false,
      notShow: true,
    },
  ];

  const handleChangeAsync = async (
    value: string | boolean,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  const handleChangeImage = async (param: File) =>
    mutateAsync({ image: param });

  const handleDeleteNews = async () => {
    try {
      await deleteNews(id);
      openAlert("Новость успешно удалена");
      navigate("/administrator/news");
    } catch (error) {
      console.error("Ошибка при удалении новости:", error);
    }
  };

  if (isLoading) return <Loader />;
  return (
    <>
      <UIFlexColumn gap={40}>
        <UIFlexColumn gap={12}>
          <UIFlexColumn gap={4}>
            <Typography variant="Text1">
              {"Загрузить фото"} <span style={{ color: "red" }}>{"*"}</span>
            </Typography>
            <CreateAvatar
              isPhoto
              src={data?.image}
              image={image}
              setImage={setImage}
              asCb={handleChangeImage}
            />
          </UIFlexColumn>
          <Typography variant="Text4">
            {"Загружать в форматах jpg, jpeg, png, heic. webp"}
          </Typography>
        </UIFlexColumn>
        {newsInfo.map((item, key) => (
          <UIFlexColumn gap={4} key={key} style={{ width: item.width }}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>*</span>
            </Typography>
            <UIFlexColumn>
              <TextAreaAsync
                placeholder={item.placeholder}
                height={item.height}
                asyncCallBack={(val) => handleChangeAsync(val, item.name)}
                value={item.value}
                maxLength={item.maxLength}
                notShow={item.notShow}
              />
            </UIFlexColumn>
          </UIFlexColumn>
        ))}
        <Button
          className={cls.button}
          theme={ThemeButton.contained}
          onClick={() => setOpenModal(true)}
        >
          Удалить новость
        </Button>
      </UIFlexColumn>
      <UIModal
        modalWidth={"400px"}
        className={cls.modal}
        themeOkBtn={isLoading ? ThemeButton.disabled : ThemeButton.contained}
        okTitle={isLoading ? <Loader small /> : "Да"}
        themeCancelBtn={ThemeButton.outline}
        cancelTitle={"Нет"}
        open={openModal}
        onCancel={() => setOpenModal(false)}
        onOkRequest={handleDeleteNews}
      >
        <Typography variant="Title2" className={cls.modal_title}>
          Удалить новость
        </Typography>
        <Typography variant="Text1" className={cls.subtitle}>
          Вы уверены, что хотите удалить новость
        </Typography>
      </UIModal>
    </>
  );
};

export default EditNews;

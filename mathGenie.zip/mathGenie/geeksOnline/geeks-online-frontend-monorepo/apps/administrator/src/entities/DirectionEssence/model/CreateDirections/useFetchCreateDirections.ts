import { useMutation } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { IDirectionsListType } from "entities/DirectionEssence/type/DirectionsTypes";
import { useNavigate } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";

export const useCreateDirectionRequest = () => {
  const navigate = useNavigate();
  const successAlert = useOpenAlert();

  return useMutation({
    mutationFn: async (param: IDirectionsListType) => {
      const formdata = new FormData();
      Object.entries(param).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (key === "progress_distribution" && Array.isArray(value)) {
            formdata.append(key, JSON.stringify(value));
          } else {
            formdata.append(key, String(value));
          }
        }
      });

      try {
        const res = await requester.post(
          "/api/v1/administrator/course/",
          formdata
        );
        return res;
      } catch (error) {
        throw error;
      }
    },
    onSuccess: (res) => {
      if (res && res.status >= 200 && res.data) {
        successAlert("Сохранено");
        const directionId =
          res.data.id || res.data.direction_id || res.data.course_id;
        if (directionId) {
          setTimeout(() => {
            navigate(`/administrator/directions/${directionId}`);
          }, 500);
        } else {
          setTimeout(() => navigate(-1), 500);
        }
      }
    },
  });
};

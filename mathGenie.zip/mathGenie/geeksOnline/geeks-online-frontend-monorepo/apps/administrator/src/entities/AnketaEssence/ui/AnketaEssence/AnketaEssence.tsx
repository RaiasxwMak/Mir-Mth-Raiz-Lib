import { UIFlexColumn } from "@geeks-online/uikit";
import AnketaCourses from "../AnketaCourses/AnketaCourses";
import CreateAnketaCourse from "../CreateAnketaCourse/CreateAnketaCourse";

const AnketaEssence = () => {
  return (
    <UIFlexColumn gap={28}>
      <CreateAnketaCourse />
      <AnketaCourses />
    </UIFlexColumn>
  );
};

export default AnketaEssence;

import {
  AsyncInput,
  IOption,
  Loader,
  SelectAsync,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useParams } from "react-router-dom";
import SendToArchive from "features/SendToArchive/ui/SendToArchive/SendToArchive";
import { TDiscountsInfo } from "../CreateDiscounts/CreateDiscounts";
import {
  useFetchDiscountEdit,
  useFetchInfoDiscount,
} from "entities/DiscountEssence/model/EditDiscount/useFetchEditDiscount";
import { useEffect, useMemo, useState } from "react";
import { useFetchDirections } from "features/CourseSelect/model/useFetchCourses";

const EditDiscount = () => {
  const { id = "" } = useParams();
  const { data, isLoading } = useFetchInfoDiscount(id);
  const { data: direction } = useFetchDirections();
  const { mutateAsync, isPending } = useFetchDiscountEdit(id);
  const [selectCourse, setSelectCourse] = useState<IOption | null>(null);

  const discountsInfo: TDiscountsInfo[] = [
    {
      name: "amount",
      label: "Сумма скидки",
      star: "*",
      type: "number",
      value: data?.amount ?? "",
    },
    {
      name: "max_hw_point",
      label: "Максимальное количество баллов за ДЗ",
      type: "number",
      star: "*",
      value: data?.max_hw_point ?? "",
    },
    {
      name: "min_hw_point",
      label: "Минимальное количество баллов за ДЗ",
      type: "number",
      star: "*",
      value: data?.min_hw_point ?? "",
    },
    {
      name: "max_test_point",
      label: "Максимальное количество баллов за тесты",
      type: "number",
      star: "*",
      value: data?.max_test_point ?? "",
    },
    {
      name: "min_test_point",
      label: "Минимальное количество баллов за тесты",
      type: "number",
      star: "*",
      value: data?.min_test_point ?? "",
    },
    {
      name: "min_attandance_count",
      label: "Минимальное количество посещений",
      type: "number",
      star: "*",
      value: data?.min_attandance_count ?? "",
    },
  ];

  const directionsOption = useMemo(() => {
    return (
      direction?.map((i) => ({
        value: i.id,
        label: i.title,
      })) ?? []
    );
  }, [direction]);

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  useEffect(() => {
    if (data?.course) {
      setSelectCourse({ label: data.course.title, value: data.course.id });
    }
  }, [data?.course]);
  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">
          Направление <span style={{ color: "red" }}>*</span>
        </Typography>
        <SelectAsync
          width={"400px"}
          height="40px"
          placeholder={"Направление"}
          valueData={selectCourse}
          asyncSelect={(val) => handleChangeAsync(String(val?.value), "course")}
          onChange={(param: IOption | null) => setSelectCourse(param)}
          options={directionsOption}
        />
      </UIFlexColumn>
      <UIFlexColumn gap={28}>
        {discountsInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <AsyncInput
              mask={item?.mask}
              value={String(item.value)}
              asyncCallBack={(val) => handleChangeAsync(val, item.name)}
              type={item.type}
              name={item.name}
              style={{ width: 400 }}
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <SendToArchive
        title={"Архивировать скидку"}
        mutateAsync={() => handleChangeAsync("True", "is_deleted")}
        isLoading={isPending}
      />
    </UIFlexColumn>
  );
};

export default EditDiscount;

import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { CustomPagination } from "shared/ui";
import { useNavigate } from "react-router-dom";
import { useMemo } from "react";
import { useDirectionsListQuery } from "entities/DirectionEssence/model/DirectionsList/useFetchDirectionsList";
import { IDirectionsListType } from "entities/DirectionEssence/type/DirectionsTypes";

const DirectionsTable = () => {
  const { data, isLoading } = useDirectionsListQuery();
  const navigate = useNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Название",
      dataIndex: "course",
      render: (text: string, record: IDirectionsListType) => {
        return (
          <span
            className={"link"}
            onClick={() => navigate(`/administrator/directions/${record.id}`)}
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Количество месяцев ",
      dataIndex: "months",
    },
    {
      title: "Количество уроков в неделю",
      dataIndex: "weekTotal",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
        course: elm.title,
        months: elm.months,
        weekTotal: elm.lesson_per_week,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length) return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordionList columns={columns} dataSource={dataSource} />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default DirectionsTable;

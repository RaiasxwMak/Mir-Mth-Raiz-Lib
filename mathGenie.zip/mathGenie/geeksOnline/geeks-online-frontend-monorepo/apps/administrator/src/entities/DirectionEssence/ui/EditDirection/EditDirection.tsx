import {
  Button,
  Input,
  Loader,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useParams } from "react-router-dom";
import SendToArchive from "features/SendToArchive/ui/SendToArchive/SendToArchive";
import { TDirectionsInfo } from "../CreateDirections/CreateDirections";
import {
  useFetchDirectionEdit,
  useFetchInfoDirection,
} from "entities/DirectionEssence/model/EditDirection/useFetchEditDirection";
import CustomCheckbox from "shared/ui/CustomCheckbox/CustomCheckbox";
import { useEffect, useState } from "react";
import {
  useOpenAlert,
  useOpenErrorAlert,
} from "app/providers/AlertProvider/selectors/useOpenAlert";
import {
  convertProgressDataToRoadmapItems,
  getRoadmapProgressDistribution,
  RoadmapEditor,
  validateRoadmapData,
} from "features/RoadmapEditor/ui/RoadmapEditor";
import {
  IDirectionsListType,
  RoadmapItem,
} from "entities/DirectionEssence/type/DirectionsTypes";

const EditDirection = () => {
  const { id = "" } = useParams();
  const { data, isLoading } = useFetchInfoDirection(id);
  const { mutateAsync, isPending } = useFetchDirectionEdit(id);

  const openAlert = useOpenAlert();
  const openError = useOpenErrorAlert();
  const [roadmap, setRoadmap] = useState<RoadmapItem[]>([]);

  const [isOnline, setIsOnline] = useState(false);
  const [inputs, setInputs] = useState({
    title: "",
    months: "",
    lesson_per_week: "",
    monthly_amount: "",
  });

  useEffect(() => {
    if (data) {
      setInputs({
        title: data.title || "",
        months: String(data.months) || "",
        lesson_per_week: String(data.lesson_per_week) || "",
        monthly_amount: String(data.monthly_amount) || "",
      });
      setIsOnline(!!data.online);
    }
  }, [data]);
  useEffect(() => {
    if (
      data?.progress_distribution &&
      Array.isArray(data.progress_distribution)
    ) {
      const formattedRoadmap = convertProgressDataToRoadmapItems(
        data.progress_distribution
      );
      setRoadmap(formattedRoadmap);
    }
  }, [data?.progress_distribution]);

  const directionsInfo: TDirectionsInfo[] = [
    {
      name: "title",
      label: "Название",
      star: "*",
      type: "text",
      isNotRequired: false,
    },
    {
      name: "months",
      label: "Количество месяцев ",
      type: "text",
      isNotRequired: false,
      star: "*",
    },
    {
      name: "lesson_per_week",
      label: "Количество уроков в неделю",
      type: "text",
      isNotRequired: false,
      star: "*",
    },
    {
      name: "monthly_amount",
      label: "Сумма ежемесячного платежа",
      type: "text",
      isNotRequired: false,
      star: "*",
    },
  ];

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const value = e.target.value;
    const name = e.target.name;
    const regex = /^[0-9.]*$/;
    if (name !== "title" && regex.test(value)) {
      setInputs((prev) => ({ ...prev, [name]: value }));
    }
    if (name === "title") {
      setInputs((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleOnlineChange = () => {
    setIsOnline((prev) => !prev);
  };

  const handleSaveDirection = async () => {
    if (
      !inputs.title ||
      !inputs.lesson_per_week ||
      !inputs.monthly_amount ||
      !inputs.months
    ) {
      return openError("Заполните все обязательные поля");
    }

    const roadmapValidation = validateRoadmapData(roadmap);
    if (!roadmapValidation.isValid) {
      return openError(roadmapValidation.errorMessage || "Ошибка в Roadmap");
    }

    const progress_distribution = getRoadmapProgressDistribution(roadmap);

    const param: IDirectionsListType = {
      filial: data?.filial,
      ...inputs,
      progress_distribution,
      online: isOnline,
    };

    try {
      await mutateAsync(param);
      openAlert("Данные успешно сохранены");
    } catch (error) {
      openError("Ошибка при сохранении данных");
    }
  };

  const handleArchive = async () => {
    try {
      await mutateAsync({ is_deleted: true });
      openAlert("Направление успешно архивировано");
    } catch (error) {
      openError("Ошибка при архивировании");
    }
  };

  if (isLoading) return <Loader />;

  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={8} style={{ width: 400 }}>
        {directionsInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <Input
              mask={item?.mask}
              value={inputs[item.name as keyof typeof inputs]}
              onChange={inputsChange}
              type={item.type}
              name={item.name}
              id={item.name}
              fullWidth
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <CustomCheckbox
        value={String(isOnline)}
        checked={isOnline}
        onChange={handleOnlineChange}
        label="Онлайн курс"
      />
      {inputs.months && (
        <RoadmapEditor
          months={inputs.months}
          roadmap={roadmap}
          setRoadmap={setRoadmap}
        />
      )}
      <Button
        theme={ThemeButton.outline}
        width={400}
        isLoading={isPending}
        onClick={handleSaveDirection}
      >
        Сохранить
      </Button>
      <SendToArchive
        title={"Архивировать направление"}
        mutateAsync={handleArchive}
        isLoading={isPending}
        bodyTitle={
          "Вы уверены, что хотите архивировать? Все, что связано с этим направлением будет тоже удалено"
        }
      />
    </UIFlexColumn>
  );
};

export default EditDirection;

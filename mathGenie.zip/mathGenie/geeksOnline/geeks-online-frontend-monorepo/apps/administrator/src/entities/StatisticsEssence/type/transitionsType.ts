export interface ITransitionsList {
  count: number;
  next: string | null;
  previous: string | null;
  total: {
    students: number;
    pays_repeats: number;
    free_repeats: number;
    moved_next_module: number;
    stayed: number;
    pause: number;
    ignore: number;
    reject: number;
    returns: number;
    transfers: number;
    in_repeat: number;
    moved_next_module_new: number;
    new: number;
  };
  results: ITransitions[];
}

export interface ITransitions {
  id: string;
  status: string;
  number: number;
  group: string;
  group_id: string;
  students: number;
  pays_repeats: number;
  free_repeats: number;
  moved_next_module: number;
  moved_next_module_new: number;
  stayed: number;
  pause: number;
  ignore: number;
  reject: number;
  new: number;
}

export interface ITransitionsListParam {
  offset: number;
  limit: number;
  course_id: string | number;
  month: string | number;
  year: string | number;
  group_id: string;
}

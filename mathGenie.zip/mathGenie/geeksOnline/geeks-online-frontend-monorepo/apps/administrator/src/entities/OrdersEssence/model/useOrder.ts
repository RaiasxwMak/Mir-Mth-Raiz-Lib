import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { requester } from "shared/configs/axios/axiosConfig";
import { IOrder, IOrderParam } from "../type/types";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import { useEffect } from "react";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useFilterSelect } from "features/FilterSelect/model/useFilterSelect";
import { TServerResponse } from "shared/globalTypes/globalTypes";

const orderListKey = "orderListKey";

export const useOrderList = () => {
  const { search } = useSearchInfo();
  const { filterSelect } = useFilterSelect();
  const { page, resetPage } = usePageChange();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [search, filterSelect?.value]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    offset,
    limit,
    q: search,
    status: filterSelect ? filterSelect?.value : "",
  };

  return useQuery<TServerResponse<IOrder>>({
    queryFn: async () => {
      const res = await requester.get("/api/v1/manager/", { params });
      return res.data;
    },
    queryKey: [orderListKey, page, search, filterSelect?.value],
  });
};

export const useRemoveOrder = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await requester.delete(`/api/v1/manager/items/${id}/`);
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [orderListKey] });
    },
  });
};

export const useChangeOrder = () => {
  const successAlert = useOpenAlert();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (param: IOrderParam) => {
      const res = await requester.patch(`/api/v1/manager/items/${param.id}/`, {
        confirm_quantity: param.confirm_quantity,
      });
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [orderListKey] });
      successAlert("Сохранено");
    },
  });
};

export const usePostOrder = () => {
  const successAlert = useOpenAlert();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (param: IOrderParam) => {
      const res = await requester.post(`/api/v1/manager/${param.id}/`, {
        status: param.status,
      });
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [orderListKey] });
      successAlert("Сохранено");
    },
  });
};

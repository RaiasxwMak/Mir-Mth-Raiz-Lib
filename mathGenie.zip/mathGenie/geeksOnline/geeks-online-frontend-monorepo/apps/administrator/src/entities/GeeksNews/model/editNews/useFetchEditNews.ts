import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { isAxiosError } from "axios";
import { INews, INewsParam } from "entities/GeeksNews/type/types";
import { requester } from "shared/configs/axios/axiosConfig";

export const queryKeyNewsDetail = "newsKey";

export const useFetchInfoNews = (id: string) => {
  return useQuery<INews>({
    queryFn: async () => {
      const { data } = await requester.get(`/api/v1/main/news/${id}/`);
      return data;
    },
    queryKey: [queryKeyNewsDetail, id],
    enabled: !!id,
  });
};

export const useFetchEditNews = (id: string) => {
  const query = useQueryClient();
  const openError = useOpenErrorAlert();
  return useMutation({
    mutationFn: async (param: INewsParam) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        `/api/v1/main/news/${id}/`,
        formdata
      );
      return response.data;
    },
    onSuccess: () => {
      query.invalidateQueries({ queryKey: [queryKeyNewsDetail, id] });
    },
    onError: (e) => {
      if (isAxiosError(e) && e.response?.data.price_head?.length) {
        openError(e.response?.data.price_head[0]);
        query.invalidateQueries({ queryKey: [queryKeyNewsDetail, id] });
      }
    },
  });
};

export const useFetchDeleteNews = () => {
  const query = useQueryClient();
  const openError = useOpenErrorAlert();

  return useMutation({
    mutationFn: async (id: string) => {
      const response = await requester.delete(`/api/v1/main/news/${id}/`);
      return response.data;
    },
    onSuccess: (_, id) => {
      query.invalidateQueries({ queryKey: [queryKeyNewsDetail, id] });
      query.invalidateQueries({ queryKey: ["newsKey"] });
    },
    onError: (e) => {
      if (isAxiosError(e) && e.response?.data?.detail) {
        openError(e.response.data.detail);
      } else {
        openError("Произошла ошибка при удалении новости");
      }
    },
  });
};

import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordion,
} from "@geeks-online/uikit";
import dayjs from "dayjs";
import { useOrderList } from "entities/OrdersEssence/model/useOrder";
import { ReactNode, useMemo } from "react";
import CustomPagination from "shared/ui/CustomPagination/CustomPagination";
import OrderInfo from "../OrderInfo/OrderInfo";
import StatusBlock from "shared/ui/StatusBlock/StatusBlock";

const OrderList = () => {
  const { data, isLoading } = useOrderList();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Дата",
      dataIndex: "order_date",
      width: "20%",
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
    },
    {
      title: "Статус заказа",
      dataIndex: "status",
    },
    {
      title: "Сумма заказа",
      dataIndex: "price",
    },
  ];

  const getStatusOrder: Record<string, ReactNode> = {
    "Ожидает подтверждения": (
      <StatusBlock yellow>Ожидает подтверждения</StatusBlock>
    ),
    "Заказ подтвержден": <StatusBlock green>Заказ подтвержден</StatusBlock>,
    "Заказ получен": "Заказ получен",
    "Заказ отменен": <StatusBlock red>Заказ отменен</StatusBlock>,
  };

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: !!elm.items.length,
        status: getStatusOrder[elm.status] ?? elm?.status,
        order_date: elm.order_date
          ? dayjs(elm.order_date).format("DD.MM.YYYY")
          : "",
        price:
          elm.confirm_total_price_gc &&
          elm.confirm_total_price_head &&
          `${elm.confirm_total_price_head}сом(${elm.confirm_total_price_gc}гиккоинов)`,
        description: (
          <OrderInfo items={elm.items} status={elm.status} id={elm.id} />
        ),
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <div className={"tableWidth"}>
        <TableAccordion
          accordion={true}
          columns={columns}
          dataSource={dataSource}
          rowExpandedColor="rgba(198, 198, 198, 0.12)"
        />
      </div>
      <div className={"pagination"}>
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default OrderList;

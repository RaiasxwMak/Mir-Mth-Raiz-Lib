import { useQuery } from "@tanstack/react-query";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import {
  ParamsType,
  TServerResponse,
  UserInfoType,
} from "shared/globalTypes/globalTypes";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export const useCuratorListQuery = () => {
  const { page, resetPage } = usePageChange();
  const { search } = useSearchInfo();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [search]);

  const limit = 12;
  const offset = (page - 1) * limit;
  const params: ParamsType = {
    offset,
    limit,
    search,
  };
  return useQuery<TServerResponse<UserInfoType>>({
    queryFn: async () => await fetchCuratorList(params),
    queryKey: ["curatorList", search, page],
  });
};

export const fetchCuratorList = async (params: ParamsType) => {
  const res = await requester.get("/api/v1/administrator/curator/", { params });
  return res.data;
};

import { useFetchProfile, useFetchProfileEdit } from "../model/useFetchProfile";
import {
  AsyncInput,
  CreateAvatar,
  Loader,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useState } from "react";

const ProfileInfo = () => {
  const { data, isLoading } = useFetchProfile();
  const { mutateAsync } = useFetchProfileEdit();
  const [image, setImage] = useState<File | null>(null);

  const infoCashier = [
    {
      label: "ФИО",
      value: data?.user.full_name ?? "",
      name: "full_name",
      disabled: true,
      isNotRequired: true,
    },
    {
      label: "Телеграм",
      value: data?.user.telegram ?? "",
      name: "telegram",
      disabled: false,
      isNotRequired: true,
    },
    {
      label: "Почта",
      value: data?.user.email ?? "",
      name: "email",
      disabled: false,
      isNotRequired: true,
    },
  ];

  const handleAsyncChange = async (param: File) => {
    return mutateAsync({ photo: param });
  };

  const setEditImage = (param: File | null) => {
    if (param) setImage(param);
  };

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={20}>
      <CreateAvatar
        asCb={handleAsyncChange}
        image={image}
        setImage={setEditImage}
        src={data?.user?.photo}
        avatarSize={140}
      />
      <UIFlexColumn gap={8} style={{ width: 400 }}>
        {infoCashier.map((item, index) => (
          <UIFlexColumn key={index} gap={4}>
            <Typography variant="Text2_bold">{item.label}</Typography>
            <AsyncInput
              disabled={item.disabled}
              value={item.value}
              name={item.name}
              asyncCallBack={(val) => handleChangeAsync(val, item.name)}
              fullWidth
              isNotRequired={item.isNotRequired}
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default ProfileInfo;

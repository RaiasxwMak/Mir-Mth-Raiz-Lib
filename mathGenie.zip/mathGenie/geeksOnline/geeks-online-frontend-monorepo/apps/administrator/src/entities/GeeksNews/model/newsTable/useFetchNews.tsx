import { useQuery } from "@tanstack/react-query";
import { INews } from "entities/GeeksNews/type/types";
import { requester } from "shared/configs/axios/axiosConfig";
import { TServerResponse } from "shared/globalTypes/globalTypes";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export const newsKey = "newsKey";

export const useFetchNews = () => {
  const { page } = usePageChange();

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    offset,
    limit,
  };

  return useQuery<TServerResponse<INews>>({
    queryFn: async () => {
      const res = await requester.get("/api/v1/main/news/", {
        params,
      });
      return res.data;
    },
    queryKey: [newsKey, page],
  });
};

import { useMutation } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { INewsParam } from "entities/GeeksNews/type/types";
import { useNavigate } from "react-router-dom";
import { requester } from "shared/configs/axios/axiosConfig";
import { useSelectDate } from "widgets/CalendarDate/model/useSelectDate";

export const useCreateNews = () => {
  const navigate = useNavigate();
  const successAlert = useOpenAlert();
  const { resetSelectDate } = useSelectDate();

  return useMutation({
    mutationFn: async (param: INewsParam) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        if (item[1]) {
          formdata.append(item[0], item[1]);
        }
      });
      try {
        const res = await requester.post("/api/v1/main/news/", formdata);
        return res;
      } catch {}
    },
    onSuccess: (res) => {
      if (res && res.status >= 200) {
        successAlert("Сохранено");
        navigate(-1);
        resetSelectDate();
      }
    },
  });
};

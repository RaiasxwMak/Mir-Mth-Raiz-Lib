import {
  AsyncInput,
  Button,
  CreateAvatar,
  Loader,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import {
  useFetchEditProduct,
  useFetchInfoProduct,
} from "entities/GeeksShopEssence/model/editProduct/useFetchEditProduct";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { useParams } from "react-router-dom";
import { useState } from "react";

const EditProduct = () => {
  const { id = "" } = useParams();
  const { image, setImage } = useCreateAvatar();
  const { data, isLoading } = useFetchInfoProduct(id);
  const { mutateAsync } = useFetchEditProduct(id);
  const [load, setLoad] = useState(false);
  const openAlert = useOpenAlert();

  const productInfo = [
    {
      name: "title",
      label: "Название товара",
      type: "text",
      value: data?.title ?? "",
      maxLength: 30,
      isNotRequired: false,
    },
    {
      name: "description",
      label: "Описание товара",
      type: "text",
      value: data?.description ?? "",
      maxLength: 200,
      isNotRequired: true,
    },
    {
      name: "price_head",
      label: "Цена в сомах",
      type: "number",
      value: data?.price_head ?? "",
      maxLength: 10,
      isNotRequired: false,
    },
    {
      name: "price_gc",
      label: "Цена в коинах",
      type: "number",
      value: data?.price_gc ?? "",
      maxLength: 10,
      isNotRequired: false,
    },
    {
      name: "quantity",
      label: "Количество товара",
      type: "number",
      value: data?.quantity ?? "",
      maxLength: 10,
      isNotRequired: false,
    },
  ];

  const handleChangeAsync = async (
    value: string | boolean,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  const handleChangeImage = async (param: File) =>
    mutateAsync({ image: param });

  const handleAsyncDelete = async () => {
    setLoad(true);
    await mutateAsync({ is_deleted: !data?.is_deleted });
    setLoad(false);
    openAlert("Сохранено");
  };

  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={12}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            {"Загрузить фото"} <span style={{ color: "red" }}>{"*"}</span>
          </Typography>
          <CreateAvatar
            isPhoto
            disable={data?.is_deleted}
            src={data?.image}
            image={image}
            setImage={setImage}
            asCb={handleChangeImage}
          />
        </UIFlexColumn>
        <Typography variant="Text4">
          {"Загружать в форматах jpg, jpeg, png, heic. webp"}
        </Typography>
      </UIFlexColumn>
      <UIFlexColumn gap={20} style={{ width: 400 }}>
        {productInfo.map((item, key) => (
          <UIFlexColumn gap={4} key={key}>
            <Typography variant="Text1">
              {item.label}{" "}
              {item.name !== "description" && (
                <span style={{ color: "red" }}>{"*"}</span>
              )}
            </Typography>
            <UIFlexColumn>
              <AsyncInput
                value={item.value}
                asyncCallBack={(val) => handleChangeAsync(val, item.name)}
                name={item.name}
                type={item.type}
                disabled={item.name === "price_gc" || data?.is_deleted}
                maxLength={item.maxLength}
                isNotRequired={item.isNotRequired}
                fullWidth
              />
              {item.name === "title" && (
                <div style={{ marginLeft: "auto", marginTop: 8 }}>
                  <span style={{ color: "#ABABAB" }}>Максимум 30 символов</span>
                </div>
              )}
              {item.name === "description" && (
                <div style={{ marginLeft: "auto", marginTop: 8 }}>
                  <span style={{ color: "#ABABAB" }}>
                    Максимум 200 символов
                  </span>
                </div>
              )}
            </UIFlexColumn>
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <Button
        isLoading={load}
        theme={ThemeButton.contained}
        width={400}
        onClick={handleAsyncDelete}
      >
        {data?.is_deleted ? "Восстановить" : "Удалить товар"}
      </Button>
    </UIFlexColumn>
  );
};

export default EditProduct;

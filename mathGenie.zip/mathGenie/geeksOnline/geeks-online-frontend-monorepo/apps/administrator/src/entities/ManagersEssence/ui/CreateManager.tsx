import {
  Button,
  CreateAvatar,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import {
  IInputs,
  useCreateInfos,
} from "features/CreateInfos/model/CreateInfos";
import { useEffect } from "react";
import { useCreateManager } from "../model/createmanager/useCreateManager";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";

export type TMangerInfo = {
  name: keyof IInputs;
  label: string;
  type: string;
  star?: string;
  placeholder?: string;
  helper?: string;
  mask?: string;
  value?: string;
  isNotRequired?: boolean;
};

const studentInfo: TMangerInfo[] = [
  {
    name: "full_name",
    label: "ФИО",
    star: "*",
    type: "text",
    placeholder: "ФИО",
  },
  {
    name: "username",
    label: "Логин",
    star: "*",
    type: "text",
    placeholder: "Логин",
  },
  {
    name: "password",
    label: "Пароль",
    star: "*",
    type: "text",
    placeholder: "Пароль",
  },
  {
    name: "password_confirm",
    label: "Подтвердите пароль",
    star: "*",
    type: "text",
    placeholder: "Подтвердите пароль",
  },
  {
    name: "phone",
    label: "Номер телефона",
    star: "*",
    type: "text",
    placeholder: "+996 999 99 - 99 - 99",
    mask: "+***************************************",
  },
  {
    name: "telegram",
    label: "Телеграм",
    type: "text",
    placeholder: "Телеграм",
  },
  {
    name: "email",
    label: "Почта",
    type: "text",
    placeholder: "Почта",
  },
];

const CreateManager = () => {
  const { mutateAsync, isPending } = useCreateManager();
  const { inputs, setInputs, clearAllInputs } = useCreateInfos();
  const openError = useOpenErrorAlert();

  const { image, setImage } = useCreateAvatar();

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    setInputs((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCreateCurator = async () => {
    const param = {
      ...inputs,
      photo: image,
    };
    if (
      !inputs.username &&
      !inputs.full_name &&
      !inputs.password &&
      !inputs.password_confirm &&
      !inputs.phone
    )
      return openError("Заполните все обязательные поля");
    if (
      !inputs.username ||
      !inputs.full_name ||
      !inputs.password ||
      !inputs.password_confirm ||
      !inputs.phone
    )
      return openError("Заполните все обязательные поля");
    if (inputs.password !== inputs.password_confirm)
      return openError("Пароли не совпадают");
    await mutateAsync(param);
  };

  useEffect(() => {
    return () => {
      clearAllInputs();
    };
  }, []);
  return (
    <UIFlexColumn gap={20}>
      <CreateAvatar image={image} setImage={setImage} avatarSize={140} />
      <UIFlexColumn gap={8} style={{ width: 400 }}>
        {studentInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <Input
              mask={item.mask}
              value={inputs[item.name]}
              type={item.type}
              name={item.name}
              onChange={inputsChange}
              id={item.name}
              placeholder={item.placeholder}
              fullWidth
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <Button
        theme={ThemeButton.contained}
        width={400}
        isLoading={isPending}
        onClick={handleCreateCurator}
      >
        Сохранить
      </Button>
    </UIFlexColumn>
  );
};

export default CreateManager;

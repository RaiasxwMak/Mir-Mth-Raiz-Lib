import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { useFetchProducts } from "entities/GeeksShopEssence/model/productsTable/useFetchProducts";
import { IProduct } from "entities/GeeksShopEssence/type/types";
import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { CustomPagination } from "shared/ui";

const ProductsTable = () => {
  const { data, isLoading } = useFetchProducts();
  const navigate = useNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Название",
      dataIndex: "title",
      render: (text: string, record: IProduct) => {
        return (
          <span
            className={"link"}
            onClick={() => navigate(`/administrator/geekshop/${record.id}/`)}
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Описание",
      dataIndex: "description",
    },
    {
      title: "Цена (сом)",
      dataIndex: "price_head",
    },
    {
      title: "Цена (GeekCoin)",
      dataIndex: "price_gc",
    },
    {
      title: "Кол-во товаров в магазине",
      dataIndex: "quantity",
      width: "170px",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
        is_deleted: elm.is_deleted ? (
          <div className="blockStatus">Товар удален</div>
        ) : (
          <></>
        ),
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordionList columns={columns} dataSource={dataSource} />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default ProductsTable;

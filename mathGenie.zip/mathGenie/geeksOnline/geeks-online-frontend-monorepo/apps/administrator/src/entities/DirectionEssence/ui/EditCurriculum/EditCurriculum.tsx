import {
  AsyncInput,
  Loader,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import {
  useFetchCurriculum,
  useFetchCurriculumEdit,
} from "entities/DirectionEssence/model/EditCurriculum/useFetchCurriculum";
import { ICurriculumType } from "entities/DirectionEssence/type/DirectionsTypes";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import cls from "./EditCurriculum.module.scss";
import TextAreaAsync from "shared/ui/TextAreaAsync/TextAreaAsync";

export const EditCurriculum = () => {
  const { id = "" } = useParams();
  const { data, isLoading } = useFetchCurriculum(id);
  const [curriculumData, setCurriculumData] = useState<ICurriculumType[]>([]);

  useEffect(() => {
    if (data) {
      setCurriculumData(data);
    }
  }, [data]);

  if (isLoading) {
    return <Loader height="360px" />;
  }

  return (
    <div className={cls.container}>
      {curriculumData.map((item) => (
        <CurriculumItem key={item.id} item={item} />
      ))}
    </div>
  );
};

interface CurriculumItemProps {
  item: ICurriculumType;
}

const CurriculumItem: React.FC<CurriculumItemProps> = ({ item }) => {
  const { mutateAsync } = useFetchCurriculumEdit(item.id);

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => {
    return mutateAsync({ [name]: value });
  };

  return (
    <div className={cls.curriculumCard}>
      <div className={cls.monthTitle}>{item.month} месяц</div>
      <UIFlexColumn gap={8}>
        <UIFlexColumn gap={4} width={400}>
          <Typography variant="Text1">Название</Typography>
          <AsyncInput
            value={item.title || ""}
            name="title"
            asyncCallBack={(val) => handleChangeAsync(val, "title")}
            id={item.id}
            placeholder={"Введите название"}
            fullWidth
          />
        </UIFlexColumn>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">Уроки</Typography>
          <TextAreaAsync
            notShow
            placeholder={"Введите учебный план"}
            height="115px"
            asyncCallBack={(val) => handleChangeAsync(val, "plan")}
            value={item.plan || ""}
          />
        </UIFlexColumn>
      </UIFlexColumn>
    </div>
  );
};

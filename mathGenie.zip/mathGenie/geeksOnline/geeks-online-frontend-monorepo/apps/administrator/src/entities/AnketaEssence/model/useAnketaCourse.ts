import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { requester } from "shared/configs/axios/axiosConfig";

export interface ICourseAnketaParam {
  title: string;
}

export interface ICourseAnketaResponse {
  id: string;
  title: string;
  filial: string;
  is_delete: boolean;
}

const anketaCoursesKey = "anketaCoursesKey";

export const useGetAnketaCourses = () => {
  return useQuery<ICourseAnketaResponse[]>({
    queryFn: async () => {
      const response = await requester.get(
        "/api/v1/administrator/application/course/"
      );
      return response.data;
    },
    queryKey: [anketaCoursesKey],
  });
};

export const useCreateAnketaCourse = () => {
  const successAlert = useOpenAlert();
  const queryCLient = useQueryClient();
  return useMutation({
    mutationFn: async (param: ICourseAnketaParam) => {
      const res = await requester.post(
        "/api/v1/administrator/application/course/",
        param
      );
      return res;
    },
    onSuccess: (res) => {
      if (res && res.status >= 200) {
        successAlert("Сохранено");
        queryCLient.invalidateQueries({ queryKey: [anketaCoursesKey] });
      }
    },
  });
};

export const useDeleteAnketaCourse = () => {
  const successAlert = useOpenAlert();
  const queryCLient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await requester.delete(
        `/api/v1/administrator/application/course/${id}/`
      );
      return res;
    },
    onSuccess: (res) => {
      if (res && res.status >= 200) {
        successAlert("Сохранено");
        queryCLient.invalidateQueries({ queryKey: [anketaCoursesKey] });
      }
    },
  });
};

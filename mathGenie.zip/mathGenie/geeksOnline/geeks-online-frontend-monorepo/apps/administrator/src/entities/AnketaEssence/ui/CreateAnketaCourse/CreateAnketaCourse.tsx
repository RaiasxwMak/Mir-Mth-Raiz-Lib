import {
  Button,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import { useCreateAnketaCourse } from "entities/AnketaEssence/model/useAnketaCourse";
import { useState } from "react";

const CreateAnketaCourse = () => {
  const [anketaCourse, setAnketaCourse] = useState("");
  const { mutateAsync, isPending } = useCreateAnketaCourse();

  const handleCreateAnketaCourse = async () => {
    if (anketaCourse) {
      setAnketaCourse("");
      await mutateAsync({ title: anketaCourse });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleCreateAnketaCourse();
  };

  return (
    <UIFlexRow gap={30} alignItems="end">
      <UIFlexColumn gap={4} width={400}>
        <Typography variant="Text2_bold">Выбранное направление</Typography>
        <Input
          value={anketaCourse}
          onChange={(e) => setAnketaCourse(e.target.value)}
          onKeyDown={handleKeyDown}
          fullWidth
          maxLength={70}
        />
      </UIFlexColumn>
      <div>
        <Button
          isLoading={isPending}
          theme={!anketaCourse ? ThemeButton.disabled : ThemeButton.contained}
          onClick={handleCreateAnketaCourse}
          width={210}
          disabled={!anketaCourse}
        >
          Сохранить
        </Button>
      </div>
    </UIFlexRow>
  );
};

export default CreateAnketaCourse;

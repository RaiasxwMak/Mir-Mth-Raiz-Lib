import {
  Button,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateGeekcoinsRequest } from "entities/GeekcoinEssence/model/CreateGeekcoins/useFetchCreateGeekcoins";
import { IGeekcoinType } from "entities/GeekcoinEssence/type/GeekcoinsListType";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useEffect, useState } from "react";

export type TGeekcoinInfo = {
  name: keyof IGeekcoinType;
  label: string;
  type: string;
  star?: string;
  placeholder?: string;
  helper?: string;
  mask?: string;
  value?: string;
};

export const CreateGeekcoins = () => {
  const openError = useOpenErrorAlert();
  const { mutateAsync, isPending } = useCreateGeekcoinsRequest();
  const { courseValueSelect, courseResetSelect } = useCoursesSelect();
  const [inputs, setInputs] = useState({
    month_number: "",
    nominal: "",
  });

  const geekcoinsInfo: TGeekcoinInfo[] = [
    {
      name: "month_number",
      label: "Номер месяца",
      star: "*",
      type: "text",
    },
    {
      name: "nominal",
      label: "Номинал",
      type: "text",
      star: "*",
    },
  ];

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const value = e.target.value;
    const regex = /^[0-9.]*$/;
    if (regex.test(value)) {
      setInputs((prev) => ({ ...prev, [e.target.name]: value }));
    }
  };

  const handleCreateGeekcoins = async () => {
    if (!courseValueSelect?.value) return openError("Заполните все обязательные поля");
    if (!inputs.month_number || !inputs.nominal)
      return openError("Заполните все обязательные поля");
    const data = {
      course: String(courseValueSelect.value),
      ...inputs,
    };
    await mutateAsync(data);
  };

  useEffect(() => {
    return () => {
      courseResetSelect();
    };
  }, []);
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={8}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            Направление <span style={{ color: "red" }}>*</span>
          </Typography>
          <CourseSelect width="400px" placeholder=" " />
        </UIFlexColumn>
        {geekcoinsInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <Input
              mask={item.mask}
              value={inputs[item.name as keyof typeof inputs]}
              type={item.type}
              name={item.name}
              onChange={inputsChange}
              id={item.name}
              placeholder={item.placeholder}
              style={{ width: 400 }}
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <Button
        theme={ThemeButton.contained}
        width={400}
        isLoading={isPending}
        onClick={handleCreateGeekcoins}
      >
        Сохранить
      </Button>
    </UIFlexColumn>
  );
};

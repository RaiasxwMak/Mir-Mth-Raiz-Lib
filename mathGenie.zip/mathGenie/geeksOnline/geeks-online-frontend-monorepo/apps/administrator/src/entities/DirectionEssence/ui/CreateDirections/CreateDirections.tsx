import {
  Button,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateDirectionRequest } from "entities/DirectionEssence/model/CreateDirections/useFetchCreateDirections";
import {
  IDirectionsListType,
  RoadmapItem,
} from "entities/DirectionEssence/type/DirectionsTypes";
import { useFetchProfile } from "entities/ProfileInfo/model/useFetchProfile";
import {
  getRoadmapProgressDistribution,
  RoadmapEditor,
  validateRoadmapData,
} from "features/RoadmapEditor/ui/RoadmapEditor";
import { useState } from "react";

export type TDirectionsInfo = {
  name: keyof IDirectionsListType;
  label: string;
  type: string;
  star?: string;
  placeholder?: string;
  helper?: string;
  mask?: string;
  value?: string;
  isNotRequired?: boolean;
};

export const CreateDirections = () => {
  const { data } = useFetchProfile();
  const openError = useOpenErrorAlert();
  const { mutateAsync, isPending } = useCreateDirectionRequest();
  const [isOnline] = useState(false);
  const [inputs, setInputs] = useState({
    title: "",
    months: "",
    lesson_per_week: "",
    monthly_amount: "",
  });
  const [roadmap, setRoadmap] = useState<RoadmapItem[]>([]);

  const directionsInfo: TDirectionsInfo[] = [
    {
      name: "title",
      label: "Название",
      star: "*",
      type: "text",
    },
    {
      name: "months",
      label: "Количество месяцев ",
      type: "text",
      star: "*",
    },
    {
      name: "lesson_per_week",
      label: "Количество уроков в неделю",
      type: "text",
      star: "*",
    },
    {
      name: "monthly_amount",
      label: "Сумма ежемесячного платежа",
      type: "text",
      star: "*",
    },
  ];

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const value = e.target.value;
    const name = e.target.name;
    const regex = /^[0-9.]*$/;
    if (name !== "title" && regex.test(value)) {
      setInputs((prev) => ({ ...prev, [e.target.name]: value }));
    }
    if (name === "title") {
      setInputs((prev) => ({ ...prev, [e.target.name]: value }));
    }
  };

  const handleCreateDirections = async () => {
    if (
      !inputs.title ||
      !inputs.lesson_per_week ||
      !inputs.monthly_amount ||
      !inputs.months
    )
      return openError("Заполните все обязательные поля");

    const roadmapValidation = validateRoadmapData(roadmap);
    if (!roadmapValidation.isValid) {
      return openError(roadmapValidation.errorMessage || "Ошибка в Roadmap");
    }
    const progress_distribution = getRoadmapProgressDistribution(roadmap);

    const param: IDirectionsListType = {
      filial: data?.user.filial_id,
      ...inputs,
      progress_distribution,
    };
    if (isOnline) {
      param.online = isOnline;
    }
    await mutateAsync(param);
  };

  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={8} style={{ width: 400 }}>
        {directionsInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <Input
              mask={item.mask}
              value={inputs[item.name as keyof typeof inputs]}
              type={item.type}
              name={item.name}
              onChange={inputsChange}
              id={item.name}
              placeholder={item.placeholder}
              fullWidth
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      {/* <CustomCheckbox
        value={String(isOnline)}
        onChange={() => setIsOnline((prev) => !prev)}
        checked={isOnline}
        label="Онлайн курс"
      /> */}
      {inputs.months && (
        <RoadmapEditor
          months={inputs.months}
          roadmap={roadmap}
          setRoadmap={setRoadmap}
        />
      )}
      <Button
        theme={ThemeButton.contained}
        width={400}
        isLoading={isPending}
        onClick={handleCreateDirections}
      >
        Сохранить
      </Button>
    </UIFlexColumn>
  );
};

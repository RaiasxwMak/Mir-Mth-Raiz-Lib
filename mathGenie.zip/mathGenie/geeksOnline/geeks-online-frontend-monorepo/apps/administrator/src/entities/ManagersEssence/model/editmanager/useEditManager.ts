import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { isAxiosError } from "axios";
import { requester } from "shared/configs/axios/axiosConfig";
import { IUserEdit, UserInfoType } from "shared/globalTypes/globalTypes";

export const queryKeyManagerDetail = "managerKeyInfo";

export const useFetchInfoManager = (id: string) => {
  return useQuery<UserInfoType>({
    queryFn: async () => {
      const { data } = await requester.get(
        `api/v1/administrator/manager/${id}/`
      );
      return data;
    },
    queryKey: [queryKeyManagerDetail],
  });
};

export const useFetchManagerEdit = (id: string) => {
  const query = useQueryClient();
  const openError = useOpenErrorAlert();
  return useMutation({
    mutationFn: async (param: IUserEdit) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        `api/v1/administrator/curator/${id}/update/`,
        formdata
      );
      return response.data;
    },
    onSuccess: (param) => {
      if (!param.is_deleted) {
        query.invalidateQueries({ queryKey: [queryKeyManagerDetail] });
      }
    },
    onError: (e) => {
      if (isAxiosError(e) && e.response?.data?.email) {
        openError(e.response?.data?.email[0]);
      }
    },
  });
};

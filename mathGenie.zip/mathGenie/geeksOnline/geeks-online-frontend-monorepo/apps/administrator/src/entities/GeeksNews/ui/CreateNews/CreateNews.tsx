import {
  Button,
  CreateAvatar,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";

import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateNews } from "entities/GeeksNews/model/createNews/useCreateNews";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { ChangeEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Textarea } from "shared/ui/Textarea/Textarea";

const initialState = {
  title: "",
  description: "",
};

type InfosState = typeof initialState;

const CreateNews = () => {
  const navigate = useNavigate();
  const { mutateAsync, isPending } = useCreateNews();
  const { image, setImage } = useCreateAvatar();
  const [infos, setInfos] = useState<InfosState>(initialState);
  const openError = useOpenErrorAlert();

  const inputsChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    const { value, name } = e.target;
    setInfos((prev) => ({ ...prev, [name]: value }));
  };

  const handleCreate = async () => {
    if (!infos.title || !infos.description || !image)
      return openError("Заполните все обязательные поля");
    await mutateAsync({
      ...infos,
      image,
    });
  };

  const handleCancel = () => {
    setInfos(initialState);
    navigate(-1);
  };

  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={12}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            {"Загрузить фото"} <span style={{ color: "red" }}>{"*"}</span>
          </Typography>
          <CreateAvatar
            isPhoto
            image={image}
            setImage={setImage}
            avatarSize={400}
          />
        </UIFlexColumn>
        <Typography variant="Text4">
          {"Загружать в форматах jpg, jpeg, png, webp"}
        </Typography>
      </UIFlexColumn>
      <UIFlexColumn gap={20} style={{ width: 400 }}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            Заголовок <span style={{ color: "red" }}>*</span>
          </Typography>
          <Textarea
            height="80px"
            name="title"
            value={infos.title}
            onChange={inputsChange}
            maxLength={255}
          />
        </UIFlexColumn>
        <UIFlexColumn gap={4} style={{ width: 770 }}>
          <Typography variant="Text1">
            Описание<span style={{ color: "red" }}>*</span>
          </Typography>
          <Textarea
            height="150px"
            name="description"
            value={infos.description}
            onChange={inputsChange}
            notShow
          />
        </UIFlexColumn>
      </UIFlexColumn>
      <UIFlexColumn gap={20}>
        <Button
          isLoading={isPending}
          onClick={handleCreate}
          theme={ThemeButton.contained}
          width={400}
        >
          Сохранить
        </Button>
        <Button onClick={handleCancel} theme={ThemeButton.bordered} width={400}>
          Отмена
        </Button>
      </UIFlexColumn>
    </UIFlexColumn>
  );
};

export default CreateNews;

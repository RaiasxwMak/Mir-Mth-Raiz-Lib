import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import dayjs from "dayjs";
import { useFetchNews } from "entities/GeeksNews/model/newsTable/useFetchNews";
import { IProduct } from "entities/GeeksShopEssence/type/types";
import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { CustomPagination } from "shared/ui";

const NewsTable = () => {
  const { data, isLoading } = useFetchNews();
  const navigate = useNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "Дата",
      dataIndex: "created_at",
      width: "160px",
      render: (text: string, record: IProduct) => {
        const formattedDate = text ? dayjs(text).format("DD.MM.YYYY") : "";
        return (
          <span
            className={"link"}
            onClick={() => navigate(`/administrator/news/${record.id}/`)}
          >
            {formattedDate}
          </span>
        );
      },
    },
    {
      title: "Заголовок",
      dataIndex: "title",
      width: "240px",
      render: (text: string, record: IProduct) => {
        return (
          <span
            className={"link"}
            style={{
              display: "inline-block",
              width: 240,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
            title={text}
            onClick={() => navigate(`/administrator/news/${record.id}/`)}
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Описание",
      dataIndex: "description",
      render: (text: string, record: IProduct) => {
        return (
          <span
            className={"link"}
            style={{
              display: "inline-block",
              width: 1140,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
            title={text}
            onClick={() => navigate(`/administrator/news/${record.id}/`)}
          >
            {text}
          </span>
        );
      },
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <>
      <TableAccordionList columns={columns} dataSource={dataSource} />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </>
  );
};

export default NewsTable;

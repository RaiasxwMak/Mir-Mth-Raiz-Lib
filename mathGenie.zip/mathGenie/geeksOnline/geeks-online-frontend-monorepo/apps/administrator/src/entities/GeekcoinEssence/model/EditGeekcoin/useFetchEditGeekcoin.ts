import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  IGeekcoinListType,
  IGeekcoinType,
} from "entities/GeekcoinEssence/type/GeekcoinsListType";
import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS = {
  GEEKCOIN: (id: string) => `/api/v1/administrator/course/nominal/${id}/`,
  GEEKCOIN_EDIT: (id: string) =>
    `/api/v1/administrator/course/nominal/${id}/update/`,
};

export const queryKeyGeekcoinDetail = "geekcoinKeyInfo";

export const useFetchInfoGeekcoin = (id: string) => {
  return useQuery<IGeekcoinListType>({
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.GEEKCOIN(id));
      return data;
    },
    queryKey: [queryKeyGeekcoinDetail],
  });
};

export const useFetchGeekcoinEdit = (id: string) => {
  const query = useQueryClient();
  return useMutation({
    mutationFn: async (param: IGeekcoinType) => {
      const formdata = new FormData();
      Object.entries(param).forEach((item) => {
        formdata.append(item[0], item[1]);
      });
      const response = await requester.patch(
        ENDPOINTS.GEEKCOIN_EDIT(id),
        formdata
      );
      return response.data;
    },
    onSuccess: (param) => {
      if (!param.is_deleted) {
        query.invalidateQueries({ queryKey: [queryKeyGeekcoinDetail] });
      }
    },
  });
};

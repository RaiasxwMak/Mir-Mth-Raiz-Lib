import {
  Button,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
  UIFlexRow,
} from "@geeks-online/uikit";
import {
  useFetchRate,
  useFetchSendRate,
} from "entities/GeeksShopEssence/model/createRate/useFetchRate";
import { ChangeEvent, useEffect, useState } from "react";

const ProductWell = () => {
  const { data } = useFetchRate();
  const { mutateAsync, isPending } = useFetchSendRate();
  const [som, setSom] = useState("");

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    let inputValue = e.target.value;

    if (inputValue.includes(".")) {
      const parts = inputValue.split(".");
      if (parts.length > 1 && parts[1].length > 2) {
        return;
      }
    }

    inputValue = inputValue.replace(/[^0-9.]/g, "");

    if (inputValue !== "") {
      setSom(inputValue);
    } else {
      setSom("");
    }
  };

  useEffect(() => {
    if (data) {
      setSom(data?.rate);
    }
  }, [data]);
  return (
    <UIFlexColumn gap={16}>
      <Typography variant="Body2">Курс</Typography>
      <UIFlexRow gap={20}>
        <UIFlexRow gap={20}>
          <Typography variant="Text1">GeekCoin</Typography>
          <Input value="1" disabled style={{ width: "140px" }} />
        </UIFlexRow>
        <UIFlexRow gap={20}>
          <Typography variant="Text1">Сом</Typography>
          <Input
            value={som}
            onChange={handleChange}
            style={{ width: "140px" }}
          />
        </UIFlexRow>
        <Button
          isLoading={isPending}
          width={140}
          theme={som ? ThemeButton.contained : ThemeButton.disabled}
          onClick={async () => await mutateAsync({ rate: som })}
        >
          Сохранить
        </Button>
      </UIFlexRow>
    </UIFlexColumn>
  );
};

export default ProductWell;

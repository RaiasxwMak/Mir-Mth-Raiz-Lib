import { useQuery } from "@tanstack/react-query";
import { IGeekcoinListType } from "entities/GeekcoinEssence/type/GeekcoinsListType";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { ParamsType, TServerResponse } from "shared/globalTypes/globalTypes";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export const useGeekcoinsListQuery = () => {
  const { page, resetPage } = usePageChange();
  const { courseValueSelect } = useCoursesSelect();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [courseValueSelect?.value]);

  const limit = 12;
  const offset = (page - 1) * limit;
  const params: ParamsType = {
    offset,
    limit,
    course_id: courseValueSelect ? String(courseValueSelect?.value) : "",
  };
  return useQuery<TServerResponse<IGeekcoinListType>>({
    queryFn: async () => await fetchGeekcoinsList(params),
    queryKey: ["geekcoinsList", courseValueSelect?.value, page],
  });
};

export const fetchGeekcoinsList = async (params: ParamsType) => {
  const res = await requester.get("/api/v1/administrator/course/nominal/", {
    params,
  });
  return res.data;
};

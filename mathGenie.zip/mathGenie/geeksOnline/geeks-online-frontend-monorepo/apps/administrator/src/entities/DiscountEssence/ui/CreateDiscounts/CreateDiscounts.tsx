import {
  Button,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateDiscountsRequest } from "entities/DiscountEssence/model/CreateDiscounts/useFetchCreateDiscounts";
import { IDiscountsType } from "entities/DiscountEssence/type/DiscountsType";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import { useEffect, useState } from "react";

export type TDiscountsInfo = {
  name: keyof IDiscountsType;
  label: string;
  type: string;
  star?: string;
  placeholder?: string;
  helper?: string;
  mask?: string;
  value?: string;
};

export const CreateDiscounts = () => {
  const openError = useOpenErrorAlert();
  const { mutateAsync, isPending } = useCreateDiscountsRequest();
  const { courseValueSelect, courseResetSelect } = useCoursesSelect();
  const [inputs, setInputs] = useState({
    amount: "",
    max_hw_point: "",
    min_hw_point: "",
    max_test_point: "",
    min_test_point: "",
    min_attandance_count: "",
  });

  const discountsInfo: TDiscountsInfo[] = [
    {
      name: "amount",
      label: "Сумма скидки",
      star: "*",
      type: "text",
    },
    {
      name: "max_hw_point",
      label: "Максимальное количество баллов за ДЗ",
      type: "text",
      star: "*",
    },
    {
      name: "min_hw_point",
      label: "Минимальное количество баллов за ДЗ",
      type: "text",
      star: "*",
    },
    {
      name: "max_test_point",
      label: "Максимальное количество баллов за тесты",
      type: "text",
      star: "*",
    },
    {
      name: "min_test_point",
      label: "Минимальное количество баллов за тесты",
      type: "text",
      star: "*",
    },
    {
      name: "min_attandance_count",
      label: "Минимальное количество посещений",
      type: "text",
      star: "*",
    },
  ];

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const value = e.target.value;
    const regex = /^[0-9.]*$/;
    if (regex.test(value)) {
      setInputs((prev) => ({ ...prev, [e.target.name]: value }));
    }
  };

  const handleCreateDirections = async () => {
    if (!courseValueSelect?.value) return openError("Заполните все обязательные поля");
    if (
      !inputs.amount ||
      !inputs.max_hw_point ||
      !inputs.max_test_point ||
      !inputs.min_attandance_count ||
      !inputs.min_hw_point ||
      !inputs.min_test_point
    )
      return openError("Заполните все обязательные поля");
    const data = {
      course: String(courseValueSelect.value),
      ...inputs,
    };
    await mutateAsync(data);
  };

  useEffect(() => {
    return () => {
      courseResetSelect();
    };
  }, []);
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={28}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            Направление <span style={{ color: "red" }}>*</span>
          </Typography>
          <CourseSelect width="400px" placeholder=" " />
        </UIFlexColumn>
        {discountsInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <Input
              mask={item.mask}
              value={inputs[item.name as keyof typeof inputs]}
              type={item.type}
              name={item.name}
              onChange={inputsChange}
              id={item.name}
              placeholder={item.placeholder}
              style={{ width: 400 }}
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <Button
        theme={ThemeButton.contained}
        width={400}
        isLoading={isPending}
        onClick={handleCreateDirections}
      >
        Сохранить
      </Button>
    </UIFlexColumn>
  );
};

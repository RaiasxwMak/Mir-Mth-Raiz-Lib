import { ChartDataset } from "chart.js";
import { ILineChart } from "shared/globalTypes/globalTypes";

export interface ChartDataByTab {
  labels: string[];
  datasets: ExtendedChartDataset[];
  cacheKey?: string;
}

export interface useStatisticsChartType {
  dataLoading: boolean;
  statisticsChartData: ILineCharts | null;
  chartDataByTab: Record<string, ChartDataByTab | null>;
  originalChartDataByTab: Record<string, ChartDataByTab | null>;
  currentCountBy: string;
  getStatistics: (params: ILineChartsParams, tab: string) => Promise<void>;
  handleFilter: (param: string, tab: string) => void;
  getChartDataForTab: (tab: string) => ChartDataByTab | null;
  clearTabData: (tab: string) => void;
  forceReloadTab: (tab: string) => void;
}

export interface ILineCharts {
  total: number | null;
  labels: string[];
  datasets: ILineChart[];
}

export const COUNT_BY = {
  ACTIVE: "active_count",
  ARCHIVE: "archive_count",
  GRADUATED: "graduated_count",
  MENTOR: "mentor_count",
} as const;

export type CountBy = (typeof COUNT_BY)[keyof typeof COUNT_BY];

export interface ILineChartsParams {
  start_date: string;
  end_date: string;
  count_by: CountBy;
}

export interface ExtendedChartDataset extends ChartDataset<"line", number[]> {
  value?: number[];
  originalValue?: number[];
}

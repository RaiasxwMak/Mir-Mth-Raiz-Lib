import {
  useDeleteAnketaCourse,
  useGetAnketaCourses,
} from "entities/AnketaEssence/model/useAnketaCourse";
import Remove from "shared/assets/icon/deleteAnketa.svg?react";
import cls from "./AnketaCourses.module.scss";

const AnketaCourses = () => {
  const { data } = useGetAnketaCourses();
  const { mutateAsync } = useDeleteAnketaCourse();

  const handleDelete = async (id: string) => {
    await mutateAsync(id);
  };

  if (!data?.length) return;
  return (
    <div className={cls.cards}>
      {data?.map((item) => (
        <div key={item.id} className={cls.card}>
          <span>{item.title}</span>
          <Remove onClick={() => handleDelete(item.id)} />
        </div>
      ))}
    </div>
  );
};

export default AnketaCourses;

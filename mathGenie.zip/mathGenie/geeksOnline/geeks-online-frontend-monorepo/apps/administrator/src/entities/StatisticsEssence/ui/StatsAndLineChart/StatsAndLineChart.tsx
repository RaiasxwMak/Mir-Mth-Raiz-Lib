import { IOption } from "@geeks-online/uikit";
import dayjs from "dayjs";
import { useStats } from "entities/StatisticsEssence/model/useStats";
import {
  COUNT_BY,
  CountBy,
} from "entities/StatisticsEssence/type/statisticsChartsType";
import {
  IParamStats,
  StatsEndPoint,
} from "entities/StatisticsEssence/type/statsType";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { FC, useCallback, useEffect, useMemo, useState, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import { useSelectDate } from "widgets/CalendarDate/model/useSelectDate";
import { DateRange } from "widgets/DateRangePicker/model/useDateRangePicker";
import Statistics from "widgets/Statistics/ui/Statistics";
import StatisticsLineChart from "widgets/StatisticsLineChart/StatisticsLineChart";

interface IProps {
  title: string;
  type: StatsEndPoint;
  tab: string;
  courseSelect?: boolean;
  isPeriodDate?: boolean;
}

const urlLineChart: Record<StatsEndPoint, CountBy> = {
  "active-statistics": COUNT_BY.ACTIVE,
  "not-active-statistics": COUNT_BY.ARCHIVE,
  "graduate-statistics": COUNT_BY.GRADUATED,
  "mentors-statistics": COUNT_BY.MENTOR,
  "mentors-earned-statistics": COUNT_BY.MENTOR,
};

const StatsAndLineChart: FC<IProps> = ({
  type,
  tab,
  title,
  courseSelect,
  isPeriodDate,
}) => {
  const { dataLoading, getStats, handleFilterStats, getStatsForTab } =
    useStats();

  const { getCourseValueSelect } = useCoursesSelect();
  const courseValueSelect = getCourseValueSelect(tab);
  const { getSelectDateForTab } = useSelectDate();
  const [tabParam] = useSearchParams();

  const selectDate = getSelectDateForTab(tab);

  const [periodValue, setPeriodValue] = useState<DateRange>([null, null]);
  const [selectPeriod, setSelectPeriod] = useState<IOption | null>(null);

  const activeTab = useMemo(() => tabParam.get("tab"), [tabParam]);

  const { statsData, stats } = getStatsForTab(tab);

  const lastRequestParams = useRef<string>("");
  const isComponentMounted = useRef(false);

  const buildStatsParams = useCallback((): IParamStats => {
    const base: IParamStats = { url: type };

    if (!isPeriodDate) {
      base.date = selectDate?.format("YYYY-MM-DD");
    }
    if (courseSelect) {
      base.course_id = courseValueSelect ? String(courseValueSelect.value) : "";
    }
    if (isPeriodDate) {
      base.start_date =
        periodValue[0]?.format("YYYY-MM-DD") ??
        dayjs().subtract(30, "day").format("YYYY-MM-DD");

      base.end_date =
        periodValue[1]?.format("YYYY-MM-DD") ?? dayjs().format("YYYY-MM-DD");
    }

    return base;
  }, [
    type,
    isPeriodDate,
    selectDate,
    courseSelect,
    courseValueSelect,
    periodValue,
  ]);

  const createRequestKey = useCallback(
    (params: IParamStats) => {
      return `${params.url}_${params.date || ""}_${params.course_id || ""}_${
        params.start_date || ""
      }_${params.end_date || ""}_${tab}`;
    },
    [tab]
  );

  useEffect(() => {
    const isActiveTab = activeTab === tab;

    if (!isComponentMounted.current) {
      isComponentMounted.current = true;
    }

    if (!isActiveTab) {
      return;
    }

    const params = buildStatsParams();
    const requestKey = createRequestKey(params);

    if (lastRequestParams.current === requestKey) {
      return;
    }

    lastRequestParams.current = requestKey;
    getStats(params, tab);
  }, [activeTab, tab, buildStatsParams, getStats, createRequestKey]);

  useEffect(() => {
    if (selectPeriod) {
      const months = Number(selectPeriod.value);
      setPeriodValue([dayjs().subtract(months, "month"), dayjs()]);
    }
  }, [selectPeriod]);

  useEffect(() => {
    return () => {
      isComponentMounted.current = false;
      lastRequestParams.current = "";
    };
  }, []);

  const handleFilterStatsWithTab = useCallback(
    (param: string) => {
      handleFilterStats(param, tab);
    },
    [handleFilterStats, tab]
  );

  return (
    <>
      <Statistics
        title={title}
        count={statsData?.total_count ?? 0}
        loader={dataLoading}
        handleFilter={handleFilterStatsWithTab}
        stats={stats}
        courseSelect={courseSelect}
        isPeriodDate={isPeriodDate}
        periodValue={periodValue}
        setPeriodValue={(param) => {
          setSelectPeriod(null);
          setPeriodValue(param);
        }}
        selectPeriod={selectPeriod}
        setSelectPeriod={setSelectPeriod}
        tab={tab}
      />
      <StatisticsLineChart tab={tab} countBy={urlLineChart[type]} />
    </>
  );
};

export default StatsAndLineChart;

import {
  AsyncInput,
  IOption,
  Loader,
  SelectAsync,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useParams } from "react-router-dom";
import SendToArchive from "features/SendToArchive/ui/SendToArchive/SendToArchive";
import { useEffect, useMemo, useState } from "react";
import { useFetchDirections } from "features/CourseSelect/model/useFetchCourses";
import { TGeekcoinInfo } from "../CreateGeekcoins/CreateGeekcoins";
import {
  useFetchGeekcoinEdit,
  useFetchInfoGeekcoin,
} from "entities/GeekcoinEssence/model/EditGeekcoin/useFetchEditGeekcoin";

const EditGeekcoin = () => {
  const { id = "" } = useParams();
  const { data, isLoading } = useFetchInfoGeekcoin(id);
  const { data: direction } = useFetchDirections();
  const { mutateAsync, isPending } = useFetchGeekcoinEdit(id);
  const [selectCourse, setSelectCourse] = useState<IOption | null>(null);

  const geekcoinInfo: TGeekcoinInfo[] = [
    {
      name: "month_number",
      label: "Номер месяца",
      star: "*",
      type: "text",
      value: data?.month_number ?? "",
    },
    {
      name: "nominal",
      label: "Номинал",
      type: "text",
      star: "*",
      value: data?.nominal ?? "",
    },
  ];

  const directionsOption = useMemo(() => {
    return (
      direction?.map((i) => ({
        value: i.id,
        label: i.title,
      })) ?? []
    );
  }, [direction]);

  const handleChangeAsync = async (
    value: string,
    name: string
  ): Promise<unknown> => mutateAsync({ [name]: value });

  useEffect(() => {
    if (data?.course) {
      setSelectCourse({ label: data.course.title, value: data.course.id });
    }
  }, [data?.course]);
  if (isLoading) return <Loader />;
  return (
    <UIFlexColumn gap={20}>
      <UIFlexColumn gap={4}>
        <Typography variant="Text1">
          Направление <span style={{ color: "red" }}>*</span>
        </Typography>
        <SelectAsync
          width={"400px"}
          height="40px"
          placeholder={"Направление"}
          valueData={selectCourse}
          asyncSelect={(val) => handleChangeAsync(String(val?.value), "course")}
          onChange={(param: IOption | null) => setSelectCourse(param)}
          options={directionsOption}
        />
      </UIFlexColumn>
      <UIFlexColumn gap={8}>
        {geekcoinInfo.map((item, index) => (
          <UIFlexColumn gap={4} key={index}>
            <Typography variant="Text1">
              {item.label} <span style={{ color: "red" }}>{item.star}</span>
            </Typography>
            <AsyncInput
              mask={item?.mask}
              value={String(item.value)}
              asyncCallBack={(val) => handleChangeAsync(val, item.name)}
              type={item.type}
              name={item.name}
              style={{ width: 400 }}
            />
          </UIFlexColumn>
        ))}
      </UIFlexColumn>
      <SendToArchive
        title={"Архивировать гиккоин"}
        mutateAsync={() => handleChangeAsync("True", "is_deleted")}
        isLoading={isPending}
      />
    </UIFlexColumn>
  );
};

export default EditGeekcoin;

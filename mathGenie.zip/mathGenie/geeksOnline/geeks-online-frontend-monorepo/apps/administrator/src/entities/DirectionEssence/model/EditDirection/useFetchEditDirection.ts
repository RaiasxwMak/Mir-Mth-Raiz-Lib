import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { IDirectionType } from "entities/DirectionEssence/type/DirectionsTypes";
import { requester } from "shared/configs/axios/axiosConfig";

const ENDPOINTS = {
  COURSE: (id: string) => `/api/v1/administrator/course/${id}/`,
};

export const queryKeyDirectionDetail = "directionKeyInfo";

export const useFetchInfoDirection = (id: string) => {
  return useQuery<IDirectionType>({
    queryFn: async () => {
      const { data } = await requester.get(ENDPOINTS.COURSE(id));
      return data;
    },
    queryKey: [queryKeyDirectionDetail],
  });
};

export const useFetchDirectionEdit = (id: string) => {
  const query = useQueryClient();
  return useMutation({
    mutationFn: async (param: IDirectionType) => {
      const formdata = new FormData();
      Object.entries(param).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (key === "progress_distribution" && Array.isArray(value)) {
            formdata.append(key, JSON.stringify(value));
          } else {
            formdata.append(key, String(value));
          }
        }
      });
      const response = await requester.patch(ENDPOINTS.COURSE(id), formdata);
      return response.data;
    },
    onSuccess: (param) => {
      if (!param.is_deleted) {
        query.invalidateQueries({ queryKey: [queryKeyDirectionDetail] });
      }
    },
  });
};

export interface IOrder {
  id: string;
  full_name: string;
  status: string;
  confirm_total_price_head: string;
  confirm_total_price_gc: string;
  order_date: string;
  items: IOrderItem[];
}

export interface IOrderItem {
  id: string;
  title: string;
  quantity: number;
  confirm_quantity: number;
  description: string | null;
}

export interface IOrderParam {
  confirm_quantity?: number;
  status?: string;
  id: string;
}

import { IOption } from "@geeks-online/uikit";

export interface IDirectionsListType {
  id?: string;
  title: string;
  months: number | string;
  lesson_per_week: number | string;
  monthly_amount: number | string;
  filial?: string;
  is_deleted?: boolean;
  online?: boolean;
  progress_distribution: IProgressItem[];
}

export interface IDirectionType {
  id?: string;
  title?: string;
  months?: number | string;
  lesson_per_week?: number | string;
  monthly_amount?: number | string;
  filial?: string;
  is_deleted?: boolean;
  online?: boolean;
  progress_distribution?: IProgressItem[];
}

export interface ICurriculumType {
  id: string;
  month: number;
  title: string | null;
  plan: string | null;
}

export interface ICurriculumEditType {
  title?: string | null;
  plan?: string | null;
}

export type TaskDifficulty = "hard" | "medium" | "easy" | "veryHard";

export interface IProgressItem {
  percentage: number;
  status: TaskDifficulty;
  month: number;
}

export interface RoadmapItem {
  month: number;
  percentage: string;
  status: TaskDifficulty;
  complexityOption: IOption | null;
}

import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";
import {
  ITransitionsList,
  ITransitionsListParam,
} from "../type/transitionsType";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";
import { useMonthsSelect } from "features/MonthsSelect/model/useMonthsSelect";
import { useYearsSelect } from "features/YearsSelect/model/useYearsSelect";
import { useSearchGroupsSelect } from "features/SearchGroupsSelect/model/useSearchGroupsSelect";

export const useTransitionsListQuery = () => {
  const { page, resetPage } = usePageChange();
  const { courseValueSelectByTab } = useCoursesSelect();
  const { monthsSelect } = useMonthsSelect();
  const { yearsSelect } = useYearsSelect();
  const { groupsSelect } = useSearchGroupsSelect();
  const currentCourseValue = courseValueSelectByTab?.transitions?.value ?? "";

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [
    currentCourseValue,
    monthsSelect?.value,
    yearsSelect?.value,
    groupsSelect?.value,
  ]);

  const limit = 12;
  const offset = (page - 1) * limit;
  const params = {
    offset,
    limit,
    course_id: currentCourseValue,
    month: monthsSelect?.value ?? "",
    year: yearsSelect?.value ?? "",
    group_id: groupsSelect?.value ?? "",
  };

  return useQuery<ITransitionsList>({
    queryFn: async () => await fetchTransitionsList(params),
    queryKey: [
      "transitionsList",
      page,
      currentCourseValue,
      monthsSelect?.value,
      yearsSelect?.value,
      groupsSelect?.value,
    ],
  });
};

export const fetchTransitionsList = async (params: ITransitionsListParam) => {
  const res = await requester.get(
    "/api/v1/administrator/course/module-statistics/",
    { params }
  );
  return res.data;
};

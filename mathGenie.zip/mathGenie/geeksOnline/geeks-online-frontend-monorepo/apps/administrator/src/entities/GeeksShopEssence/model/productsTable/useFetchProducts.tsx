import { useQuery } from "@tanstack/react-query";
import { IProduct } from "entities/GeeksShopEssence/type/types";
import { useActivateSelect } from "features/ActivateSelect/model/useActivateSelect";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { TServerResponse } from "shared/globalTypes/globalTypes";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export const productsKey = "productsKey";

export const useFetchProducts = () => {
  const { page, resetPage } = usePageChange();
  const { search } = useSearchInfo();
  const { activateSelect } = useActivateSelect();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [search, activateSelect?.value]);

  const limit = 12;
  const offset = (page - 1) * limit;

  const params = {
    offset,
    limit,
    q: search,
    is_deleted: activateSelect ? activateSelect.value : "",
  };

  return useQuery<TServerResponse<IProduct>>({
    queryFn: async () => {
      const res = await requester.get("/api/v1/manager/products/list/", {
        params,
      });
      return res.data;
    },
    queryKey: [productsKey, search, page, activateSelect?.value],
  });
};

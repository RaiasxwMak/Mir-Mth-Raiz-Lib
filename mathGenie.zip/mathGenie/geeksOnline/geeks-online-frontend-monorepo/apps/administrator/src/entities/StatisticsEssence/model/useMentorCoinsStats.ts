import { create } from "zustand";
import { requester } from "shared/configs/axios/axiosConfig";
import { AxiosResponse } from "axios";
import { generateColor } from "shared/lib/helper/helper";
import { IStatsData } from "../type/statsType";

const mapCoursesToStats = (courses: IStatsData["courses"], indexOffset = 0) => {
  return courses
    .filter((item) => Number(item.count) > 0)
    .map((item, index) => ({
      type: item.course ?? item.title,
      value: Number(item.count),
      originalValue: Number(item.count),
      color: item.color ?? generateColor(index + indexOffset),
      id: item.id,
    }));
};

interface MentorCoinsStatsParams {
  start_date?: string;
  end_date?: string;
  date?: string;
}

interface useMentorCoinsStatsType {
  dataLoading: boolean;
  statsData: IStatsData | null;
  stats: any[] | null;
  getStats: (params: MentorCoinsStatsParams) => Promise<void>;
  handleFilterStats: (param: string) => void;
}

export const useMentorCoinsStats = create<useMentorCoinsStatsType>(
  (set, get) => ({
    dataLoading: false,
    statsData: null,
    stats: null,

    getStats: async ({
      date,
      start_date,
      end_date,
    }: MentorCoinsStatsParams) => {
      try {
        set({ dataLoading: true });

        const params: Record<string, string> = {};

        if (start_date && end_date) {
          params.start_date = start_date;
          params.end_date = end_date;
        } else if (date) {
          params.date = date;
        }

        const response: AxiosResponse<IStatsData> = await requester.get(
          `api/v1/administrator/course/mentors-earned-statistics/`,
          { params }
        );

        set({
          dataLoading: false,
          statsData: response.data,
          stats: mapCoursesToStats(response.data.courses),
        });
      } catch (error) {
        console.error("Error fetching mentor coins stats:", error);
        set({
          dataLoading: false,
          statsData: null,
          stats: [],
        });
      }
    },

    handleFilterStats: (param) => {
      const { stats } = get();

      if (!stats) return;

      if (param === "reset") {
        const resetStats = stats.map((item) => ({ ...item, value: undefined }));
        set({ stats: resetStats });
        return;
      }

      if (param === "show") {
        const showStats = stats.map((item) => ({
          ...item,
          value: item.originalValue,
        }));
        set({ stats: showStats });
        return;
      }

      const updatedData = stats.map((item) =>
        item.type === param
          ? {
              ...item,
              value: item.value === undefined ? item.originalValue : undefined,
            }
          : item
      );

      set({ stats: updatedData });
    },
  })
);

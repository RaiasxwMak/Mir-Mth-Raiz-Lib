import {
  EmptyState,
  Loader,
  rowClass,
  TableAccordionList,
} from "@geeks-online/uikit";
import { useMemo } from "react";
import { useManagersListQuery } from "../model/managersList/useManagersList";
import { useNavigate } from "react-router-dom";
import { CustomPagination } from "shared/ui";
import { UserInfoType } from "shared/globalTypes/globalTypes";

const ManagersTable = () => {
  const { data, isLoading } = useManagersListQuery();
  const navigate = useNavigate();

  const columns = [
    {
      title: "№",
      dataIndex: "index",
      width: "60px",
    },
    {
      title: "ФИО",
      dataIndex: "full_name",
      width: "30%",
      render: (text: string, record: UserInfoType) => {
        return (
          <span
            className={"link"}
            onClick={() =>
              navigate(`/administrator/manager/${record.id}/${record.user.id}`)
            }
          >
            {text}
          </span>
        );
      },
    },
    {
      title: "Логин",
      dataIndex: "login",
    },
    {
      title: "Номер телефона",
      dataIndex: "phone",
      width: "250px",
    },
  ];

  const dataSource = useMemo(() => {
    return data?.results.map((elm, index: number) => {
      const even = (index + 1) % 2 === 0;
      return {
        ...elm,
        key: index + 1,
        index: index + 1,
        className: even ? rowClass : "",
        expand: false,
        full_name: elm.user.full_name,
        login: elm.user.username,
        phone: elm.user.phone,
      };
    });
  }, [data]);

  if (isLoading) return <Loader height="572px" />;
  if (!data?.results?.length)
    return <EmptyState text={"Здесь пока ничего нет"} />;
  return (
    <div>
      <TableAccordionList columns={columns} dataSource={dataSource} />
      <div className="pagination">
        {data && data.count > 12 && <CustomPagination count={data.count} />}
      </div>
    </div>
  );
};

export default ManagersTable;

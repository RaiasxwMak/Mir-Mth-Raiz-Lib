import { UIFlexColumn, UIFlexRow } from "@geeks-online/uikit";
import CourseSelect from "features/CourseSelect/ui/CourseSelect";
import MonthsSelect from "features/MonthsSelect/ui/MonthsSelect";
import YearsSelect from "features/YearsSelect/ui/YearsSelect";
import SearchGroupsSelect from "features/SearchGroupsSelect/ui/SearchGroupsSelect";
import TransitionsTable from "../TransitionsTable/TransitionsTable";
import { useYearsSelect } from "features/YearsSelect/model/useYearsSelect";
import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useMonthsSelect } from "features/MonthsSelect/model/useMonthsSelect";
import dayjs from "dayjs";
import { useCoursesSelect } from "features/CourseSelect/model/useCourseSelect";

const months: Record<string, string> = {
  "Month 1": "Январь",
  "Month 2": "Февраль",
  "Month 3": "Март",
  "Month 4": "Апрель",
  "Month 5": "Май",
  "Month 6": "Июнь",
  "Month 7": "Июль",
  "Month 8": "Август",
  "Month 9": "Сентябрь",
  "Month 10": "Октябрь",
  "Month 11": "Ноябрь",
  "Month 12": "Декабрь",
};

const Transitions = () => {
  const [tabParam, _] = useSearchParams();
  const { yearsChangeSelect } = useYearsSelect();
  const { onChangeMonthsSelects } = useMonthsSelect();

  const currentDate = dayjs();

  const { courseValueSelectByTab } = useCoursesSelect();

  useEffect(() => {
    yearsChangeSelect({
      label: String(currentDate.year()),
      value: String(currentDate.year()),
    });
    onChangeMonthsSelects({
      label: months[`Month ${currentDate.month() + 1}`],
      value: String(currentDate.month() + 1),
    });
  }, [tabParam]);
  return (
    <UIFlexColumn gap={24}>
      <UIFlexRow gap={12} alignItems="center">
        <CourseSelect tab={"transitions"} />
        <SearchGroupsSelect
          course_id={courseValueSelectByTab?.transitions?.value?.toString()}
        />
        <YearsSelect />
        <MonthsSelect />
      </UIFlexRow>
      <TransitionsTable />
    </UIFlexColumn>
  );
};

export default Transitions;

export interface IProduct {
  id: string;
  title: string;
  description: string;
  image: string;
  price_head: string;
  price_gc: string;
  is_deleted: boolean;
  quantity: string;
}

export interface IProductParam {
  title?: string;
  image?: File | null;
  price_head?: string;
  price_gc?: string;
  is_deleted?: boolean;
}

export interface IRate {
  rate: string;
}

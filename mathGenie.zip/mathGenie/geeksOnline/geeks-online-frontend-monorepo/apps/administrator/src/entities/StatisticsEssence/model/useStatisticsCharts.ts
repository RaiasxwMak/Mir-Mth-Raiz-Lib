import { create } from "zustand";
import { requester } from "shared/configs/axios/axiosConfig";
import { AxiosResponse } from "axios";
import {
  ExtendedChartDataset,
  ILineCharts,
  ILineChartsParams,
  useStatisticsChartType,
} from "../type/statisticsChartsType";
import dayjs from "dayjs";
import { generateColor } from "shared/lib/helper/helper";

export const useStatisticsCharts = create<useStatisticsChartType>(
  (set, get) => ({
    dataLoading: false,
    statisticsChartData: null,
    chartDataByTab: {},
    originalChartDataByTab: {},
    currentCountBy: "active_count",

    getStatistics: async (params: ILineChartsParams, tab: string) => {
      try {
        set({ dataLoading: true });
        const state = get();
        const existingData = state.chartDataByTab[tab];
        const cacheKey = `${params.start_date}_${params.end_date}_${params.count_by}`;
        if (
          existingData &&
          (existingData as any).cacheKey === cacheKey &&
          existingData.datasets &&
          existingData.datasets.length > 0 &&
          existingData.labels &&
          existingData.labels.length > 0
        ) {
          set({ dataLoading: false });
          return;
        }

        const response: AxiosResponse<ILineCharts> = await requester.get(
          "api/v1/administrator/course/statistics/chart/",
          { params }
        );

        const formattedLabels = response.data.labels.map((date) =>
          dayjs(date).format("DD.MM.YY")
        );

        const datasetsForChart: ExtendedChartDataset[] =
          response.data.datasets.map((dataset, index) => {
            const values = dataset.statistics.map((stat) => stat.count);

            return {
              type: "line",
              label: dataset.title,
              originalValue: values,
              value: values,
              data: values,
              borderColor: dataset.color ?? generateColor(index),
              backgroundColor: dataset.color ?? generateColor(index),
              tension: 0.1,
              pointRadius: 2,
            };
          });

        const chartDataForTab = {
          labels: formattedLabels,
          datasets: datasetsForChart,
          cacheKey,
        };

        set((state) => ({
          dataLoading: false,
          statisticsChartData: response.data,
          chartDataByTab: {
            ...state.chartDataByTab,
            [tab]: chartDataForTab,
          },
          originalChartDataByTab: {
            ...state.originalChartDataByTab,
            [tab]: chartDataForTab,
          },
        }));
      } catch (error) {
        console.error("Error loading statistics:", error);
        set({
          dataLoading: false,
          statisticsChartData: null,
        });
      } finally {
        set({ dataLoading: false });
      }
    },

    handleFilter: (param: string, tab: string) => {
      const state = get();
      const current = state.chartDataByTab[tab];
      const original = state.originalChartDataByTab[tab];

      if (!current || !original) return;

      const updateChartDataForTab = (datasets: ExtendedChartDataset[]) => {
        set((state) => ({
          chartDataByTab: {
            ...state.chartDataByTab,
            [tab]: {
              ...current,
              datasets,
            },
          },
        }));
      };

      const currentDatasets = current.datasets as ExtendedChartDataset[];
      const originalDatasets = original.datasets as ExtendedChartDataset[];

      if (param === "reset") {
        updateChartDataForTab(
          original.datasets.map((item) => ({ ...item, data: [] }))
        );
        return;
      }

      if (param === "show") {
        updateChartDataForTab(originalDatasets);
        return;
      }

      const target = currentDatasets.find((d) => d.label === param);
      const isHidden = !target?.data?.length;

      if (!isHidden) {
        updateChartDataForTab(
          currentDatasets.map((item) =>
            item.label === param ? { ...item, data: [] } : item
          )
        );
      } else {
        const restore = originalDatasets.find((item) => item.label === param);
        if (!restore) return;
        updateChartDataForTab(
          currentDatasets.map((item) =>
            item.label === param
              ? { ...item, data: restore.originalValue ?? [] }
              : item
          )
        );
      }
    },

    getChartDataForTab: (tab: string) => {
      return get().chartDataByTab[tab] || null;
    },

    clearTabData: (tab: string) => {
      set((state) => {
        const newChartDataByTab = { ...state.chartDataByTab };
        const newOriginalChartDataByTab = { ...state.originalChartDataByTab };
        delete newChartDataByTab[tab];
        delete newOriginalChartDataByTab[tab];

        return {
          chartDataByTab: newChartDataByTab,
          originalChartDataByTab: newOriginalChartDataByTab,
        };
      });
    },

    forceReloadTab: (tab: string) => {
      set((state) => {
        const newChartDataByTab = { ...state.chartDataByTab };
        const newOriginalChartDataByTab = { ...state.originalChartDataByTab };
        delete newChartDataByTab[tab];
        delete newOriginalChartDataByTab[tab];

        return {
          chartDataByTab: newChartDataByTab,
          originalChartDataByTab: newOriginalChartDataByTab,
        };
      });
    },
  })
);

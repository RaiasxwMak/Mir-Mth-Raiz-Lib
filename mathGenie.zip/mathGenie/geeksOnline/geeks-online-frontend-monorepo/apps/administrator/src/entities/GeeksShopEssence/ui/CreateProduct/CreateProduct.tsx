import {
  Button,
  CreateAvatar,
  Input,
  ThemeButton,
  Typography,
  UIFlexColumn,
} from "@geeks-online/uikit";
import { useOpenErrorAlert } from "app/providers/AlertProvider/selectors/useOpenAlert";
import { useCreateProduct } from "entities/GeeksShopEssence/model/createProduct/useCreateProduct";
import { useCreateAvatar } from "features/CreateAvatarInfo/model/CreateAvatarInfo";
import { useState } from "react";

const CreateProduct = () => {
  const { mutateAsync, isPending } = useCreateProduct();
  const { image, setImage } = useCreateAvatar();
  const [infos, setInfos] = useState({
    price_head: "",
    title: "",
    description: "",
    quantity: "",
  });
  const openError = useOpenErrorAlert();

  const inputsChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { value, name } = e.target;
    if (name === "price_head" || name === "quantity") {
      let inputValue = value;
      if (inputValue.includes(".")) {
        const parts = inputValue.split(".");
        if (parts.length > 1 && parts[1].length > 2) {
          return;
        }
      }

      inputValue = inputValue.replace(/[^0-9.]/g, "");

      if (inputValue !== "") {
        setInfos((prev) => ({ ...prev, [name]: inputValue }));
      } else {
        setInfos((prev) => ({ ...prev, [name]: "" }));
      }
    } else {
      setInfos((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleCreate = async () => {
    if (!infos.price_head || !infos.title || !infos.quantity || !image)
      return openError("Заполните все обязательные поля");

    await mutateAsync({
      ...infos,
      image,
    });
  };

  return (
    <UIFlexColumn gap={40}>
      <UIFlexColumn gap={12}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            {"Загрузить фото"} <span style={{ color: "red" }}>{"*"}</span>
          </Typography>
          <CreateAvatar
            isPhoto
            image={image}
            setImage={setImage}
            avatarSize={140}
          />
        </UIFlexColumn>
        <Typography variant="Text4">
          {"Загружать в форматах jpg, jpeg, png, webp"}
        </Typography>
      </UIFlexColumn>
      <UIFlexColumn gap={20} style={{ width: 400 }}>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            {"Название товара"} <span style={{ color: "red" }}>{"*"}</span>
          </Typography>
          <UIFlexColumn>
            <Input
              value={infos.title}
              name={"title"}
              placeholder={"Название товара"}
              onChange={inputsChange}
              maxLength={30}
              fullWidth
            />
            <div style={{ marginLeft: "auto", marginTop: 8 }}>
              <span style={{ color: "#ABABAB" }}>{infos.title.length}/30</span>
            </div>
          </UIFlexColumn>
        </UIFlexColumn>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">{"Описание товара"}</Typography>
          <UIFlexColumn>
            <Input
              value={infos.description}
              name={"description"}
              placeholder={"Описание товара"}
              onChange={inputsChange}
              maxLength={200}
              fullWidth
            />
            <div style={{ marginLeft: "auto", marginTop: 8 }}>
              <span style={{ color: "#ABABAB" }}>
                {infos.description.length}/200
              </span>
            </div>
          </UIFlexColumn>
        </UIFlexColumn>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            {"Цена в сомах"} <span style={{ color: "red" }}>{"*"}</span>
          </Typography>
          <Input
            value={infos.price_head}
            name={"price_head"}
            placeholder={"Цена в сомах"}
            onChange={inputsChange}
            maxLength={10}
            fullWidth
          />
        </UIFlexColumn>
        <UIFlexColumn gap={4}>
          <Typography variant="Text1">
            {"Количество товара"} <span style={{ color: "red" }}>{"*"}</span>
          </Typography>
          <Input
            value={infos.quantity}
            name={"quantity"}
            placeholder={"Количество товара"}
            onChange={inputsChange}
            maxLength={10}
            fullWidth
          />
        </UIFlexColumn>
      </UIFlexColumn>
      <Button
        isLoading={isPending}
        onClick={handleCreate}
        theme={ThemeButton.contained}
        width={400}
      >
        {"Добавить"}
      </Button>
    </UIFlexColumn>
  );
};

export default CreateProduct;

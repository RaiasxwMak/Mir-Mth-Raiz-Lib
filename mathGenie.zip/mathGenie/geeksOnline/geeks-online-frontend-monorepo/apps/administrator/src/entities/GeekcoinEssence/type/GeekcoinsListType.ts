export interface IGeekcoinListType {
  id: string;
  nominal: string;
  course: {
    id: string;
    title: string;
  };
  month_number: string;
  is_deleted: boolean;
}

export interface IGeekcoinType {
  id?: string;
  nominal?: string;
  course?: string;
  month_number?: string;
  is_deleted?: boolean;
}

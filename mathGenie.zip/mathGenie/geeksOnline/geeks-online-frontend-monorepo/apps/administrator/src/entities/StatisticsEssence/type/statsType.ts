export interface IStatsData {
  total_count: number;
  courses: Array<{
    id: number;
    course?: string;
    title?: string;
    count: number;
    color?: string;
    type?: string;
  }>;
}

export interface IParamStats {
  url: StatsEndPoint;
  date?: string;
  course_id?: string;
  start_date?: string;
  end_date?: string;
}

export type StatsEndPoint =
  | "active-statistics"
  | "not-active-statistics"
  | "graduate-statistics"
  | "mentors-statistics"
  | "mentors-earned-statistics";

export interface IStats {
  type: string;
  value: number | undefined;
  originalValue: number;
  color: string;
  id: number;
}

export interface StatsDataByTab {
  statsData: IStatsData | null;
  stats: IStats[] | null;
  originalStats: IStats[] | null;
}

export interface useStatsType {
  dataLoading: boolean;
  statsByTab: Record<string, StatsDataByTab>;
  getStats: (params: IParamStats, tab: string) => Promise<void>;
  handleFilterStats: (param: string, tab: string) => void;
  getStatsForTab: (tab: string) => StatsDataByTab;
  clearTabData: (tab: string) => void;
}

export interface useStatsTypeLegacy {
  dataLoading: boolean;
  statsData: IStatsData | null;
  stats: IStats[] | null;
  getStats: (params: IParamStats) => Promise<void>;
  handleFilterStats: (param: string) => void;
}

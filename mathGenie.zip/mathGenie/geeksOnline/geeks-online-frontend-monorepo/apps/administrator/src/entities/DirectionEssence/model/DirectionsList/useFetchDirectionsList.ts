import { useQuery } from "@tanstack/react-query";
import { IDirectionsListType } from "entities/DirectionEssence/type/DirectionsTypes";
import { useSearchInfo } from "features/SearchInfo/model/useSearchInfo";
import { useEffect } from "react";
import { requester } from "shared/configs/axios/axiosConfig";
import { ParamsType, TServerResponse } from "shared/globalTypes/globalTypes";
import { usePageChange } from "shared/ui/CustomPagination/CustomPagination";

export const useDirectionsListQuery = () => {
  const { page, resetPage } = usePageChange();
  const { search } = useSearchInfo();

  useEffect(() => {
    if (page !== 1) resetPage();
  }, [search]);

  const limit = 12;
  const offset = (page - 1) * limit;
  const params: ParamsType = {
    offset,
    limit,
    search,
  };
  return useQuery<TServerResponse<IDirectionsListType>>({
    queryFn: async () => await fetchDirectionsList(params),
    queryKey: ["directionsList", search, page],
  });
};

export const fetchDirectionsList = async (params: ParamsType) => {
  const res = await requester.get("/api/v1/administrator/course/", { params });
  return res.data;
};

export interface IDiscountsListType {
  id: string;
  course: {
    id: string;
    title: string;
  };
  amount: string;
  max_hw_point: string;
  min_hw_point: string;
  max_test_point: string;
  min_test_point: string;
  min_attandance_count: string;
  is_deleted: boolean;
}

export interface IDiscountsType {
  id?: string;
  course?: string;
  amount?: string;
  max_hw_point?: string;
  min_hw_point?: string;
  max_test_point?: string;
  min_test_point?: string;
  min_attandance_count?: string;
  is_deleted?: boolean;
}

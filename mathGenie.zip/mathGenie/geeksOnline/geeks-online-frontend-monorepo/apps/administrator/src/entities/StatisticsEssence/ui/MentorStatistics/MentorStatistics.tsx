import { useMentorCoinsStats } from "entities/StatisticsEssence/model/useMentorCoinsStats";
import StatsAndLineChart from "../StatsAndLineChart/StatsAndLineChart";
import { FC, useCallback, useEffect, useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import Statistics from "widgets/Statistics/ui/Statistics";
import dayjs from "dayjs";
import { DateRange } from "widgets/DateRangePicker/model/useDateRangePicker";
import { IOption } from "@geeks-online/uikit";

interface IProps {
  isPeriodDate?: boolean;
  tab?: string;
}

const MentorStatistics: FC<IProps> = ({ isPeriodDate = true, tab = "5" }) => {
  const { stats, dataLoading, statsData, getStats, handleFilterStats } =
    useMentorCoinsStats();

  const [periodValue, setPeriodValue] = useState<DateRange>([null, null]);
  const [selectPeriod, setSelectPeriod] = useState<IOption | null>(null);
  const [tabParam] = useSearchParams();

  const activeTab = useMemo(() => tabParam.get("tab"), [tabParam]);

  const buildStatsParams = useCallback(() => {
    return {
      start_date:
        periodValue[0]?.format("YYYY-MM-DD") ??
        dayjs().subtract(30, "day").format("YYYY-MM-DD"),
      end_date:
        periodValue[1]?.format("YYYY-MM-DD") ?? dayjs().format("YYYY-MM-DD"),
    };
  }, [periodValue]);

  useEffect(() => {
    const isActiveTab = activeTab === tab;

    if (!isActiveTab) {
      return;
    }

    const params = buildStatsParams();
    getStats(params);
  }, [buildStatsParams, getStats]);

  useEffect(() => {
    if (selectPeriod) {
      const months = Number(selectPeriod.value);
      setPeriodValue([dayjs().subtract(months, "month"), dayjs()]);
    }
  }, [selectPeriod]);

  useEffect(() => {
    if (activeTab === tab) {
      if (!periodValue[0] && !periodValue[1]) {
        setPeriodValue([dayjs().subtract(30, "day"), dayjs()]);
      }
    }
  }, [activeTab, tab, periodValue]);

  return (
    <div>
      <StatsAndLineChart
        title="Количество менторов: "
        tab={"5"}
        type="mentors-statistics"
      />
      <Statistics
        title={"Общий заработок: "}
        count={statsData?.total_count ?? 0}
        loader={dataLoading}
        handleFilter={handleFilterStats}
        stats={stats}
        isPeriodDate={isPeriodDate}
        periodValue={periodValue}
        setPeriodValue={(param) => {
          setSelectPeriod(null);
          setPeriodValue(param);
        }}
        selectPeriod={selectPeriod}
        setSelectPeriod={setSelectPeriod}
        tab={`${tab}-earnings`}
      />
    </div>
  );
};

export default MentorStatistics;

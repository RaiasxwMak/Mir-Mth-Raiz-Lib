# INSTALL  
FROM node:18-alpine as build
LABEL org.opencontainers.image.authors="Aalyev Nursultan <nusi.aalyev@gmail.com>"

RUN apk add --no-cache git

# Create app directory 
RUN mkdir -p /usr/src/app
WORKDIR /usr/src/app

# Bundle app source  
COPY . .
#TimeZone
ENV TZ=Asia/Bishkek

RUN ln -snf /usr/share/zoneinfo/$TZ /etc/localtime && echo $TZ > /etc/timezone  

# Install app dependencies
RUN npm install && \
    npm run build-shared && \
    npm run build-uikit && \
    npm run build-cashier

# #start node
FROM nginx:alpine as runtime
COPY --from=build /usr/src/app/apps/cashier/dist/ /usr/share/nginx/html
COPY nginx/cashier.conf /etc/nginx/conf.d/default.conf

CMD ["nginx", "-g", "daemon off;"]
